
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/InitScene/Init');
require('./assets/LevelScene/Script/LevelCamera');
require('./assets/LevelScene/Script/LevelManager');
require('./assets/LevelScene/Script/MyLevelManager');
require('./assets/LevelUI/LevelInfoUI/LevelInfoUI');
require('./assets/LevelUI/LoseUI/LoseUI');
require('./assets/LevelUI/PauseLevelUI/PauseLevelUI');
require('./assets/LevelUI/ResurgenceUI/ResurgenceUI');
require('./assets/LevelUI/WinUI/WinAnim');
require('./assets/LevelUI/WinUI/WinUI');
require('./assets/LobbyUI/ChooseLevelUI/ChooseLevelUI');
require('./assets/LobbyUI/ConfigSettingUI/ConfigSettingUI');
require('./assets/LobbyUI/ShopUI/ShopItem');
require('./assets/LobbyUI/ShopUI/ShopStage');
require('./assets/LobbyUI/ShopUI/ShopUI');
require('./assets/MainScene/Script/GameDirector');
require('./assets/MainScene/Script/GameLobby');
require('./assets/MainScene/Script/LevelController');
require('./assets/MainScene/Script/LoadingUI');
require('./assets/MainScene/Script/PlayerAssetBar');
require('./assets/MainScene/Script/TipMessage');
require('./assets/Recommend/Script/RecommendBanner');
require('./assets/Recommend/Script/RecommendDrawer');
require('./assets/Recommend/Script/RecommendItem');
require('./assets/Recommend/Script/RecommendMatrix');
require('./assets/Recommend/Script/RecommendPrimary');
require('./assets/Script/ALD/ALDManager');
require('./assets/Script/Common/Action3dManager');
require('./assets/Script/Common/AudioManager');
require('./assets/Script/Common/CommonEnum');
require('./assets/Script/Common/CommonEventType');
require('./assets/Script/Common/CommonGameConfig');
require('./assets/Script/Common/CryptoAes');
require('./assets/Script/Common/CryptoJS');
require('./assets/Script/Common/EventManager');
require('./assets/Script/Common/GameData');
require('./assets/Script/Common/GlobalPool');
require('./assets/Script/Common/Loader');
require('./assets/Script/Common/PlayerData');
require('./assets/Script/Common/PowerManager');
require('./assets/Script/Common/UIManager');
require('./assets/Script/Common/http_request');
require('./assets/Script/Common/yyComponent');
require('./assets/Script/GameSpecial/GameConfig');
require('./assets/Script/GameSpecial/GameEventType');
require('./assets/Script/GameSpecial/GlobalEnum');
require('./assets/Script/GameSpecial/LevelDataTemplate');
require('./assets/Script/GameSpecial/PlayerDataTemplate');
require('./assets/Script/GameSpecial/SkinDataTemplate');
require('./assets/Script/Platform/GamePlatform');
require('./assets/Script/Platform/GamePlatformConfig');
require('./assets/Script/Platform/GamePlatformType');
require('./assets/Script/Platform/SDK/OPPOSDK');
require('./assets/Script/Platform/SDK/PCSDK');
require('./assets/Script/Platform/SDK/QQSDK');
require('./assets/Script/Platform/SDK/SDK');
require('./assets/Script/Platform/SDK/TTSDK');
require('./assets/Script/Platform/SDK/VIVOSDK');
require('./assets/Script/Platform/SDK/WXSDK');
require('./assets/Script/Recommend/MyAtlas');
require('./assets/Script/Recommend/MyAtlasSprite');
require('./assets/Script/Recommend/Recommend');
require('./assets/Script/Recommend/RecommendConfig');
require('./assets/Script/Recommend/RecommendContainer');
require('./assets/Script/Recommend/RecommendDataManager');
require('./assets/Script/Recommend/RecommendImageManager');
require('./assets/Script/Recommend/RecommendManager');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();