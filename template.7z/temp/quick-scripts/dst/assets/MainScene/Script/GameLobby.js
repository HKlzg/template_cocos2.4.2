
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/MainScene/Script/GameLobby.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '69ef72xiQlAL4AzHd4vX34+', 'GameLobby');
// MainScene/Script/GameLobby.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameLobby = /** @class */ (function (_super) {
    __extends(GameLobby, _super);
    function GameLobby() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._uiType = GlobalEnum_1.GlobalEnum.UI.lobby;
        /**当前关卡 */
        _this.curLevel = null;
        return _this;
    }
    Object.defineProperty(GameLobby.prototype, "uiType", {
        /**场景/UI类型 */
        get: function () { return this._uiType; },
        enumerable: false,
        configurable: true
    });
    GameLobby.prototype.init = function () {
        this.updateCurLevel();
        this.onEvents();
    };
    GameLobby.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, this.onPlayerDataChanged, this);
    };
    GameLobby.prototype.reset = function () {
    };
    GameLobby.prototype.show = function () {
        this.node.active = true;
        this.emit(GameEventType_1.EventType.AudioEvent.playBGM, GlobalEnum_1.GlobalEnum.AudioClip.BGM, true);
    };
    GameLobby.prototype.hide = function () {
        this.node.active = false;
    };
    GameLobby.prototype.onPlayerDataChanged = function (data) {
        if (data.attribute == "gameData.curLevel") {
            this.curLevel.string = data.value.toString();
        }
    };
    GameLobby.prototype.updateCurLevel = function () {
        var lv = PlayerData_1.default.getData("gameData.curLevel");
        this.curLevel.string = lv.toString();
    };
    GameLobby.prototype.onBtnStartGame = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.DirectorEvent.startGame);
    };
    GameLobby.prototype.onBtnShop = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.UIEvent.enter, GlobalEnum_1.GlobalEnum.UI.shop);
    };
    __decorate([
        property(cc.Label)
    ], GameLobby.prototype, "curLevel", void 0);
    GameLobby = __decorate([
        ccclass
    ], GameLobby);
    return GameLobby;
}(yyComponent_1.default));
exports.default = GameLobby;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTWFpblNjZW5lXFxTY3JpcHRcXEdhbWVMb2JieS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrREFBMEQ7QUFDMUQsa0VBQWlFO0FBQ2pFLHdFQUFtRTtBQUNuRSw2REFBd0Q7QUFFbEQsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBdUMsNkJBQVc7SUFBbEQ7UUFBQSxxRUErQ0M7UUE1Q2EsYUFBTyxHQUFHLHVCQUFVLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUV4QyxVQUFVO1FBRUEsY0FBUSxHQUFhLElBQUksQ0FBQzs7SUF3Q3hDLENBQUM7SUE3Q0csc0JBQVcsNkJBQU07UUFEakIsYUFBYTthQUNiLGNBQXNCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBT3JDLHdCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFDUyw0QkFBUSxHQUFsQjtRQUNJLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3pGLENBQUM7SUFDTSx5QkFBSyxHQUFaO0lBQ0EsQ0FBQztJQUVNLHdCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsdUJBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFDTSx3QkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFFUyx1Q0FBbUIsR0FBN0IsVUFBOEIsSUFBSTtRQUM5QixJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksbUJBQW1CLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNoRDtJQUNMLENBQUM7SUFDUyxrQ0FBYyxHQUF4QjtRQUNJLElBQUksRUFBRSxHQUFHLG9CQUFVLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3pDLENBQUM7SUFFUyxrQ0FBYyxHQUF4QjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRVMsNkJBQVMsR0FBbkI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLHVCQUFVLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNELENBQUM7SUF0Q0Q7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQzsrQ0FDaUI7SUFQbkIsU0FBUztRQUQ3QixPQUFPO09BQ2EsU0FBUyxDQStDN0I7SUFBRCxnQkFBQztDQS9DRCxBQStDQyxDQS9Dc0MscUJBQVcsR0ErQ2pEO2tCQS9Db0IsU0FBUyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB5eUNvbXBvbmVudCBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi95eUNvbXBvbmVudFwiO1xuaW1wb3J0IHsgR2xvYmFsRW51bSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2xvYmFsRW51bVwiO1xuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XG5pbXBvcnQgUGxheWVyRGF0YSBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9QbGF5ZXJEYXRhXCI7XG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHYW1lTG9iYnkgZXh0ZW5kcyB5eUNvbXBvbmVudCB7XG4gICAgLyoq5Zy65pmvL1VJ57G75Z6LICovXG4gICAgcHVibGljIGdldCB1aVR5cGUoKSB7IHJldHVybiB0aGlzLl91aVR5cGU7IH1cbiAgICBwcm90ZWN0ZWQgX3VpVHlwZSA9IEdsb2JhbEVudW0uVUkubG9iYnk7XG5cbiAgICAvKirlvZPliY3lhbPljaEgKi9cbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgcHJvdGVjdGVkIGN1ckxldmVsOiBjYy5MYWJlbCA9IG51bGw7XG5cbiAgICBwdWJsaWMgaW5pdCgpIHtcbiAgICAgICAgdGhpcy51cGRhdGVDdXJMZXZlbCgpO1xuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBvbkV2ZW50cygpIHtcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuUGxheWVyRGF0YUV2ZW50LnBsYXllckRhdGFDaGFuZ2VkLCB0aGlzLm9uUGxheWVyRGF0YUNoYW5nZWQsIHRoaXMpO1xuICAgIH1cbiAgICBwdWJsaWMgcmVzZXQoKSB7XG4gICAgfVxuXG4gICAgcHVibGljIHNob3coKSB7XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUJHTSwgR2xvYmFsRW51bS5BdWRpb0NsaXAuQkdNLCB0cnVlKTtcbiAgICB9XG4gICAgcHVibGljIGhpZGUoKSB7XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgb25QbGF5ZXJEYXRhQ2hhbmdlZChkYXRhKSB7XG4gICAgICAgIGlmIChkYXRhLmF0dHJpYnV0ZSA9PSBcImdhbWVEYXRhLmN1ckxldmVsXCIpIHtcbiAgICAgICAgICAgIHRoaXMuY3VyTGV2ZWwuc3RyaW5nID0gZGF0YS52YWx1ZS50b1N0cmluZygpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByb3RlY3RlZCB1cGRhdGVDdXJMZXZlbCgpIHtcbiAgICAgICAgbGV0IGx2ID0gUGxheWVyRGF0YS5nZXREYXRhKFwiZ2FtZURhdGEuY3VyTGV2ZWxcIik7XG4gICAgICAgIHRoaXMuY3VyTGV2ZWwuc3RyaW5nID0gbHYudG9TdHJpbmcoKTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgb25CdG5TdGFydEdhbWUoKSB7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQXVkaW9FdmVudC5wbGF5Q2xpY2tCdG4pO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQuc3RhcnRHYW1lKTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgb25CdG5TaG9wKCkge1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmVudGVyLCBHbG9iYWxFbnVtLlVJLnNob3ApO1xuICAgIH1cblxufVxuIl19