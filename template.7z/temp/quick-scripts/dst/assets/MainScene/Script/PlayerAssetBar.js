
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/MainScene/Script/PlayerAssetBar.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '08b7fQRKfNDVZa5QgqRT/Gw', 'PlayerAssetBar');
// MainScene/Script/PlayerAssetBar.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
//玩家的金币体力等资产信息条
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var PlayerAssetBar = /** @class */ (function (_super) {
    __extends(PlayerAssetBar, _super);
    function PlayerAssetBar() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //#region 金币信息
        _this.goldLabel = null;
        //#endregion
        //#region 金币动画
        _this.goldLayer = null;
        _this.goldIconPrefab = null;
        return _this;
        //#endregion
        //#region 体力信息
        //#endregion
        //#region 体力动画
        //#endregion
    }
    PlayerAssetBar.prototype.init = function () {
        this.initComponents();
        this.initGoldIcon();
        this.onEvents();
        this.setData();
    };
    PlayerAssetBar.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, this.onPlayerDataChanged, this);
        this.on(GameEventType_1.EventType.UIEvent.playGoldAnim, this.playGoldAnim, this);
    };
    PlayerAssetBar.prototype.reset = function () {
        this.resetGoldIcon();
    };
    PlayerAssetBar.prototype.show = function () {
        this.node.active = true;
        this.setData();
        this.onEvents();
    };
    PlayerAssetBar.prototype.hide = function () {
        this.offEvents();
        this.node.active = false;
    };
    PlayerAssetBar.prototype.setData = function () {
        var data = PlayerData_1.default.getData("gameData.asset");
        this.setGold(data.gold);
    };
    PlayerAssetBar.prototype.convertToString = function (v) {
        if (v < 1100)
            return v.toString();
        if (v < 1000000)
            return (v * 0.001).toFixed(1) + "K";
        return (v * 0.000001).toFixed(1) + "M";
    };
    PlayerAssetBar.prototype.onPlayerDataChanged = function (data) {
        switch (data.attribute) {
            case "gameData.asset.gold": {
                this.setGold(data.value);
                break;
            }
        }
    };
    PlayerAssetBar.prototype.setGold = function (gold) {
        this.goldLabel.string = this.convertToString(gold);
    };
    PlayerAssetBar.prototype.initGoldIcon = function () {
        var p = this.goldLabel.node.convertToWorldSpaceAR(cc.v2(0, 0));
        p = this.node.convertToNodeSpaceAR(p);
        this.targetPos = cc.v3(p.x, p.y, 0);
        this.cb = null;
        GlobalPool_1.default.createPool(GlobalEnum_1.GlobalEnum.LevelPrefab.goldIcon, this.goldIconPrefab);
    };
    PlayerAssetBar.prototype.resetGoldIcon = function () {
        this.cb = null;
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI);
        for (var i = this.goldLayer.childrenCount - 1; i >= 0; --i) {
            actMng.stopAllActions(this.goldLayer.children[i]);
        }
        GlobalPool_1.default.putAllChildren(this.goldLayer, true);
    };
    PlayerAssetBar.prototype.playGoldAnim = function (data) {
        this.resetGoldIcon();
        this.emit(GameEventType_1.EventType.UIEvent.showTouchMask);
        this.cb = data.cb;
        var center = cc.v2();
        if (!!data.startPos) {
            center.set(data.startPos);
        }
        var duration = 0.2;
        var count = Math.round(Math.random() * 10) + 20;
        var scope = 250;
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI);
        for (var i = 0; i < count; i++) {
            var item = GlobalPool_1.default.get(GlobalEnum_1.GlobalEnum.LevelPrefab.goldIcon);
            this.goldLayer.addChild(item);
            item.setPosition(center);
            item.setScale(1, 1);
            var move = Action3dManager_1.default.moveTo(duration, (Math.random() - 0.5) * scope, (Math.random() - 0.5) * scope, 0);
            move.easing(Action3dManager_1.default.easeOut(2));
            actMng.runAction(item, move);
        }
        this.scheduleOnce(this.toTarget, duration);
    };
    PlayerAssetBar.prototype.toTarget = function () {
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI);
        var duration = 0.8;
        var delay = 0.005;
        var totalDelay = this.goldLayer.childrenCount * delay;
        for (var i = this.goldLayer.childrenCount - 1; i >= 0; --i) {
            var move = Action3dManager_1.default.moveTo(duration, this.targetPos);
            var scale = Action3dManager_1.default.scaleTo(duration, 0.5, 0.5, 1);
            var spawn = Action3dManager_1.default.spawn(move, scale);
            var d = Action3dManager_1.default.delay(delay + i * delay);
            var seq = Action3dManager_1.default.sequence(d, spawn);
            actMng.runAction(this.goldLayer.children[i], seq);
        }
        this.scheduleOnce(this.playFinish, duration + totalDelay);
    };
    PlayerAssetBar.prototype.playFinish = function () {
        this.emit(GameEventType_1.EventType.UIEvent.hideTouchMask);
        if (!!this.cb) {
            this.cb();
        }
        else {
            this.emit(GameEventType_1.EventType.UIEvent.goldAnimPlayFinish);
        }
        this.resetGoldIcon();
    };
    __decorate([
        property(cc.Label)
    ], PlayerAssetBar.prototype, "goldLabel", void 0);
    __decorate([
        property(cc.Node)
    ], PlayerAssetBar.prototype, "goldLayer", void 0);
    __decorate([
        property(cc.Prefab)
    ], PlayerAssetBar.prototype, "goldIconPrefab", void 0);
    PlayerAssetBar = __decorate([
        ccclass
    ], PlayerAssetBar);
    return PlayerAssetBar;
}(yyComponent_1.default));
exports.default = PlayerAssetBar;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTWFpblNjZW5lXFxTY3JpcHRcXFBsYXllckFzc2V0QmFyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLCtEQUEwRDtBQUMxRCx3RUFBbUU7QUFDbkUsNkRBQXdEO0FBQ3hELDZEQUF3RDtBQUN4RCxrRUFBaUU7QUFDakUsdUVBQXFGO0FBRXJGLGVBQWU7QUFDVCxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUE0QyxrQ0FBVztJQUF2RDtRQUFBLHFFQTBJQztRQTVGRyxjQUFjO1FBRUosZUFBUyxHQUFhLElBQUksQ0FBQztRQUlyQyxZQUFZO1FBRVosY0FBYztRQUVKLGVBQVMsR0FBWSxJQUFJLENBQUM7UUFFMUIsb0JBQWMsR0FBYyxJQUFJLENBQUM7O1FBcUUzQyxZQUFZO1FBRVosY0FBYztRQUVkLFlBQVk7UUFFWixjQUFjO1FBRWQsWUFBWTtJQUdoQixDQUFDO0lBeElVLDZCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUNTLGlDQUFRLEdBQWxCO1FBQ0ksSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDckYsSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBQ00sOEJBQUssR0FBWjtRQUNJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRU0sNkJBQUksR0FBWDtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDZixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUNNLDZCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFFUyxnQ0FBTyxHQUFqQjtRQUNJLElBQUksSUFBSSxHQUFHLG9CQUFVLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVTLHdDQUFlLEdBQXpCLFVBQTBCLENBQVM7UUFDL0IsSUFBSSxDQUFDLEdBQUcsSUFBSTtZQUFFLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2xDLElBQUksQ0FBQyxHQUFHLE9BQU87WUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDckQsT0FBTyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQzNDLENBQUM7SUFFUyw0Q0FBbUIsR0FBN0IsVUFBOEIsSUFBSTtRQUM5QixRQUFRLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDcEIsS0FBSyxxQkFBcUIsQ0FBQyxDQUFDO2dCQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDekIsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBS1MsZ0NBQU8sR0FBakIsVUFBa0IsSUFBWTtRQUMxQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFVUyxxQ0FBWSxHQUF0QjtRQUNJLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDL0QsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwQyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQztRQUNmLG9CQUFVLENBQUMsVUFBVSxDQUFDLHVCQUFVLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDaEYsQ0FBQztJQUNTLHNDQUFhLEdBQXZCO1FBQ0ksSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDZixJQUFJLE1BQU0sR0FBRyx5QkFBZSxDQUFDLE1BQU0sQ0FBQywrQkFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3RELEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDeEQsTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3JEO1FBQ0Qsb0JBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ1MscUNBQVksR0FBdEIsVUFBdUIsSUFBd0Q7UUFDM0UsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDO1FBRWxCLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2pCLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzdCO1FBRUQsSUFBSSxRQUFRLEdBQUcsR0FBRyxDQUFDO1FBQ25CLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNoRCxJQUFJLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDaEIsSUFBSSxNQUFNLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsK0JBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN0RCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzVCLElBQUksSUFBSSxHQUFHLG9CQUFVLENBQUMsR0FBRyxDQUFDLHVCQUFVLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzNELElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDekIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFcEIsSUFBSSxJQUFJLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDN0csSUFBSSxDQUFDLE1BQU0sQ0FBQyx5QkFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3hDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2hDO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDUyxpQ0FBUSxHQUFsQjtRQUNJLElBQUksTUFBTSxHQUFHLHlCQUFlLENBQUMsTUFBTSxDQUFDLCtCQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdEQsSUFBSSxRQUFRLEdBQUcsR0FBRyxDQUFDO1FBQ25CLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNsQixJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDdEQsS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN4RCxJQUFJLElBQUksR0FBRyx5QkFBZSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzVELElBQUksS0FBSyxHQUFHLHlCQUFlLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzNELElBQUksS0FBSyxHQUFHLHlCQUFlLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsR0FBRyx5QkFBZSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO1lBQ2pELElBQUksR0FBRyxHQUFHLHlCQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM3QyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ3JEO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFFBQVEsR0FBRyxVQUFVLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ1MsbUNBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzNDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDWCxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7U0FDYjthQUFNO1lBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1NBQ25EO1FBQ0QsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUE3RUQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztxREFDa0I7SUFRckM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztxREFDa0I7SUFFcEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzswREFDdUI7SUExRDFCLGNBQWM7UUFEbEMsT0FBTztPQUNhLGNBQWMsQ0EwSWxDO0lBQUQscUJBQUM7Q0ExSUQsQUEwSUMsQ0ExSTJDLHFCQUFXLEdBMEl0RDtrQkExSW9CLGNBQWMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeXlDb21wb25lbnQgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24veXlDb21wb25lbnRcIjtcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2FtZUV2ZW50VHlwZVwiO1xuaW1wb3J0IFBsYXllckRhdGEgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vUGxheWVyRGF0YVwiO1xuaW1wb3J0IEdsb2JhbFBvb2wgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vR2xvYmFsUG9vbFwiO1xuaW1wb3J0IHsgR2xvYmFsRW51bSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2xvYmFsRW51bVwiO1xuaW1wb3J0IEFjdGlvbjNkTWFuYWdlciwgeyBBY3Rpb25NbmdUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vQWN0aW9uM2RNYW5hZ2VyXCI7XG5cbi8v546p5a6255qE6YeR5biB5L2T5Yqb562J6LWE5Lqn5L+h5oGv5p2hXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGxheWVyQXNzZXRCYXIgZXh0ZW5kcyB5eUNvbXBvbmVudCB7XG5cbiAgICBwdWJsaWMgaW5pdCgpIHtcbiAgICAgICAgdGhpcy5pbml0Q29tcG9uZW50cygpO1xuICAgICAgICB0aGlzLmluaXRHb2xkSWNvbigpO1xuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgb25FdmVudHMoKSB7XG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLlBsYXllckRhdGFFdmVudC5wbGF5ZXJEYXRhQ2hhbmdlZCwgdGhpcy5vblBsYXllckRhdGFDaGFuZ2VkLCB0aGlzKTtcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuVUlFdmVudC5wbGF5R29sZEFuaW0sIHRoaXMucGxheUdvbGRBbmltLCB0aGlzKTtcbiAgICB9XG4gICAgcHVibGljIHJlc2V0KCkge1xuICAgICAgICB0aGlzLnJlc2V0R29sZEljb24oKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgc2hvdygpIHtcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgpO1xuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XG4gICAgfVxuICAgIHB1YmxpYyBoaWRlKCkge1xuICAgICAgICB0aGlzLm9mZkV2ZW50cygpO1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHNldERhdGEoKSB7XG4gICAgICAgIGxldCBkYXRhID0gUGxheWVyRGF0YS5nZXREYXRhKFwiZ2FtZURhdGEuYXNzZXRcIik7XG4gICAgICAgIHRoaXMuc2V0R29sZChkYXRhLmdvbGQpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBjb252ZXJ0VG9TdHJpbmcodjogbnVtYmVyKSB7XG4gICAgICAgIGlmICh2IDwgMTEwMCkgcmV0dXJuIHYudG9TdHJpbmcoKTtcbiAgICAgICAgaWYgKHYgPCAxMDAwMDAwKSByZXR1cm4gKHYgKiAwLjAwMSkudG9GaXhlZCgxKSArIFwiS1wiO1xuICAgICAgICByZXR1cm4gKHYgKiAwLjAwMDAwMSkudG9GaXhlZCgxKSArIFwiTVwiO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBvblBsYXllckRhdGFDaGFuZ2VkKGRhdGEpIHtcbiAgICAgICAgc3dpdGNoIChkYXRhLmF0dHJpYnV0ZSkge1xuICAgICAgICAgICAgY2FzZSBcImdhbWVEYXRhLmFzc2V0LmdvbGRcIjoge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0R29sZChkYXRhLnZhbHVlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vI3JlZ2lvbiDph5HluIHkv6Hmga9cbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgcHJvdGVjdGVkIGdvbGRMYWJlbDogY2MuTGFiZWwgPSBudWxsO1xuICAgIHByb3RlY3RlZCBzZXRHb2xkKGdvbGQ6IG51bWJlcikge1xuICAgICAgICB0aGlzLmdvbGRMYWJlbC5zdHJpbmcgPSB0aGlzLmNvbnZlcnRUb1N0cmluZyhnb2xkKTtcbiAgICB9XG4gICAgLy8jZW5kcmVnaW9uXG5cbiAgICAvLyNyZWdpb24g6YeR5biB5Yqo55S7XG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGdvbGRMYXllcjogY2MuTm9kZSA9IG51bGw7XG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcbiAgICBwcm90ZWN0ZWQgZ29sZEljb25QcmVmYWI6IGNjLlByZWZhYiA9IG51bGw7XG4gICAgcHJvdGVjdGVkIHRhcmdldFBvczogY2MuVmVjMztcbiAgICBwcm90ZWN0ZWQgY2I6IEZ1bmN0aW9uO1xuICAgIHByb3RlY3RlZCBpbml0R29sZEljb24oKSB7XG4gICAgICAgIGxldCBwID0gdGhpcy5nb2xkTGFiZWwubm9kZS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xuICAgICAgICBwID0gdGhpcy5ub2RlLmNvbnZlcnRUb05vZGVTcGFjZUFSKHApO1xuICAgICAgICB0aGlzLnRhcmdldFBvcyA9IGNjLnYzKHAueCwgcC55LCAwKTtcbiAgICAgICAgdGhpcy5jYiA9IG51bGw7XG4gICAgICAgIEdsb2JhbFBvb2wuY3JlYXRlUG9vbChHbG9iYWxFbnVtLkxldmVsUHJlZmFiLmdvbGRJY29uLCB0aGlzLmdvbGRJY29uUHJlZmFiKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHJlc2V0R29sZEljb24oKSB7XG4gICAgICAgIHRoaXMuY2IgPSBudWxsO1xuICAgICAgICBsZXQgYWN0TW5nID0gQWN0aW9uM2RNYW5hZ2VyLmdldE1uZyhBY3Rpb25NbmdUeXBlLlVJKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IHRoaXMuZ29sZExheWVyLmNoaWxkcmVuQ291bnQgLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgYWN0TW5nLnN0b3BBbGxBY3Rpb25zKHRoaXMuZ29sZExheWVyLmNoaWxkcmVuW2ldKTtcbiAgICAgICAgfVxuICAgICAgICBHbG9iYWxQb29sLnB1dEFsbENoaWxkcmVuKHRoaXMuZ29sZExheWVyLCB0cnVlKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHBsYXlHb2xkQW5pbShkYXRhOiB7IHN0YXJ0UG9zOiBjYy5WZWMyLCBjYjogRnVuY3Rpb24sIGdvbGQ/OiBudW1iZXIgfSkge1xuICAgICAgICB0aGlzLnJlc2V0R29sZEljb24oKTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LnNob3dUb3VjaE1hc2spO1xuICAgICAgICB0aGlzLmNiID0gZGF0YS5jYjtcblxuICAgICAgICBsZXQgY2VudGVyID0gY2MudjIoKTtcbiAgICAgICAgaWYgKCEhZGF0YS5zdGFydFBvcykge1xuICAgICAgICAgICAgY2VudGVyLnNldChkYXRhLnN0YXJ0UG9zKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBkdXJhdGlvbiA9IDAuMjtcbiAgICAgICAgbGV0IGNvdW50ID0gTWF0aC5yb3VuZChNYXRoLnJhbmRvbSgpICogMTApICsgMjA7XG4gICAgICAgIGxldCBzY29wZSA9IDI1MDtcbiAgICAgICAgbGV0IGFjdE1uZyA9IEFjdGlvbjNkTWFuYWdlci5nZXRNbmcoQWN0aW9uTW5nVHlwZS5VSSk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQ7IGkrKykge1xuICAgICAgICAgICAgbGV0IGl0ZW0gPSBHbG9iYWxQb29sLmdldChHbG9iYWxFbnVtLkxldmVsUHJlZmFiLmdvbGRJY29uKTtcbiAgICAgICAgICAgIHRoaXMuZ29sZExheWVyLmFkZENoaWxkKGl0ZW0pO1xuICAgICAgICAgICAgaXRlbS5zZXRQb3NpdGlvbihjZW50ZXIpO1xuICAgICAgICAgICAgaXRlbS5zZXRTY2FsZSgxLCAxKTtcblxuICAgICAgICAgICAgbGV0IG1vdmUgPSBBY3Rpb24zZE1hbmFnZXIubW92ZVRvKGR1cmF0aW9uLCAoTWF0aC5yYW5kb20oKSAtIDAuNSkgKiBzY29wZSwgKE1hdGgucmFuZG9tKCkgLSAwLjUpICogc2NvcGUsIDApO1xuICAgICAgICAgICAgbW92ZS5lYXNpbmcoQWN0aW9uM2RNYW5hZ2VyLmVhc2VPdXQoMikpO1xuICAgICAgICAgICAgYWN0TW5nLnJ1bkFjdGlvbihpdGVtLCBtb3ZlKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSh0aGlzLnRvVGFyZ2V0LCBkdXJhdGlvbik7XG4gICAgfVxuICAgIHByb3RlY3RlZCB0b1RhcmdldCgpIHtcbiAgICAgICAgbGV0IGFjdE1uZyA9IEFjdGlvbjNkTWFuYWdlci5nZXRNbmcoQWN0aW9uTW5nVHlwZS5VSSk7XG4gICAgICAgIGxldCBkdXJhdGlvbiA9IDAuODtcbiAgICAgICAgbGV0IGRlbGF5ID0gMC4wMDU7XG4gICAgICAgIGxldCB0b3RhbERlbGF5ID0gdGhpcy5nb2xkTGF5ZXIuY2hpbGRyZW5Db3VudCAqIGRlbGF5O1xuICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5nb2xkTGF5ZXIuY2hpbGRyZW5Db3VudCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgICAgICBsZXQgbW92ZSA9IEFjdGlvbjNkTWFuYWdlci5tb3ZlVG8oZHVyYXRpb24sIHRoaXMudGFyZ2V0UG9zKTtcbiAgICAgICAgICAgIGxldCBzY2FsZSA9IEFjdGlvbjNkTWFuYWdlci5zY2FsZVRvKGR1cmF0aW9uLCAwLjUsIDAuNSwgMSk7XG4gICAgICAgICAgICBsZXQgc3Bhd24gPSBBY3Rpb24zZE1hbmFnZXIuc3Bhd24obW92ZSwgc2NhbGUpO1xuICAgICAgICAgICAgbGV0IGQgPSBBY3Rpb24zZE1hbmFnZXIuZGVsYXkoZGVsYXkgKyBpICogZGVsYXkpO1xuICAgICAgICAgICAgbGV0IHNlcSA9IEFjdGlvbjNkTWFuYWdlci5zZXF1ZW5jZShkLCBzcGF3bik7XG4gICAgICAgICAgICBhY3RNbmcucnVuQWN0aW9uKHRoaXMuZ29sZExheWVyLmNoaWxkcmVuW2ldLCBzZXEpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKHRoaXMucGxheUZpbmlzaCwgZHVyYXRpb24gKyB0b3RhbERlbGF5KTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHBsYXlGaW5pc2goKSB7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5oaWRlVG91Y2hNYXNrKTtcbiAgICAgICAgaWYgKCEhdGhpcy5jYikge1xuICAgICAgICAgICAgdGhpcy5jYigpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmdvbGRBbmltUGxheUZpbmlzaCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5yZXNldEdvbGRJY29uKCk7XG4gICAgfVxuXG4gICAgLy8jZW5kcmVnaW9uXG5cbiAgICAvLyNyZWdpb24g5L2T5Yqb5L+h5oGvXG5cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDkvZPlipvliqjnlLtcblxuICAgIC8vI2VuZHJlZ2lvblxuXG5cbn1cbiJdfQ==