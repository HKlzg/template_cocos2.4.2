
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/MainScene/Script/TipMessage.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fa03fEKcf5HdqLeM7wO+JGh', 'TipMessage');
// MainScene/Script/TipMessage.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
//信息提示节点
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var TipMessage = /** @class */ (function (_super) {
    __extends(TipMessage, _super);
    function TipMessage() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.msg = null;
        _this.action = null;
        return _this;
    }
    TipMessage.prototype.init = function () {
        this.node = this.node;
        var delay0 = Action3dManager_1.default.delay(0.01);
        var fadeIn = Action3dManager_1.default.fadeTo(0, 255);
        var delay = Action3dManager_1.default.delay(1);
        var fadeOut = Action3dManager_1.default.fadeTo(0.5, 0);
        var cb = Action3dManager_1.default.callFun(this.onFadeOut, this);
        var seq = Action3dManager_1.default.sequence(delay0, fadeIn, delay, fadeOut, cb);
        this.action = seq;
        this.setMsg("");
        this.onEvents();
    };
    TipMessage.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.UIEvent.showTip, this.show, this);
    };
    TipMessage.prototype.reset = function () {
        this.node.opacity = 0;
    };
    TipMessage.prototype.show = function (msg) {
        this.node.active = true;
        this.reset();
        this.setMsg(msg);
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).runAction(this.node, this.action);
    };
    TipMessage.prototype.hide = function () {
        this.node.active = false;
    };
    TipMessage.prototype.setMsg = function (msg) {
        this.msg.string = msg;
    };
    TipMessage.prototype.onFadeOut = function () {
        this.hide();
    };
    __decorate([
        property(cc.Label)
    ], TipMessage.prototype, "msg", void 0);
    TipMessage = __decorate([
        ccclass
    ], TipMessage);
    return TipMessage;
}(yyComponent_1.default));
exports.default = TipMessage;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTWFpblNjZW5lXFxTY3JpcHRcXFRpcE1lc3NhZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBQzFELHVFQUFxRjtBQUNyRix3RUFBbUU7QUFFbkUsUUFBUTtBQUNGLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXdDLDhCQUFXO0lBQW5EO1FBQUEscUVBMENDO1FBdkNXLFNBQUcsR0FBYSxJQUFJLENBQUM7UUFFckIsWUFBTSxHQUFHLElBQUksQ0FBQzs7SUFxQzFCLENBQUM7SUFuQ1UseUJBQUksR0FBWDtRQUNJLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUV0QixJQUFJLE1BQU0sR0FBRyx5QkFBZSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN6QyxJQUFJLE1BQU0sR0FBRyx5QkFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDNUMsSUFBSSxLQUFLLEdBQUcseUJBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDckMsSUFBSSxPQUFPLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzdDLElBQUksRUFBRSxHQUFHLHlCQUFlLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDdkQsSUFBSSxHQUFHLEdBQUcseUJBQWUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBRWxCLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFDUyw2QkFBUSxHQUFsQjtRQUNJLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUNNLDBCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUNNLHlCQUFJLEdBQVgsVUFBWSxHQUFXO1FBQ25CLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLHlCQUFlLENBQUMsTUFBTSxDQUFDLCtCQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQy9FLENBQUM7SUFDTSx5QkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFDTywyQkFBTSxHQUFkLFVBQWUsR0FBVztRQUN0QixJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7SUFDMUIsQ0FBQztJQUNPLDhCQUFTLEdBQWpCO1FBQ0ksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ2hCLENBQUM7SUF0Q0Q7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQzsyQ0FDVTtJQUhaLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0EwQzlCO0lBQUQsaUJBQUM7Q0ExQ0QsQUEwQ0MsQ0ExQ3VDLHFCQUFXLEdBMENsRDtrQkExQ29CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeXlDb21wb25lbnQgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24veXlDb21wb25lbnRcIjtcbmltcG9ydCBBY3Rpb24zZE1hbmFnZXIsIHsgQWN0aW9uTW5nVHlwZSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL0FjdGlvbjNkTWFuYWdlclwiO1xuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XG5cbi8v5L+h5oGv5o+Q56S66IqC54K5XG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGlwTWVzc2FnZSBleHRlbmRzIHl5Q29tcG9uZW50IHtcblxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcbiAgICBwcml2YXRlIG1zZzogY2MuTGFiZWwgPSBudWxsO1xuXG4gICAgcHJpdmF0ZSBhY3Rpb24gPSBudWxsO1xuXG4gICAgcHVibGljIGluaXQoKSB7XG4gICAgICAgIHRoaXMubm9kZSA9IHRoaXMubm9kZTtcblxuICAgICAgICBsZXQgZGVsYXkwID0gQWN0aW9uM2RNYW5hZ2VyLmRlbGF5KDAuMDEpO1xuICAgICAgICBsZXQgZmFkZUluID0gQWN0aW9uM2RNYW5hZ2VyLmZhZGVUbygwLCAyNTUpO1xuICAgICAgICBsZXQgZGVsYXkgPSBBY3Rpb24zZE1hbmFnZXIuZGVsYXkoMSk7XG4gICAgICAgIGxldCBmYWRlT3V0ID0gQWN0aW9uM2RNYW5hZ2VyLmZhZGVUbygwLjUsIDApO1xuICAgICAgICBsZXQgY2IgPSBBY3Rpb24zZE1hbmFnZXIuY2FsbEZ1bih0aGlzLm9uRmFkZU91dCwgdGhpcyk7XG4gICAgICAgIGxldCBzZXEgPSBBY3Rpb24zZE1hbmFnZXIuc2VxdWVuY2UoZGVsYXkwLCBmYWRlSW4sIGRlbGF5LCBmYWRlT3V0LCBjYik7XG4gICAgICAgIHRoaXMuYWN0aW9uID0gc2VxO1xuXG4gICAgICAgIHRoaXMuc2V0TXNnKFwiXCIpO1xuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBvbkV2ZW50cygpIHtcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuVUlFdmVudC5zaG93VGlwLCB0aGlzLnNob3csIHRoaXMpO1xuICAgIH1cbiAgICBwdWJsaWMgcmVzZXQoKSB7XG4gICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMDtcbiAgICB9XG4gICAgcHVibGljIHNob3cobXNnOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMucmVzZXQoKTtcbiAgICAgICAgdGhpcy5zZXRNc2cobXNnKTtcbiAgICAgICAgQWN0aW9uM2RNYW5hZ2VyLmdldE1uZyhBY3Rpb25NbmdUeXBlLlVJKS5ydW5BY3Rpb24odGhpcy5ub2RlLCB0aGlzLmFjdGlvbik7XG4gICAgfVxuICAgIHB1YmxpYyBoaWRlKCkge1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgfVxuICAgIHByaXZhdGUgc2V0TXNnKG1zZzogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMubXNnLnN0cmluZyA9IG1zZztcbiAgICB9XG4gICAgcHJpdmF0ZSBvbkZhZGVPdXQoKSB7XG4gICAgICAgIHRoaXMuaGlkZSgpO1xuICAgIH1cbn1cbiJdfQ==