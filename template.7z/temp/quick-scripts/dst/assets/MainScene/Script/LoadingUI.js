
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/MainScene/Script/LoadingUI.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '326d3l9GUNNN6sC8bQK7+Ik', 'LoadingUI');
// MainScene/Script/LoadingUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**加载进度条UI */
var LoadingUI = /** @class */ (function (_super) {
    __extends(LoadingUI, _super);
    function LoadingUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bar = null;
        _this.totalLength = 0;
        return _this;
    }
    LoadingUI.prototype.init = function () {
        if (this.totalLength == 0) {
            this.totalLength = this.bar.getComponent(cc.Sprite).spriteFrame.getOriginalSize().width;
        }
        this.bar.setPosition(-0.5 * this.totalLength, this.bar.y);
        this.onEvents();
    };
    LoadingUI.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.LoadAssetEvent.showProgress, this.onShowProgress, this);
        this.on(GameEventType_1.EventType.LoadAssetEvent.updateProgress, this.onUpdateProgress, this);
        this.on(GameEventType_1.EventType.LoadAssetEvent.hideProgress, this.onHideProgress, this);
    };
    LoadingUI.prototype.onShowProgress = function (rate) {
        this.node.active = true;
        this.bar.width = this.totalLength * rate;
    };
    LoadingUI.prototype.onUpdateProgress = function (rate) {
        this.bar.width = this.totalLength * rate;
    };
    LoadingUI.prototype.onHideProgress = function () {
        this.node.active = false;
    };
    __decorate([
        property(cc.Node)
    ], LoadingUI.prototype, "bar", void 0);
    __decorate([
        property
    ], LoadingUI.prototype, "totalLength", void 0);
    LoadingUI = __decorate([
        ccclass
    ], LoadingUI);
    return LoadingUI;
}(yyComponent_1.default));
exports.default = LoadingUI;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTWFpblNjZW5lXFxTY3JpcHRcXExvYWRpbmdVSS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrREFBMEQ7QUFDMUQsd0VBQW1FO0FBRTdELElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBQzVDLGFBQWE7QUFFYjtJQUF1Qyw2QkFBVztJQUFsRDtRQUFBLHFFQWtDQztRQS9CYSxTQUFHLEdBQVksSUFBSSxDQUFDO1FBRXBCLGlCQUFXLEdBQVcsQ0FBQyxDQUFDOztJQTZCdEMsQ0FBQztJQTNCVSx3QkFBSSxHQUFYO1FBQ0ksSUFBSSxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsRUFBRTtZQUN2QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLENBQUMsS0FBSyxDQUFDO1NBQzNGO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRVMsNEJBQVEsR0FBbEI7UUFDSSxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFFLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM5RSxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzlFLENBQUM7SUFFUyxrQ0FBYyxHQUF4QixVQUF5QixJQUFZO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztJQUM3QyxDQUFDO0lBRVMsb0NBQWdCLEdBQTFCLFVBQTJCLElBQVk7UUFDbkMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7SUFDN0MsQ0FBQztJQUVTLGtDQUFjLEdBQXhCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUE3QkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzswQ0FDWTtJQUU5QjtRQURDLFFBQVE7a0RBQ3lCO0lBTGpCLFNBQVM7UUFEN0IsT0FBTztPQUNhLFNBQVMsQ0FrQzdCO0lBQUQsZ0JBQUM7Q0FsQ0QsQUFrQ0MsQ0FsQ3NDLHFCQUFXLEdBa0NqRDtrQkFsQ29CLFNBQVMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeXlDb21wb25lbnQgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24veXlDb21wb25lbnRcIjtcclxuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG4vKirliqDovb3ov5vluqbmnaFVSSAqL1xyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMb2FkaW5nVUkgZXh0ZW5kcyB5eUNvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgYmFyOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eVxyXG4gICAgcHJvdGVjdGVkIHRvdGFsTGVuZ3RoOiBudW1iZXIgPSAwO1xyXG5cclxuICAgIHB1YmxpYyBpbml0KCkge1xyXG4gICAgICAgIGlmICh0aGlzLnRvdGFsTGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgdGhpcy50b3RhbExlbmd0aCA9IHRoaXMuYmFyLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lLmdldE9yaWdpbmFsU2l6ZSgpLndpZHRoO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmJhci5zZXRQb3NpdGlvbigtMC41ICogdGhpcy50b3RhbExlbmd0aCwgdGhpcy5iYXIueSk7XHJcbiAgICAgICAgdGhpcy5vbkV2ZW50cygpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBvbkV2ZW50cygpIHtcclxuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5Mb2FkQXNzZXRFdmVudC5zaG93UHJvZ3Jlc3MsIHRoaXMub25TaG93UHJvZ3Jlc3MsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLkxvYWRBc3NldEV2ZW50LnVwZGF0ZVByb2dyZXNzLCB0aGlzLm9uVXBkYXRlUHJvZ3Jlc3MsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLkxvYWRBc3NldEV2ZW50LmhpZGVQcm9ncmVzcywgdGhpcy5vbkhpZGVQcm9ncmVzcywgdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIG9uU2hvd1Byb2dyZXNzKHJhdGU6IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuYmFyLndpZHRoID0gdGhpcy50b3RhbExlbmd0aCAqIHJhdGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIG9uVXBkYXRlUHJvZ3Jlc3MocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy5iYXIud2lkdGggPSB0aGlzLnRvdGFsTGVuZ3RoICogcmF0ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgb25IaWRlUHJvZ3Jlc3MoKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=