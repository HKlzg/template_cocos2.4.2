
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/MainScene/Script/LevelController.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '40bcc/o5rtGMK5aKqyYxbY2', 'LevelController');
// Level/LevelController/LevelController.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//关卡中的控制器，接收玩家操作
var LevelController = /** @class */ (function (_super) {
    __extends(LevelController, _super);
    function LevelController() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LevelController.prototype.onLoad = function () {
        this.init();
        this.setDisable();
    };
    LevelController.prototype.init = function () {
        this.initComponents();
        this.initTouchState();
        this.initCustomUpdateState();
        this.registAllCustomUpdate();
        this.onEvents();
    };
    LevelController.prototype.onEvents = function () {
        this.node.on("touchstart", this.onTouchStart, this);
        this.node.on("touchmove", this.onTouchMove, this);
        this.node.on("touchend", this.onTouchEnd, this);
        this.on(GameEventType_1.EventType.CtrlEvent.ctrlStart, this.setEnable, this);
        this.on(GameEventType_1.EventType.CtrlEvent.ctrlEnd, this.setDisable, this);
    };
    LevelController.prototype.registAllCustomUpdate = function () {
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.CtrlState.touched, this.stepTouchStay);
    };
    LevelController.prototype.reset = function () {
        this.resetTouchState();
    };
    //启用触摸操作层
    LevelController.prototype.setEnable = function () {
        this.reset();
        this.node.active = true;
    };
    //禁用触摸操作层
    LevelController.prototype.setDisable = function () {
        this.reset();
        this.node.active = false;
    };
    LevelController.prototype.getTouchData = function (e) {
        return {
            startTime: this.touchStartTime,
            stayTime: this.touchStayTime,
            path: this.touchPath,
            e: e
        };
    };
    LevelController.prototype.initTouchState = function () {
        this.touched = false;
        this.touchId = -1;
        this.touchStartTime = -1;
        this.touchStayTime = 0;
        this.touchPath = [];
    };
    LevelController.prototype.resetTouchState = function () {
        this.touched = false;
        this.touchId = -1;
        this.touchStartTime = -1;
        this.touchStayTime = 0;
        this.touchPath = [];
    };
    //触摸开始
    LevelController.prototype.onTouchStart = function (e) {
        //屏蔽多点触摸
        if (this.isMultipleTouch(e))
            return;
        //记录触摸状态
        this.touched = true;
        this.touchId = e.getID();
        this.touchStartTime = Date.now();
        this.touchStayTime = 0;
        var p = e.getLocation();
        // this.touchPath.push(p);
        this.touchPath[0] = p; //不需要记录触摸路径时用此方式
        this.emit(GameEventType_1.EventType.CtrlEvent.touchStart, this.getTouchData(e));
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.CtrlState.touched);
    };
    //触摸移动
    LevelController.prototype.onTouchMove = function (e) {
        if (!this.isCurTouchEvent(e))
            return;
        var p = e.getLocation();
        // let p2 = this.touchPath[this.touchPath.length - 1];
        // if (Math.abs(p.x - p2.x) < 5 && Math.abs(p.y - p2.y) < 5) return;
        this.touchPath[1] = p; //不需要记录触摸路径时用此方式
        // this.touchPath.push(p);
        this.emit(GameEventType_1.EventType.CtrlEvent.touchMove, this.getTouchData(e));
    };
    //触摸结束
    LevelController.prototype.onTouchEnd = function (e) {
        if (!this.isCurTouchEvent(e))
            return;
        var p = e.getLocation();
        // this.touchPath.push(p);
        this.touchPath[1] = p; //不需要记录触摸路径时用此方式
        this.emit(GameEventType_1.EventType.CtrlEvent.touchEnd, this.getTouchData(e));
        this.resetTouchState();
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.CtrlState.none);
    };
    /**
     * 是否多重触摸
     * @param e 触摸事件
     */
    LevelController.prototype.isMultipleTouch = function (e) {
        return e.getTouches().length > 1;
    };
    //是否当前已记录的有效的触摸事件
    LevelController.prototype.isCurTouchEvent = function (e) {
        return e.getID() == this.touchId;
    };
    LevelController.prototype.stepTouchStay = function (dt) {
        if (this.touched) {
            this.touchStayTime += dt;
            this.emit(GameEventType_1.EventType.CtrlEvent.touchStay, this.getTouchData(null));
        }
    };
    LevelController = __decorate([
        ccclass
    ], LevelController);
    return LevelController;
}(yyComponent_1.default));
exports.default = LevelController;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxcXExldmVsQ29udHJvbGxlclxcTGV2ZWxDb250cm9sbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLCtEQUEwRDtBQUMxRCx3RUFBbUU7QUFDbkUsa0VBQWlFO0FBRzNELElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBQzVDLGdCQUFnQjtBQUVoQjtJQUE2QyxtQ0FBVztJQUF4RDs7SUEySEEsQ0FBQztJQXpIRyxnQ0FBTSxHQUFOO1FBQ0ksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ1osSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFFTSw4QkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUNTLGtDQUFRLEdBQWxCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFaEQsSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFDUywrQ0FBcUIsR0FBL0I7UUFDSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsdUJBQVUsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUM5RSxDQUFDO0lBQ00sK0JBQUssR0FBWjtRQUNJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRUQsU0FBUztJQUNGLG1DQUFTLEdBQWhCO1FBQ0ksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO0lBQzVCLENBQUM7SUFDRCxTQUFTO0lBQ0Ysb0NBQVUsR0FBakI7UUFDSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQVFPLHNDQUFZLEdBQXBCLFVBQXFCLENBQUM7UUFDbEIsT0FBTztZQUNILFNBQVMsRUFBRSxJQUFJLENBQUMsY0FBYztZQUM5QixRQUFRLEVBQUUsSUFBSSxDQUFDLGFBQWE7WUFDNUIsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTO1lBQ3BCLENBQUMsRUFBRSxDQUFDO1NBQ1AsQ0FBQztJQUNOLENBQUM7SUFDTyx3Q0FBYyxHQUF0QjtRQUNJLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDbEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUN6QixJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztRQUN2QixJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBQ08seUNBQWUsR0FBdkI7UUFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztRQUNyQixJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2xCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDekIsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7UUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUNELE1BQU07SUFDRSxzQ0FBWSxHQUFwQixVQUFxQixDQUFDO1FBQ2xCLFFBQVE7UUFDUixJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1lBQUUsT0FBTztRQUNwQyxRQUFRO1FBQ1IsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDcEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDakMsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7UUFDdkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3hCLDBCQUEwQjtRQUMxQixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBLGdCQUFnQjtRQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEUsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHVCQUFVLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFDRCxNQUFNO0lBQ0UscUNBQVcsR0FBbkIsVUFBb0IsQ0FBQztRQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7WUFBRSxPQUFPO1FBQ3JDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN4QixzREFBc0Q7UUFDdEQsb0VBQW9FO1FBQ3BFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUEsZ0JBQWdCO1FBQ3RDLDBCQUEwQjtRQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUNELE1BQU07SUFDRSxvQ0FBVSxHQUFsQixVQUFtQixDQUFDO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztZQUFFLE9BQU87UUFDckMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3hCLDBCQUEwQjtRQUMxQixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBLGdCQUFnQjtRQUV0QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyx1QkFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUUzRCxDQUFDO0lBQ0Q7OztPQUdHO0lBQ0sseUNBQWUsR0FBdkIsVUFBd0IsQ0FBQztRQUNyQixPQUFPLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxpQkFBaUI7SUFDVCx5Q0FBZSxHQUF2QixVQUF3QixDQUFDO1FBQ3JCLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDckMsQ0FBQztJQUVPLHVDQUFhLEdBQXJCLFVBQXNCLEVBQVU7UUFDNUIsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2QsSUFBSSxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ3JFO0lBQ0wsQ0FBQztJQTFIZ0IsZUFBZTtRQURuQyxPQUFPO09BQ2EsZUFBZSxDQTJIbkM7SUFBRCxzQkFBQztDQTNIRCxBQTJIQyxDQTNINEMscUJBQVcsR0EySHZEO2tCQTNIb0IsZUFBZSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB5eUNvbXBvbmVudCBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi95eUNvbXBvbmVudFwiO1xuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XG5pbXBvcnQgeyBHbG9iYWxFbnVtIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HbG9iYWxFbnVtXCI7XG5cblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcbi8v5YWz5Y2h5Lit55qE5o6n5Yi25Zmo77yM5o6l5pS2546p5a625pON5L2cXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTGV2ZWxDb250cm9sbGVyIGV4dGVuZHMgeXlDb21wb25lbnQge1xuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICB0aGlzLmluaXQoKTtcbiAgICAgICAgdGhpcy5zZXREaXNhYmxlKCk7XG4gICAgfVxuXG4gICAgcHVibGljIGluaXQoKSB7XG4gICAgICAgIHRoaXMuaW5pdENvbXBvbmVudHMoKTtcbiAgICAgICAgdGhpcy5pbml0VG91Y2hTdGF0ZSgpO1xuICAgICAgICB0aGlzLmluaXRDdXN0b21VcGRhdGVTdGF0ZSgpO1xuICAgICAgICB0aGlzLnJlZ2lzdEFsbEN1c3RvbVVwZGF0ZSgpO1xuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBvbkV2ZW50cygpIHtcbiAgICAgICAgdGhpcy5ub2RlLm9uKFwidG91Y2hzdGFydFwiLCB0aGlzLm9uVG91Y2hTdGFydCwgdGhpcyk7XG4gICAgICAgIHRoaXMubm9kZS5vbihcInRvdWNobW92ZVwiLCB0aGlzLm9uVG91Y2hNb3ZlLCB0aGlzKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKFwidG91Y2hlbmRcIiwgdGhpcy5vblRvdWNoRW5kLCB0aGlzKTtcblxuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5DdHJsRXZlbnQuY3RybFN0YXJ0LCB0aGlzLnNldEVuYWJsZSwgdGhpcyk7XG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLkN0cmxFdmVudC5jdHJsRW5kLCB0aGlzLnNldERpc2FibGUsIHRoaXMpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgcmVnaXN0QWxsQ3VzdG9tVXBkYXRlKCkge1xuICAgICAgICB0aGlzLnJlZ2lzdEN1c3RvbVVwZGF0ZShHbG9iYWxFbnVtLkN0cmxTdGF0ZS50b3VjaGVkLCB0aGlzLnN0ZXBUb3VjaFN0YXkpO1xuICAgIH1cbiAgICBwdWJsaWMgcmVzZXQoKSB7XG4gICAgICAgIHRoaXMucmVzZXRUb3VjaFN0YXRlKCk7XG4gICAgfVxuXG4gICAgLy/lkK/nlKjop6bmkbjmk43kvZzlsYJcbiAgICBwdWJsaWMgc2V0RW5hYmxlKCkge1xuICAgICAgICB0aGlzLnJlc2V0KCk7XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgIH1cbiAgICAvL+emgeeUqOinpuaRuOaTjeS9nOWxglxuICAgIHB1YmxpYyBzZXREaXNhYmxlKCkge1xuICAgICAgICB0aGlzLnJlc2V0KCk7XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICB9XG5cbiAgICAvL+inpuaRuOaTjeS9nOWKn+iDve+8mlxuICAgIHByaXZhdGUgdG91Y2hlZDogYm9vbGVhbjsgICAgICAgLy/mmK/lkKbop6bmkbjkuK1cbiAgICBwcml2YXRlIHRvdWNoSWQ6IG51bWJlcjsgICAgICAgIC8v6Kem5pG45LqL5Lu2SUTvvIzlpJrngrnop6bmkbjml7bvvIzlj6rmnInnrKzkuIDkuKrop6bmkbjngrnmnInmlYhcbiAgICBwcml2YXRlIHRvdWNoU3RhcnRUaW1lOiBudW1iZXI7IC8v6Kem5pG45byA5aeL5pe255qE5pe26Ze0XG4gICAgcHJpdmF0ZSB0b3VjaFN0YXlUaW1lOiBudW1iZXI7ICAvL+inpuaRuOaMgee7reaXtumXtO+8jOWNleS9je+8muenklxuICAgIHByaXZhdGUgdG91Y2hQYXRoOiBjYy5WZWMyW107ICAgLy/op6bmkbjnp7vliqjnmoTot6/lvoTlnZDmoIdcbiAgICBwcml2YXRlIGdldFRvdWNoRGF0YShlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdGFydFRpbWU6IHRoaXMudG91Y2hTdGFydFRpbWUsXG4gICAgICAgICAgICBzdGF5VGltZTogdGhpcy50b3VjaFN0YXlUaW1lLFxuICAgICAgICAgICAgcGF0aDogdGhpcy50b3VjaFBhdGgsXG4gICAgICAgICAgICBlOiBlXG4gICAgICAgIH07XG4gICAgfVxuICAgIHByaXZhdGUgaW5pdFRvdWNoU3RhdGUoKSB7XG4gICAgICAgIHRoaXMudG91Y2hlZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLnRvdWNoSWQgPSAtMTtcbiAgICAgICAgdGhpcy50b3VjaFN0YXJ0VGltZSA9IC0xO1xuICAgICAgICB0aGlzLnRvdWNoU3RheVRpbWUgPSAwO1xuICAgICAgICB0aGlzLnRvdWNoUGF0aCA9IFtdO1xuICAgIH1cbiAgICBwcml2YXRlIHJlc2V0VG91Y2hTdGF0ZSgpIHtcbiAgICAgICAgdGhpcy50b3VjaGVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMudG91Y2hJZCA9IC0xO1xuICAgICAgICB0aGlzLnRvdWNoU3RhcnRUaW1lID0gLTE7XG4gICAgICAgIHRoaXMudG91Y2hTdGF5VGltZSA9IDA7XG4gICAgICAgIHRoaXMudG91Y2hQYXRoID0gW107XG4gICAgfVxuICAgIC8v6Kem5pG45byA5aeLXG4gICAgcHJpdmF0ZSBvblRvdWNoU3RhcnQoZSkge1xuICAgICAgICAvL+Wxj+iUveWkmueCueinpuaRuFxuICAgICAgICBpZiAodGhpcy5pc011bHRpcGxlVG91Y2goZSkpIHJldHVybjtcbiAgICAgICAgLy/orrDlvZXop6bmkbjnirbmgIFcbiAgICAgICAgdGhpcy50b3VjaGVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy50b3VjaElkID0gZS5nZXRJRCgpO1xuICAgICAgICB0aGlzLnRvdWNoU3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgdGhpcy50b3VjaFN0YXlUaW1lID0gMDtcbiAgICAgICAgbGV0IHAgPSBlLmdldExvY2F0aW9uKCk7XG4gICAgICAgIC8vIHRoaXMudG91Y2hQYXRoLnB1c2gocCk7XG4gICAgICAgIHRoaXMudG91Y2hQYXRoWzBdID0gcDsvL+S4jemcgOimgeiusOW9leinpuaRuOi3r+W+hOaXtueUqOatpOaWueW8j1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkN0cmxFdmVudC50b3VjaFN0YXJ0LCB0aGlzLmdldFRvdWNoRGF0YShlKSk7XG4gICAgICAgIHRoaXMuZW50ZXJDdXN0b21VcGRhdGVTdGF0ZShHbG9iYWxFbnVtLkN0cmxTdGF0ZS50b3VjaGVkKTtcbiAgICB9XG4gICAgLy/op6bmkbjnp7vliqhcbiAgICBwcml2YXRlIG9uVG91Y2hNb3ZlKGUpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlzQ3VyVG91Y2hFdmVudChlKSkgcmV0dXJuO1xuICAgICAgICBsZXQgcCA9IGUuZ2V0TG9jYXRpb24oKTtcbiAgICAgICAgLy8gbGV0IHAyID0gdGhpcy50b3VjaFBhdGhbdGhpcy50b3VjaFBhdGgubGVuZ3RoIC0gMV07XG4gICAgICAgIC8vIGlmIChNYXRoLmFicyhwLnggLSBwMi54KSA8IDUgJiYgTWF0aC5hYnMocC55IC0gcDIueSkgPCA1KSByZXR1cm47XG4gICAgICAgIHRoaXMudG91Y2hQYXRoWzFdID0gcDsvL+S4jemcgOimgeiusOW9leinpuaRuOi3r+W+hOaXtueUqOatpOaWueW8j1xuICAgICAgICAvLyB0aGlzLnRvdWNoUGF0aC5wdXNoKHApO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkN0cmxFdmVudC50b3VjaE1vdmUsIHRoaXMuZ2V0VG91Y2hEYXRhKGUpKTtcbiAgICB9XG4gICAgLy/op6bmkbjnu5PmnZ9cbiAgICBwcml2YXRlIG9uVG91Y2hFbmQoZSkge1xuICAgICAgICBpZiAoIXRoaXMuaXNDdXJUb3VjaEV2ZW50KGUpKSByZXR1cm47XG4gICAgICAgIGxldCBwID0gZS5nZXRMb2NhdGlvbigpO1xuICAgICAgICAvLyB0aGlzLnRvdWNoUGF0aC5wdXNoKHApO1xuICAgICAgICB0aGlzLnRvdWNoUGF0aFsxXSA9IHA7Ly/kuI3pnIDopoHorrDlvZXop6bmkbjot6/lvoTml7bnlKjmraTmlrnlvI9cblxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkN0cmxFdmVudC50b3VjaEVuZCwgdGhpcy5nZXRUb3VjaERhdGEoZSkpO1xuICAgICAgICB0aGlzLnJlc2V0VG91Y2hTdGF0ZSgpO1xuICAgICAgICB0aGlzLmVudGVyQ3VzdG9tVXBkYXRlU3RhdGUoR2xvYmFsRW51bS5DdHJsU3RhdGUubm9uZSk7XG5cbiAgICB9XG4gICAgLyoqXG4gICAgICog5piv5ZCm5aSa6YeN6Kem5pG4XG4gICAgICogQHBhcmFtIGUg6Kem5pG45LqL5Lu2XG4gICAgICovXG4gICAgcHJpdmF0ZSBpc011bHRpcGxlVG91Y2goZSk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gZS5nZXRUb3VjaGVzKCkubGVuZ3RoID4gMTtcbiAgICB9XG4gICAgLy/mmK/lkKblvZPliY3lt7LorrDlvZXnmoTmnInmlYjnmoTop6bmkbjkuovku7ZcbiAgICBwcml2YXRlIGlzQ3VyVG91Y2hFdmVudChlKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiBlLmdldElEKCkgPT0gdGhpcy50b3VjaElkO1xuICAgIH1cblxuICAgIHByaXZhdGUgc3RlcFRvdWNoU3RheShkdDogbnVtYmVyKSB7XG4gICAgICAgIGlmICh0aGlzLnRvdWNoZWQpIHtcbiAgICAgICAgICAgIHRoaXMudG91Y2hTdGF5VGltZSArPSBkdDtcbiAgICAgICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQ3RybEV2ZW50LnRvdWNoU3RheSwgdGhpcy5nZXRUb3VjaERhdGEobnVsbCkpO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19