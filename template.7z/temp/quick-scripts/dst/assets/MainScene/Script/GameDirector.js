
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/MainScene/Script/GameDirector.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6d088A7nYNLd6wJkhsMlfmq', 'GameDirector');
// MainScene/Script/GameDirector.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var RecommendManager_1 = require("../../Script/Recommend/RecommendManager");
var UIManager_1 = require("../../Script/Common/UIManager");
var GameConfig_1 = require("../../Script/GameSpecial/GameConfig");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var AudioManager_1 = require("../../Script/Common/AudioManager");
var GameData_1 = require("../../Script/Common/GameData");
var PowerManager_1 = require("../../Script/Common/PowerManager");
var Loader_1 = require("../../Script/Common/Loader");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
//游戏流程管理器
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * 游戏流程总管理器
 *
 * 游戏流程：
 *
 * 登录:
 * 登录账号
 * 获取玩家数据
 *
 * 进入首页：
 * 加载首页资源
 * 显示首页UI
 *
 * 开始游戏：
 * 加载关卡数据
 * 加载关卡资源
 * 进入关卡
 * 隐藏首页UI
 *
 * 关卡结束：
 * 加载结算UI资源
 * 显示结算UI
 *
 * 继续下一关：
 * 退出当前关卡
 * 回收当前关卡资源
 * 加载关卡数据
 * 加载关卡资源
 * 进入关卡
 *
 * 重玩当前关：
 * 重置关卡状态
 * 进入关卡
 *
 * 返回首页：
 * 退出关卡
 * 回收关卡资源
 * 显示首页UI
 */
var GameDirector = /** @class */ (function (_super) {
    __extends(GameDirector, _super);
    function GameDirector() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bg = null;
        /************************************快捷方法************************************/
        //#region 触摸遮罩
        /**出没遮罩层，阻挡玩家触摸操作 */
        _this.touchMask = null;
        //#endregion
        /************************************管理的对象************************************/
        //#region 已经存在的UI
        _this.defaultUIs = [];
        //#endregion
        //只能在首页中时才显示的UI
        _this.lobbyUIs = [];
        //只能在关卡中时才显示的UI
        _this.levelUIs = [];
        //可在任意情况下显示的UI
        _this.persistUIs = [];
        /**关卡管理器 */
        _this.levelMng = null;
        //#region UI动作管理器
        _this.uiActMng = null;
        return _this;
        //#endregion
    }
    GameDirector.prototype.start = function () {
        this.init();
        this.loadGameData();
    };
    GameDirector.prototype.update = function (dt) {
        this.uiActMng.update(dt);
        if (!!this.levelMng) {
            this.levelMng.running(dt);
        }
    };
    GameDirector.prototype.initTouchMask = function () {
        this.touchMask.active = false;
        this.touchMaskCount = 0;
    };
    GameDirector.prototype.resetTouchMask = function () {
        this.touchMask.active = false;
        this.touchMaskCount = 0;
    };
    /**显示一层遮罩，阻挡玩家操作 */
    GameDirector.prototype.showTouchMask = function (count) {
        if (count === void 0) { count = 1; }
        this.touchMaskCount += count;
        this.touchMask.active = true;
    };
    /**移除一层遮罩，遮罩层数为0时玩家才能进行操作 */
    GameDirector.prototype.hideTouchMask = function (count) {
        if (count === void 0) { count = 1; }
        this.touchMaskCount -= count;
        if (this.touchMaskCount <= 0) {
            this.touchMaskCount = 0;
            this.touchMask.active = false;
        }
    };
    //#endregion
    //#region 关卡暂停/继续快捷方法
    /**暂停关卡 */
    GameDirector.prototype.pauseLevel = function () {
        this.emit(GameEventType_1.EventType.DirectorEvent.pauseLevel);
    };
    /**恢复关卡 */
    GameDirector.prototype.resumeLevel = function () {
        this.emit(GameEventType_1.EventType.DirectorEvent.resumeLevel);
    };
    //#endregion
    //#region UI显隐快捷方法
    GameDirector.prototype.showUI = function (ui, data) {
        this.emit(GameEventType_1.EventType.UIEvent.enter, ui, data);
    };
    GameDirector.prototype.showUIs = function (uis) {
        for (var i = uis.length - 1; i >= 0; --i) {
            this.emit(GameEventType_1.EventType.UIEvent.enter, uis[i]);
        }
    };
    GameDirector.prototype.hideUI = function (ui) {
        this.emit(GameEventType_1.EventType.UIEvent.exit, ui);
    };
    GameDirector.prototype.hideUIs = function (uis) {
        for (var i = uis.length - 1; i >= 0; --i) {
            this.emit(GameEventType_1.EventType.UIEvent.exit, uis[i]);
        }
    };
    GameDirector.prototype.initDefaultUIs = function () {
        for (var i = this.defaultUIs.length - 1; i >= 0; --i) {
            this.defaultUIs[i].init();
            this.defaultUIs[i].hide();
        }
    };
    GameDirector.prototype.initUIConfig = function () {
        this.lobbyUIs = [];
        this.lobbyUIs.push(GlobalEnum_1.GlobalEnum.UI.lobby);
        this.lobbyUIs.push(GlobalEnum_1.GlobalEnum.UI.shop);
        this.lobbyUIs.push(GlobalEnum_1.GlobalEnum.UI.chooseLevel);
        this.levelUIs = [];
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.levelInfo);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.levelTeach);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.winUI);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.loseUI);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.trySkin);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.pauseLevel);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.resurgence);
        this.persistUIs = [];
        this.persistUIs.push(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
        this.persistUIs.push(GlobalEnum_1.GlobalEnum.UI.tipPower);
        this.persistUIs.push(GlobalEnum_1.GlobalEnum.UI.getPower);
        this.persistUIs.push(GlobalEnum_1.GlobalEnum.UI.configSetting);
    };
    GameDirector.prototype.initActMng = function () {
        this.uiActMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI);
    };
    //#endregion
    /************************************游戏流程************************************/
    //#region 脚本通用流程
    GameDirector.prototype.init = function () {
        this.initUIConfig();
        this.initActMng();
        this.initTouchMask();
        this.initModels();
        this.initDefaultUIs();
        this.onEvents();
    };
    GameDirector.prototype.initModels = function () {
        //互推
        var node = this.node.getChildByName("Recommend");
        if (!!node && node.active) {
            RecommendManager_1.default.init(node);
        }
        //广告
        // AdvertManager.init();
        //UI
        UIManager_1.default.init(this.node.getChildByName("UI"));
        //todo:测试：重置玩家数据，需要再次重置时，将needResetPlayerData字符串最后一位数字加1
        var resetPlayerData = cc.sys.localStorage.getItem(GameConfig_1.default.gameName + "needResetPlayerData1");
        if (!resetPlayerData) {
            cc.sys.localStorage.setItem(GameConfig_1.default.gameName + "needResetPlayerData1", JSON.stringify(true));
        }
        PlayerData_1.default.init();
        AudioManager_1.default.init();
        GameData_1.default.init();
        PowerManager_1.default.init();
    };
    GameDirector.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.DirectorEvent.startGame, this.onStartGame, this);
        this.on(GameEventType_1.EventType.DirectorEvent.enterLobby, this.enterGameLobby, this);
        this.on(GameEventType_1.EventType.DirectorEvent.playNextLevel, this.onPlayNextLevel, this);
        this.on(GameEventType_1.EventType.DirectorEvent.replayCurLevel, this.onReplayCurLevel, this);
        this.on(GameEventType_1.EventType.DirectorEvent.playerWin, this.onLevelWin, this);
        this.on(GameEventType_1.EventType.DirectorEvent.playerLose, this.onLevelLose, this);
        this.on(GameEventType_1.EventType.DirectorEvent.hideGameLobby, this.hideGameLobbyUI, this);
        this.on(GameEventType_1.EventType.DirectorEvent.chooseTrySkinFinish, this.onChooseTrySkinFinish, this);
        this.on(GameEventType_1.EventType.UIEvent.showTouchMask, this.showTouchMask, this);
        this.on(GameEventType_1.EventType.UIEvent.hideTouchMask, this.hideTouchMask, this);
    };
    GameDirector.prototype.reset = function () {
        this.exitLevel();
        this.resetTouchMask();
    };
    //#endregion
    //#region 游戏数据加载
    /**加载全部游戏数据（json文件） */
    GameDirector.prototype.loadGameData = function () {
        var _this = this;
        Loader_1.default.loadBundle("GameData", function () {
            Loader_1.default.loadBundleDir("GameData", "JSONData", function (res) {
                var urls = [];
                for (var i = 0, c = res.length; i < c; ++i) {
                    urls.push(res[i].name);
                }
                GameData_1.default.setData(res, urls);
                _this.enterGameLobby();
            }, cc.JsonAsset, true);
        }, true, true);
    };
    //#endregion
    //#region 游戏流程：进入/退出首页
    //进入首页
    GameDirector.prototype.enterGameLobby = function () {
        if (!!this.levelMng) {
            this.levelMng.exit();
        }
        this.showGameLobbyUI();
    };
    //显示首页UI
    GameDirector.prototype.showGameLobbyUI = function () {
        this.hideUIs(this.levelUIs);
        this.hideUIs(this.persistUIs);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.lobby);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
    };
    //隐藏首页UI 
    GameDirector.prototype.hideGameLobbyUI = function () {
        this.hideUIs(this.lobbyUIs);
        this.hideUIs(this.persistUIs);
        this.hideUI(GlobalEnum_1.GlobalEnum.UI.lobby);
    };
    //#endregion
    //#region 游戏流程：进入关卡
    //开始游戏：
    GameDirector.prototype.onStartGame = function () {
        if (!this.levelMng) {
            Loader_1.default.loadBundle("LevelScene", this.loadLevelCommonAsset.bind(this), true, true);
        }
        else {
            this.enterLevel();
        }
    };
    //加载关卡场景所需的通用资源并创建对象池
    GameDirector.prototype.loadLevelCommonAsset = function () {
        var _this = this;
        Loader_1.default.loadBundleDir("LevelScene", "MultiplePrefab", function (assets) {
            for (var i = assets.length - 1; i >= 0; --i) {
                var prefab = assets[i];
                GlobalPool_1.default.createPool(prefab.name, prefab, prefab.name);
            }
            _this.loadLevelManager();
        });
    };
    //加载关卡场景管理器
    GameDirector.prototype.loadLevelManager = function () {
        var _this = this;
        Loader_1.default.loadBundleRes("LevelScene", "SinglePrefab/LevelManager", function (res) {
            var node = cc.instantiate(res);
            _this.node.getChildByName("LevelManager").addChild(node);
            _this.levelMng = node.getComponent("LevelManager");
            _this.levelMng.init();
            _this.enterLevel();
        });
    };
    //进入关卡
    GameDirector.prototype.enterLevel = function (level) {
        if (!level) {
            level = this.getCurLevel();
        }
        //进入关卡:
        this.hideGameLobbyUI();
        this.hideUIs(this.levelUIs);
        var levelData = this.getLevelData(level);
        this.levelMng.enterLevel(levelData);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.levelInfo, levelData);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
        // this.showTeachAnim();
        // this.showTrySkin();
    };
    //获取玩家当前能进入的关卡
    GameDirector.prototype.getCurLevel = function () {
        return PlayerData_1.default.getData("gameData.curLevel");
    };
    //获取关卡数据
    GameDirector.prototype.getLevelData = function (level) {
        // level = 2;
        var data = GameData_1.default.getLevelData(level);
        // let data = GameData.getLevelData(14);
        data.id = level;
        data.lv = level;
        return data;
    };
    //皮肤试用界面
    GameDirector.prototype.showTrySkin = function () {
        this.pauseLevel();
        this.showUI(GlobalEnum_1.GlobalEnum.UI.trySkin, GlobalEnum_1.GlobalEnum.GoodsType.playerSkin);
    };
    //试用皮肤流程结束(不论玩家是否选择了试用皮肤)
    GameDirector.prototype.onChooseTrySkinFinish = function () {
        this.hideUI(GlobalEnum_1.GlobalEnum.UI.trySkin);
        this.showTeachAnim();
    };
    //显示教学动画
    GameDirector.prototype.showTeachAnim = function () {
        // let teached = cc.sys.localStorage.getItem(GameConfig.gameName + "teached");
        // if (!!teached && !!JSON.parse(teached)) return;
        this.pauseLevel();
        this.showUI(GlobalEnum_1.GlobalEnum.UI.levelTeach);
    };
    //#endregion
    //#region 游戏流程：关卡胜利
    //关卡胜利
    GameDirector.prototype.onLevelWin = function () {
        this.addCurLevel();
        this.showUI(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.winUI);
    };
    //关卡进度+1
    GameDirector.prototype.addCurLevel = function () {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData.curLevel",
            value: 1,
            mode: "+",
        });
    };
    //#endregion
    //#region 游戏流程：胜利后继续下一关
    //继续下一关
    GameDirector.prototype.onPlayNextLevel = function () {
        this.exitCurLevel();
        this.putBackCurLevelAsset();
        this.enterLevel();
    };
    //退出当前关卡
    GameDirector.prototype.exitCurLevel = function () {
        this.levelMng.exit();
    };
    //回收当前关卡使用的资源
    GameDirector.prototype.putBackCurLevelAsset = function () {
    };
    //#endregion
    //#region 游戏流程：关卡失败
    //关卡失败
    GameDirector.prototype.onLevelLose = function () {
        this.showUI(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.loseUI);
    };
    //#endregion
    //#region 游戏流程：失败后重玩
    //重玩当前关卡
    GameDirector.prototype.onReplayCurLevel = function () {
        this.resetCurLevel();
        this.putBackCurLevelAsset();
        this.enterLevel();
    };
    //重置当前关卡状态
    GameDirector.prototype.resetCurLevel = function () {
        this.levelMng.reset();
    };
    //#endregion
    //#region 游戏流程：返回首页
    //返回首页
    GameDirector.prototype.onComeBackGameLobby = function () {
        this.exitLevel();
        this.putBackLevelAsset();
        this.showGameLobbyUI();
    };
    //彻底退出关卡场景
    GameDirector.prototype.exitLevel = function () {
        if (!!this.levelMng)
            this.levelMng.exit();
    };
    //回收关卡场景的全部资源
    GameDirector.prototype.putBackLevelAsset = function () {
    };
    __decorate([
        property(cc.Node)
    ], GameDirector.prototype, "bg", void 0);
    __decorate([
        property(cc.Node)
    ], GameDirector.prototype, "touchMask", void 0);
    __decorate([
        property([yyComponent_1.default])
    ], GameDirector.prototype, "defaultUIs", void 0);
    GameDirector = __decorate([
        ccclass
    ], GameDirector);
    return GameDirector;
}(yyComponent_1.default));
exports.default = GameDirector;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTWFpblNjZW5lXFxTY3JpcHRcXEdhbWVEaXJlY3Rvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrREFBMEQ7QUFDMUQsd0VBQW1FO0FBQ25FLHVFQUFxRjtBQUNyRiw0RUFBdUU7QUFDdkUsMkRBQXNEO0FBQ3RELGtFQUE2RDtBQUM3RCw2REFBd0Q7QUFDeEQsaUVBQTREO0FBQzVELHlEQUFvRDtBQUNwRCxpRUFBNEQ7QUFDNUQscURBQWdEO0FBQ2hELGtFQUFpRTtBQUNqRSw2REFBd0Q7QUFHeEQsU0FBUztBQUNILElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRTVDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXNDRztBQUVIO0lBQTBDLGdDQUFXO0lBQXJEO1FBQUEscUVBcVhDO1FBbFhhLFFBQUUsR0FBWSxJQUFJLENBQUM7UUFhN0IsOEVBQThFO1FBQzlFLGNBQWM7UUFDZCxvQkFBb0I7UUFFVixlQUFTLEdBQVksSUFBSSxDQUFDO1FBc0RwQyxZQUFZO1FBRVosK0VBQStFO1FBQy9FLGlCQUFpQjtRQUVQLGdCQUFVLEdBQWtCLEVBQUUsQ0FBQztRQU96QyxZQUFZO1FBRVosZUFBZTtRQUNMLGNBQVEsR0FBRyxFQUFFLENBQUM7UUFDeEIsZUFBZTtRQUNMLGNBQVEsR0FBRyxFQUFFLENBQUM7UUFDeEIsY0FBYztRQUNKLGdCQUFVLEdBQUcsRUFBRSxDQUFDO1FBd0IxQixXQUFXO1FBQ0QsY0FBUSxHQUFHLElBQUksQ0FBQztRQUUxQixpQkFBaUI7UUFDUCxjQUFRLEdBQW9CLElBQUksQ0FBQzs7UUEwUDNDLFlBQVk7SUFFaEIsQ0FBQztJQWhYRyw0QkFBSyxHQUFMO1FBQ0ksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ1osSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFDRCw2QkFBTSxHQUFOLFVBQU8sRUFBRTtRQUNMLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDakIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBU1Msb0NBQWEsR0FBdkI7UUFDSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDOUIsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUNTLHFDQUFjLEdBQXhCO1FBQ0ksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQzlCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFDRCxtQkFBbUI7SUFDVCxvQ0FBYSxHQUF2QixVQUF3QixLQUFpQjtRQUFqQixzQkFBQSxFQUFBLFNBQWlCO1FBQ3JDLElBQUksQ0FBQyxjQUFjLElBQUksS0FBSyxDQUFDO1FBQzdCLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztJQUNqQyxDQUFDO0lBQ0QsNEJBQTRCO0lBQ2xCLG9DQUFhLEdBQXZCLFVBQXdCLEtBQWlCO1FBQWpCLHNCQUFBLEVBQUEsU0FBaUI7UUFDckMsSUFBSSxDQUFDLGNBQWMsSUFBSSxLQUFLLENBQUM7UUFDN0IsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLENBQUMsRUFBRTtZQUMxQixJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQztZQUN4QixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBQ0QsWUFBWTtJQUVaLHFCQUFxQjtJQUNyQixVQUFVO0lBQ0EsaUNBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFDRCxVQUFVO0lBQ0Esa0NBQVcsR0FBckI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFDRCxZQUFZO0lBRVosa0JBQWtCO0lBQ1IsNkJBQU0sR0FBaEIsVUFBaUIsRUFBRSxFQUFFLElBQVU7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDUyw4QkFBTyxHQUFqQixVQUFrQixHQUFHO1FBQ2pCLEtBQUssSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM5QztJQUNMLENBQUM7SUFDUyw2QkFBTSxHQUFoQixVQUFpQixFQUFFO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUNTLDhCQUFPLEdBQWpCLFVBQWtCLEdBQUc7UUFDakIsS0FBSyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzdDO0lBQ0wsQ0FBQztJQU9TLHFDQUFjLEdBQXhCO1FBQ0ksS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNsRCxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBU1MsbUNBQVksR0FBdEI7UUFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUU5QyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMxQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUU3QyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUV0RCxDQUFDO0lBT1MsaUNBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLHlCQUFlLENBQUMsTUFBTSxDQUFDLCtCQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUNELFlBQVk7SUFFWiw4RUFBOEU7SUFDOUUsZ0JBQWdCO0lBQ1QsMkJBQUksR0FBWDtRQUNJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFdEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFUyxpQ0FBVSxHQUFwQjtRQUNJLElBQUk7UUFDSixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUN2QiwwQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFDRCxJQUFJO1FBQ0osd0JBQXdCO1FBQ3hCLElBQUk7UUFDSixtQkFBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRS9DLHdEQUF3RDtRQUN4RCxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsb0JBQVUsQ0FBQyxRQUFRLEdBQUcsc0JBQXNCLENBQUMsQ0FBQztRQUNoRyxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ2xCLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxvQkFBVSxDQUFDLFFBQVEsR0FBRyxzQkFBc0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7U0FDbkc7UUFDRCxvQkFBVSxDQUFDLElBQUksRUFBRSxDQUFDO1FBRWxCLHNCQUFZLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDcEIsa0JBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNoQixzQkFBWSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFUywrQkFBUSxHQUFsQjtRQUNJLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbkUsSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNFLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM3RSxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDcEUsSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMzRSxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsYUFBYSxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUV2RixJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ25FLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVNLDRCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFDRCxZQUFZO0lBRVosZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUNaLG1DQUFZLEdBQXRCO1FBQUEsaUJBV0M7UUFWRyxnQkFBTSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUU7WUFDMUIsZ0JBQU0sQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxVQUFDLEdBQUc7Z0JBQzdDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDZCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDMUI7Z0JBQ0Qsa0JBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM1QixLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDMUIsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDM0IsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuQixDQUFDO0lBQ0QsWUFBWTtJQUVaLHNCQUFzQjtJQUN0QixNQUFNO0lBQ0kscUNBQWMsR0FBeEI7UUFDSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDeEI7UUFDRCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUNELFFBQVE7SUFDRSxzQ0FBZSxHQUF6QjtRQUNJLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsdUJBQVUsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsU0FBUztJQUNDLHNDQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDOUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsWUFBWTtJQUVaLG1CQUFtQjtJQUNuQixPQUFPO0lBQ0csa0NBQVcsR0FBckI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNoQixnQkFBTSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDckY7YUFBTTtZQUNILElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztTQUNyQjtJQUNMLENBQUM7SUFDRCxxQkFBcUI7SUFDWCwyQ0FBb0IsR0FBOUI7UUFBQSxpQkFRQztRQVBHLGdCQUFNLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxVQUFDLE1BQU07WUFDeEQsS0FBSyxJQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN6QyxJQUFJLE1BQU0sR0FBYyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xDLG9CQUFVLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMzRDtZQUNELEtBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELFdBQVc7SUFDRCx1Q0FBZ0IsR0FBMUI7UUFBQSxpQkFRQztRQVBHLGdCQUFNLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSwyQkFBMkIsRUFBRSxVQUFDLEdBQUc7WUFDaEUsSUFBSSxJQUFJLEdBQVksRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN4QyxLQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDeEQsS0FBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ2xELEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDckIsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ3RCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELE1BQU07SUFDSSxpQ0FBVSxHQUFwQixVQUFxQixLQUFjO1FBQy9CLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDUixLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQzlCO1FBQ0QsT0FBTztRQUNQLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM1QixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxNQUFNLENBQUMsdUJBQVUsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxNQUFNLENBQUMsdUJBQVUsQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDMUMsd0JBQXdCO1FBQ3hCLHNCQUFzQjtJQUMxQixDQUFDO0lBRUQsY0FBYztJQUNKLGtDQUFXLEdBQXJCO1FBQ0ksT0FBTyxvQkFBVSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFDRCxRQUFRO0lBQ0UsbUNBQVksR0FBdEIsVUFBdUIsS0FBYTtRQUNoQyxhQUFhO1FBQ2IsSUFBSSxJQUFJLEdBQUcsa0JBQVEsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDeEMsd0NBQXdDO1FBQ3hDLElBQUksQ0FBQyxFQUFFLEdBQUcsS0FBSyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxFQUFFLEdBQUcsS0FBSyxDQUFDO1FBQ2hCLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCxRQUFRO0lBQ0Usa0NBQVcsR0FBckI7UUFDSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsdUJBQVUsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUNELHlCQUF5QjtJQUNmLDRDQUFxQixHQUEvQjtRQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsdUJBQVUsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRCxRQUFRO0lBQ0Usb0NBQWEsR0FBdkI7UUFDSSw4RUFBOEU7UUFDOUUsa0RBQWtEO1FBQ2xELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsTUFBTSxDQUFDLHVCQUFVLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxZQUFZO0lBRVosbUJBQW1CO0lBQ25CLE1BQU07SUFDSSxpQ0FBVSxHQUFwQjtRQUNJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsTUFBTSxDQUFDLHVCQUFVLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxNQUFNLENBQUMsdUJBQVUsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELFFBQVE7SUFDRSxrQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUU7WUFDbEQsSUFBSSxFQUFFLFVBQVU7WUFDaEIsU0FBUyxFQUFFLG1CQUFtQjtZQUM5QixLQUFLLEVBQUUsQ0FBQztZQUNSLElBQUksRUFBRSxHQUFHO1NBQ1osQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELFlBQVk7SUFFWix1QkFBdUI7SUFDdkIsT0FBTztJQUNHLHNDQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBQ0QsUUFBUTtJQUNFLG1DQUFZLEdBQXRCO1FBQ0ksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBQ0QsYUFBYTtJQUNILDJDQUFvQixHQUE5QjtJQUVBLENBQUM7SUFDRCxZQUFZO0lBRVosbUJBQW1CO0lBQ25CLE1BQU07SUFDSSxrQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsdUJBQVUsQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsWUFBWTtJQUVaLG9CQUFvQjtJQUNwQixRQUFRO0lBQ0UsdUNBQWdCLEdBQTFCO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBQ0QsVUFBVTtJQUNBLG9DQUFhLEdBQXZCO1FBQ0ksSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBQ0QsWUFBWTtJQUVaLG1CQUFtQjtJQUNuQixNQUFNO0lBQ0ksMENBQW1CLEdBQTdCO1FBQ0ksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBQ0QsVUFBVTtJQUNBLGdDQUFTLEdBQW5CO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQzlDLENBQUM7SUFDRCxhQUFhO0lBQ0gsd0NBQWlCLEdBQTNCO0lBRUEsQ0FBQztJQS9XRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzRDQUNXO0lBaUI3QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO21EQUNrQjtJQTJEcEM7UUFEQyxRQUFRLENBQUMsQ0FBQyxxQkFBVyxDQUFDLENBQUM7b0RBQ2lCO0lBL0V4QixZQUFZO1FBRGhDLE9BQU87T0FDYSxZQUFZLENBcVhoQztJQUFELG1CQUFDO0NBclhELEFBcVhDLENBclh5QyxxQkFBVyxHQXFYcEQ7a0JBclhvQixZQUFZIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHl5Q29tcG9uZW50IGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL3l5Q29tcG9uZW50XCI7XG5pbXBvcnQgeyBFdmVudFR5cGUgfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcbmltcG9ydCBBY3Rpb24zZE1hbmFnZXIsIHsgQWN0aW9uTW5nVHlwZSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL0FjdGlvbjNkTWFuYWdlclwiO1xuaW1wb3J0IFJlY29tbWVuZE1hbmFnZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9SZWNvbW1lbmQvUmVjb21tZW5kTWFuYWdlclwiO1xuaW1wb3J0IFVJTWFuYWdlciBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9VSU1hbmFnZXJcIjtcbmltcG9ydCBHYW1lQ29uZmlnIGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2FtZUNvbmZpZ1wiO1xuaW1wb3J0IFBsYXllckRhdGEgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vUGxheWVyRGF0YVwiO1xuaW1wb3J0IEF1ZGlvTWFuYWdlciBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9BdWRpb01hbmFnZXJcIjtcbmltcG9ydCBHYW1lRGF0YSBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9HYW1lRGF0YVwiO1xuaW1wb3J0IFBvd2VyTWFuYWdlciBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9Qb3dlck1hbmFnZXJcIjtcbmltcG9ydCBMb2FkZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vTG9hZGVyXCI7XG5pbXBvcnQgeyBHbG9iYWxFbnVtIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HbG9iYWxFbnVtXCI7XG5pbXBvcnQgR2xvYmFsUG9vbCBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9HbG9iYWxQb29sXCI7XG5cblxuLy/muLjmiI/mtYHnqIvnrqHnkIblmahcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbi8qKlxuICog5ri45oiP5rWB56iL5oC7566h55CG5ZmoXG4gKiBcbiAqIOa4uOaIj+a1geeoi++8mlxuICogXG4gKiDnmbvlvZU6XG4gKiDnmbvlvZXotKblj7dcbiAqIOiOt+WPlueOqeWutuaVsOaNrlxuICogXG4gKiDov5vlhaXpppbpobXvvJpcbiAqIOWKoOi9vemmlumhtei1hOa6kFxuICog5pi+56S66aaW6aG1VUlcbiAqIFxuICog5byA5aeL5ri45oiP77yaXG4gKiDliqDovb3lhbPljaHmlbDmja5cbiAqIOWKoOi9veWFs+WNoei1hOa6kFxuICog6L+b5YWl5YWz5Y2hXG4gKiDpmpDol4/pppbpobVVSVxuICogXG4gKiDlhbPljaHnu5PmnZ/vvJpcbiAqIOWKoOi9vee7k+eul1VJ6LWE5rqQXG4gKiDmmL7npLrnu5PnrpdVSVxuICogXG4gKiDnu6fnu63kuIvkuIDlhbPvvJpcbiAqIOmAgOWHuuW9k+WJjeWFs+WNoVxuICog5Zue5pS25b2T5YmN5YWz5Y2h6LWE5rqQXG4gKiDliqDovb3lhbPljaHmlbDmja5cbiAqIOWKoOi9veWFs+WNoei1hOa6kFxuICog6L+b5YWl5YWz5Y2hXG4gKiBcbiAqIOmHjeeOqeW9k+WJjeWFs++8mlxuICog6YeN572u5YWz5Y2h54q25oCBXG4gKiDov5vlhaXlhbPljaFcbiAqIFxuICog6L+U5Zue6aaW6aG177yaXG4gKiDpgIDlh7rlhbPljaFcbiAqIOWbnuaUtuWFs+WNoei1hOa6kFxuICog5pi+56S66aaW6aG1VUlcbiAqL1xuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdhbWVEaXJlY3RvciBleHRlbmRzIHl5Q29tcG9uZW50IHtcblxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICAgIHByb3RlY3RlZCBiZzogY2MuTm9kZSA9IG51bGw7XG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgdGhpcy5pbml0KCk7XG4gICAgICAgIHRoaXMubG9hZEdhbWVEYXRhKCk7XG4gICAgfVxuICAgIHVwZGF0ZShkdCkge1xuICAgICAgICB0aGlzLnVpQWN0TW5nLnVwZGF0ZShkdCk7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxNbmcpIHtcbiAgICAgICAgICAgIHRoaXMubGV2ZWxNbmcucnVubmluZyhkdCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5b+r5o235pa55rOVKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIC8vI3JlZ2lvbiDop6bmkbjpga7nvalcbiAgICAvKirlh7rmsqHpga7nvanlsYLvvIzpmLvmjKHnjqnlrrbop6bmkbjmk43kvZwgKi9cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBwcm90ZWN0ZWQgdG91Y2hNYXNrOiBjYy5Ob2RlID0gbnVsbDtcbiAgICAvKirorrDlvZXpnIDopoHmmL7npLrpga7nvannmoTmrKHmlbDvvIzmrKHmlbDkuLow5pe26ZqQ6JeP6YGu572p5bGCICovXG4gICAgcHJvdGVjdGVkIHRvdWNoTWFza0NvdW50OiBudW1iZXI7XG4gICAgcHJvdGVjdGVkIGluaXRUb3VjaE1hc2soKSB7XG4gICAgICAgIHRoaXMudG91Y2hNYXNrLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnRvdWNoTWFza0NvdW50ID0gMDtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHJlc2V0VG91Y2hNYXNrKCkge1xuICAgICAgICB0aGlzLnRvdWNoTWFzay5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy50b3VjaE1hc2tDb3VudCA9IDA7XG4gICAgfVxuICAgIC8qKuaYvuekuuS4gOWxgumBrue9qe+8jOmYu+aMoeeOqeWutuaTjeS9nCAqL1xuICAgIHByb3RlY3RlZCBzaG93VG91Y2hNYXNrKGNvdW50OiBudW1iZXIgPSAxKSB7XG4gICAgICAgIHRoaXMudG91Y2hNYXNrQ291bnQgKz0gY291bnQ7XG4gICAgICAgIHRoaXMudG91Y2hNYXNrLmFjdGl2ZSA9IHRydWU7XG4gICAgfVxuICAgIC8qKuenu+mZpOS4gOWxgumBrue9qe+8jOmBrue9qeWxguaVsOS4ujDml7bnjqnlrrbmiY3og73ov5vooYzmk43kvZwgKi9cbiAgICBwcm90ZWN0ZWQgaGlkZVRvdWNoTWFzayhjb3VudDogbnVtYmVyID0gMSkge1xuICAgICAgICB0aGlzLnRvdWNoTWFza0NvdW50IC09IGNvdW50O1xuICAgICAgICBpZiAodGhpcy50b3VjaE1hc2tDb3VudCA8PSAwKSB7XG4gICAgICAgICAgICB0aGlzLnRvdWNoTWFza0NvdW50ID0gMDtcbiAgICAgICAgICAgIHRoaXMudG91Y2hNYXNrLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLy8jcmVnaW9uIOWFs+WNoeaaguWBnC/nu6fnu63lv6vmjbfmlrnms5VcbiAgICAvKirmmoLlgZzlhbPljaEgKi9cbiAgICBwcm90ZWN0ZWQgcGF1c2VMZXZlbCgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LnBhdXNlTGV2ZWwpO1xuICAgIH1cbiAgICAvKirmgaLlpI3lhbPljaEgKi9cbiAgICBwcm90ZWN0ZWQgcmVzdW1lTGV2ZWwoKSB7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5yZXN1bWVMZXZlbCk7XG4gICAgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLy8jcmVnaW9uIFVJ5pi+6ZqQ5b+r5o235pa55rOVXG4gICAgcHJvdGVjdGVkIHNob3dVSSh1aSwgZGF0YT86IGFueSkge1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuZW50ZXIsIHVpLCBkYXRhKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHNob3dVSXModWlzKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSB1aXMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5lbnRlciwgdWlzW2ldKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcm90ZWN0ZWQgaGlkZVVJKHVpKSB7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5leGl0LCB1aSk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBoaWRlVUlzKHVpcykge1xuICAgICAgICBmb3IgKGxldCBpID0gdWlzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuZXhpdCwgdWlzW2ldKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKirnrqHnkIbnmoTlr7nosaEqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgLy8jcmVnaW9uIOW3sue7j+WtmOWcqOeahFVJXG4gICAgQHByb3BlcnR5KFt5eUNvbXBvbmVudF0pXG4gICAgcHJvdGVjdGVkIGRlZmF1bHRVSXM6IHl5Q29tcG9uZW50W10gPSBbXTtcbiAgICBwcm90ZWN0ZWQgaW5pdERlZmF1bHRVSXMoKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSB0aGlzLmRlZmF1bHRVSXMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgIHRoaXMuZGVmYXVsdFVJc1tpXS5pbml0KCk7XG4gICAgICAgICAgICB0aGlzLmRlZmF1bHRVSXNbaV0uaGlkZSgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLy/lj6rog73lnKjpppbpobXkuK3ml7bmiY3mmL7npLrnmoRVSVxuICAgIHByb3RlY3RlZCBsb2JieVVJcyA9IFtdO1xuICAgIC8v5Y+q6IO95Zyo5YWz5Y2h5Lit5pe25omN5pi+56S655qEVUlcbiAgICBwcm90ZWN0ZWQgbGV2ZWxVSXMgPSBbXTtcbiAgICAvL+WPr+WcqOS7u+aEj+aDheWGteS4i+aYvuekuueahFVJXG4gICAgcHJvdGVjdGVkIHBlcnNpc3RVSXMgPSBbXTtcbiAgICBwcm90ZWN0ZWQgaW5pdFVJQ29uZmlnKCkge1xuICAgICAgICB0aGlzLmxvYmJ5VUlzID0gW107XG4gICAgICAgIHRoaXMubG9iYnlVSXMucHVzaChHbG9iYWxFbnVtLlVJLmxvYmJ5KTtcbiAgICAgICAgdGhpcy5sb2JieVVJcy5wdXNoKEdsb2JhbEVudW0uVUkuc2hvcCk7XG4gICAgICAgIHRoaXMubG9iYnlVSXMucHVzaChHbG9iYWxFbnVtLlVJLmNob29zZUxldmVsKTtcblxuICAgICAgICB0aGlzLmxldmVsVUlzID0gW107XG4gICAgICAgIHRoaXMubGV2ZWxVSXMucHVzaChHbG9iYWxFbnVtLlVJLmxldmVsSW5mbyk7XG4gICAgICAgIHRoaXMubGV2ZWxVSXMucHVzaChHbG9iYWxFbnVtLlVJLmxldmVsVGVhY2gpO1xuICAgICAgICB0aGlzLmxldmVsVUlzLnB1c2goR2xvYmFsRW51bS5VSS53aW5VSSk7XG4gICAgICAgIHRoaXMubGV2ZWxVSXMucHVzaChHbG9iYWxFbnVtLlVJLmxvc2VVSSk7XG4gICAgICAgIHRoaXMubGV2ZWxVSXMucHVzaChHbG9iYWxFbnVtLlVJLnRyeVNraW4pO1xuICAgICAgICB0aGlzLmxldmVsVUlzLnB1c2goR2xvYmFsRW51bS5VSS5wYXVzZUxldmVsKTtcbiAgICAgICAgdGhpcy5sZXZlbFVJcy5wdXNoKEdsb2JhbEVudW0uVUkucmVzdXJnZW5jZSk7XG5cbiAgICAgICAgdGhpcy5wZXJzaXN0VUlzID0gW107XG4gICAgICAgIHRoaXMucGVyc2lzdFVJcy5wdXNoKEdsb2JhbEVudW0uVUkucGxheWVyQXNzZXRCYXIpO1xuICAgICAgICB0aGlzLnBlcnNpc3RVSXMucHVzaChHbG9iYWxFbnVtLlVJLnRpcFBvd2VyKTtcbiAgICAgICAgdGhpcy5wZXJzaXN0VUlzLnB1c2goR2xvYmFsRW51bS5VSS5nZXRQb3dlcik7XG4gICAgICAgIHRoaXMucGVyc2lzdFVJcy5wdXNoKEdsb2JhbEVudW0uVUkuY29uZmlnU2V0dGluZyk7XG5cbiAgICB9XG5cbiAgICAvKirlhbPljaHnrqHnkIblmaggKi9cbiAgICBwcm90ZWN0ZWQgbGV2ZWxNbmcgPSBudWxsO1xuXG4gICAgLy8jcmVnaW9uIFVJ5Yqo5L2c566h55CG5ZmoXG4gICAgcHJvdGVjdGVkIHVpQWN0TW5nOiBBY3Rpb24zZE1hbmFnZXIgPSBudWxsO1xuICAgIHByb3RlY3RlZCBpbml0QWN0TW5nKCkge1xuICAgICAgICB0aGlzLnVpQWN0TW5nID0gQWN0aW9uM2RNYW5hZ2VyLmdldE1uZyhBY3Rpb25NbmdUeXBlLlVJKTtcbiAgICB9XG4gICAgLy8jZW5kcmVnaW9uXG5cbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5ri45oiP5rWB56iLKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIC8vI3JlZ2lvbiDohJrmnKzpgJrnlKjmtYHnqItcbiAgICBwdWJsaWMgaW5pdCgpIHtcbiAgICAgICAgdGhpcy5pbml0VUlDb25maWcoKTtcbiAgICAgICAgdGhpcy5pbml0QWN0TW5nKCk7XG4gICAgICAgIHRoaXMuaW5pdFRvdWNoTWFzaygpO1xuICAgICAgICB0aGlzLmluaXRNb2RlbHMoKTtcbiAgICAgICAgdGhpcy5pbml0RGVmYXVsdFVJcygpO1xuXG4gICAgICAgIHRoaXMub25FdmVudHMoKTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgaW5pdE1vZGVscygpIHtcbiAgICAgICAgLy/kupLmjqhcbiAgICAgICAgbGV0IG5vZGUgPSB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJSZWNvbW1lbmRcIik7XG4gICAgICAgIGlmICghIW5vZGUgJiYgbm9kZS5hY3RpdmUpIHtcbiAgICAgICAgICAgIFJlY29tbWVuZE1hbmFnZXIuaW5pdChub2RlKTtcbiAgICAgICAgfVxuICAgICAgICAvL+W5v+WRilxuICAgICAgICAvLyBBZHZlcnRNYW5hZ2VyLmluaXQoKTtcbiAgICAgICAgLy9VSVxuICAgICAgICBVSU1hbmFnZXIuaW5pdCh0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJVSVwiKSk7XG5cbiAgICAgICAgLy90b2RvOua1i+ivle+8mumHjee9rueOqeWutuaVsOaNru+8jOmcgOimgeWGjeasoemHjee9ruaXtu+8jOWwhm5lZWRSZXNldFBsYXllckRhdGHlrZfnrKbkuLLmnIDlkI7kuIDkvY3mlbDlrZfliqAxXG4gICAgICAgIGxldCByZXNldFBsYXllckRhdGEgPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oR2FtZUNvbmZpZy5nYW1lTmFtZSArIFwibmVlZFJlc2V0UGxheWVyRGF0YTFcIik7XG4gICAgICAgIGlmICghcmVzZXRQbGF5ZXJEYXRhKSB7XG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oR2FtZUNvbmZpZy5nYW1lTmFtZSArIFwibmVlZFJlc2V0UGxheWVyRGF0YTFcIiwgSlNPTi5zdHJpbmdpZnkodHJ1ZSkpO1xuICAgICAgICB9XG4gICAgICAgIFBsYXllckRhdGEuaW5pdCgpO1xuXG4gICAgICAgIEF1ZGlvTWFuYWdlci5pbml0KCk7XG4gICAgICAgIEdhbWVEYXRhLmluaXQoKTtcbiAgICAgICAgUG93ZXJNYW5hZ2VyLmluaXQoKTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgb25FdmVudHMoKSB7XG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQuc3RhcnRHYW1lLCB0aGlzLm9uU3RhcnRHYW1lLCB0aGlzKTtcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5lbnRlckxvYmJ5LCB0aGlzLmVudGVyR2FtZUxvYmJ5LCB0aGlzKTtcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5wbGF5TmV4dExldmVsLCB0aGlzLm9uUGxheU5leHRMZXZlbCwgdGhpcyk7XG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQucmVwbGF5Q3VyTGV2ZWwsIHRoaXMub25SZXBsYXlDdXJMZXZlbCwgdGhpcyk7XG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQucGxheWVyV2luLCB0aGlzLm9uTGV2ZWxXaW4sIHRoaXMpO1xuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LnBsYXllckxvc2UsIHRoaXMub25MZXZlbExvc2UsIHRoaXMpO1xuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LmhpZGVHYW1lTG9iYnksIHRoaXMuaGlkZUdhbWVMb2JieVVJLCB0aGlzKTtcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5jaG9vc2VUcnlTa2luRmluaXNoLCB0aGlzLm9uQ2hvb3NlVHJ5U2tpbkZpbmlzaCwgdGhpcyk7XG5cbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuVUlFdmVudC5zaG93VG91Y2hNYXNrLCB0aGlzLnNob3dUb3VjaE1hc2ssIHRoaXMpO1xuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5VSUV2ZW50LmhpZGVUb3VjaE1hc2ssIHRoaXMuaGlkZVRvdWNoTWFzaywgdGhpcyk7XG4gICAgfVxuXG4gICAgcHVibGljIHJlc2V0KCkge1xuICAgICAgICB0aGlzLmV4aXRMZXZlbCgpO1xuICAgICAgICB0aGlzLnJlc2V0VG91Y2hNYXNrKCk7XG4gICAgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLy8jcmVnaW9uIOa4uOaIj+aVsOaNruWKoOi9vVxuICAgIC8qKuWKoOi9veWFqOmDqOa4uOaIj+aVsOaNru+8iGpzb27mlofku7bvvIkgKi9cbiAgICBwcm90ZWN0ZWQgbG9hZEdhbWVEYXRhKCkge1xuICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZShcIkdhbWVEYXRhXCIsICgpID0+IHtcbiAgICAgICAgICAgIExvYWRlci5sb2FkQnVuZGxlRGlyKFwiR2FtZURhdGFcIiwgXCJKU09ORGF0YVwiLCAocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IHVybHMgPSBbXTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgYyA9IHJlcy5sZW5ndGg7IGkgPCBjOyArK2kpIHtcbiAgICAgICAgICAgICAgICAgICAgdXJscy5wdXNoKHJlc1tpXS5uYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgR2FtZURhdGEuc2V0RGF0YShyZXMsIHVybHMpO1xuICAgICAgICAgICAgICAgIHRoaXMuZW50ZXJHYW1lTG9iYnkoKTtcbiAgICAgICAgICAgIH0sIGNjLkpzb25Bc3NldCwgdHJ1ZSk7XG4gICAgICAgIH0sIHRydWUsIHRydWUpO1xuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDmuLjmiI/mtYHnqIvvvJrov5vlhaUv6YCA5Ye66aaW6aG1XG4gICAgLy/ov5vlhaXpppbpobVcbiAgICBwcm90ZWN0ZWQgZW50ZXJHYW1lTG9iYnkoKSB7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxNbmcpIHtcbiAgICAgICAgICAgIHRoaXMubGV2ZWxNbmcuZXhpdCgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2hvd0dhbWVMb2JieVVJKCk7XG4gICAgfVxuICAgIC8v5pi+56S66aaW6aG1VUlcbiAgICBwcm90ZWN0ZWQgc2hvd0dhbWVMb2JieVVJKCkge1xuICAgICAgICB0aGlzLmhpZGVVSXModGhpcy5sZXZlbFVJcyk7XG4gICAgICAgIHRoaXMuaGlkZVVJcyh0aGlzLnBlcnNpc3RVSXMpO1xuICAgICAgICB0aGlzLnNob3dVSShHbG9iYWxFbnVtLlVJLmxvYmJ5KTtcbiAgICAgICAgdGhpcy5zaG93VUkoR2xvYmFsRW51bS5VSS5wbGF5ZXJBc3NldEJhcik7XG4gICAgfVxuICAgIC8v6ZqQ6JeP6aaW6aG1VUkgXG4gICAgcHJvdGVjdGVkIGhpZGVHYW1lTG9iYnlVSSgpIHtcbiAgICAgICAgdGhpcy5oaWRlVUlzKHRoaXMubG9iYnlVSXMpO1xuICAgICAgICB0aGlzLmhpZGVVSXModGhpcy5wZXJzaXN0VUlzKTtcbiAgICAgICAgdGhpcy5oaWRlVUkoR2xvYmFsRW51bS5VSS5sb2JieSk7XG4gICAgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLy8jcmVnaW9uIOa4uOaIj+a1geeoi++8mui/m+WFpeWFs+WNoVxuICAgIC8v5byA5aeL5ri45oiP77yaXG4gICAgcHJvdGVjdGVkIG9uU3RhcnRHYW1lKCkge1xuICAgICAgICBpZiAoIXRoaXMubGV2ZWxNbmcpIHtcbiAgICAgICAgICAgIExvYWRlci5sb2FkQnVuZGxlKFwiTGV2ZWxTY2VuZVwiLCB0aGlzLmxvYWRMZXZlbENvbW1vbkFzc2V0LmJpbmQodGhpcyksIHRydWUsIHRydWUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5lbnRlckxldmVsKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy/liqDovb3lhbPljaHlnLrmma/miYDpnIDnmoTpgJrnlKjotYTmupDlubbliJvlu7rlr7nosaHmsaBcbiAgICBwcm90ZWN0ZWQgbG9hZExldmVsQ29tbW9uQXNzZXQoKSB7XG4gICAgICAgIExvYWRlci5sb2FkQnVuZGxlRGlyKFwiTGV2ZWxTY2VuZVwiLCBcIk11bHRpcGxlUHJlZmFiXCIsIChhc3NldHMpID0+IHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSBhc3NldHMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgICAgICBsZXQgcHJlZmFiOiBjYy5QcmVmYWIgPSBhc3NldHNbaV07XG4gICAgICAgICAgICAgICAgR2xvYmFsUG9vbC5jcmVhdGVQb29sKHByZWZhYi5uYW1lLCBwcmVmYWIsIHByZWZhYi5uYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMubG9hZExldmVsTWFuYWdlcigpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgLy/liqDovb3lhbPljaHlnLrmma/nrqHnkIblmahcbiAgICBwcm90ZWN0ZWQgbG9hZExldmVsTWFuYWdlcigpIHtcbiAgICAgICAgTG9hZGVyLmxvYWRCdW5kbGVSZXMoXCJMZXZlbFNjZW5lXCIsIFwiU2luZ2xlUHJlZmFiL0xldmVsTWFuYWdlclwiLCAocmVzKSA9PiB7XG4gICAgICAgICAgICBsZXQgbm9kZTogY2MuTm9kZSA9IGNjLmluc3RhbnRpYXRlKHJlcyk7XG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJMZXZlbE1hbmFnZXJcIikuYWRkQ2hpbGQobm9kZSk7XG4gICAgICAgICAgICB0aGlzLmxldmVsTW5nID0gbm9kZS5nZXRDb21wb25lbnQoXCJMZXZlbE1hbmFnZXJcIik7XG4gICAgICAgICAgICB0aGlzLmxldmVsTW5nLmluaXQoKTtcbiAgICAgICAgICAgIHRoaXMuZW50ZXJMZXZlbCgpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgLy/ov5vlhaXlhbPljaFcbiAgICBwcm90ZWN0ZWQgZW50ZXJMZXZlbChsZXZlbD86IG51bWJlcikge1xuICAgICAgICBpZiAoIWxldmVsKSB7XG4gICAgICAgICAgICBsZXZlbCA9IHRoaXMuZ2V0Q3VyTGV2ZWwoKTtcbiAgICAgICAgfVxuICAgICAgICAvL+i/m+WFpeWFs+WNoTpcbiAgICAgICAgdGhpcy5oaWRlR2FtZUxvYmJ5VUkoKTtcbiAgICAgICAgdGhpcy5oaWRlVUlzKHRoaXMubGV2ZWxVSXMpO1xuICAgICAgICBsZXQgbGV2ZWxEYXRhID0gdGhpcy5nZXRMZXZlbERhdGEobGV2ZWwpO1xuICAgICAgICB0aGlzLmxldmVsTW5nLmVudGVyTGV2ZWwobGV2ZWxEYXRhKTtcbiAgICAgICAgdGhpcy5zaG93VUkoR2xvYmFsRW51bS5VSS5sZXZlbEluZm8sIGxldmVsRGF0YSk7XG4gICAgICAgIHRoaXMuc2hvd1VJKEdsb2JhbEVudW0uVUkucGxheWVyQXNzZXRCYXIpO1xuICAgICAgICAvLyB0aGlzLnNob3dUZWFjaEFuaW0oKTtcbiAgICAgICAgLy8gdGhpcy5zaG93VHJ5U2tpbigpO1xuICAgIH1cblxuICAgIC8v6I635Y+W546p5a625b2T5YmN6IO96L+b5YWl55qE5YWz5Y2hXG4gICAgcHJvdGVjdGVkIGdldEN1ckxldmVsKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiBQbGF5ZXJEYXRhLmdldERhdGEoXCJnYW1lRGF0YS5jdXJMZXZlbFwiKTtcbiAgICB9XG4gICAgLy/ojrflj5blhbPljaHmlbDmja5cbiAgICBwcm90ZWN0ZWQgZ2V0TGV2ZWxEYXRhKGxldmVsOiBudW1iZXIpIHtcbiAgICAgICAgLy8gbGV2ZWwgPSAyO1xuICAgICAgICBsZXQgZGF0YSA9IEdhbWVEYXRhLmdldExldmVsRGF0YShsZXZlbCk7XG4gICAgICAgIC8vIGxldCBkYXRhID0gR2FtZURhdGEuZ2V0TGV2ZWxEYXRhKDE0KTtcbiAgICAgICAgZGF0YS5pZCA9IGxldmVsO1xuICAgICAgICBkYXRhLmx2ID0gbGV2ZWw7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cblxuICAgIC8v55qu6IKk6K+V55So55WM6Z2iXG4gICAgcHJvdGVjdGVkIHNob3dUcnlTa2luKCkge1xuICAgICAgICB0aGlzLnBhdXNlTGV2ZWwoKTtcbiAgICAgICAgdGhpcy5zaG93VUkoR2xvYmFsRW51bS5VSS50cnlTa2luLCBHbG9iYWxFbnVtLkdvb2RzVHlwZS5wbGF5ZXJTa2luKTtcbiAgICB9XG4gICAgLy/or5XnlKjnmq7ogqTmtYHnqIvnu5PmnZ8o5LiN6K66546p5a625piv5ZCm6YCJ5oup5LqG6K+V55So55qu6IKkKVxuICAgIHByb3RlY3RlZCBvbkNob29zZVRyeVNraW5GaW5pc2goKSB7XG4gICAgICAgIHRoaXMuaGlkZVVJKEdsb2JhbEVudW0uVUkudHJ5U2tpbik7XG4gICAgICAgIHRoaXMuc2hvd1RlYWNoQW5pbSgpO1xuICAgIH1cblxuICAgIC8v5pi+56S65pWZ5a2m5Yqo55S7XG4gICAgcHJvdGVjdGVkIHNob3dUZWFjaEFuaW0oKSB7XG4gICAgICAgIC8vIGxldCB0ZWFjaGVkID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKEdhbWVDb25maWcuZ2FtZU5hbWUgKyBcInRlYWNoZWRcIik7XG4gICAgICAgIC8vIGlmICghIXRlYWNoZWQgJiYgISFKU09OLnBhcnNlKHRlYWNoZWQpKSByZXR1cm47XG4gICAgICAgIHRoaXMucGF1c2VMZXZlbCgpO1xuICAgICAgICB0aGlzLnNob3dVSShHbG9iYWxFbnVtLlVJLmxldmVsVGVhY2gpO1xuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDmuLjmiI/mtYHnqIvvvJrlhbPljaHog5zliKlcbiAgICAvL+WFs+WNoeiDnOWIqVxuICAgIHByb3RlY3RlZCBvbkxldmVsV2luKCkge1xuICAgICAgICB0aGlzLmFkZEN1ckxldmVsKCk7XG4gICAgICAgIHRoaXMuc2hvd1VJKEdsb2JhbEVudW0uVUkucGxheWVyQXNzZXRCYXIpO1xuICAgICAgICB0aGlzLnNob3dVSShHbG9iYWxFbnVtLlVJLndpblVJKTtcbiAgICB9XG4gICAgLy/lhbPljaHov5vluqYrMVxuICAgIHByb3RlY3RlZCBhZGRDdXJMZXZlbCgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5QbGF5ZXJEYXRhRXZlbnQudXBkYXRlUGxheWVyRGF0YSwge1xuICAgICAgICAgICAgdHlwZTogXCJnYW1lRGF0YVwiLFxuICAgICAgICAgICAgYXR0cmlidXRlOiBcImdhbWVEYXRhLmN1ckxldmVsXCIsXG4gICAgICAgICAgICB2YWx1ZTogMSxcbiAgICAgICAgICAgIG1vZGU6IFwiK1wiLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLy8jZW5kcmVnaW9uXG5cbiAgICAvLyNyZWdpb24g5ri45oiP5rWB56iL77ya6IOc5Yip5ZCO57un57ut5LiL5LiA5YWzXG4gICAgLy/nu6fnu63kuIvkuIDlhbNcbiAgICBwcm90ZWN0ZWQgb25QbGF5TmV4dExldmVsKCkge1xuICAgICAgICB0aGlzLmV4aXRDdXJMZXZlbCgpO1xuICAgICAgICB0aGlzLnB1dEJhY2tDdXJMZXZlbEFzc2V0KCk7XG4gICAgICAgIHRoaXMuZW50ZXJMZXZlbCgpO1xuICAgIH1cbiAgICAvL+mAgOWHuuW9k+WJjeWFs+WNoVxuICAgIHByb3RlY3RlZCBleGl0Q3VyTGV2ZWwoKSB7XG4gICAgICAgIHRoaXMubGV2ZWxNbmcuZXhpdCgpO1xuICAgIH1cbiAgICAvL+WbnuaUtuW9k+WJjeWFs+WNoeS9v+eUqOeahOi1hOa6kFxuICAgIHByb3RlY3RlZCBwdXRCYWNrQ3VyTGV2ZWxBc3NldCgpIHtcblxuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDmuLjmiI/mtYHnqIvvvJrlhbPljaHlpLHotKVcbiAgICAvL+WFs+WNoeWksei0pVxuICAgIHByb3RlY3RlZCBvbkxldmVsTG9zZSgpIHtcbiAgICAgICAgdGhpcy5zaG93VUkoR2xvYmFsRW51bS5VSS5wbGF5ZXJBc3NldEJhcik7XG4gICAgICAgIHRoaXMuc2hvd1VJKEdsb2JhbEVudW0uVUkubG9zZVVJKTtcbiAgICB9XG4gICAgLy8jZW5kcmVnaW9uXG5cbiAgICAvLyNyZWdpb24g5ri45oiP5rWB56iL77ya5aSx6LSl5ZCO6YeN546pXG4gICAgLy/ph43njqnlvZPliY3lhbPljaFcbiAgICBwcm90ZWN0ZWQgb25SZXBsYXlDdXJMZXZlbCgpIHtcbiAgICAgICAgdGhpcy5yZXNldEN1ckxldmVsKCk7XG4gICAgICAgIHRoaXMucHV0QmFja0N1ckxldmVsQXNzZXQoKTtcbiAgICAgICAgdGhpcy5lbnRlckxldmVsKCk7XG4gICAgfVxuICAgIC8v6YeN572u5b2T5YmN5YWz5Y2h54q25oCBXG4gICAgcHJvdGVjdGVkIHJlc2V0Q3VyTGV2ZWwoKSB7XG4gICAgICAgIHRoaXMubGV2ZWxNbmcucmVzZXQoKTtcbiAgICB9XG4gICAgLy8jZW5kcmVnaW9uXG5cbiAgICAvLyNyZWdpb24g5ri45oiP5rWB56iL77ya6L+U5Zue6aaW6aG1XG4gICAgLy/ov5Tlm57pppbpobVcbiAgICBwcm90ZWN0ZWQgb25Db21lQmFja0dhbWVMb2JieSgpIHtcbiAgICAgICAgdGhpcy5leGl0TGV2ZWwoKTtcbiAgICAgICAgdGhpcy5wdXRCYWNrTGV2ZWxBc3NldCgpO1xuICAgICAgICB0aGlzLnNob3dHYW1lTG9iYnlVSSgpO1xuICAgIH1cbiAgICAvL+W9u+W6lemAgOWHuuWFs+WNoeWcuuaZr1xuICAgIHByb3RlY3RlZCBleGl0TGV2ZWwoKSB7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxNbmcpIHRoaXMubGV2ZWxNbmcuZXhpdCgpO1xuICAgIH1cbiAgICAvL+WbnuaUtuWFs+WNoeWcuuaZr+eahOWFqOmDqOi1hOa6kFxuICAgIHByb3RlY3RlZCBwdXRCYWNrTGV2ZWxBc3NldCgpIHtcblxuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxufVxuIl19