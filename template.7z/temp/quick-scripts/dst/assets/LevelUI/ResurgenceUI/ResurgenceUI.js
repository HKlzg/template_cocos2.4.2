
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LevelUI/ResurgenceUI/ResurgenceUI.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '537ef5L6LZFSoQ2QezJLHX7', 'ResurgenceUI');
// LevelUI/ResurgenceUI/ResurgenceUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ResurgenceUI = /** @class */ (function (_super) {
    __extends(ResurgenceUI, _super);
    function ResurgenceUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btnCancel = null;
        _this.curScore = null;
        _this.maxScore = null;
        _this.timer = null;
        _this.t = 0;
        return _this;
    }
    ResurgenceUI.prototype.init = function () {
        this.initComponents();
        this.initTimer();
        this.hideBtnCancel();
    };
    ResurgenceUI.prototype.reset = function () {
        this.resetTimer();
        this.hideBtnCancel();
        this.unschedule(this.showBtnCancel);
    };
    ResurgenceUI.prototype.hideBtnCancel = function () {
        this.btnCancel.active = false;
    };
    ResurgenceUI.prototype.showBtnCancel = function () {
        this.btnCancel.active = true;
    };
    ResurgenceUI.prototype.initTimer = function () {
    };
    ResurgenceUI.prototype.resetTimer = function () {
        this.t = 10;
        this.timer.string = this.t.toString();
        this.stopTimer();
    };
    ResurgenceUI.prototype.updateTimer = function () {
        this.t -= 1;
        if (this.t <= 0) {
            this.t = 0;
            this.waitingTimeOver();
        }
        this.timer.string = this.t.toString();
    };
    ResurgenceUI.prototype.waitingTimeOver = function () {
        this.stopTimer();
        this.cancelFuHuo();
    };
    ResurgenceUI.prototype.startTimer = function () {
        this.schedule(this.updateTimer, 1);
    };
    ResurgenceUI.prototype.stopTimer = function () {
        this.unschedule(this.updateTimer);
    };
    ResurgenceUI.prototype.show = function () {
        this.node.active = true;
        this.reset();
        this.scheduleOnce(this.showBtnCancel, 2);
        this.startTimer();
        // let v = PlayerData.getData("gameData.maxScore");
        // this.maxScore.string = v.toString();
        // let ui = UIManager.getUI(GlobalEnum.UI.levelInfo);
        // let data = ui.getData();
        // this.curScore.string = data.gold.toString();
    };
    ResurgenceUI.prototype.onBtnFuHuo = function () {
        this.stopTimer();
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, {
            success: this.fuHuo.bind(this),
            fail: this.startTimer.bind(this),
            quit: this.startTimer.bind(this),
        });
    };
    ResurgenceUI.prototype.onBtnCancel = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.cancelFuHuo();
    };
    ResurgenceUI.prototype.cancelFuHuo = function () {
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.resurgence);
        this.emit(GameEventType_1.EventType.LevelEvent.cancelResurgence);
    };
    ResurgenceUI.prototype.fuHuo = function () {
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.resurgence);
        this.emit(GameEventType_1.EventType.LevelEvent.resurgence);
    };
    __decorate([
        property(cc.Node)
    ], ResurgenceUI.prototype, "btnCancel", void 0);
    __decorate([
        property(cc.Label)
    ], ResurgenceUI.prototype, "curScore", void 0);
    __decorate([
        property(cc.Label)
    ], ResurgenceUI.prototype, "maxScore", void 0);
    __decorate([
        property(cc.Label)
    ], ResurgenceUI.prototype, "timer", void 0);
    ResurgenceUI = __decorate([
        ccclass
    ], ResurgenceUI);
    return ResurgenceUI;
}(yyComponent_1.default));
exports.default = ResurgenceUI;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxVSVxcUmVzdXJnZW5jZVVJXFxSZXN1cmdlbmNlVUkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBQzFELHdFQUFtRTtBQUduRSxrRUFBaUU7QUFFM0QsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBMEMsZ0NBQVc7SUFBckQ7UUFBQSxxRUE0RkM7UUE5RWEsZUFBUyxHQUFZLElBQUksQ0FBQztRQVMxQixjQUFRLEdBQWEsSUFBSSxDQUFDO1FBRTFCLGNBQVEsR0FBYSxJQUFJLENBQUM7UUFHMUIsV0FBSyxHQUFhLElBQUksQ0FBQztRQUN2QixPQUFDLEdBQVcsQ0FBQyxDQUFDOztJQStENUIsQ0FBQztJQTFGVSwyQkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUNNLDRCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFJUyxvQ0FBYSxHQUF2QjtRQUNJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ1Msb0NBQWEsR0FBdkI7UUFDSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7SUFDakMsQ0FBQztJQVVTLGdDQUFTLEdBQW5CO0lBRUEsQ0FBQztJQUNTLGlDQUFVLEdBQXBCO1FBQ0ksSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDWixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBQ1Msa0NBQVcsR0FBckI7UUFDSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNaLElBQUksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDYixJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNYLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztTQUMxQjtRQUNELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDMUMsQ0FBQztJQUNTLHNDQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBQ1MsaUNBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNTLGdDQUFTLEdBQW5CO1FBQ0ksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVNLDJCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDeEIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUVsQixtREFBbUQ7UUFDbkQsdUNBQXVDO1FBQ3ZDLHFEQUFxRDtRQUNyRCwyQkFBMkI7UUFDM0IsK0NBQStDO0lBQ25ELENBQUM7SUFFUyxpQ0FBVSxHQUFwQjtRQUNJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFO1lBQ3BDLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDOUIsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNoQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ25DLENBQUMsQ0FBQztJQUNQLENBQUM7SUFDUyxrQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFUyxrQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLHVCQUFVLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzVELElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBQ1MsNEJBQUssR0FBZjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLHVCQUFVLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzVELElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQTdFRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO21EQUNrQjtJQVNwQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO2tEQUNpQjtJQUVwQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO2tEQUNpQjtJQUdwQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDOytDQUNjO0lBNUJoQixZQUFZO1FBRGhDLE9BQU87T0FDYSxZQUFZLENBNEZoQztJQUFELG1CQUFDO0NBNUZELEFBNEZDLENBNUZ5QyxxQkFBVyxHQTRGcEQ7a0JBNUZvQixZQUFZIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHl5Q29tcG9uZW50IGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL3l5Q29tcG9uZW50XCI7XHJcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2FtZUV2ZW50VHlwZVwiO1xyXG5pbXBvcnQgUGxheWVyRGF0YSBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9QbGF5ZXJEYXRhXCI7XHJcbmltcG9ydCBVSU1hbmFnZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vVUlNYW5hZ2VyXCI7XHJcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZXN1cmdlbmNlVUkgZXh0ZW5kcyB5eUNvbXBvbmVudCB7XHJcblxyXG4gICAgcHVibGljIGluaXQoKSB7XHJcbiAgICAgICAgdGhpcy5pbml0Q29tcG9uZW50cygpO1xyXG4gICAgICAgIHRoaXMuaW5pdFRpbWVyKCk7XHJcbiAgICAgICAgdGhpcy5oaWRlQnRuQ2FuY2VsKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgcmVzZXQoKSB7XHJcbiAgICAgICAgdGhpcy5yZXNldFRpbWVyKCk7XHJcbiAgICAgICAgdGhpcy5oaWRlQnRuQ2FuY2VsKCk7XHJcbiAgICAgICAgdGhpcy51bnNjaGVkdWxlKHRoaXMuc2hvd0J0bkNhbmNlbCk7XHJcbiAgICB9XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgYnRuQ2FuY2VsOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIHByb3RlY3RlZCBoaWRlQnRuQ2FuY2VsKCkge1xyXG4gICAgICAgIHRoaXMuYnRuQ2FuY2VsLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHNob3dCdG5DYW5jZWwoKSB7XHJcbiAgICAgICAgdGhpcy5idG5DYW5jZWwuYWN0aXZlID0gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXHJcbiAgICBwcm90ZWN0ZWQgY3VyU2NvcmU6IGNjLkxhYmVsID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcclxuICAgIHByb3RlY3RlZCBtYXhTY29yZTogY2MuTGFiZWwgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcclxuICAgIHByb3RlY3RlZCB0aW1lcjogY2MuTGFiZWwgPSBudWxsO1xyXG4gICAgcHJvdGVjdGVkIHQ6IG51bWJlciA9IDA7XHJcbiAgICBwcm90ZWN0ZWQgaW5pdFRpbWVyKCkge1xyXG5cclxuICAgIH1cclxuICAgIHByb3RlY3RlZCByZXNldFRpbWVyKCkge1xyXG4gICAgICAgIHRoaXMudCA9IDEwO1xyXG4gICAgICAgIHRoaXMudGltZXIuc3RyaW5nID0gdGhpcy50LnRvU3RyaW5nKCk7XHJcbiAgICAgICAgdGhpcy5zdG9wVGltZXIoKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCB1cGRhdGVUaW1lcigpIHtcclxuICAgICAgICB0aGlzLnQgLT0gMTtcclxuICAgICAgICBpZiAodGhpcy50IDw9IDApIHtcclxuICAgICAgICAgICAgdGhpcy50ID0gMDtcclxuICAgICAgICAgICAgdGhpcy53YWl0aW5nVGltZU92ZXIoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy50aW1lci5zdHJpbmcgPSB0aGlzLnQudG9TdHJpbmcoKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCB3YWl0aW5nVGltZU92ZXIoKSB7XHJcbiAgICAgICAgdGhpcy5zdG9wVGltZXIoKTtcclxuICAgICAgICB0aGlzLmNhbmNlbEZ1SHVvKCk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc3RhcnRUaW1lcigpIHtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKHRoaXMudXBkYXRlVGltZXIsIDEpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHN0b3BUaW1lcigpIHtcclxuICAgICAgICB0aGlzLnVuc2NoZWR1bGUodGhpcy51cGRhdGVUaW1lcik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNob3coKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5yZXNldCgpO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKHRoaXMuc2hvd0J0bkNhbmNlbCwgMik7XHJcbiAgICAgICAgdGhpcy5zdGFydFRpbWVyKCk7XHJcblxyXG4gICAgICAgIC8vIGxldCB2ID0gUGxheWVyRGF0YS5nZXREYXRhKFwiZ2FtZURhdGEubWF4U2NvcmVcIik7XHJcbiAgICAgICAgLy8gdGhpcy5tYXhTY29yZS5zdHJpbmcgPSB2LnRvU3RyaW5nKCk7XHJcbiAgICAgICAgLy8gbGV0IHVpID0gVUlNYW5hZ2VyLmdldFVJKEdsb2JhbEVudW0uVUkubGV2ZWxJbmZvKTtcclxuICAgICAgICAvLyBsZXQgZGF0YSA9IHVpLmdldERhdGEoKTtcclxuICAgICAgICAvLyB0aGlzLmN1clNjb3JlLnN0cmluZyA9IGRhdGEuZ29sZC50b1N0cmluZygpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBvbkJ0bkZ1SHVvKCkge1xyXG4gICAgICAgIHRoaXMuc3RvcFRpbWVyKCk7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5TREtFdmVudC5zaG93VmlkZW8sIHtcclxuICAgICAgICAgICAgc3VjY2VzczogdGhpcy5mdUh1by5iaW5kKHRoaXMpLFxyXG4gICAgICAgICAgICBmYWlsOiB0aGlzLnN0YXJ0VGltZXIuYmluZCh0aGlzKSxcclxuICAgICAgICAgICAgcXVpdDogdGhpcy5zdGFydFRpbWVyLmJpbmQodGhpcyksXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgb25CdG5DYW5jZWwoKSB7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XHJcbiAgICAgICAgdGhpcy5jYW5jZWxGdUh1bygpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBjYW5jZWxGdUh1bygpIHtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuZXhpdCwgR2xvYmFsRW51bS5VSS5yZXN1cmdlbmNlKTtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkxldmVsRXZlbnQuY2FuY2VsUmVzdXJnZW5jZSk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgZnVIdW8oKSB7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmV4aXQsIEdsb2JhbEVudW0uVUkucmVzdXJnZW5jZSk7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5MZXZlbEV2ZW50LnJlc3VyZ2VuY2UpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==