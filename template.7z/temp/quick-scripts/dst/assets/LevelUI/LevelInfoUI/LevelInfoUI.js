
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LevelUI/LevelInfoUI/LevelInfoUI.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4393ap5mKNKOIGdbWF8MM3a', 'LevelInfoUI');
// LevelUI/LevelInfoUI/LevelInfoUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
//关卡进度分数等信息UI
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LevelInfoUI = /** @class */ (function (_super) {
    __extends(LevelInfoUI, _super);
    function LevelInfoUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /****************************************管理对象****************************************/
        //#region 关卡进度
        _this.curLevelLabel = null;
        _this.nextLevelLabel = null;
        //关卡进度
        _this.levelProgressBar = null;
        //#endregion
        //#region 金币
        _this.curGoldLabel = null;
        _this.curGold = 0;
        return _this;
    }
    Object.defineProperty(LevelInfoUI.prototype, "uiType", {
        get: function () { return GlobalEnum_1.GlobalEnum.UI.levelInfo; },
        enumerable: false,
        configurable: true
    });
    LevelInfoUI.prototype.init = function () {
        this.initCurGold();
        this.initComponents();
        this.initProgress();
        this.onEvents();
    };
    LevelInfoUI.prototype.onEvents = function () {
    };
    LevelInfoUI.prototype.reset = function () {
        this.resetCurGold();
        this.resetProgress();
    };
    LevelInfoUI.prototype.show = function (levelData) {
        this.node.active = true;
        this.reset();
        this.setData(levelData);
    };
    LevelInfoUI.prototype.hide = function () {
        this.reset();
        this.node.active = false;
    };
    LevelInfoUI.prototype.getData = function () {
        return {
            speGold: 0,
            gold: this.curGold,
        };
    };
    LevelInfoUI.prototype.setData = function (data) {
        if (!!this.curLevelLabel)
            this.curLevelLabel.string = data.lv.toString();
        if (!!this.nextLevelLabel)
            this.nextLevelLabel.string = (data.lv + 1).toString();
    };
    LevelInfoUI.prototype.convertToString = function (v) {
        if (v < 1100)
            return v.toString();
        if (v < 1100000)
            return (v * 0.001).toFixed(1) + "K";
        return (v * 0.000001).toFixed(1) + "M";
    };
    LevelInfoUI.prototype.initProgress = function () {
        if (!!this.levelProgressBar)
            this.levelProgressBar.progress = 0;
    };
    LevelInfoUI.prototype.resetProgress = function () {
        if (!!this.levelProgressBar)
            this.levelProgressBar.progress = 0;
    };
    LevelInfoUI.prototype.setProgress = function (r) {
        if (!!this.levelProgressBar)
            this.levelProgressBar.progress = r;
    };
    LevelInfoUI.prototype.initCurGold = function () {
        this.curGold = 0;
        this.curGoldLabel.string = this.curGold.toString();
    };
    LevelInfoUI.prototype.resetCurGold = function () {
        this.curGold = 0;
        this.curGoldLabel.string = this.curGold.toString();
    };
    LevelInfoUI.prototype.addCurGold = function (v) {
        this.curGold += v;
        this.curGoldLabel.string = this.curGold.toString();
    };
    LevelInfoUI.prototype.onPlayerCollGold = function (count) {
        this.addCurGold(1);
    };
    //#endregion
    /**设置按钮 */
    LevelInfoUI.prototype.onBtnConfigSetting = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.UIEvent.enter, GlobalEnum_1.GlobalEnum.UI.configSetting);
    };
    /**暂停按钮 */
    LevelInfoUI.prototype.onBtnPause = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.UIEvent.enter, GlobalEnum_1.GlobalEnum.UI.pauseLevel);
    };
    //测试用：重置关卡
    LevelInfoUI.prototype.onBtnReplay = function () {
        this.emit(GameEventType_1.EventType.DirectorEvent.replayCurLevel);
    };
    //测试用：返回首页
    LevelInfoUI.prototype.onBtnLobby = function () {
        this.emit(GameEventType_1.EventType.DirectorEvent.enterLobby);
    };
    LevelInfoUI.prototype.onBtnWin = function () {
        this.emit(GameEventType_1.EventType.LevelEvent.testWin);
    };
    LevelInfoUI.prototype.onBtnLose = function () {
        this.emit(GameEventType_1.EventType.LevelEvent.testLose);
    };
    __decorate([
        property(cc.Label)
    ], LevelInfoUI.prototype, "curLevelLabel", void 0);
    __decorate([
        property(cc.Label)
    ], LevelInfoUI.prototype, "nextLevelLabel", void 0);
    __decorate([
        property(cc.ProgressBar)
    ], LevelInfoUI.prototype, "levelProgressBar", void 0);
    __decorate([
        property(cc.Label)
    ], LevelInfoUI.prototype, "curGoldLabel", void 0);
    LevelInfoUI = __decorate([
        ccclass
    ], LevelInfoUI);
    return LevelInfoUI;
}(yyComponent_1.default));
exports.default = LevelInfoUI;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxVSVxcTGV2ZWxJbmZvVUlcXExldmVsSW5mb1VJLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLCtEQUEwRDtBQUMxRCxrRUFBaUU7QUFDakUsd0VBQW1FO0FBSW5FLGFBQWE7QUFDUCxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUF5QywrQkFBVztJQUFwRDtRQUFBLHFFQXFIQztRQXRFRyxzRkFBc0Y7UUFDdEYsY0FBYztRQUVKLG1CQUFhLEdBQWEsSUFBSSxDQUFDO1FBRy9CLG9CQUFjLEdBQWEsSUFBSSxDQUFDO1FBQzFDLE1BQU07UUFFSSxzQkFBZ0IsR0FBbUIsSUFBSSxDQUFDO1FBVWxELFlBQVk7UUFFWixZQUFZO1FBRUYsa0JBQVksR0FBYSxJQUFJLENBQUM7UUFDOUIsYUFBTyxHQUFXLENBQUMsQ0FBQzs7SUE4Q2xDLENBQUM7SUFuSEcsc0JBQVcsK0JBQU07YUFBakIsY0FBc0IsT0FBTyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUVoRCwwQkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFDUyw4QkFBUSxHQUFsQjtJQUVBLENBQUM7SUFFTSwyQkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRU0sMEJBQUksR0FBWCxVQUFZLFNBQWM7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUNNLDBCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUVNLDZCQUFPLEdBQWQ7UUFDSSxPQUFPO1lBQ0gsT0FBTyxFQUFFLENBQUM7WUFDVixJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU87U0FDckIsQ0FBQztJQUNOLENBQUM7SUFFUyw2QkFBTyxHQUFqQixVQUFrQixJQUFTO1FBQ3ZCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhO1lBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUN6RSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYztZQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNyRixDQUFDO0lBRVMscUNBQWUsR0FBekIsVUFBMEIsQ0FBUztRQUMvQixJQUFJLENBQUMsR0FBRyxJQUFJO1lBQUUsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDbEMsSUFBSSxDQUFDLEdBQUcsT0FBTztZQUFFLE9BQU8sQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUNyRCxPQUFPLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7SUFDM0MsQ0FBQztJQVlTLGtDQUFZLEdBQXRCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQjtZQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFDUyxtQ0FBYSxHQUF2QjtRQUNJLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0I7WUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ1MsaUNBQVcsR0FBckIsVUFBc0IsQ0FBQztRQUNuQixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7SUFDcEUsQ0FBQztJQU9TLGlDQUFXLEdBQXJCO1FBQ0ksSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDakIsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUN2RCxDQUFDO0lBQ1Msa0NBQVksR0FBdEI7UUFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUNqQixJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3ZELENBQUM7SUFDUyxnQ0FBVSxHQUFwQixVQUFxQixDQUFDO1FBQ2xCLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDO1FBQ2xCLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDdkQsQ0FBQztJQUNTLHNDQUFnQixHQUExQixVQUEyQixLQUFhO1FBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdkIsQ0FBQztJQUNELFlBQVk7SUFFWixVQUFVO0lBQ0Esd0NBQWtCLEdBQTVCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsVUFBVTtJQUNBLGdDQUFVLEdBQXBCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBR0QsVUFBVTtJQUNBLGlDQUFXLEdBQXJCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBQ0QsVUFBVTtJQUNBLGdDQUFVLEdBQXBCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRVMsOEJBQVEsR0FBbEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDUywrQkFBUyxHQUFuQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQWpFRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO3NEQUNzQjtJQUd6QztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO3VEQUN1QjtJQUcxQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDO3lEQUN5QjtJQWNsRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO3FEQUNxQjtJQXRFdkIsV0FBVztRQUQvQixPQUFPO09BQ2EsV0FBVyxDQXFIL0I7SUFBRCxrQkFBQztDQXJIRCxBQXFIQyxDQXJId0MscUJBQVcsR0FxSG5EO2tCQXJIb0IsV0FBVyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB5eUNvbXBvbmVudCBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi95eUNvbXBvbmVudFwiO1xuaW1wb3J0IHsgR2xvYmFsRW51bSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2xvYmFsRW51bVwiO1xuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XG5pbXBvcnQgR2FtZUNvbmZpZyBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dhbWVDb25maWdcIjtcbmltcG9ydCBBY3Rpb24zZE1hbmFnZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vQWN0aW9uM2RNYW5hZ2VyXCI7XG5cbi8v5YWz5Y2h6L+b5bqm5YiG5pWw562J5L+h5oGvVUlcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMZXZlbEluZm9VSSBleHRlbmRzIHl5Q29tcG9uZW50IHtcblxuICAgIHB1YmxpYyBnZXQgdWlUeXBlKCkgeyByZXR1cm4gR2xvYmFsRW51bS5VSS5sZXZlbEluZm87IH1cblxuICAgIHB1YmxpYyBpbml0KCkge1xuICAgICAgICB0aGlzLmluaXRDdXJHb2xkKCk7XG4gICAgICAgIHRoaXMuaW5pdENvbXBvbmVudHMoKTtcbiAgICAgICAgdGhpcy5pbml0UHJvZ3Jlc3MoKTtcbiAgICAgICAgdGhpcy5vbkV2ZW50cygpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgb25FdmVudHMoKSB7XG5cbiAgICB9XG5cbiAgICBwdWJsaWMgcmVzZXQoKSB7XG4gICAgICAgIHRoaXMucmVzZXRDdXJHb2xkKCk7XG4gICAgICAgIHRoaXMucmVzZXRQcm9ncmVzcygpO1xuICAgIH1cblxuICAgIHB1YmxpYyBzaG93KGxldmVsRGF0YTogYW55KSB7XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLnJlc2V0KCk7XG4gICAgICAgIHRoaXMuc2V0RGF0YShsZXZlbERhdGEpO1xuICAgIH1cbiAgICBwdWJsaWMgaGlkZSgpIHtcbiAgICAgICAgdGhpcy5yZXNldCgpO1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgfVxuXG4gICAgcHVibGljIGdldERhdGEoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzcGVHb2xkOiAwLFxuICAgICAgICAgICAgZ29sZDogdGhpcy5jdXJHb2xkLFxuICAgICAgICB9O1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBzZXREYXRhKGRhdGE6IGFueSkge1xuICAgICAgICBpZiAoISF0aGlzLmN1ckxldmVsTGFiZWwpIHRoaXMuY3VyTGV2ZWxMYWJlbC5zdHJpbmcgPSBkYXRhLmx2LnRvU3RyaW5nKCk7XG4gICAgICAgIGlmICghIXRoaXMubmV4dExldmVsTGFiZWwpIHRoaXMubmV4dExldmVsTGFiZWwuc3RyaW5nID0gKGRhdGEubHYgKyAxKS50b1N0cmluZygpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBjb252ZXJ0VG9TdHJpbmcodjogbnVtYmVyKTogc3RyaW5nIHtcbiAgICAgICAgaWYgKHYgPCAxMTAwKSByZXR1cm4gdi50b1N0cmluZygpO1xuICAgICAgICBpZiAodiA8IDExMDAwMDApIHJldHVybiAodiAqIDAuMDAxKS50b0ZpeGVkKDEpICsgXCJLXCI7XG4gICAgICAgIHJldHVybiAodiAqIDAuMDAwMDAxKS50b0ZpeGVkKDEpICsgXCJNXCI7XG4gICAgfVxuXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKirnrqHnkIblr7nosaEqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIC8vI3JlZ2lvbiDlhbPljaHov5vluqZcbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgcHJvdGVjdGVkIGN1ckxldmVsTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcbiAgICBwcm90ZWN0ZWQgbmV4dExldmVsTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcbiAgICAvL+WFs+WNoei/m+W6plxuICAgIEBwcm9wZXJ0eShjYy5Qcm9ncmVzc0JhcilcbiAgICBwcm90ZWN0ZWQgbGV2ZWxQcm9ncmVzc0JhcjogY2MuUHJvZ3Jlc3NCYXIgPSBudWxsO1xuICAgIHByb3RlY3RlZCBpbml0UHJvZ3Jlc3MoKSB7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxQcm9ncmVzc0JhcikgdGhpcy5sZXZlbFByb2dyZXNzQmFyLnByb2dyZXNzID0gMDtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHJlc2V0UHJvZ3Jlc3MoKSB7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxQcm9ncmVzc0JhcikgdGhpcy5sZXZlbFByb2dyZXNzQmFyLnByb2dyZXNzID0gMDtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHNldFByb2dyZXNzKHIpIHtcbiAgICAgICAgaWYgKCEhdGhpcy5sZXZlbFByb2dyZXNzQmFyKSB0aGlzLmxldmVsUHJvZ3Jlc3NCYXIucHJvZ3Jlc3MgPSByO1xuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDph5HluIFcbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgcHJvdGVjdGVkIGN1ckdvbGRMYWJlbDogY2MuTGFiZWwgPSBudWxsO1xuICAgIHByb3RlY3RlZCBjdXJHb2xkOiBudW1iZXIgPSAwO1xuICAgIHByb3RlY3RlZCBpbml0Q3VyR29sZCgpIHtcbiAgICAgICAgdGhpcy5jdXJHb2xkID0gMDtcbiAgICAgICAgdGhpcy5jdXJHb2xkTGFiZWwuc3RyaW5nID0gdGhpcy5jdXJHb2xkLnRvU3RyaW5nKCk7XG4gICAgfVxuICAgIHByb3RlY3RlZCByZXNldEN1ckdvbGQoKSB7XG4gICAgICAgIHRoaXMuY3VyR29sZCA9IDA7XG4gICAgICAgIHRoaXMuY3VyR29sZExhYmVsLnN0cmluZyA9IHRoaXMuY3VyR29sZC50b1N0cmluZygpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgYWRkQ3VyR29sZCh2KSB7XG4gICAgICAgIHRoaXMuY3VyR29sZCArPSB2O1xuICAgICAgICB0aGlzLmN1ckdvbGRMYWJlbC5zdHJpbmcgPSB0aGlzLmN1ckdvbGQudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIG9uUGxheWVyQ29sbEdvbGQoY291bnQ6IG51bWJlcikge1xuICAgICAgICB0aGlzLmFkZEN1ckdvbGQoMSk7XG4gICAgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLyoq6K6+572u5oyJ6ZKuICovXG4gICAgcHJvdGVjdGVkIG9uQnRuQ29uZmlnU2V0dGluZygpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5lbnRlciwgR2xvYmFsRW51bS5VSS5jb25maWdTZXR0aW5nKTtcbiAgICB9XG4gICAgLyoq5pqC5YGc5oyJ6ZKuICovXG4gICAgcHJvdGVjdGVkIG9uQnRuUGF1c2UoKSB7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQXVkaW9FdmVudC5wbGF5Q2xpY2tCdG4pO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuZW50ZXIsIEdsb2JhbEVudW0uVUkucGF1c2VMZXZlbCk7XG4gICAgfVxuXG5cbiAgICAvL+a1i+ivleeUqO+8mumHjee9ruWFs+WNoVxuICAgIHByb3RlY3RlZCBvbkJ0blJlcGxheSgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LnJlcGxheUN1ckxldmVsKTtcbiAgICB9XG4gICAgLy/mtYvor5XnlKjvvJrov5Tlm57pppbpobVcbiAgICBwcm90ZWN0ZWQgb25CdG5Mb2JieSgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LmVudGVyTG9iYnkpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBvbkJ0bldpbigpe1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkxldmVsRXZlbnQudGVzdFdpbik7XG4gICAgfVxuICAgIHByb3RlY3RlZCBvbkJ0bkxvc2UoKXtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5MZXZlbEV2ZW50LnRlc3RMb3NlKTtcbiAgICB9XG4gICAgXG59XG4iXX0=