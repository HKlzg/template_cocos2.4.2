
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LevelUI/WinUI/WinUI.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd8843No3IJGf4jWUiXUAgX3', 'WinUI');
// LevelUI/WinUI/WinUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var UIManager_1 = require("../../Script/Common/UIManager");
var GamePlatform_1 = require("../../Script/Platform/GamePlatform");
var GamePlatformType_1 = require("../../Script/Platform/GamePlatformType");
var WinAnim_1 = require("./WinAnim");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WinUI = /** @class */ (function (_super) {
    __extends(WinUI, _super);
    function WinUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bg = null;
        _this.winAnim = null;
        //关卡奖励的金币    
        /**显示关卡奖励的金币的节点层 */
        _this.levelGoldLayer = null;
        _this.goldLabel = null;
        _this.baseGold = 0;
        _this.speGold = 0;
        //视频与普通领取分开的方案：
        /**单倍领取 */
        _this.btnGetAwardSingle = null;
        /**视频领取 */
        _this.btnVideo = null;
        /**下一关按钮 */
        _this.btnNextLevel = null;
        _this.btnLobby = null;
        //头条分享录屏
        _this.btnShareVideo = null;
        _this.shareGold = null;
        /**分享录屏奖励的金币量 */
        _this.shareVideoAwardGold = 100;
        return _this;
    }
    Object.defineProperty(WinUI.prototype, "uiType", {
        /**场景/UI类型 */
        get: function () { return GlobalEnum_1.GlobalEnum.UI.winUI; },
        enumerable: false,
        configurable: true
    });
    WinUI.prototype.reset = function () {
        this.hideBtnGetAward();
        this.hideBtnLobby();
        this.hideBtnShareVideo();
        this.hideLevelGold();
    };
    /**
     * 显示UI
     * @param data 关卡成绩
     */
    WinUI.prototype.show = function (data) {
        this.reset();
        if (undefined === data) {
            var ui = UIManager_1.default.getUI(GlobalEnum_1.GlobalEnum.UI.levelInfo);
            data = ui.getData();
        }
        this.node.active = true;
        this.setData(data);
        this.winAnim.play(this.onWinAnimFinished.bind(this));
    };
    WinUI.prototype.onWinAnimFinished = function () {
        this.emit(GameEventType_1.EventType.SDKEvent.stopRecord);
        this.stepShowBtnGetAward();
    };
    WinUI.prototype.stepShowBtnGetAward = function () {
        this.showBtnShareVideo();
        this.showBtnGetAward();
        this.showLevelGold();
    };
    WinUI.prototype.stepShowBtnLobby = function () {
        this.showBtnLobby();
    };
    /**显示分享录屏按钮 */
    WinUI.prototype.showBtnShareVideo = function () {
        if (!this.btnShareVideo)
            return false;
        if (GamePlatform_1.default.instance.Config.type != GamePlatformType_1.GamePlatformType.TT)
            return false;
        if (!!this.shareGold) {
            this.shareGold.node.parent.active = true;
            this.shareGold.string = "+" + this.shareVideoAwardGold;
        }
        this.btnShareVideo.active = true;
        return true;
    };
    /**隐藏分享录屏按钮 */
    WinUI.prototype.hideBtnShareVideo = function () {
        if (!!this.shareGold)
            this.shareGold.node.parent.active = false;
        if (!!this.btnShareVideo) {
            // this.btnShareVideo.stopAllActions();
            this.btnShareVideo.active = false;
        }
    };
    /**显示领取奖励按钮 */
    WinUI.prototype.showBtnGetAward = function () {
        if (!!this.btnGetAwardSingle)
            this.btnGetAwardSingle.active = true;
        if (!!this.btnVideo)
            this.btnVideo.active = true;
    };
    /**隐藏领取奖励按钮 */
    WinUI.prototype.hideBtnGetAward = function () {
        if (!!this.btnGetAwardSingle)
            this.btnGetAwardSingle.active = false;
        if (!!this.btnVideo)
            this.btnVideo.active = false;
    };
    /**显示关卡金币奖励 */
    WinUI.prototype.showLevelGold = function () {
        if (!!this.levelGoldLayer)
            this.levelGoldLayer.active = true;
    };
    /**隐藏关卡金币奖励 */
    WinUI.prototype.hideLevelGold = function () {
        if (!!this.levelGoldLayer)
            this.levelGoldLayer.active = false;
    };
    //返回、下一关等按钮
    WinUI.prototype.showBtnLobby = function () {
        if (!!this.btnNextLevel)
            this.btnNextLevel.active = true;
        if (!!this.btnLobby)
            this.btnLobby.active = true;
    };
    WinUI.prototype.hideBtnLobby = function () {
        if (!!this.btnNextLevel)
            this.btnNextLevel.active = false;
        if (!!this.btnLobby)
            this.btnLobby.active = false;
    };
    WinUI.prototype.hide = function () {
        this.node.active = false;
    };
    WinUI.prototype.setData = function (data) {
        this.data = data;
        this.baseGold = data.gold;
        this.goldLabel.string = (this.baseGold + this.speGold).toString();
    };
    WinUI.prototype.getTotalGold = function () {
        return this.baseGold + this.speGold;
    };
    //视频三倍
    WinUI.prototype.onBtnVideo = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, this.onVideoFinish.bind(this));
    };
    WinUI.prototype.onVideoFinish = function () {
        this.hideLevelGold();
        this.addGold(this.getTotalGold() * 3, this.onGetGoldFinish.bind(this));
    };
    //普通领取
    WinUI.prototype.onBtnGetGold = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.hideLevelGold();
        this.addGold(this.getTotalGold(), this.onGetGoldFinish.bind(this));
    };
    //返回首页
    WinUI.prototype.onBtnLobby = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.DirectorEvent.enterLobby);
    };
    /**下一关 */
    WinUI.prototype.onBtnNextLevel = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.DirectorEvent.playNextLevel);
        // this.emit(EventType.DirectorEvent.enterLobby);
    };
    //金币领取完成后显示下一关和返回首页按钮
    WinUI.prototype.onGetGoldFinish = function () {
        this.hideLevelGold();
        this.hideBtnGetAward();
        this.stepShowBtnLobby();
    };
    /**设置按钮坐标为常规状态 */
    WinUI.prototype.setBtnsPosNormal = function () {
        // this.btnNextLevel.y = 310 + this.btnNextLevel.height * this.btnNextLevel.anchorY - this.node.height * this.node.anchorY;
    };
    /**播放金币动画获得金币 */
    WinUI.prototype.addGold = function (gold, cb) {
        var _this = this;
        var pos = this.levelGoldLayer.convertToWorldSpaceAR(cc.v2());
        var cvs = cc.find("Canvas");
        pos.x -= cvs.width * 0.5;
        pos.y -= cvs.height * 0.5;
        this.emit(GameEventType_1.EventType.UIEvent.playGoldAnim, {
            startPos: pos,
            cb: function () {
                _this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
                    attribute: "gameData.asset.gold",
                    value: gold,
                    mode: "+"
                });
                !!cb && cb();
            },
            gold: gold,
        });
    };
    //头条平台录屏分享
    WinUI.prototype.onBtnShareVideo = function () {
        this.emit(GameEventType_1.EventType.SDKEvent.shareRecord, this.onShareVideoFinish.bind(this), this.onShareVideoFail.bind(this));
    };
    WinUI.prototype.onShareVideoFinish = function () {
        this.hideBtnShareVideo();
        // this.addGold(this.shareVideoAwardGold);
        this.emit(GameEventType_1.EventType.AssetEvent.getPower, 2);
        this.emit(GameEventType_1.EventType.UIEvent.showTip, "分享成功，获得体力奖励！");
    };
    WinUI.prototype.onShareVideoFail = function () {
    };
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "bg", void 0);
    __decorate([
        property(WinAnim_1.default)
    ], WinUI.prototype, "winAnim", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "levelGoldLayer", void 0);
    __decorate([
        property(cc.Label)
    ], WinUI.prototype, "goldLabel", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnGetAwardSingle", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnVideo", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnNextLevel", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnLobby", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnShareVideo", void 0);
    __decorate([
        property(cc.Label)
    ], WinUI.prototype, "shareGold", void 0);
    WinUI = __decorate([
        ccclass
    ], WinUI);
    return WinUI;
}(yyComponent_1.default));
exports.default = WinUI;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxVSVxcV2luVUlcXFdpblVJLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLCtEQUEwRDtBQUMxRCxrRUFBaUU7QUFFakUsd0VBQW1FO0FBQ25FLDJEQUFzRDtBQUN0RCxtRUFBOEQ7QUFDOUQsMkVBQTBFO0FBQzFFLHFDQUFnQztBQUUxQixJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFtQyx5QkFBVztJQUE5QztRQUFBLHFFQTJOQztRQXJOYSxRQUFFLEdBQVksSUFBSSxDQUFDO1FBR25CLGFBQU8sR0FBWSxJQUFJLENBQUM7UUFFbEMsYUFBYTtRQUNiLG1CQUFtQjtRQUVULG9CQUFjLEdBQVksSUFBSSxDQUFDO1FBRS9CLGVBQVMsR0FBYSxJQUFJLENBQUM7UUFFM0IsY0FBUSxHQUFXLENBQUMsQ0FBQztRQUNyQixhQUFPLEdBQVcsQ0FBQyxDQUFDO1FBRTlCLGVBQWU7UUFDZixVQUFVO1FBRUEsdUJBQWlCLEdBQVksSUFBSSxDQUFDO1FBQzVDLFVBQVU7UUFFQSxjQUFRLEdBQVksSUFBSSxDQUFDO1FBRW5DLFdBQVc7UUFFRCxrQkFBWSxHQUFZLElBQUksQ0FBQztRQUU3QixjQUFRLEdBQVksSUFBSSxDQUFDO1FBQ25DLFFBQVE7UUFFRSxtQkFBYSxHQUFZLElBQUksQ0FBQztRQUU5QixlQUFTLEdBQWEsSUFBSSxDQUFDO1FBQ3JDLGdCQUFnQjtRQUNOLHlCQUFtQixHQUFXLEdBQUcsQ0FBQzs7SUFtTGhELENBQUM7SUF4Tkcsc0JBQVcseUJBQU07UUFEakIsYUFBYTthQUNiLGNBQXNCLE9BQU8sdUJBQVUsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUF5QzVDLHFCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBQ0Q7OztPQUdHO0lBQ0ksb0JBQUksR0FBWCxVQUFZLElBQVU7UUFDbEIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2IsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLElBQUksRUFBRSxHQUFHLG1CQUFTLENBQUMsS0FBSyxDQUFDLHVCQUFVLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2xELElBQUksR0FBRyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDdkI7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDeEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDekQsQ0FBQztJQUNTLGlDQUFpQixHQUEzQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVTLG1DQUFtQixHQUE3QjtRQUNJLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVTLGdDQUFnQixHQUExQjtRQUNJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRUQsY0FBYztJQUNKLGlDQUFpQixHQUEzQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYTtZQUFFLE9BQU8sS0FBSyxDQUFDO1FBQ3RDLElBQUksc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxtQ0FBZ0IsQ0FBQyxFQUFFO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFFM0UsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUN6QyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1NBQzFEO1FBRUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2pDLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDRCxjQUFjO0lBQ0osaUNBQWlCLEdBQTNCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVM7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUNoRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3RCLHVDQUF1QztZQUN2QyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7U0FDckM7SUFDTCxDQUFDO0lBQ0QsY0FBYztJQUNKLCtCQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQjtZQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ25FLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO0lBQ3JELENBQUM7SUFDRCxjQUFjO0lBQ0osK0JBQWUsR0FBekI7UUFDSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCO1lBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDcEUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDdEQsQ0FBQztJQUNELGNBQWM7SUFDSiw2QkFBYSxHQUF2QjtRQUNJLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjO1lBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO0lBQ2pFLENBQUM7SUFDRCxjQUFjO0lBQ0osNkJBQWEsR0FBdkI7UUFDSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYztZQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUNsRSxDQUFDO0lBQ0QsV0FBVztJQUNELDRCQUFZLEdBQXRCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVk7WUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDekQsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7SUFDckQsQ0FBQztJQUNTLDRCQUFZLEdBQXRCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVk7WUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDMUQsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDdEQsQ0FBQztJQUVNLG9CQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUVTLHVCQUFPLEdBQWpCLFVBQWtCLElBQXNCO1FBQ3BDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWpCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3RFLENBQUM7SUFFUyw0QkFBWSxHQUF0QjtRQUNJLE9BQU8sSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ3hDLENBQUM7SUFFRCxNQUFNO0lBQ0ksMEJBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUNTLDZCQUFhLEdBQXZCO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzNFLENBQUM7SUFDRCxNQUFNO0lBQ0ksNEJBQVksR0FBdEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7SUFFRCxNQUFNO0lBQ0ksMEJBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVELFNBQVM7SUFDQyw4QkFBYyxHQUF4QjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNqRCxpREFBaUQ7SUFDckQsQ0FBQztJQUVELHFCQUFxQjtJQUNYLCtCQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRUQsaUJBQWlCO0lBQ1AsZ0NBQWdCLEdBQTFCO1FBQ0ksMkhBQTJIO0lBQy9ILENBQUM7SUFFRCxnQkFBZ0I7SUFDTix1QkFBTyxHQUFqQixVQUFrQixJQUFZLEVBQUUsRUFBYTtRQUE3QyxpQkFpQkM7UUFoQkcsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM3RCxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVCLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRTtZQUN0QyxRQUFRLEVBQUUsR0FBRztZQUNiLEVBQUUsRUFBRTtnQkFDQSxLQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsZUFBZSxDQUFDLGdCQUFnQixFQUFFO29CQUNsRCxTQUFTLEVBQUUscUJBQXFCO29CQUNoQyxLQUFLLEVBQUUsSUFBSTtvQkFDWCxJQUFJLEVBQUUsR0FBRztpQkFDWixDQUFDLENBQUM7Z0JBQ0gsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUNqQixDQUFDO1lBQ0QsSUFBSSxFQUFFLElBQUk7U0FDYixDQUFDLENBQUE7SUFDTixDQUFDO0lBRUQsVUFBVTtJQUNBLCtCQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDcEgsQ0FBQztJQUNTLGtDQUFrQixHQUE1QjtRQUNJLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pCLDBDQUEwQztRQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ1MsZ0NBQWdCLEdBQTFCO0lBRUEsQ0FBQztJQW5ORDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO3FDQUNXO0lBRzdCO1FBREMsUUFBUSxDQUFDLGlCQUFPLENBQUM7MENBQ2dCO0lBS2xDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7aURBQ3VCO0lBRXpDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7NENBQ2tCO0lBUXJDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7b0RBQzBCO0lBRzVDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7MkNBQ2lCO0lBSW5DO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7K0NBQ3FCO0lBRXZDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7MkNBQ2lCO0lBR25DO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7Z0RBQ3NCO0lBRXhDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7NENBQ2tCO0lBdENwQixLQUFLO1FBRHpCLE9BQU87T0FDYSxLQUFLLENBMk56QjtJQUFELFlBQUM7Q0EzTkQsQUEyTkMsQ0EzTmtDLHFCQUFXLEdBMk43QztrQkEzTm9CLEtBQUsiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeXlDb21wb25lbnQgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24veXlDb21wb25lbnRcIjtcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcbmltcG9ydCBBY3Rpb24zZE1hbmFnZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vQWN0aW9uM2RNYW5hZ2VyXCI7XG5pbXBvcnQgeyBFdmVudFR5cGUgfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcbmltcG9ydCBVSU1hbmFnZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vVUlNYW5hZ2VyXCI7XG5pbXBvcnQgR2FtZVBsYXRmb3JtIGZyb20gXCIuLi8uLi9TY3JpcHQvUGxhdGZvcm0vR2FtZVBsYXRmb3JtXCI7XG5pbXBvcnQgeyBHYW1lUGxhdGZvcm1UeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9QbGF0Zm9ybS9HYW1lUGxhdGZvcm1UeXBlXCI7XG5pbXBvcnQgV2luQW5pbSBmcm9tIFwiLi9XaW5BbmltXCI7XG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBXaW5VSSBleHRlbmRzIHl5Q29tcG9uZW50IHtcblxuICAgIC8qKuWcuuaZry9VSeexu+WeiyAqL1xuICAgIHB1YmxpYyBnZXQgdWlUeXBlKCkgeyByZXR1cm4gR2xvYmFsRW51bS5VSS53aW5VSTsgfVxuXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJnOiBjYy5Ob2RlID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShXaW5BbmltKVxuICAgIHByb3RlY3RlZCB3aW5BbmltOiBXaW5BbmltID0gbnVsbDtcblxuICAgIC8v5YWz5Y2h5aWW5Yqx55qE6YeR5biBICAgIFxuICAgIC8qKuaYvuekuuWFs+WNoeWlluWKseeahOmHkeW4geeahOiKgueCueWxgiAqL1xuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICAgIHByb3RlY3RlZCBsZXZlbEdvbGRMYXllcjogY2MuTm9kZSA9IG51bGw7XG4gICAgQHByb3BlcnR5KGNjLkxhYmVsKVxuICAgIHByb3RlY3RlZCBnb2xkTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcblxuICAgIHByb3RlY3RlZCBiYXNlR29sZDogbnVtYmVyID0gMDtcbiAgICBwcm90ZWN0ZWQgc3BlR29sZDogbnVtYmVyID0gMDtcblxuICAgIC8v6KeG6aKR5LiO5pmu6YCa6aKG5Y+W5YiG5byA55qE5pa55qGI77yaXG4gICAgLyoq5Y2V5YCN6aKG5Y+WICovXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJ0bkdldEF3YXJkU2luZ2xlOiBjYy5Ob2RlID0gbnVsbDtcbiAgICAvKirop4bpopHpooblj5YgKi9cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBwcm90ZWN0ZWQgYnRuVmlkZW86IGNjLk5vZGUgPSBudWxsO1xuXG4gICAgLyoq5LiL5LiA5YWz5oyJ6ZKuICovXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJ0bk5leHRMZXZlbDogY2MuTm9kZSA9IG51bGw7XG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJ0bkxvYmJ5OiBjYy5Ob2RlID0gbnVsbDtcbiAgICAvL+WktOadoeWIhuS6q+W9leWxj1xuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICAgIHByb3RlY3RlZCBidG5TaGFyZVZpZGVvOiBjYy5Ob2RlID0gbnVsbDtcbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgcHJvdGVjdGVkIHNoYXJlR29sZDogY2MuTGFiZWwgPSBudWxsO1xuICAgIC8qKuWIhuS6q+W9leWxj+WlluWKseeahOmHkeW4gemHjyAqL1xuICAgIHByb3RlY3RlZCBzaGFyZVZpZGVvQXdhcmRHb2xkOiBudW1iZXIgPSAxMDA7XG5cbiAgICBwcm90ZWN0ZWQgZGF0YTogYW55O1xuXG4gICAgcHVibGljIHJlc2V0KCkge1xuICAgICAgICB0aGlzLmhpZGVCdG5HZXRBd2FyZCgpO1xuICAgICAgICB0aGlzLmhpZGVCdG5Mb2JieSgpO1xuICAgICAgICB0aGlzLmhpZGVCdG5TaGFyZVZpZGVvKCk7XG4gICAgICAgIHRoaXMuaGlkZUxldmVsR29sZCgpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiDmmL7npLpVSVxuICAgICAqIEBwYXJhbSBkYXRhIOWFs+WNoeaIkOe7qVxuICAgICAqL1xuICAgIHB1YmxpYyBzaG93KGRhdGE/OiBhbnkpIHtcbiAgICAgICAgdGhpcy5yZXNldCgpO1xuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBkYXRhKSB7XG4gICAgICAgICAgICBsZXQgdWkgPSBVSU1hbmFnZXIuZ2V0VUkoR2xvYmFsRW51bS5VSS5sZXZlbEluZm8pO1xuICAgICAgICAgICAgZGF0YSA9IHVpLmdldERhdGEoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLnNldERhdGEoZGF0YSk7XG4gICAgICAgIHRoaXMud2luQW5pbS5wbGF5KHRoaXMub25XaW5BbmltRmluaXNoZWQuYmluZCh0aGlzKSk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBvbldpbkFuaW1GaW5pc2hlZCgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5TREtFdmVudC5zdG9wUmVjb3JkKTtcbiAgICAgICAgdGhpcy5zdGVwU2hvd0J0bkdldEF3YXJkKCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHN0ZXBTaG93QnRuR2V0QXdhcmQoKSB7XG4gICAgICAgIHRoaXMuc2hvd0J0blNoYXJlVmlkZW8oKTtcbiAgICAgICAgdGhpcy5zaG93QnRuR2V0QXdhcmQoKTtcbiAgICAgICAgdGhpcy5zaG93TGV2ZWxHb2xkKCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHN0ZXBTaG93QnRuTG9iYnkoKSB7XG4gICAgICAgIHRoaXMuc2hvd0J0bkxvYmJ5KCk7XG4gICAgfVxuXG4gICAgLyoq5pi+56S65YiG5Lqr5b2V5bGP5oyJ6ZKuICovXG4gICAgcHJvdGVjdGVkIHNob3dCdG5TaGFyZVZpZGVvKCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAoIXRoaXMuYnRuU2hhcmVWaWRlbykgcmV0dXJuIGZhbHNlO1xuICAgICAgICBpZiAoR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy50eXBlICE9IEdhbWVQbGF0Zm9ybVR5cGUuVFQpIHJldHVybiBmYWxzZTtcblxuICAgICAgICBpZiAoISF0aGlzLnNoYXJlR29sZCkge1xuICAgICAgICAgICAgdGhpcy5zaGFyZUdvbGQubm9kZS5wYXJlbnQuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuc2hhcmVHb2xkLnN0cmluZyA9IFwiK1wiICsgdGhpcy5zaGFyZVZpZGVvQXdhcmRHb2xkO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5idG5TaGFyZVZpZGVvLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICAvKirpmpDol4/liIbkuqvlvZXlsY/mjInpkq4gKi9cbiAgICBwcm90ZWN0ZWQgaGlkZUJ0blNoYXJlVmlkZW8oKSB7XG4gICAgICAgIGlmICghIXRoaXMuc2hhcmVHb2xkKSB0aGlzLnNoYXJlR29sZC5ub2RlLnBhcmVudC5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5TaGFyZVZpZGVvKSB7XG4gICAgICAgICAgICAvLyB0aGlzLmJ0blNoYXJlVmlkZW8uc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgICAgIHRoaXMuYnRuU2hhcmVWaWRlby5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvKirmmL7npLrpooblj5blpZblirHmjInpkq4gKi9cbiAgICBwcm90ZWN0ZWQgc2hvd0J0bkdldEF3YXJkKCkge1xuICAgICAgICBpZiAoISF0aGlzLmJ0bkdldEF3YXJkU2luZ2xlKSB0aGlzLmJ0bkdldEF3YXJkU2luZ2xlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIGlmICghIXRoaXMuYnRuVmlkZW8pIHRoaXMuYnRuVmlkZW8uYWN0aXZlID0gdHJ1ZTtcbiAgICB9XG4gICAgLyoq6ZqQ6JeP6aKG5Y+W5aWW5Yqx5oyJ6ZKuICovXG4gICAgcHJvdGVjdGVkIGhpZGVCdG5HZXRBd2FyZCgpIHtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5HZXRBd2FyZFNpbmdsZSkgdGhpcy5idG5HZXRBd2FyZFNpbmdsZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5WaWRlbykgdGhpcy5idG5WaWRlby5hY3RpdmUgPSBmYWxzZTtcbiAgICB9XG4gICAgLyoq5pi+56S65YWz5Y2h6YeR5biB5aWW5YqxICovXG4gICAgcHJvdGVjdGVkIHNob3dMZXZlbEdvbGQoKSB7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxHb2xkTGF5ZXIpIHRoaXMubGV2ZWxHb2xkTGF5ZXIuYWN0aXZlID0gdHJ1ZTtcbiAgICB9XG4gICAgLyoq6ZqQ6JeP5YWz5Y2h6YeR5biB5aWW5YqxICovXG4gICAgcHJvdGVjdGVkIGhpZGVMZXZlbEdvbGQoKSB7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxHb2xkTGF5ZXIpIHRoaXMubGV2ZWxHb2xkTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgfVxuICAgIC8v6L+U5Zue44CB5LiL5LiA5YWz562J5oyJ6ZKuXG4gICAgcHJvdGVjdGVkIHNob3dCdG5Mb2JieSgpIHtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5OZXh0TGV2ZWwpIHRoaXMuYnRuTmV4dExldmVsLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIGlmICghIXRoaXMuYnRuTG9iYnkpIHRoaXMuYnRuTG9iYnkuYWN0aXZlID0gdHJ1ZTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIGhpZGVCdG5Mb2JieSgpIHtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5OZXh0TGV2ZWwpIHRoaXMuYnRuTmV4dExldmVsLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICBpZiAoISF0aGlzLmJ0bkxvYmJ5KSB0aGlzLmJ0bkxvYmJ5LmFjdGl2ZSA9IGZhbHNlO1xuICAgIH1cblxuICAgIHB1YmxpYyBoaWRlKCkge1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHNldERhdGEoZGF0YTogeyBnb2xkOiBudW1iZXIgfSkge1xuICAgICAgICB0aGlzLmRhdGEgPSBkYXRhO1xuXG4gICAgICAgIHRoaXMuYmFzZUdvbGQgPSBkYXRhLmdvbGQ7XG4gICAgICAgIHRoaXMuZ29sZExhYmVsLnN0cmluZyA9ICh0aGlzLmJhc2VHb2xkICsgdGhpcy5zcGVHb2xkKS50b1N0cmluZygpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBnZXRUb3RhbEdvbGQoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuYmFzZUdvbGQgKyB0aGlzLnNwZUdvbGQ7XG4gICAgfVxuXG4gICAgLy/op4bpopHkuInlgI1cbiAgICBwcm90ZWN0ZWQgb25CdG5WaWRlbygpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuU0RLRXZlbnQuc2hvd1ZpZGVvLCB0aGlzLm9uVmlkZW9GaW5pc2guYmluZCh0aGlzKSk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBvblZpZGVvRmluaXNoKCkge1xuICAgICAgICB0aGlzLmhpZGVMZXZlbEdvbGQoKTtcbiAgICAgICAgdGhpcy5hZGRHb2xkKHRoaXMuZ2V0VG90YWxHb2xkKCkgKiAzLCB0aGlzLm9uR2V0R29sZEZpbmlzaC5iaW5kKHRoaXMpKTtcbiAgICB9XG4gICAgLy/mma7pgJrpooblj5ZcbiAgICBwcm90ZWN0ZWQgb25CdG5HZXRHb2xkKCkge1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcbiAgICAgICAgdGhpcy5oaWRlTGV2ZWxHb2xkKCk7XG4gICAgICAgIHRoaXMuYWRkR29sZCh0aGlzLmdldFRvdGFsR29sZCgpLCB0aGlzLm9uR2V0R29sZEZpbmlzaC5iaW5kKHRoaXMpKTtcbiAgICB9XG5cbiAgICAvL+i/lOWbnummlumhtVxuICAgIHByb3RlY3RlZCBvbkJ0bkxvYmJ5KCkge1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LmVudGVyTG9iYnkpO1xuICAgIH1cblxuICAgIC8qKuS4i+S4gOWFsyAqL1xuICAgIHByb3RlY3RlZCBvbkJ0bk5leHRMZXZlbCgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5wbGF5TmV4dExldmVsKTtcbiAgICAgICAgLy8gdGhpcy5lbWl0KEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LmVudGVyTG9iYnkpO1xuICAgIH1cblxuICAgIC8v6YeR5biB6aKG5Y+W5a6M5oiQ5ZCO5pi+56S65LiL5LiA5YWz5ZKM6L+U5Zue6aaW6aG15oyJ6ZKuXG4gICAgcHJvdGVjdGVkIG9uR2V0R29sZEZpbmlzaCgpIHtcbiAgICAgICAgdGhpcy5oaWRlTGV2ZWxHb2xkKCk7XG4gICAgICAgIHRoaXMuaGlkZUJ0bkdldEF3YXJkKCk7XG4gICAgICAgIHRoaXMuc3RlcFNob3dCdG5Mb2JieSgpO1xuICAgIH1cblxuICAgIC8qKuiuvue9ruaMiemSruWdkOagh+S4uuW4uOinhOeKtuaAgSAqL1xuICAgIHByb3RlY3RlZCBzZXRCdG5zUG9zTm9ybWFsKCkge1xuICAgICAgICAvLyB0aGlzLmJ0bk5leHRMZXZlbC55ID0gMzEwICsgdGhpcy5idG5OZXh0TGV2ZWwuaGVpZ2h0ICogdGhpcy5idG5OZXh0TGV2ZWwuYW5jaG9yWSAtIHRoaXMubm9kZS5oZWlnaHQgKiB0aGlzLm5vZGUuYW5jaG9yWTtcbiAgICB9XG5cbiAgICAvKirmkq3mlL7ph5HluIHliqjnlLvojrflvpfph5HluIEgKi9cbiAgICBwcm90ZWN0ZWQgYWRkR29sZChnb2xkOiBudW1iZXIsIGNiPzogRnVuY3Rpb24pIHtcbiAgICAgICAgbGV0IHBvcyA9IHRoaXMubGV2ZWxHb2xkTGF5ZXIuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKCkpO1xuICAgICAgICBsZXQgY3ZzID0gY2MuZmluZChcIkNhbnZhc1wiKTtcbiAgICAgICAgcG9zLnggLT0gY3ZzLndpZHRoICogMC41O1xuICAgICAgICBwb3MueSAtPSBjdnMuaGVpZ2h0ICogMC41O1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQucGxheUdvbGRBbmltLCB7XG4gICAgICAgICAgICBzdGFydFBvczogcG9zLFxuICAgICAgICAgICAgY2I6ICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlBsYXllckRhdGFFdmVudC51cGRhdGVQbGF5ZXJEYXRhLCB7XG4gICAgICAgICAgICAgICAgICAgIGF0dHJpYnV0ZTogXCJnYW1lRGF0YS5hc3NldC5nb2xkXCIsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBnb2xkLFxuICAgICAgICAgICAgICAgICAgICBtb2RlOiBcIitcIlxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICEhY2IgJiYgY2IoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnb2xkOiBnb2xkLFxuICAgICAgICB9KVxuICAgIH1cblxuICAgIC8v5aS05p2h5bmz5Y+w5b2V5bGP5YiG5LqrXG4gICAgcHJvdGVjdGVkIG9uQnRuU2hhcmVWaWRlbygpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5TREtFdmVudC5zaGFyZVJlY29yZCwgdGhpcy5vblNoYXJlVmlkZW9GaW5pc2guYmluZCh0aGlzKSwgdGhpcy5vblNoYXJlVmlkZW9GYWlsLmJpbmQodGhpcykpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgb25TaGFyZVZpZGVvRmluaXNoKCkge1xuICAgICAgICB0aGlzLmhpZGVCdG5TaGFyZVZpZGVvKCk7XG4gICAgICAgIC8vIHRoaXMuYWRkR29sZCh0aGlzLnNoYXJlVmlkZW9Bd2FyZEdvbGQpO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkFzc2V0RXZlbnQuZ2V0UG93ZXIsIDIpO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuc2hvd1RpcCwgXCLliIbkuqvmiJDlip/vvIzojrflvpfkvZPlipvlpZblirHvvIFcIik7XG4gICAgfVxuICAgIHByb3RlY3RlZCBvblNoYXJlVmlkZW9GYWlsKCkge1xuXG4gICAgfVxuXG59XG4iXX0=