
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LevelUI/WinUI/WinAnim.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2c9f1wU97FCOJH/XExKCKoF', 'WinAnim');
// LevelUI/WinUI/WinAnim.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WinAnim = /** @class */ (function (_super) {
    __extends(WinAnim, _super);
    function WinAnim() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.prefab = null;
        _this.imgs = [];
        _this.minScale = 0.5;
        _this.maxScale = 2;
        _this.minAngle = 0;
        _this.maxAngle = 180;
        _this.minSkew = 0;
        _this.maxSkew = 5;
        _this.duration = 1;
        _this.minSpd = 1500;
        _this.maxSpd = 2500;
        _this.gravity = -3000;
        _this.count = 100;
        _this.particles = [];
        _this.index = 0;
        _this.finishCallFun = null;
        return _this;
    }
    WinAnim.prototype.addItem = function () {
        this.index++;
        if (this.index >= this.imgs.length) {
            this.index = 0;
        }
        var node = GlobalPool_1.default.get(this.prefab.name);
        node.getComponent(cc.Sprite).spriteFrame = this.imgs[this.index];
        var scale = this.randomScope(this.minScale, this.maxScale);
        var angle = this.randomScope(this.minAngle, this.maxAngle);
        node.setScale(scale);
        node.angle = angle;
        var duration = this.duration;
        var scale1 = Action3dManager_1.default.scaleTo(duration, this.randomScope(this.minScale, this.maxScale), this.randomScope(this.minScale, this.maxScale), 1);
        var rotate1 = Action3dManager_1.default.rotateTo2d(duration, this.randomScope(this.minAngle, this.maxAngle));
        var spawn = Action3dManager_1.default.spawn(scale1, rotate1);
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).runAction(node, spawn);
        var v = cc.v2();
        var spd = this.minSpd + Math.random() * (this.maxSpd - this.minSpd);
        var radian = (Math.random() * 0.5 + 0.25) * 3.14;
        v.x = spd * Math.cos(radian);
        v.y = spd * Math.sin(radian);
        this.particles.push(new Particle(node, v, this.gravity));
        node.setPosition(0, 0);
        this.node.addChild(node);
    };
    WinAnim.prototype.randomScope = function (min, max) {
        return min + Math.random() * (max - min);
    };
    WinAnim.prototype.play = function (cb) {
        if (!!cb)
            this.finishCallFun = cb;
        var c = this.count;
        GlobalPool_1.default.createPool(this.prefab.name, this.prefab);
        GlobalPool_1.default.preCreate(this.prefab.name, c);
        for (var i = 0; i < this.count; ++i) {
            this.addItem();
        }
        this.schedule(this.step, 0.016);
    };
    WinAnim.prototype.step = function () {
        var dt = 0.016;
        for (var i = this.particles.length - 1; i >= 0; --i) {
            this.particles[i].update(dt);
            if (this.particles[i].finished) {
                GlobalPool_1.default.put(this.particles[i].node);
                this.particles.splice(i, 1);
            }
        }
        if (this.particles.length == 0) {
            this.onFinish();
        }
    };
    WinAnim.prototype.onFinish = function () {
        this.unscheduleAllCallbacks();
        if (!!this.finishCallFun) {
            var cb = this.finishCallFun;
            this.finishCallFun = null;
            cb();
        }
    };
    __decorate([
        property(cc.Prefab)
    ], WinAnim.prototype, "prefab", void 0);
    __decorate([
        property([cc.SpriteFrame])
    ], WinAnim.prototype, "imgs", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "minScale", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "maxScale", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "minAngle", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "maxAngle", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "minSkew", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "maxSkew", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "duration", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "minSpd", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "maxSpd", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "gravity", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "count", void 0);
    WinAnim = __decorate([
        ccclass
    ], WinAnim);
    return WinAnim;
}(cc.Component));
exports.default = WinAnim;
var Particle = /** @class */ (function () {
    function Particle(node, spd, g) {
        this.node = node;
        this.spd = spd;
        this.gravity = g;
    }
    Particle.prototype.update = function (dt) {
        this.spd.y += this.gravity * dt;
        this.node.setPosition(this.node.x + this.spd.x * dt, this.node.y + this.spd.y * dt);
    };
    Object.defineProperty(Particle.prototype, "finished", {
        get: function () {
            return this.node.y < -667;
        },
        enumerable: false,
        configurable: true
    });
    return Particle;
}());

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxVSVxcV2luVUlcXFdpbkFuaW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsNkRBQXdEO0FBQ3hELHVFQUFxRjtBQUUvRSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFxQywyQkFBWTtJQUFqRDtRQUFBLHFFQWlHQztRQS9GYSxZQUFNLEdBQWMsSUFBSSxDQUFDO1FBRXpCLFVBQUksR0FBcUIsRUFBRSxDQUFDO1FBRzVCLGNBQVEsR0FBVyxHQUFHLENBQUM7UUFFdkIsY0FBUSxHQUFXLENBQUMsQ0FBQztRQUVyQixjQUFRLEdBQVcsQ0FBQyxDQUFDO1FBRXJCLGNBQVEsR0FBVyxHQUFHLENBQUM7UUFFdkIsYUFBTyxHQUFXLENBQUMsQ0FBQztRQUVwQixhQUFPLEdBQVcsQ0FBQyxDQUFDO1FBRXBCLGNBQVEsR0FBVyxDQUFDLENBQUM7UUFFckIsWUFBTSxHQUFXLElBQUksQ0FBQztRQUV0QixZQUFNLEdBQVcsSUFBSSxDQUFDO1FBRXRCLGFBQU8sR0FBVyxDQUFDLElBQUksQ0FBQztRQUV4QixXQUFLLEdBQVcsR0FBRyxDQUFDO1FBRXBCLGVBQVMsR0FBZSxFQUFFLENBQUM7UUFDM0IsV0FBSyxHQUFHLENBQUMsQ0FBQztRQWtDVixtQkFBYSxHQUFHLElBQUksQ0FBQzs7SUFpQ25DLENBQUM7SUFsRWEseUJBQU8sR0FBakI7UUFDSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7U0FDbEI7UUFDRCxJQUFJLElBQUksR0FBRyxvQkFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNqRSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzNELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUVuQixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBRTdCLElBQUksTUFBTSxHQUFHLHlCQUFlLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbEosSUFBSSxPQUFPLEdBQUcseUJBQWUsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUNuRyxJQUFJLEtBQUssR0FBRyx5QkFBZSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDbkQseUJBQWUsQ0FBQyxNQUFNLENBQUMsK0JBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRWhFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUNoQixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3BFLElBQUksTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDakQsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM3QixDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFekQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUNTLDZCQUFXLEdBQXJCLFVBQXNCLEdBQVcsRUFBRSxHQUFXO1FBQzFDLE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBR00sc0JBQUksR0FBWCxVQUFZLEVBQWE7UUFDckIsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUFFLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBQ2xDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDbkIsb0JBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JELG9CQUFVLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzFDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUNsQjtRQUNELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ1Msc0JBQUksR0FBZDtRQUNJLElBQUksRUFBRSxHQUFHLEtBQUssQ0FBQztRQUNmLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDakQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDN0IsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTtnQkFDNUIsb0JBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQy9CO1NBQ0o7UUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtZQUM1QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDbkI7SUFDTCxDQUFDO0lBQ1MsMEJBQVEsR0FBbEI7UUFDSSxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3RCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDNUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7WUFDMUIsRUFBRSxFQUFFLENBQUM7U0FDUjtJQUNMLENBQUM7SUE3RkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzsyQ0FDZTtJQUVuQztRQURDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQzt5Q0FDVztJQUd0QztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDOzZDQUNZO0lBRWpDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7NkNBQ1U7SUFFL0I7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQzs2Q0FDVTtJQUUvQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDOzZDQUNZO0lBRWpDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7NENBQ1M7SUFFOUI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQzs0Q0FDUztJQUU5QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDOzZDQUNVO0lBRS9CO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7MkNBQ1c7SUFFaEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQzsyQ0FDVztJQUVoQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDOzRDQUNhO0lBRWxDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7MENBQ1M7SUEzQmIsT0FBTztRQUQzQixPQUFPO09BQ2EsT0FBTyxDQWlHM0I7SUFBRCxjQUFDO0NBakdELEFBaUdDLENBakdvQyxFQUFFLENBQUMsU0FBUyxHQWlHaEQ7a0JBakdvQixPQUFPO0FBa0c1QjtJQUlJLGtCQUFZLElBQWEsRUFBRSxHQUFZLEVBQUUsQ0FBUztRQUM5QyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNmLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFDTSx5QkFBTSxHQUFiLFVBQWMsRUFBVTtRQUNwQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7SUFDeEYsQ0FBQztJQUNELHNCQUFXLDhCQUFRO2FBQW5CO1lBQ0ksT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztRQUM5QixDQUFDOzs7T0FBQTtJQUNMLGVBQUM7QUFBRCxDQWhCQSxBQWdCQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEdsb2JhbFBvb2wgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vR2xvYmFsUG9vbFwiO1xyXG5pbXBvcnQgQWN0aW9uM2RNYW5hZ2VyLCB7IEFjdGlvbk1uZ1R5cGUgfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9BY3Rpb24zZE1hbmFnZXJcIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBXaW5BbmltIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICBwcm90ZWN0ZWQgcHJlZmFiOiBjYy5QcmVmYWIgPSBudWxsO1xyXG4gICAgQHByb3BlcnR5KFtjYy5TcHJpdGVGcmFtZV0pXHJcbiAgICBwcm90ZWN0ZWQgaW1nczogY2MuU3ByaXRlRnJhbWVbXSA9IFtdO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5JbnRlZ2VyKVxyXG4gICAgcHJvdGVjdGVkIG1pblNjYWxlOiBudW1iZXIgPSAwLjU7XHJcbiAgICBAcHJvcGVydHkoY2MuSW50ZWdlcilcclxuICAgIHByb3RlY3RlZCBtYXhTY2FsZTogbnVtYmVyID0gMjtcclxuICAgIEBwcm9wZXJ0eShjYy5JbnRlZ2VyKVxyXG4gICAgcHJvdGVjdGVkIG1pbkFuZ2xlOiBudW1iZXIgPSAwO1xyXG4gICAgQHByb3BlcnR5KGNjLkludGVnZXIpXHJcbiAgICBwcm90ZWN0ZWQgbWF4QW5nbGU6IG51bWJlciA9IDE4MDtcclxuICAgIEBwcm9wZXJ0eShjYy5JbnRlZ2VyKVxyXG4gICAgcHJvdGVjdGVkIG1pblNrZXc6IG51bWJlciA9IDA7XHJcbiAgICBAcHJvcGVydHkoY2MuSW50ZWdlcilcclxuICAgIHByb3RlY3RlZCBtYXhTa2V3OiBudW1iZXIgPSA1O1xyXG4gICAgQHByb3BlcnR5KGNjLkludGVnZXIpXHJcbiAgICBwcm90ZWN0ZWQgZHVyYXRpb246IG51bWJlciA9IDE7XHJcbiAgICBAcHJvcGVydHkoY2MuSW50ZWdlcilcclxuICAgIHByb3RlY3RlZCBtaW5TcGQ6IG51bWJlciA9IDE1MDA7XHJcbiAgICBAcHJvcGVydHkoY2MuSW50ZWdlcilcclxuICAgIHByb3RlY3RlZCBtYXhTcGQ6IG51bWJlciA9IDI1MDA7XHJcbiAgICBAcHJvcGVydHkoY2MuSW50ZWdlcilcclxuICAgIHByb3RlY3RlZCBncmF2aXR5OiBudW1iZXIgPSAtMzAwMDtcclxuICAgIEBwcm9wZXJ0eShjYy5JbnRlZ2VyKVxyXG4gICAgcHJvdGVjdGVkIGNvdW50OiBudW1iZXIgPSAxMDA7XHJcblxyXG4gICAgcHJvdGVjdGVkIHBhcnRpY2xlczogUGFydGljbGVbXSA9IFtdO1xyXG4gICAgcHJvdGVjdGVkIGluZGV4ID0gMDtcclxuICAgIHByb3RlY3RlZCBhZGRJdGVtKCkge1xyXG4gICAgICAgIHRoaXMuaW5kZXgrKztcclxuICAgICAgICBpZiAodGhpcy5pbmRleCA+PSB0aGlzLmltZ3MubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW5kZXggPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgbm9kZSA9IEdsb2JhbFBvb2wuZ2V0KHRoaXMucHJlZmFiLm5hbWUpO1xyXG4gICAgICAgIG5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSB0aGlzLmltZ3NbdGhpcy5pbmRleF07XHJcbiAgICAgICAgbGV0IHNjYWxlID0gdGhpcy5yYW5kb21TY29wZSh0aGlzLm1pblNjYWxlLCB0aGlzLm1heFNjYWxlKTtcclxuICAgICAgICBsZXQgYW5nbGUgPSB0aGlzLnJhbmRvbVNjb3BlKHRoaXMubWluQW5nbGUsIHRoaXMubWF4QW5nbGUpO1xyXG4gICAgICAgIG5vZGUuc2V0U2NhbGUoc2NhbGUpO1xyXG4gICAgICAgIG5vZGUuYW5nbGUgPSBhbmdsZTtcclxuXHJcbiAgICAgICAgbGV0IGR1cmF0aW9uID0gdGhpcy5kdXJhdGlvbjtcclxuXHJcbiAgICAgICAgbGV0IHNjYWxlMSA9IEFjdGlvbjNkTWFuYWdlci5zY2FsZVRvKGR1cmF0aW9uLCB0aGlzLnJhbmRvbVNjb3BlKHRoaXMubWluU2NhbGUsIHRoaXMubWF4U2NhbGUpLCB0aGlzLnJhbmRvbVNjb3BlKHRoaXMubWluU2NhbGUsIHRoaXMubWF4U2NhbGUpLCAxKTtcclxuICAgICAgICBsZXQgcm90YXRlMSA9IEFjdGlvbjNkTWFuYWdlci5yb3RhdGVUbzJkKGR1cmF0aW9uLCB0aGlzLnJhbmRvbVNjb3BlKHRoaXMubWluQW5nbGUsIHRoaXMubWF4QW5nbGUpKTtcclxuICAgICAgICBsZXQgc3Bhd24gPSBBY3Rpb24zZE1hbmFnZXIuc3Bhd24oc2NhbGUxLCByb3RhdGUxKTtcclxuICAgICAgICBBY3Rpb24zZE1hbmFnZXIuZ2V0TW5nKEFjdGlvbk1uZ1R5cGUuVUkpLnJ1bkFjdGlvbihub2RlLCBzcGF3bik7XHJcblxyXG4gICAgICAgIGxldCB2ID0gY2MudjIoKTtcclxuICAgICAgICBsZXQgc3BkID0gdGhpcy5taW5TcGQgKyBNYXRoLnJhbmRvbSgpICogKHRoaXMubWF4U3BkIC0gdGhpcy5taW5TcGQpO1xyXG4gICAgICAgIGxldCByYWRpYW4gPSAoTWF0aC5yYW5kb20oKSAqIDAuNSArIDAuMjUpICogMy4xNDtcclxuICAgICAgICB2LnggPSBzcGQgKiBNYXRoLmNvcyhyYWRpYW4pO1xyXG4gICAgICAgIHYueSA9IHNwZCAqIE1hdGguc2luKHJhZGlhbik7XHJcbiAgICAgICAgdGhpcy5wYXJ0aWNsZXMucHVzaChuZXcgUGFydGljbGUobm9kZSwgdiwgdGhpcy5ncmF2aXR5KSk7XHJcblxyXG4gICAgICAgIG5vZGUuc2V0UG9zaXRpb24oMCwgMCk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKG5vZGUpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHJhbmRvbVNjb3BlKG1pbjogbnVtYmVyLCBtYXg6IG51bWJlcikge1xyXG4gICAgICAgIHJldHVybiBtaW4gKyBNYXRoLnJhbmRvbSgpICogKG1heCAtIG1pbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGZpbmlzaENhbGxGdW4gPSBudWxsO1xyXG4gICAgcHVibGljIHBsYXkoY2I/OiBGdW5jdGlvbikge1xyXG4gICAgICAgIGlmICghIWNiKSB0aGlzLmZpbmlzaENhbGxGdW4gPSBjYjtcclxuICAgICAgICBsZXQgYyA9IHRoaXMuY291bnQ7XHJcbiAgICAgICAgR2xvYmFsUG9vbC5jcmVhdGVQb29sKHRoaXMucHJlZmFiLm5hbWUsIHRoaXMucHJlZmFiKTtcclxuICAgICAgICBHbG9iYWxQb29sLnByZUNyZWF0ZSh0aGlzLnByZWZhYi5uYW1lLCBjKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY291bnQ7ICsraSkge1xyXG4gICAgICAgICAgICB0aGlzLmFkZEl0ZW0oKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZSh0aGlzLnN0ZXAsIDAuMDE2KTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBzdGVwKCkge1xyXG4gICAgICAgIGxldCBkdCA9IDAuMDE2O1xyXG4gICAgICAgIGZvciAobGV0IGkgPSB0aGlzLnBhcnRpY2xlcy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xyXG4gICAgICAgICAgICB0aGlzLnBhcnRpY2xlc1tpXS51cGRhdGUoZHQpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5wYXJ0aWNsZXNbaV0uZmluaXNoZWQpIHtcclxuICAgICAgICAgICAgICAgIEdsb2JhbFBvb2wucHV0KHRoaXMucGFydGljbGVzW2ldLm5vZGUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wYXJ0aWNsZXMuc3BsaWNlKGksIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLnBhcnRpY2xlcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLm9uRmluaXNoKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uRmluaXNoKCkge1xyXG4gICAgICAgIHRoaXMudW5zY2hlZHVsZUFsbENhbGxiYWNrcygpO1xyXG4gICAgICAgIGlmICghIXRoaXMuZmluaXNoQ2FsbEZ1bikge1xyXG4gICAgICAgICAgICBsZXQgY2IgPSB0aGlzLmZpbmlzaENhbGxGdW47XHJcbiAgICAgICAgICAgIHRoaXMuZmluaXNoQ2FsbEZ1biA9IG51bGw7XHJcbiAgICAgICAgICAgIGNiKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG5jbGFzcyBQYXJ0aWNsZSB7XHJcbiAgICBwdWJsaWMgbm9kZTogY2MuTm9kZTtcclxuICAgIHB1YmxpYyBzcGQ6IGNjLlZlYzI7XHJcbiAgICBwdWJsaWMgZ3Jhdml0eTogbnVtYmVyO1xyXG4gICAgY29uc3RydWN0b3Iobm9kZTogY2MuTm9kZSwgc3BkOiBjYy5WZWMyLCBnOiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLm5vZGUgPSBub2RlO1xyXG4gICAgICAgIHRoaXMuc3BkID0gc3BkO1xyXG4gICAgICAgIHRoaXMuZ3Jhdml0eSA9IGc7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgdXBkYXRlKGR0OiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLnNwZC55ICs9IHRoaXMuZ3Jhdml0eSAqIGR0O1xyXG4gICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih0aGlzLm5vZGUueCArIHRoaXMuc3BkLnggKiBkdCwgdGhpcy5ub2RlLnkgKyB0aGlzLnNwZC55ICogZHQpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGdldCBmaW5pc2hlZCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5ub2RlLnkgPCAtNjY3O1xyXG4gICAgfVxyXG59XHJcbiJdfQ==