
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LevelUI/LoseUI/LoseUI.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6f8173lok9Jd7axmbmpArAu', 'LoseUI');
// LevelUI/LoseUI/LoseUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var UIManager_1 = require("../../Script/Common/UIManager");
var GamePlatform_1 = require("../../Script/Platform/GamePlatform");
var GamePlatformType_1 = require("../../Script/Platform/GamePlatformType");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LoseUI = /** @class */ (function (_super) {
    __extends(LoseUI, _super);
    function LoseUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**显示关卡奖励的金币的节点层 */
        _this.levelGoldLayer = null;
        _this.goldLabel = null;
        _this.baseGold = 0;
        _this.speGold = 0;
        //视频与普通领取分开的方案：
        /**单倍领取 */
        _this.btnGetAwardSingle = null;
        /**视频领取 */
        _this.btnVideo = null;
        /**下一关按钮 */
        _this.btnNextLevel = null;
        _this.btnReplay = null;
        _this.btnLobby = null;
        //头条录屏分享
        _this.btnShareVideo = null;
        _this.shareGold = null;
        /**分享录屏奖励的金币量 */
        _this.shareVideoAwardGold = 100;
        return _this;
    }
    Object.defineProperty(LoseUI.prototype, "uiType", {
        /**场景/UI类型 */
        get: function () { return GlobalEnum_1.GlobalEnum.UI.loseUI; },
        enumerable: false,
        configurable: true
    });
    LoseUI.prototype.reset = function () {
        this.hideBtnGetAward();
        this.hideBtnLobby();
        this.hideBtnShareVideo();
        this.hideLevelGold();
    };
    /**
     * 显示UI
     * @param data 关卡成绩
     */
    LoseUI.prototype.show = function (data) {
        this.reset();
        if (undefined === data) {
            var ui = UIManager_1.default.getUI(GlobalEnum_1.GlobalEnum.UI.levelInfo);
            data = ui.getData();
        }
        this.node.active = true;
        this.setData(data);
        this.stepShowBtnGetAward();
    };
    LoseUI.prototype.stepShowBtnGetAward = function () {
        this.showBtnShareVideo();
        this.showBtnGetAward();
        this.showLevelGold();
    };
    LoseUI.prototype.stepShowBtnLobby = function () {
        this.showBtnLobby();
    };
    /**显示分享录屏按钮 */
    LoseUI.prototype.showBtnShareVideo = function () {
        if (!this.btnShareVideo)
            return false;
        if (GamePlatform_1.default.instance.Config.type != GamePlatformType_1.GamePlatformType.TT)
            return false;
        if (!!this.shareGold) {
            this.shareGold.node.parent.active = true;
            this.shareGold.string = "+" + this.shareVideoAwardGold;
        }
        this.btnShareVideo.active = true;
        return true;
    };
    /**隐藏分享录屏按钮 */
    LoseUI.prototype.hideBtnShareVideo = function () {
        if (!!this.shareGold)
            this.shareGold.node.parent.active = false;
        if (!!this.btnShareVideo) {
            this.btnShareVideo.active = false;
        }
    };
    /**显示领取奖励按钮 */
    LoseUI.prototype.showBtnGetAward = function () {
        if (!!this.btnGetAwardSingle)
            this.btnGetAwardSingle.active = true;
        if (!!this.btnVideo)
            this.btnVideo.active = true;
    };
    LoseUI.prototype.hideBtnGetAward = function () {
        if (!!this.btnGetAwardSingle)
            this.btnGetAwardSingle.active = false;
        if (!!this.btnVideo)
            this.btnVideo.active = false;
    };
    /**显示关卡金币奖励 */
    LoseUI.prototype.showLevelGold = function () {
        if (!!this.levelGoldLayer)
            this.levelGoldLayer.active = true;
    };
    /**隐藏关卡金币奖励 */
    LoseUI.prototype.hideLevelGold = function () {
        if (!!this.levelGoldLayer)
            this.levelGoldLayer.active = false;
    };
    //返回、下一关等按钮
    LoseUI.prototype.showBtnLobby = function () {
        if (!!this.btnReplay)
            this.btnReplay.active = true;
        if (!!this.btnNextLevel)
            this.btnNextLevel.active = true;
        if (!!this.btnLobby)
            this.btnLobby.active = true;
    };
    LoseUI.prototype.hideBtnLobby = function () {
        if (!!this.btnReplay)
            this.btnReplay.active = false;
        if (!!this.btnNextLevel)
            this.btnNextLevel.active = false;
        if (!!this.btnLobby)
            this.btnLobby.active = false;
    };
    LoseUI.prototype.hide = function () {
        this.node.active = false;
    };
    LoseUI.prototype.setData = function (data) {
        this.data = data;
        this.baseGold = data.gold;
        this.goldLabel.string = (this.baseGold + this.speGold).toString();
    };
    LoseUI.prototype.getTotalGold = function () {
        return this.baseGold + this.speGold;
    };
    //返回首页
    LoseUI.prototype.onBtnLobby = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.DirectorEvent.enterLobby);
    };
    /**视频跳关 */
    LoseUI.prototype.onBtnNextLevel = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, this.passLevel.bind(this));
    };
    LoseUI.prototype.passLevel = function () {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData.curLevel",
            value: 1,
            mode: "+",
        });
        this.emit(GameEventType_1.EventType.DirectorEvent.playNextLevel);
    };
    //重玩
    LoseUI.prototype.onBtnReplay = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.DirectorEvent.replayCurLevel);
    };
    /**设置按钮坐标为常规状态 */
    LoseUI.prototype.setBtnsPosNormal = function () {
        // this.btnReplay.y = 310 + this.btnReplay.height * this.btnReplay.anchorY - this.node.height * this.node.anchorY;
    };
    //视频三倍
    LoseUI.prototype.onBtnVideo = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, this.onVideoFinish.bind(this));
    };
    LoseUI.prototype.onVideoFinish = function () {
        this.hideLevelGold();
        this.addGold(this.getTotalGold() * 3, this.onGetGoldFinish.bind(this));
    };
    LoseUI.prototype.onGetGoldFinish = function () {
        //隐藏领取按钮，显示返回和重玩按钮
        this.hideLevelGold();
        this.hideBtnGetAward();
        this.stepShowBtnLobby();
    };
    //普通领取
    LoseUI.prototype.onBtnGetGold = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.hideLevelGold();
        this.addGold(this.getTotalGold(), this.onGetGoldFinish.bind(this));
    };
    LoseUI.prototype.addGold = function (gold, cb) {
        var _this = this;
        var pos = this.levelGoldLayer.convertToWorldSpaceAR(cc.v2());
        var cvs = cc.find("Canvas");
        pos.x -= cvs.width * 0.5;
        pos.y -= cvs.height * 0.5;
        this.emit(GameEventType_1.EventType.UIEvent.playGoldAnim, {
            startPos: pos,
            cb: function () {
                _this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
                    type: "gameData",
                    attribute: "gameData.asset.gold",
                    value: gold,
                    mode: "+"
                });
                !!cb && cb();
            },
            gold: gold,
        });
    };
    //头条平台录屏分享
    LoseUI.prototype.onBtnShareVideo = function () {
        this.emit(GameEventType_1.EventType.SDKEvent.shareRecord, this.onShareVideoFinish.bind(this), this.onShareVideoFail.bind(this));
    };
    LoseUI.prototype.onShareVideoFinish = function () {
        this.hideBtnShareVideo();
        this.emit(GameEventType_1.EventType.AssetEvent.getPower, 2);
        this.emit(GameEventType_1.EventType.UIEvent.showTip, "分享成功，获得体力奖励！");
    };
    LoseUI.prototype.onShareVideoFail = function () {
    };
    //观看视频，加时60秒，继续游戏
    LoseUI.prototype.onBtnAddTime = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, this.onAddTime.bind(this));
    };
    LoseUI.prototype.onAddTime = function () {
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.loseUI);
        // this.emit(EventType.LevelEvent.addRemainTimeByVideo);
    };
    __decorate([
        property(cc.Node)
    ], LoseUI.prototype, "levelGoldLayer", void 0);
    __decorate([
        property(cc.Label)
    ], LoseUI.prototype, "goldLabel", void 0);
    __decorate([
        property(cc.Node)
    ], LoseUI.prototype, "btnGetAwardSingle", void 0);
    __decorate([
        property(cc.Node)
    ], LoseUI.prototype, "btnVideo", void 0);
    __decorate([
        property(cc.Node)
    ], LoseUI.prototype, "btnNextLevel", void 0);
    __decorate([
        property(cc.Node)
    ], LoseUI.prototype, "btnReplay", void 0);
    __decorate([
        property(cc.Node)
    ], LoseUI.prototype, "btnLobby", void 0);
    __decorate([
        property(cc.Node)
    ], LoseUI.prototype, "btnShareVideo", void 0);
    __decorate([
        property(cc.Label)
    ], LoseUI.prototype, "shareGold", void 0);
    LoseUI = __decorate([
        ccclass
    ], LoseUI);
    return LoseUI;
}(yyComponent_1.default));
exports.default = LoseUI;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxVSVxcTG9zZVVJXFxMb3NlVUkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBQzFELGtFQUFpRTtBQUVqRSx3RUFBbUU7QUFDbkUsMkRBQXNEO0FBQ3RELG1FQUE4RDtBQUM5RCwyRUFBMEU7QUFFcEUsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBb0MsMEJBQVc7SUFBL0M7UUFBQSxxRUF3T0M7UUFuT0csbUJBQW1CO1FBRVQsb0JBQWMsR0FBWSxJQUFJLENBQUM7UUFHL0IsZUFBUyxHQUFhLElBQUksQ0FBQztRQUUzQixjQUFRLEdBQVcsQ0FBQyxDQUFDO1FBQ3JCLGFBQU8sR0FBVyxDQUFDLENBQUM7UUFFOUIsZUFBZTtRQUNmLFVBQVU7UUFFQSx1QkFBaUIsR0FBWSxJQUFJLENBQUM7UUFDNUMsVUFBVTtRQUVBLGNBQVEsR0FBWSxJQUFJLENBQUM7UUFFbkMsV0FBVztRQUVELGtCQUFZLEdBQVksSUFBSSxDQUFDO1FBRTdCLGVBQVMsR0FBWSxJQUFJLENBQUM7UUFFMUIsY0FBUSxHQUFZLElBQUksQ0FBQztRQUNuQyxRQUFRO1FBRUUsbUJBQWEsR0FBWSxJQUFJLENBQUM7UUFFOUIsZUFBUyxHQUFhLElBQUksQ0FBQztRQUNyQyxnQkFBZ0I7UUFDTix5QkFBbUIsR0FBVyxHQUFHLENBQUM7O0lBb01oRCxDQUFDO0lBck9HLHNCQUFXLDBCQUFNO1FBRGpCLGFBQWE7YUFDYixjQUFzQixPQUFPLHVCQUFVLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBcUM3QyxzQkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUNEOzs7T0FHRztJQUNJLHFCQUFJLEdBQVgsVUFBWSxJQUFTO1FBQ2pCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtZQUNwQixJQUFJLEVBQUUsR0FBRyxtQkFBUyxDQUFDLEtBQUssQ0FBQyx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNsRCxJQUFJLEdBQUcsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQ3ZCO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBRXhCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVTLG9DQUFtQixHQUE3QjtRQUNJLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVTLGlDQUFnQixHQUExQjtRQUNJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRUQsY0FBYztJQUNKLGtDQUFpQixHQUEzQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYTtZQUFFLE9BQU8sS0FBSyxDQUFDO1FBQ3RDLElBQUksc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxtQ0FBZ0IsQ0FBQyxFQUFFO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFFM0UsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUN6QyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1NBQzFEO1FBRUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2pDLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDRCxjQUFjO0lBQ0osa0NBQWlCLEdBQTNCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVM7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUNoRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3RCLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztTQUNyQztJQUNMLENBQUM7SUFFRCxjQUFjO0lBQ0osZ0NBQWUsR0FBekI7UUFDSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCO1lBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDbkUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7SUFDckQsQ0FBQztJQUNTLGdDQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQjtZQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3RELENBQUM7SUFDRCxjQUFjO0lBQ0osOEJBQWEsR0FBdkI7UUFDSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYztZQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztJQUNqRSxDQUFDO0lBQ0QsY0FBYztJQUNKLDhCQUFhLEdBQXZCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWM7WUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDbEUsQ0FBQztJQUNELFdBQVc7SUFDRCw2QkFBWSxHQUF0QjtRQUNJLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ25ELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZO1lBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3pELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO0lBQ3JELENBQUM7SUFDUyw2QkFBWSxHQUF0QjtRQUNJLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3BELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZO1lBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQzFELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3RELENBQUM7SUFFTSxxQkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFFUyx3QkFBTyxHQUFqQixVQUFrQixJQUFTO1FBQ3ZCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWpCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3RFLENBQUM7SUFFUyw2QkFBWSxHQUF0QjtRQUNJLE9BQU8sSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ3hDLENBQUM7SUFFRCxNQUFNO0lBQ0ksMkJBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUNELFVBQVU7SUFDQSwrQkFBYyxHQUF4QjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUN2RSxDQUFDO0lBQ1MsMEJBQVMsR0FBbkI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsZUFBZSxDQUFDLGdCQUFnQixFQUFFO1lBQ2xELElBQUksRUFBRSxVQUFVO1lBQ2hCLFNBQVMsRUFBRSxtQkFBbUI7WUFDOUIsS0FBSyxFQUFFLENBQUM7WUFDUixJQUFJLEVBQUUsR0FBRztTQUNaLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUNELElBQUk7SUFDTSw0QkFBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsaUJBQWlCO0lBQ1AsaUNBQWdCLEdBQTFCO1FBQ0ksa0hBQWtIO0lBQ3RILENBQUM7SUFFRCxNQUFNO0lBQ0ksMkJBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUNTLDhCQUFhLEdBQXZCO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzNFLENBQUM7SUFDUyxnQ0FBZSxHQUF6QjtRQUNJLGtCQUFrQjtRQUNsQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFDRCxNQUFNO0lBQ0ksNkJBQVksR0FBdEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7SUFFUyx3QkFBTyxHQUFqQixVQUFrQixJQUFZLEVBQUUsRUFBYTtRQUE3QyxpQkFrQkM7UUFqQkcsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM3RCxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVCLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRTtZQUN0QyxRQUFRLEVBQUUsR0FBRztZQUNiLEVBQUUsRUFBRTtnQkFDQSxLQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsZUFBZSxDQUFDLGdCQUFnQixFQUFFO29CQUNsRCxJQUFJLEVBQUUsVUFBVTtvQkFDaEIsU0FBUyxFQUFFLHFCQUFxQjtvQkFDaEMsS0FBSyxFQUFFLElBQUk7b0JBQ1gsSUFBSSxFQUFFLEdBQUc7aUJBQ1osQ0FBQyxDQUFDO2dCQUNILENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUM7WUFDakIsQ0FBQztZQUNELElBQUksRUFBRSxJQUFJO1NBQ2IsQ0FBQyxDQUFBO0lBQ04sQ0FBQztJQUVELFVBQVU7SUFDQSxnQ0FBZSxHQUF6QjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3BILENBQUM7SUFDUyxtQ0FBa0IsR0FBNUI7UUFDSSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ1MsaUNBQWdCLEdBQTFCO0lBRUEsQ0FBQztJQUVELGlCQUFpQjtJQUNQLDZCQUFZLEdBQXRCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7SUFDUywwQkFBUyxHQUFuQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLHVCQUFVLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hELHdEQUF3RDtJQUM1RCxDQUFDO0lBL05EO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7a0RBQ3VCO0lBR3pDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7NkNBQ2tCO0lBUXJDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7cURBQzBCO0lBRzVDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7NENBQ2lCO0lBSW5DO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7Z0RBQ3FCO0lBRXZDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7NkNBQ2tCO0lBRXBDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7NENBQ2lCO0lBR25DO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7aURBQ3NCO0lBRXhDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7NkNBQ2tCO0lBbENwQixNQUFNO1FBRDFCLE9BQU87T0FDYSxNQUFNLENBd08xQjtJQUFELGFBQUM7Q0F4T0QsQUF3T0MsQ0F4T21DLHFCQUFXLEdBd085QztrQkF4T29CLE1BQU0iLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeXlDb21wb25lbnQgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24veXlDb21wb25lbnRcIjtcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcbmltcG9ydCBBY3Rpb24zZE1hbmFnZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vQWN0aW9uM2RNYW5hZ2VyXCI7XG5pbXBvcnQgeyBFdmVudFR5cGUgfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcbmltcG9ydCBVSU1hbmFnZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vVUlNYW5hZ2VyXCI7XG5pbXBvcnQgR2FtZVBsYXRmb3JtIGZyb20gXCIuLi8uLi9TY3JpcHQvUGxhdGZvcm0vR2FtZVBsYXRmb3JtXCI7XG5pbXBvcnQgeyBHYW1lUGxhdGZvcm1UeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9QbGF0Zm9ybS9HYW1lUGxhdGZvcm1UeXBlXCI7XG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMb3NlVUkgZXh0ZW5kcyB5eUNvbXBvbmVudCB7XG5cbiAgICAvKirlnLrmma8vVUnnsbvlnosgKi9cbiAgICBwdWJsaWMgZ2V0IHVpVHlwZSgpIHsgcmV0dXJuIEdsb2JhbEVudW0uVUkubG9zZVVJOyB9XG5cbiAgICAvKirmmL7npLrlhbPljaHlpZblirHnmoTph5HluIHnmoToioLngrnlsYIgKi9cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBwcm90ZWN0ZWQgbGV2ZWxHb2xkTGF5ZXI6IGNjLk5vZGUgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLkxhYmVsKVxuICAgIHByb3RlY3RlZCBnb2xkTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcblxuICAgIHByb3RlY3RlZCBiYXNlR29sZDogbnVtYmVyID0gMDtcbiAgICBwcm90ZWN0ZWQgc3BlR29sZDogbnVtYmVyID0gMDtcblxuICAgIC8v6KeG6aKR5LiO5pmu6YCa6aKG5Y+W5YiG5byA55qE5pa55qGI77yaXG4gICAgLyoq5Y2V5YCN6aKG5Y+WICovXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJ0bkdldEF3YXJkU2luZ2xlOiBjYy5Ob2RlID0gbnVsbDtcbiAgICAvKirop4bpopHpooblj5YgKi9cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBwcm90ZWN0ZWQgYnRuVmlkZW86IGNjLk5vZGUgPSBudWxsO1xuXG4gICAgLyoq5LiL5LiA5YWz5oyJ6ZKuICovXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJ0bk5leHRMZXZlbDogY2MuTm9kZSA9IG51bGw7XG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJ0blJlcGxheTogY2MuTm9kZSA9IG51bGw7XG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJ0bkxvYmJ5OiBjYy5Ob2RlID0gbnVsbDtcbiAgICAvL+WktOadoeW9leWxj+WIhuS6q1xuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICAgIHByb3RlY3RlZCBidG5TaGFyZVZpZGVvOiBjYy5Ob2RlID0gbnVsbDtcbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgcHJvdGVjdGVkIHNoYXJlR29sZDogY2MuTGFiZWwgPSBudWxsO1xuICAgIC8qKuWIhuS6q+W9leWxj+WlluWKseeahOmHkeW4gemHjyAqL1xuICAgIHByb3RlY3RlZCBzaGFyZVZpZGVvQXdhcmRHb2xkOiBudW1iZXIgPSAxMDA7XG5cbiAgICBwcm90ZWN0ZWQgZGF0YTogYW55O1xuXG4gICAgcHVibGljIHJlc2V0KCkge1xuICAgICAgICB0aGlzLmhpZGVCdG5HZXRBd2FyZCgpO1xuICAgICAgICB0aGlzLmhpZGVCdG5Mb2JieSgpO1xuICAgICAgICB0aGlzLmhpZGVCdG5TaGFyZVZpZGVvKCk7XG4gICAgICAgIHRoaXMuaGlkZUxldmVsR29sZCgpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiDmmL7npLpVSVxuICAgICAqIEBwYXJhbSBkYXRhIOWFs+WNoeaIkOe7qVxuICAgICAqL1xuICAgIHB1YmxpYyBzaG93KGRhdGE6IGFueSkge1xuICAgICAgICB0aGlzLnJlc2V0KCk7XG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IGRhdGEpIHtcbiAgICAgICAgICAgIGxldCB1aSA9IFVJTWFuYWdlci5nZXRVSShHbG9iYWxFbnVtLlVJLmxldmVsSW5mbyk7XG4gICAgICAgICAgICBkYXRhID0gdWkuZ2V0RGF0YSgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xuXG4gICAgICAgIHRoaXMuc2V0RGF0YShkYXRhKTtcbiAgICAgICAgdGhpcy5zdGVwU2hvd0J0bkdldEF3YXJkKCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHN0ZXBTaG93QnRuR2V0QXdhcmQoKSB7XG4gICAgICAgIHRoaXMuc2hvd0J0blNoYXJlVmlkZW8oKTtcbiAgICAgICAgdGhpcy5zaG93QnRuR2V0QXdhcmQoKTtcbiAgICAgICAgdGhpcy5zaG93TGV2ZWxHb2xkKCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHN0ZXBTaG93QnRuTG9iYnkoKSB7XG4gICAgICAgIHRoaXMuc2hvd0J0bkxvYmJ5KCk7XG4gICAgfVxuXG4gICAgLyoq5pi+56S65YiG5Lqr5b2V5bGP5oyJ6ZKuICovXG4gICAgcHJvdGVjdGVkIHNob3dCdG5TaGFyZVZpZGVvKCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAoIXRoaXMuYnRuU2hhcmVWaWRlbykgcmV0dXJuIGZhbHNlO1xuICAgICAgICBpZiAoR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy50eXBlICE9IEdhbWVQbGF0Zm9ybVR5cGUuVFQpIHJldHVybiBmYWxzZTtcblxuICAgICAgICBpZiAoISF0aGlzLnNoYXJlR29sZCkge1xuICAgICAgICAgICAgdGhpcy5zaGFyZUdvbGQubm9kZS5wYXJlbnQuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuc2hhcmVHb2xkLnN0cmluZyA9IFwiK1wiICsgdGhpcy5zaGFyZVZpZGVvQXdhcmRHb2xkO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5idG5TaGFyZVZpZGVvLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICAvKirpmpDol4/liIbkuqvlvZXlsY/mjInpkq4gKi9cbiAgICBwcm90ZWN0ZWQgaGlkZUJ0blNoYXJlVmlkZW8oKSB7XG4gICAgICAgIGlmICghIXRoaXMuc2hhcmVHb2xkKSB0aGlzLnNoYXJlR29sZC5ub2RlLnBhcmVudC5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5TaGFyZVZpZGVvKSB7XG4gICAgICAgICAgICB0aGlzLmJ0blNoYXJlVmlkZW8uYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKirmmL7npLrpooblj5blpZblirHmjInpkq4gKi9cbiAgICBwcm90ZWN0ZWQgc2hvd0J0bkdldEF3YXJkKCkge1xuICAgICAgICBpZiAoISF0aGlzLmJ0bkdldEF3YXJkU2luZ2xlKSB0aGlzLmJ0bkdldEF3YXJkU2luZ2xlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIGlmICghIXRoaXMuYnRuVmlkZW8pIHRoaXMuYnRuVmlkZW8uYWN0aXZlID0gdHJ1ZTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIGhpZGVCdG5HZXRBd2FyZCgpIHtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5HZXRBd2FyZFNpbmdsZSkgdGhpcy5idG5HZXRBd2FyZFNpbmdsZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5WaWRlbykgdGhpcy5idG5WaWRlby5hY3RpdmUgPSBmYWxzZTtcbiAgICB9XG4gICAgLyoq5pi+56S65YWz5Y2h6YeR5biB5aWW5YqxICovXG4gICAgcHJvdGVjdGVkIHNob3dMZXZlbEdvbGQoKSB7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxHb2xkTGF5ZXIpIHRoaXMubGV2ZWxHb2xkTGF5ZXIuYWN0aXZlID0gdHJ1ZTtcbiAgICB9XG4gICAgLyoq6ZqQ6JeP5YWz5Y2h6YeR5biB5aWW5YqxICovXG4gICAgcHJvdGVjdGVkIGhpZGVMZXZlbEdvbGQoKSB7XG4gICAgICAgIGlmICghIXRoaXMubGV2ZWxHb2xkTGF5ZXIpIHRoaXMubGV2ZWxHb2xkTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgfVxuICAgIC8v6L+U5Zue44CB5LiL5LiA5YWz562J5oyJ6ZKuXG4gICAgcHJvdGVjdGVkIHNob3dCdG5Mb2JieSgpIHtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5SZXBsYXkpIHRoaXMuYnRuUmVwbGF5LmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIGlmICghIXRoaXMuYnRuTmV4dExldmVsKSB0aGlzLmJ0bk5leHRMZXZlbC5hY3RpdmUgPSB0cnVlO1xuICAgICAgICBpZiAoISF0aGlzLmJ0bkxvYmJ5KSB0aGlzLmJ0bkxvYmJ5LmFjdGl2ZSA9IHRydWU7XG4gICAgfVxuICAgIHByb3RlY3RlZCBoaWRlQnRuTG9iYnkoKSB7XG4gICAgICAgIGlmICghIXRoaXMuYnRuUmVwbGF5KSB0aGlzLmJ0blJlcGxheS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgaWYgKCEhdGhpcy5idG5OZXh0TGV2ZWwpIHRoaXMuYnRuTmV4dExldmVsLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICBpZiAoISF0aGlzLmJ0bkxvYmJ5KSB0aGlzLmJ0bkxvYmJ5LmFjdGl2ZSA9IGZhbHNlO1xuICAgIH1cblxuICAgIHB1YmxpYyBoaWRlKCkge1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHNldERhdGEoZGF0YTogYW55KSB7XG4gICAgICAgIHRoaXMuZGF0YSA9IGRhdGE7XG5cbiAgICAgICAgdGhpcy5iYXNlR29sZCA9IGRhdGEuZ29sZDtcbiAgICAgICAgdGhpcy5nb2xkTGFiZWwuc3RyaW5nID0gKHRoaXMuYmFzZUdvbGQgKyB0aGlzLnNwZUdvbGQpLnRvU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGdldFRvdGFsR29sZCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5iYXNlR29sZCArIHRoaXMuc3BlR29sZDtcbiAgICB9XG5cbiAgICAvL+i/lOWbnummlumhtVxuICAgIHByb3RlY3RlZCBvbkJ0bkxvYmJ5KCkge1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LmVudGVyTG9iYnkpO1xuICAgIH1cbiAgICAvKirop4bpopHot7PlhbMgKi9cbiAgICBwcm90ZWN0ZWQgb25CdG5OZXh0TGV2ZWwoKSB7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQXVkaW9FdmVudC5wbGF5Q2xpY2tCdG4pO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlNES0V2ZW50LnNob3dWaWRlbywgdGhpcy5wYXNzTGV2ZWwuYmluZCh0aGlzKSk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBwYXNzTGV2ZWwoKSB7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuUGxheWVyRGF0YUV2ZW50LnVwZGF0ZVBsYXllckRhdGEsIHtcbiAgICAgICAgICAgIHR5cGU6IFwiZ2FtZURhdGFcIixcbiAgICAgICAgICAgIGF0dHJpYnV0ZTogXCJnYW1lRGF0YS5jdXJMZXZlbFwiLFxuICAgICAgICAgICAgdmFsdWU6IDEsXG4gICAgICAgICAgICBtb2RlOiBcIitcIixcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5wbGF5TmV4dExldmVsKTtcbiAgICB9XG4gICAgLy/ph43njqlcbiAgICBwcm90ZWN0ZWQgb25CdG5SZXBsYXkoKSB7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQXVkaW9FdmVudC5wbGF5Q2xpY2tCdG4pO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQucmVwbGF5Q3VyTGV2ZWwpO1xuICAgIH1cblxuICAgIC8qKuiuvue9ruaMiemSruWdkOagh+S4uuW4uOinhOeKtuaAgSAqL1xuICAgIHByb3RlY3RlZCBzZXRCdG5zUG9zTm9ybWFsKCkge1xuICAgICAgICAvLyB0aGlzLmJ0blJlcGxheS55ID0gMzEwICsgdGhpcy5idG5SZXBsYXkuaGVpZ2h0ICogdGhpcy5idG5SZXBsYXkuYW5jaG9yWSAtIHRoaXMubm9kZS5oZWlnaHQgKiB0aGlzLm5vZGUuYW5jaG9yWTtcbiAgICB9XG5cbiAgICAvL+inhumikeS4ieWAjVxuICAgIHByb3RlY3RlZCBvbkJ0blZpZGVvKCkge1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5TREtFdmVudC5zaG93VmlkZW8sIHRoaXMub25WaWRlb0ZpbmlzaC5iaW5kKHRoaXMpKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIG9uVmlkZW9GaW5pc2goKSB7XG4gICAgICAgIHRoaXMuaGlkZUxldmVsR29sZCgpO1xuICAgICAgICB0aGlzLmFkZEdvbGQodGhpcy5nZXRUb3RhbEdvbGQoKSAqIDMsIHRoaXMub25HZXRHb2xkRmluaXNoLmJpbmQodGhpcykpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgb25HZXRHb2xkRmluaXNoKCkge1xuICAgICAgICAvL+makOiXj+mihuWPluaMiemSru+8jOaYvuekuui/lOWbnuWSjOmHjeeOqeaMiemSrlxuICAgICAgICB0aGlzLmhpZGVMZXZlbEdvbGQoKTtcbiAgICAgICAgdGhpcy5oaWRlQnRuR2V0QXdhcmQoKTtcbiAgICAgICAgdGhpcy5zdGVwU2hvd0J0bkxvYmJ5KCk7XG4gICAgfVxuICAgIC8v5pmu6YCa6aKG5Y+WXG4gICAgcHJvdGVjdGVkIG9uQnRuR2V0R29sZCgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XG4gICAgICAgIHRoaXMuaGlkZUxldmVsR29sZCgpO1xuICAgICAgICB0aGlzLmFkZEdvbGQodGhpcy5nZXRUb3RhbEdvbGQoKSwgdGhpcy5vbkdldEdvbGRGaW5pc2guYmluZCh0aGlzKSk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGFkZEdvbGQoZ29sZDogbnVtYmVyLCBjYj86IEZ1bmN0aW9uKSB7XG4gICAgICAgIGxldCBwb3MgPSB0aGlzLmxldmVsR29sZExheWVyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigpKTtcbiAgICAgICAgbGV0IGN2cyA9IGNjLmZpbmQoXCJDYW52YXNcIik7XG4gICAgICAgIHBvcy54IC09IGN2cy53aWR0aCAqIDAuNTtcbiAgICAgICAgcG9zLnkgLT0gY3ZzLmhlaWdodCAqIDAuNTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LnBsYXlHb2xkQW5pbSwge1xuICAgICAgICAgICAgc3RhcnRQb3M6IHBvcyxcbiAgICAgICAgICAgIGNiOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5QbGF5ZXJEYXRhRXZlbnQudXBkYXRlUGxheWVyRGF0YSwge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImdhbWVEYXRhXCIsXG4gICAgICAgICAgICAgICAgICAgIGF0dHJpYnV0ZTogXCJnYW1lRGF0YS5hc3NldC5nb2xkXCIsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBnb2xkLFxuICAgICAgICAgICAgICAgICAgICBtb2RlOiBcIitcIlxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICEhY2IgJiYgY2IoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnb2xkOiBnb2xkLFxuICAgICAgICB9KVxuICAgIH1cblxuICAgIC8v5aS05p2h5bmz5Y+w5b2V5bGP5YiG5LqrXG4gICAgcHJvdGVjdGVkIG9uQnRuU2hhcmVWaWRlbygpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5TREtFdmVudC5zaGFyZVJlY29yZCwgdGhpcy5vblNoYXJlVmlkZW9GaW5pc2guYmluZCh0aGlzKSwgdGhpcy5vblNoYXJlVmlkZW9GYWlsLmJpbmQodGhpcykpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgb25TaGFyZVZpZGVvRmluaXNoKCkge1xuICAgICAgICB0aGlzLmhpZGVCdG5TaGFyZVZpZGVvKCk7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQXNzZXRFdmVudC5nZXRQb3dlciwgMik7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5zaG93VGlwLCBcIuWIhuS6q+aIkOWKn++8jOiOt+W+l+S9k+WKm+WlluWKse+8gVwiKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIG9uU2hhcmVWaWRlb0ZhaWwoKSB7XG5cbiAgICB9XG5cbiAgICAvL+ingueci+inhumike+8jOWKoOaXtjYw56eS77yM57un57ut5ri45oiPXG4gICAgcHJvdGVjdGVkIG9uQnRuQWRkVGltZSgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuU0RLRXZlbnQuc2hvd1ZpZGVvLCB0aGlzLm9uQWRkVGltZS5iaW5kKHRoaXMpKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIG9uQWRkVGltZSgpIHtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmV4aXQsIEdsb2JhbEVudW0uVUkubG9zZVVJKTtcbiAgICAgICAgLy8gdGhpcy5lbWl0KEV2ZW50VHlwZS5MZXZlbEV2ZW50LmFkZFJlbWFpblRpbWVCeVZpZGVvKTtcbiAgICB9XG5cbn1cbiJdfQ==