
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Recommend/Script/RecommendItem.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd1ce16euR1GAq5K0MAlolRv', 'RecommendItem');
// Recommend/Script/RecommendItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var RecommendImageManager_1 = require("../../Script/Recommend/RecommendImageManager");
var MyAtlasSprite_1 = require("../../Script/Recommend/MyAtlasSprite");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * 推荐游戏节点
 */
var RecommendItem = /** @class */ (function (_super) {
    __extends(RecommendItem, _super);
    function RecommendItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.gameIcon = null; //游戏图标
        _this.gameName = null; //游戏名称
        return _this;
    }
    /**互推数据id */
    RecommendItem.prototype.getRecommendId = function () { return this.recommendId; };
    RecommendItem.prototype.init = function (data) {
        this.node.setPosition(0, 0);
        this.node.setScale(1, 1);
        this.onEvents();
        if (undefined !== data) {
            this.setData(data);
        }
    };
    RecommendItem.prototype.onEvents = function () {
        this.node.on("touchend", this.onClick, this);
    };
    RecommendItem.prototype.reset = function () {
        this.node.setPosition(0, 0);
        this.node.setScale(1, 1);
        var wg = this.node.getComponent(cc.Widget);
        if (!!wg) {
            wg.isAbsoluteBottom = false;
            wg.isAbsoluteLeft = false;
            wg.isAbsoluteRight = false;
            wg.isAbsoluteTop = false;
        }
    };
    RecommendItem.prototype.reuse = function (data) {
        this.reset();
        this.setData(data);
    };
    RecommendItem.prototype.unuse = function () {
    };
    RecommendItem.prototype.setData = function (data) {
        var recommendData;
        if (typeof data === "number") {
            if (this.recommendId === data)
                return;
            recommendData = RecommendDataManager_1.default.getRecommendData(data);
        }
        else {
            if (this.recommendId === data.id)
                return;
            recommendData = data;
        }
        this.recommendId = recommendData.id;
        //与已有数据相同时不需要再次设置
        //图标
        this.setGameIcon(recommendData.gameIcon);
        //名字
        this.setGameName(recommendData.gameName);
    };
    RecommendItem.prototype.setGameIcon = function (gameIcon) {
        //本地图片：
        // this.gameIcon.getComponent(cc.Sprite).spriteFrame = RecommendDataManager.getGameIcon(gameIcon);
        var _this = this;
        //远程地址图片
        RecommendImageManager_1.default.load(gameIcon, function (data) {
            data.width = _this.node.width;
            data.height = _this.node.height;
            _this.gameIcon.getComponent(MyAtlasSprite_1.default).setAtlasData(data);
        });
    };
    RecommendItem.prototype.setGameName = function (n) {
        this.gameName.string = n;
    };
    //点击节点
    RecommendItem.prototype.onClick = function () {
        this.emit(GameEventType_1.EventType.RecommendEvent.clickRecommendItem, this.recommendId);
    };
    __decorate([
        property(cc.Node)
    ], RecommendItem.prototype, "gameIcon", void 0);
    __decorate([
        property(cc.Label)
    ], RecommendItem.prototype, "gameName", void 0);
    RecommendItem = __decorate([
        ccclass
    ], RecommendItem);
    return RecommendItem;
}(yyComponent_1.default));
exports.default = RecommendItem;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcUmVjb21tZW5kXFxTY3JpcHRcXFJlY29tbWVuZEl0ZW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBQzFELG9GQUErRTtBQUMvRSx3RUFBbUU7QUFDbkUsc0ZBQWlGO0FBQ2pGLHNFQUFpRTtBQUUzRCxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUM1Qzs7R0FFRztBQUVIO0lBQTJDLGlDQUFXO0lBQXREO1FBQUEscUVBMkVDO1FBekVXLGNBQVEsR0FBWSxJQUFJLENBQUMsQ0FBSyxNQUFNO1FBRXBDLGNBQVEsR0FBYSxJQUFJLENBQUMsQ0FBTSxNQUFNOztJQXVFbEQsQ0FBQztJQXBFRyxZQUFZO0lBQ0wsc0NBQWMsR0FBckIsY0FBMEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUU3Qyw0QkFBSSxHQUFYLFVBQVksSUFBYTtRQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDcEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN0QjtJQUNMLENBQUM7SUFDUyxnQ0FBUSxHQUFsQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDTSw2QkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN6QixJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ04sRUFBRSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztZQUM1QixFQUFFLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztZQUMxQixFQUFFLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztZQUMzQixFQUFFLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztTQUM1QjtJQUNMLENBQUM7SUFDTSw2QkFBSyxHQUFaLFVBQWEsSUFBWTtRQUNyQixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFDTSw2QkFBSyxHQUFaO0lBRUEsQ0FBQztJQUVNLCtCQUFPLEdBQWQsVUFBZSxJQUFpRTtRQUM1RSxJQUFJLGFBQWEsQ0FBQztRQUNsQixJQUFJLE9BQU8sSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUMxQixJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssSUFBSTtnQkFBRSxPQUFPO1lBQ3RDLGFBQWEsR0FBRyw4QkFBb0IsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvRDthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLElBQUksQ0FBQyxFQUFFO2dCQUFFLE9BQU87WUFDekMsYUFBYSxHQUFHLElBQUksQ0FBQztTQUN4QjtRQUNELElBQUksQ0FBQyxXQUFXLEdBQUcsYUFBYSxDQUFDLEVBQUUsQ0FBQztRQUNwQyxpQkFBaUI7UUFDakIsSUFBSTtRQUNKLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLElBQUk7UUFDSixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ08sbUNBQVcsR0FBbkIsVUFBb0IsUUFBZ0I7UUFDaEMsT0FBTztRQUNQLGtHQUFrRztRQUZ0RyxpQkFVQztRQU5HLFFBQVE7UUFDUiwrQkFBcUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQUMsSUFBSTtZQUN0QyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQzdCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDL0IsS0FBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsdUJBQWEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqRSxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFDTyxtQ0FBVyxHQUFuQixVQUFvQixDQUFTO1FBQ3pCLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBRUQsTUFBTTtJQUNFLCtCQUFPLEdBQWY7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBeEVEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7bURBQ2U7SUFFakM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQzttREFDZTtJQUpqQixhQUFhO1FBRGpDLE9BQU87T0FDYSxhQUFhLENBMkVqQztJQUFELG9CQUFDO0NBM0VELEFBMkVDLENBM0UwQyxxQkFBVyxHQTJFckQ7a0JBM0VvQixhQUFhIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHl5Q29tcG9uZW50IGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL3l5Q29tcG9uZW50XCI7XHJcbmltcG9ydCBSZWNvbW1lbmREYXRhTWFuYWdlciBmcm9tIFwiLi4vLi4vU2NyaXB0L1JlY29tbWVuZC9SZWNvbW1lbmREYXRhTWFuYWdlclwiO1xyXG5pbXBvcnQgeyBFdmVudFR5cGUgfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcclxuaW1wb3J0IFJlY29tbWVuZEltYWdlTWFuYWdlciBmcm9tIFwiLi4vLi4vU2NyaXB0L1JlY29tbWVuZC9SZWNvbW1lbmRJbWFnZU1hbmFnZXJcIjtcclxuaW1wb3J0IE15QXRsYXNTcHJpdGUgZnJvbSBcIi4uLy4uL1NjcmlwdC9SZWNvbW1lbmQvTXlBdGxhc1Nwcml0ZVwiO1xyXG5cclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuLyoqXHJcbiAqIOaOqOiNkOa4uOaIj+iKgueCuVxyXG4gKi9cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVjb21tZW5kSXRlbSBleHRlbmRzIHl5Q29tcG9uZW50IHtcclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcHJpdmF0ZSBnYW1lSWNvbjogY2MuTm9kZSA9IG51bGw7ICAgICAvL+a4uOaIj+Wbvuagh1xyXG4gICAgQHByb3BlcnR5KGNjLkxhYmVsKVxyXG4gICAgcHJpdmF0ZSBnYW1lTmFtZTogY2MuTGFiZWwgPSBudWxsOyAgICAgIC8v5ri45oiP5ZCN56ewXHJcblxyXG4gICAgcHJpdmF0ZSByZWNvbW1lbmRJZDogbnVtYmVyOyAgICAvL+S6kuaOqOaVsOaNrmlkXHJcbiAgICAvKirkupLmjqjmlbDmja5pZCAqL1xyXG4gICAgcHVibGljIGdldFJlY29tbWVuZElkKCkgeyByZXR1cm4gdGhpcy5yZWNvbW1lbmRJZDsgfVxyXG5cclxuICAgIHB1YmxpYyBpbml0KGRhdGE/OiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24oMCwgMCk7XHJcbiAgICAgICAgdGhpcy5ub2RlLnNldFNjYWxlKDEsIDEpO1xyXG4gICAgICAgIHRoaXMub25FdmVudHMoKTtcclxuICAgICAgICBpZiAodW5kZWZpbmVkICE9PSBkYXRhKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YShkYXRhKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgb25FdmVudHMoKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKFwidG91Y2hlbmRcIiwgdGhpcy5vbkNsaWNrLCB0aGlzKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyByZXNldCgpIHtcclxuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24oMCwgMCk7XHJcbiAgICAgICAgdGhpcy5ub2RlLnNldFNjYWxlKDEsIDEpO1xyXG4gICAgICAgIGxldCB3ZyA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuV2lkZ2V0KTtcclxuICAgICAgICBpZiAoISF3Zykge1xyXG4gICAgICAgICAgICB3Zy5pc0Fic29sdXRlQm90dG9tID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHdnLmlzQWJzb2x1dGVMZWZ0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHdnLmlzQWJzb2x1dGVSaWdodCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB3Zy5pc0Fic29sdXRlVG9wID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHVibGljIHJldXNlKGRhdGE6IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICB0aGlzLnNldERhdGEoZGF0YSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgdW51c2UoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXREYXRhKGRhdGE6IG51bWJlciB8IHsgaWQ6IG51bWJlciwgaWNvbk5hbWU6IHN0cmluZywgZ2FtZU5hbWU6IHN0cmluZyB9KSB7XHJcbiAgICAgICAgbGV0IHJlY29tbWVuZERhdGE7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBkYXRhID09PSBcIm51bWJlclwiKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLnJlY29tbWVuZElkID09PSBkYXRhKSByZXR1cm47XHJcbiAgICAgICAgICAgIHJlY29tbWVuZERhdGEgPSBSZWNvbW1lbmREYXRhTWFuYWdlci5nZXRSZWNvbW1lbmREYXRhKGRhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLnJlY29tbWVuZElkID09PSBkYXRhLmlkKSByZXR1cm47XHJcbiAgICAgICAgICAgIHJlY29tbWVuZERhdGEgPSBkYXRhO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnJlY29tbWVuZElkID0gcmVjb21tZW5kRGF0YS5pZDtcclxuICAgICAgICAvL+S4juW3suacieaVsOaNruebuOWQjOaXtuS4jemcgOimgeWGjeasoeiuvue9rlxyXG4gICAgICAgIC8v5Zu+5qCHXHJcbiAgICAgICAgdGhpcy5zZXRHYW1lSWNvbihyZWNvbW1lbmREYXRhLmdhbWVJY29uKTtcclxuICAgICAgICAvL+WQjeWtl1xyXG4gICAgICAgIHRoaXMuc2V0R2FtZU5hbWUocmVjb21tZW5kRGF0YS5nYW1lTmFtZSk7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIHNldEdhbWVJY29uKGdhbWVJY29uOiBzdHJpbmcpIHtcclxuICAgICAgICAvL+acrOWcsOWbvueJh++8mlxyXG4gICAgICAgIC8vIHRoaXMuZ2FtZUljb24uZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSBSZWNvbW1lbmREYXRhTWFuYWdlci5nZXRHYW1lSWNvbihnYW1lSWNvbik7XHJcblxyXG4gICAgICAgIC8v6L+c56iL5Zyw5Z2A5Zu+54mHXHJcbiAgICAgICAgUmVjb21tZW5kSW1hZ2VNYW5hZ2VyLmxvYWQoZ2FtZUljb24sIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgIGRhdGEud2lkdGggPSB0aGlzLm5vZGUud2lkdGg7XHJcbiAgICAgICAgICAgIGRhdGEuaGVpZ2h0ID0gdGhpcy5ub2RlLmhlaWdodDtcclxuICAgICAgICAgICAgdGhpcy5nYW1lSWNvbi5nZXRDb21wb25lbnQoTXlBdGxhc1Nwcml0ZSkuc2V0QXRsYXNEYXRhKGRhdGEpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgcHJpdmF0ZSBzZXRHYW1lTmFtZShuOiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLmdhbWVOYW1lLnN0cmluZyA9IG47XHJcbiAgICB9XHJcblxyXG4gICAgLy/ngrnlh7voioLngrlcclxuICAgIHByaXZhdGUgb25DbGljaygpIHtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlJlY29tbWVuZEV2ZW50LmNsaWNrUmVjb21tZW5kSXRlbSwgdGhpcy5yZWNvbW1lbmRJZCk7XHJcbiAgICB9XHJcbn1cclxuIl19