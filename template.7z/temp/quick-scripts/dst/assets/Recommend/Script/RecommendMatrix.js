
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Recommend/Script/RecommendMatrix.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0f711Q689tAopW3Al+kx54X', 'RecommendMatrix');
// Recommend/Script/RecommendMatrix.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendContainer_1 = require("../../Script/Recommend/RecommendContainer");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
//互推矩阵
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecommendMatrix = /** @class */ (function (_super) {
    __extends(RecommendMatrix, _super);
    function RecommendMatrix() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.matrix = null;
        return _this;
    }
    RecommendMatrix.prototype.setData = function (data) {
        if (!!data.scale) {
            this.matrix.setScale(data.scale);
        }
        if (!!data.pos) {
            this.matrix.setPosition(data.pos);
        }
        if (!!data.widget) {
            this.setWidget(this.matrix, data.widget);
        }
        var items = data.items;
        //默认使用全部互推数据
        if (!items) {
            items = [].concat(RecommendDataManager_1.default.getAllRecommendData());
            if (items.length > 8) {
                items.length = 8;
            }
        }
        this.addItems(items, data.itemType);
    };
    __decorate([
        property(cc.Node)
    ], RecommendMatrix.prototype, "matrix", void 0);
    RecommendMatrix = __decorate([
        ccclass
    ], RecommendMatrix);
    return RecommendMatrix;
}(RecommendContainer_1.default));
exports.default = RecommendMatrix;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcUmVjb21tZW5kXFxTY3JpcHRcXFJlY29tbWVuZE1hdHJpeC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnRkFBMkU7QUFDM0Usb0ZBQStFO0FBRS9FLE1BQU07QUFDQSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUE2QyxtQ0FBa0I7SUFBL0Q7UUFBQSxxRUF3QkM7UUF0QlcsWUFBTSxHQUFZLElBQUksQ0FBQzs7SUFzQm5DLENBQUM7SUFwQmEsaUNBQU8sR0FBakIsVUFBa0IsSUFBUztRQUN2QixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ2QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3BDO1FBQ0QsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNaLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNyQztRQUNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDZixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzVDO1FBQ0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUN2QixZQUFZO1FBQ1osSUFBSSxDQUFDLEtBQUssRUFBRTtZQUNSLEtBQUssR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLDhCQUFvQixDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQztZQUM5RCxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUNsQixLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzthQUNwQjtTQUNKO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFyQkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzttREFDYTtJQUZkLGVBQWU7UUFEbkMsT0FBTztPQUNhLGVBQWUsQ0F3Qm5DO0lBQUQsc0JBQUM7Q0F4QkQsQUF3QkMsQ0F4QjRDLDRCQUFrQixHQXdCOUQ7a0JBeEJvQixlQUFlIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlY29tbWVuZENvbnRhaW5lciBmcm9tIFwiLi4vLi4vU2NyaXB0L1JlY29tbWVuZC9SZWNvbW1lbmRDb250YWluZXJcIjtcclxuaW1wb3J0IFJlY29tbWVuZERhdGFNYW5hZ2VyIGZyb20gXCIuLi8uLi9TY3JpcHQvUmVjb21tZW5kL1JlY29tbWVuZERhdGFNYW5hZ2VyXCI7XHJcblxyXG4vL+S6kuaOqOefqemYtVxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVjb21tZW5kTWF0cml4IGV4dGVuZHMgUmVjb21tZW5kQ29udGFpbmVyIHtcclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcHJpdmF0ZSBtYXRyaXg6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIHByb3RlY3RlZCBzZXREYXRhKGRhdGE6IGFueSkge1xyXG4gICAgICAgIGlmICghIWRhdGEuc2NhbGUpIHtcclxuICAgICAgICAgICAgdGhpcy5tYXRyaXguc2V0U2NhbGUoZGF0YS5zY2FsZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghIWRhdGEucG9zKSB7XHJcbiAgICAgICAgICAgIHRoaXMubWF0cml4LnNldFBvc2l0aW9uKGRhdGEucG9zKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCEhZGF0YS53aWRnZXQpIHtcclxuICAgICAgICAgICAgdGhpcy5zZXRXaWRnZXQodGhpcy5tYXRyaXgsIGRhdGEud2lkZ2V0KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGl0ZW1zID0gZGF0YS5pdGVtcztcclxuICAgICAgICAvL+m7mOiupOS9v+eUqOWFqOmDqOS6kuaOqOaVsOaNrlxyXG4gICAgICAgIGlmICghaXRlbXMpIHtcclxuICAgICAgICAgICAgaXRlbXMgPSBbXS5jb25jYXQoUmVjb21tZW5kRGF0YU1hbmFnZXIuZ2V0QWxsUmVjb21tZW5kRGF0YSgpKTtcclxuICAgICAgICAgICAgaWYgKGl0ZW1zLmxlbmd0aCA+IDgpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW1zLmxlbmd0aCA9IDg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5hZGRJdGVtcyhpdGVtcywgZGF0YS5pdGVtVHlwZSk7XHJcbiAgICB9XHJcbn1cclxuIl19