
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Recommend/Script/RecommendPrimary.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9bb1cZVwklInqSmpbVoh3e6', 'RecommendPrimary');
// Recommend/Script/RecommendPrimary.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendItem_1 = require("./RecommendItem");
var RecommendContainer_1 = require("../../Script/Recommend/RecommendContainer");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
//互推-主推，单个的互推节点分散在界面四周显示的互推组件
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecommendPrimary = /** @class */ (function (_super) {
    __extends(RecommendPrimary, _super);
    function RecommendPrimary() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    //添加互推游戏节点
    RecommendPrimary.prototype.addItems = function (data, type) {
        if (type === void 0) { type = GlobalEnum_1.GlobalEnum.RecommendItemType.normal; }
        var ids = [].concat(RecommendDataManager_1.default.getAllRecommendData());
        var needScale = data.length > 2;
        for (var i = 0, count = data.length; i < count; ++i) {
            // let id = data[i].id;
            var id = i;
            if (id >= ids.length) {
                var index = Math.round(Math.random() * (ids.length - 1));
                id = ids[index].id;
                ids.splice(index, 1);
            }
            var item = this.getItem(type, id);
            this.content.addChild(item);
            if (needScale) {
                item.setScale(0.7, 0.7);
            }
            if (!!data[i].scale) {
                item.setScale(data[i].scale);
            }
            if (!!data[i].pos) {
                item.setPosition(data[i].pos);
            }
            this.setWidget(item, data[i].widget);
        }
    };
    RecommendPrimary.prototype.setData = function (data) {
        var items = data.items;
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        this.addItems(items);
        //自动轮播
        if (undefined === data.autoUpdate || !!data.autoUpdate) {
            this.autoUpdateItem();
        }
    };
    RecommendPrimary.prototype.unuse = function () {
        this.reset();
        this.stopUpdateItem();
    };
    /**启动自动轮播 */
    RecommendPrimary.prototype.autoUpdateItem = function () {
        this.schedule(this.updateItems, 3);
    };
    RecommendPrimary.prototype.stopUpdateItem = function () {
        this.unschedule(this.updateItems);
    };
    /**更新主推内容(轮播) */
    RecommendPrimary.prototype.updateItems = function () {
        var count = this.content.childrenCount;
        var ids = RecommendDataManager_1.default.getAllRecommendData();
        var index = this.content.children[count - 1].getComponent(RecommendItem_1.default).getRecommendId();
        for (var i = 0; i < count; ++i) {
            index += 1;
            if (index >= ids.length) {
                index = 0;
            }
            this.content.children[i].getComponent(RecommendItem_1.default).setData(ids[index]);
        }
    };
    RecommendPrimary = __decorate([
        ccclass
    ], RecommendPrimary);
    return RecommendPrimary;
}(RecommendContainer_1.default));
exports.default = RecommendPrimary;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcUmVjb21tZW5kXFxTY3JpcHRcXFJlY29tbWVuZFByaW1hcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsaURBQTRDO0FBQzVDLGdGQUEyRTtBQUMzRSxrRUFBaUU7QUFDakUsb0ZBQStFO0FBQy9FLDZCQUE2QjtBQUN2QixJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUE4QyxvQ0FBa0I7SUFBaEU7O0lBOERBLENBQUM7SUE3REcsVUFBVTtJQUNBLG1DQUFRLEdBQWxCLFVBQW1CLElBQVcsRUFBRSxJQUEwQztRQUExQyxxQkFBQSxFQUFBLE9BQU8sdUJBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNO1FBQ3RFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsOEJBQW9CLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDO1FBQ2hFLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2hDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDakQsdUJBQXVCO1lBQ3ZCLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztZQUNYLElBQUksRUFBRSxJQUFJLEdBQUcsQ0FBQyxNQUFNLEVBQUU7Z0JBQ2xCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN6RCxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQztnQkFDbkIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDeEI7WUFDRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QixJQUFJLFNBQVMsRUFBRTtnQkFDWCxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQzthQUMzQjtZQUNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7Z0JBQ2pCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ2hDO1lBQ0QsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRTtnQkFDZixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNqQztZQUNELElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN4QztJQUNMLENBQUM7SUFDUyxrQ0FBTyxHQUFqQixVQUFrQixJQUFTO1FBQ3ZCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLEtBQUssRUFBRTtZQUNSLEtBQUssR0FBRyw4QkFBb0IsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1NBQ3REO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixNQUFNO1FBQ04sSUFBSSxTQUFTLEtBQUssSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNwRCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7U0FDekI7SUFDTCxDQUFDO0lBQ00sZ0NBQUssR0FBWjtRQUNJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBQ0QsWUFBWTtJQUNGLHlDQUFjLEdBQXhCO1FBQ0ksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDUyx5Q0FBYyxHQUF4QjtRQUNJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxnQkFBZ0I7SUFDTixzQ0FBVyxHQUFyQjtRQUNJLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1FBQ3ZDLElBQUksR0FBRyxHQUFHLDhCQUFvQixDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDckQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyx1QkFBYSxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDMUYsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRTtZQUM1QixLQUFLLElBQUksQ0FBQyxDQUFDO1lBQ1gsSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDLE1BQU0sRUFBRTtnQkFDckIsS0FBSyxHQUFHLENBQUMsQ0FBQzthQUNiO1lBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLHVCQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7U0FDNUU7SUFDTCxDQUFDO0lBN0RnQixnQkFBZ0I7UUFEcEMsT0FBTztPQUNhLGdCQUFnQixDQThEcEM7SUFBRCx1QkFBQztDQTlERCxBQThEQyxDQTlENkMsNEJBQWtCLEdBOEQvRDtrQkE5RG9CLGdCQUFnQiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgUmVjb21tZW5kSXRlbSBmcm9tIFwiLi9SZWNvbW1lbmRJdGVtXCI7XHJcbmltcG9ydCBSZWNvbW1lbmRDb250YWluZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9SZWNvbW1lbmQvUmVjb21tZW5kQ29udGFpbmVyXCI7XHJcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcclxuaW1wb3J0IFJlY29tbWVuZERhdGFNYW5hZ2VyIGZyb20gXCIuLi8uLi9TY3JpcHQvUmVjb21tZW5kL1JlY29tbWVuZERhdGFNYW5hZ2VyXCI7XHJcbi8v5LqS5o6oLeS4u+aOqO+8jOWNleS4queahOS6kuaOqOiKgueCueWIhuaVo+WcqOeVjOmdouWbm+WRqOaYvuekuueahOS6kuaOqOe7hOS7tlxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVjb21tZW5kUHJpbWFyeSBleHRlbmRzIFJlY29tbWVuZENvbnRhaW5lciB7XHJcbiAgICAvL+a3u+WKoOS6kuaOqOa4uOaIj+iKgueCuVxyXG4gICAgcHJvdGVjdGVkIGFkZEl0ZW1zKGRhdGE6IGFueVtdLCB0eXBlID0gR2xvYmFsRW51bS5SZWNvbW1lbmRJdGVtVHlwZS5ub3JtYWwpIHtcclxuICAgICAgICBsZXQgaWRzID0gW10uY29uY2F0KFJlY29tbWVuZERhdGFNYW5hZ2VyLmdldEFsbFJlY29tbWVuZERhdGEoKSk7XHJcbiAgICAgICAgbGV0IG5lZWRTY2FsZSA9IGRhdGEubGVuZ3RoID4gMjtcclxuICAgICAgICBmb3IgKGxldCBpID0gMCwgY291bnQgPSBkYXRhLmxlbmd0aDsgaSA8IGNvdW50OyArK2kpIHtcclxuICAgICAgICAgICAgLy8gbGV0IGlkID0gZGF0YVtpXS5pZDtcclxuICAgICAgICAgICAgbGV0IGlkID0gaTtcclxuICAgICAgICAgICAgaWYgKGlkID49IGlkcy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGxldCBpbmRleCA9IE1hdGgucm91bmQoTWF0aC5yYW5kb20oKSAqIChpZHMubGVuZ3RoIC0gMSkpO1xyXG4gICAgICAgICAgICAgICAgaWQgPSBpZHNbaW5kZXhdLmlkO1xyXG4gICAgICAgICAgICAgICAgaWRzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbGV0IGl0ZW0gPSB0aGlzLmdldEl0ZW0odHlwZSwgaWQpO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnQuYWRkQ2hpbGQoaXRlbSk7XHJcbiAgICAgICAgICAgIGlmIChuZWVkU2NhbGUpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0uc2V0U2NhbGUoMC43LCAwLjcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICghIWRhdGFbaV0uc2NhbGUpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0uc2V0U2NhbGUoZGF0YVtpXS5zY2FsZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKCEhZGF0YVtpXS5wb3MpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0uc2V0UG9zaXRpb24oZGF0YVtpXS5wb3MpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuc2V0V2lkZ2V0KGl0ZW0sIGRhdGFbaV0ud2lkZ2V0KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc2V0RGF0YShkYXRhOiBhbnkpIHtcclxuICAgICAgICBsZXQgaXRlbXMgPSBkYXRhLml0ZW1zO1xyXG4gICAgICAgIGlmICghaXRlbXMpIHtcclxuICAgICAgICAgICAgaXRlbXMgPSBSZWNvbW1lbmREYXRhTWFuYWdlci5nZXRBbGxSZWNvbW1lbmREYXRhKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuYWRkSXRlbXMoaXRlbXMpO1xyXG4gICAgICAgIC8v6Ieq5Yqo6L2u5pKtXHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gZGF0YS5hdXRvVXBkYXRlIHx8ICEhZGF0YS5hdXRvVXBkYXRlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXV0b1VwZGF0ZUl0ZW0oKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgdW51c2UoKSB7XHJcbiAgICAgICAgdGhpcy5yZXNldCgpO1xyXG4gICAgICAgIHRoaXMuc3RvcFVwZGF0ZUl0ZW0oKTtcclxuICAgIH1cclxuICAgIC8qKuWQr+WKqOiHquWKqOi9ruaSrSAqL1xyXG4gICAgcHJvdGVjdGVkIGF1dG9VcGRhdGVJdGVtKCkge1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUodGhpcy51cGRhdGVJdGVtcywgMyk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc3RvcFVwZGF0ZUl0ZW0oKSB7XHJcbiAgICAgICAgdGhpcy51bnNjaGVkdWxlKHRoaXMudXBkYXRlSXRlbXMpO1xyXG4gICAgfVxyXG4gICAgLyoq5pu05paw5Li75o6o5YaF5a65KOi9ruaSrSkgKi9cclxuICAgIHByb3RlY3RlZCB1cGRhdGVJdGVtcygpIHtcclxuICAgICAgICBsZXQgY291bnQgPSB0aGlzLmNvbnRlbnQuY2hpbGRyZW5Db3VudDtcclxuICAgICAgICBsZXQgaWRzID0gUmVjb21tZW5kRGF0YU1hbmFnZXIuZ2V0QWxsUmVjb21tZW5kRGF0YSgpO1xyXG4gICAgICAgIGxldCBpbmRleCA9IHRoaXMuY29udGVudC5jaGlsZHJlbltjb3VudCAtIDFdLmdldENvbXBvbmVudChSZWNvbW1lbmRJdGVtKS5nZXRSZWNvbW1lbmRJZCgpO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQ7ICsraSkge1xyXG4gICAgICAgICAgICBpbmRleCArPSAxO1xyXG4gICAgICAgICAgICBpZiAoaW5kZXggPj0gaWRzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgaW5kZXggPSAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuY29udGVudC5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoUmVjb21tZW5kSXRlbSkuc2V0RGF0YShpZHNbaW5kZXhdKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19