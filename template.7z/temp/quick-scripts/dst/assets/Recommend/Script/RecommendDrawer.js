
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Recommend/Script/RecommendDrawer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '13584udb5ZFfKHNpwzpXjg2', 'RecommendDrawer');
// Recommend/Script/RecommendDrawer.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendContainer_1 = require("../../Script/Recommend/RecommendContainer");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**抽屉状态 */
var DrawerState;
(function (DrawerState) {
    DrawerState[DrawerState["close"] = 0] = "close";
    DrawerState[DrawerState["open"] = 1] = "open";
    DrawerState[DrawerState["moving"] = 2] = "moving";
})(DrawerState || (DrawerState = {}));
var RecommendDrawer = /** @class */ (function (_super) {
    __extends(RecommendDrawer, _super);
    function RecommendDrawer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.drawer = null; //抽屉
        _this.btnDrawer = null; //抽屉开关按钮
        _this.btnClose = null;
        return _this;
    }
    RecommendDrawer.prototype.init = function (data) {
        this.state = DrawerState.close;
        this.btnClose.active = false;
        // this.openTargetX = 0;//暂设为打开抽屉时移动到屏幕正中间
        var cvs = cc.find("Canvas");
        this.openTargetX = this.drawer.width * this.drawer.anchorX - cvs.width * 0.5;
        this.openDuration = 0.5;
        this.closeDuration = 0.5;
        this.initType();
        this.onEvents();
        if (!!data) {
            this.setData(data);
        }
    };
    RecommendDrawer.prototype.initType = function () {
        this.type = GlobalEnum_1.GlobalEnum.RecommendDrawerType.left;
        this.drawer.x = -0.5 * (this.node.width + this.drawer.width);
        this.closeDis = this.drawer.x - this.openTargetX;
    };
    RecommendDrawer.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.RecommendEvent.openDrawer, this.onBtnDrawer, this);
        this.on(GameEventType_1.EventType.RecommendEvent.closeDrawer, this.onBtnDrawer, this);
    };
    RecommendDrawer.prototype.reset = function () {
        this.state = DrawerState.close;
        this.btnClose.active = false;
    };
    /**
     * 设置抽屉的数据
     * 只记录数据，打开抽屉的时候再添加节点
     * @param data
     * @param [data.type]       抽屉类型,GlobalEnum.RecommendDrawerType枚举值
     * @param [data.itemType]   节点类型，GlobalEnum.RecommendItemType枚举值
     * @param [data.items]      互推游戏的数据数组，包含游戏id，名字，图标文件名等信息
     */
    RecommendDrawer.prototype.setData = function (data) {
        this.data = data;
        this.setType(data.type);
        if (undefined != this.data.scale) {
            this.drawer.setScale(this.data.scale);
        }
        if (undefined != this.data.pos) {
            this.drawer.setPosition(this.data.pos);
        }
        if (!!data.widget) {
            this.setWidget(this.drawer, data.widget);
        }
        if (!!data.btnWidget) {
            this.setWidget(this.btnDrawer, data.btnWidget);
        }
    };
    /**设置抽屉类型 */
    RecommendDrawer.prototype.setType = function (type) {
        this.type = type;
        switch (type) {
            case GlobalEnum_1.GlobalEnum.RecommendDrawerType.left: {
                this.drawer.x = -0.5 * (this.node.width + this.drawer.width);
                break;
            }
            case GlobalEnum_1.GlobalEnum.RecommendDrawerType.right: {
                this.drawer.x = 0.5 * (this.node.width + this.drawer.width);
                break;
            }
            default: {
                this.type = GlobalEnum_1.GlobalEnum.RecommendDrawerType.left;
                this.drawer.x = -0.5 * (this.node.width + this.drawer.width);
                break;
            }
        }
        this.closeDis = this.drawer.x - this.openTargetX;
    };
    RecommendDrawer.prototype.onBtnDrawer = function () {
        switch (this.state) {
            case DrawerState.close: {
                this.openDrawer();
                break;
            }
            case DrawerState.open: {
                this.closeDrawer();
                break;
            }
        }
    };
    /**打开抽屉 */
    RecommendDrawer.prototype.openDrawer = function () {
        this.showMask();
        this.state = DrawerState.moving;
        this.drawer.stopAllActions();
        var items = this.data.items;
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        this.addItems(items, this.data.itemType);
        var action = cc.moveTo(this.openDuration, this.openTargetX, this.drawer.y);
        action.easing(cc.easeOut(2));
        this.drawer.runAction(cc.sequence(action, cc.callFunc(this.onOpenDrawerFinish, this)));
        this.emit(GameEventType_1.EventType.RecommendEvent.drawerStartOpen);
    };
    RecommendDrawer.prototype.onOpenDrawerFinish = function () {
        this.hideMask();
        this.state = DrawerState.open;
        this.btnClose.active = true;
        this.emit(GameEventType_1.EventType.RecommendEvent.drawerOpened);
    };
    /**关闭抽屉 */
    RecommendDrawer.prototype.closeDrawer = function () {
        this.showMask();
        this.state = DrawerState.moving;
        this.drawer.stopAllActions();
        this.drawer.x = this.openTargetX;
        var action = cc.moveBy(this.closeDuration, this.closeDis, 0);
        action.easing(cc.easeIn(2));
        this.drawer.runAction(cc.sequence(action, cc.callFunc(this.onCloseDrawerFinish, this)));
        this.emit(GameEventType_1.EventType.RecommendEvent.drawerStartClose);
    };
    RecommendDrawer.prototype.onCloseDrawerFinish = function () {
        this.resetItems();
        this.hideMask();
        this.state = DrawerState.close;
        this.btnClose.active = false;
        this.emit(GameEventType_1.EventType.RecommendEvent.drawerClosed);
    };
    RecommendDrawer.prototype.showMask = function () {
        this.emit(GameEventType_1.EventType.UIEvent.showTouchMask);
    };
    RecommendDrawer.prototype.hideMask = function () {
        this.emit(GameEventType_1.EventType.UIEvent.hideTouchMask);
    };
    __decorate([
        property(cc.Node)
    ], RecommendDrawer.prototype, "drawer", void 0);
    __decorate([
        property(cc.Node)
    ], RecommendDrawer.prototype, "btnDrawer", void 0);
    __decorate([
        property(cc.Node)
    ], RecommendDrawer.prototype, "btnClose", void 0);
    RecommendDrawer = __decorate([
        ccclass
    ], RecommendDrawer);
    return RecommendDrawer;
}(RecommendContainer_1.default));
exports.default = RecommendDrawer;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcUmVjb21tZW5kXFxTY3JpcHRcXFJlY29tbWVuZERyYXdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnRkFBMkU7QUFDM0Usa0VBQWlFO0FBQ2pFLHdFQUFtRTtBQUNuRSxvRkFBK0U7QUFFekUsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFDNUMsVUFBVTtBQUNWLElBQUssV0FJSjtBQUpELFdBQUssV0FBVztJQUNaLCtDQUFLLENBQUE7SUFDTCw2Q0FBSSxDQUFBO0lBQ0osaURBQU0sQ0FBQTtBQUNWLENBQUMsRUFKSSxXQUFXLEtBQVgsV0FBVyxRQUlmO0FBRUQ7SUFBNkMsbUNBQWtCO0lBQS9EO1FBQUEscUVBc0pDO1FBcEpXLFlBQU0sR0FBWSxJQUFJLENBQUMsQ0FBSyxJQUFJO1FBRWhDLGVBQVMsR0FBWSxJQUFJLENBQUMsQ0FBRSxRQUFRO1FBR3BDLGNBQVEsR0FBWSxJQUFJLENBQUM7O0lBK0lyQyxDQUFDO0lBdElVLDhCQUFJLEdBQVgsVUFBWSxJQUFVO1FBQ2xCLElBQUksQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQztRQUMvQixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDN0IsMENBQTBDO1FBQzFDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUM3RSxJQUFJLENBQUMsWUFBWSxHQUFHLEdBQUcsQ0FBQztRQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQztRQUN6QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRTtZQUNSLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDdEI7SUFDTCxDQUFDO0lBQ1Msa0NBQVEsR0FBbEI7UUFDSSxJQUFJLENBQUMsSUFBSSxHQUFHLHVCQUFVLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDO1FBQ2hELElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDckQsQ0FBQztJQUNTLGtDQUFRLEdBQWxCO1FBQ0ksSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzFFLENBQUM7SUFFTSwrQkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO1FBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUNqQyxDQUFDO0lBQ0Q7Ozs7Ozs7T0FPRztJQUNPLGlDQUFPLEdBQWpCLFVBQWtCLElBQVM7UUFDdkIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFDakIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEIsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDOUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUN6QztRQUNELElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzVCLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDMUM7UUFDRCxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM1QztRQUNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFFRCxZQUFZO0lBQ0YsaUNBQU8sR0FBakIsVUFBa0IsSUFBSTtRQUNsQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixRQUFRLElBQUksRUFBRTtZQUNWLEtBQUssdUJBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM3RCxNQUFNO2FBQ1Q7WUFDRCxLQUFLLHVCQUFVLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzVELE1BQU07YUFDVDtZQUNELE9BQU8sQ0FBQyxDQUFDO2dCQUNMLElBQUksQ0FBQyxJQUFJLEdBQUcsdUJBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUM7Z0JBQ2hELElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDN0QsTUFBTTthQUNUO1NBQ0o7UUFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDckQsQ0FBQztJQUVTLHFDQUFXLEdBQXJCO1FBQ0ksUUFBUSxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ2hCLEtBQUssV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2xCLE1BQU07YUFDVDtZQUNELEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNuQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25CLE1BQU07YUFDVDtTQUNKO0lBQ0wsQ0FBQztJQUVELFVBQVU7SUFDQSxvQ0FBVSxHQUFwQjtRQUNJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7UUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUM3QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUM1QixJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ1IsS0FBSyxHQUFHLDhCQUFvQixDQUFDLG1CQUFtQixFQUFFLENBQUM7U0FDdEQ7UUFDRCxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0UsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZGLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUNTLDRDQUFrQixHQUE1QjtRQUNJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUM7UUFDOUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVELFVBQVU7SUFDQSxxQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7UUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQ2pDLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzdELE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN4RixJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDekQsQ0FBQztJQUNTLDZDQUFtQixHQUE3QjtRQUNJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO1FBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFUyxrQ0FBUSxHQUFsQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNTLGtDQUFRLEdBQWxCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBbkpEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7bURBQ2E7SUFFL0I7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztzREFDZ0I7SUFHbEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztxREFDZTtJQVBoQixlQUFlO1FBRG5DLE9BQU87T0FDYSxlQUFlLENBc0puQztJQUFELHNCQUFDO0NBdEpELEFBc0pDLENBdEo0Qyw0QkFBa0IsR0FzSjlEO2tCQXRKb0IsZUFBZSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWNvbW1lbmRDb250YWluZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9SZWNvbW1lbmQvUmVjb21tZW5kQ29udGFpbmVyXCI7XHJcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcclxuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XHJcbmltcG9ydCBSZWNvbW1lbmREYXRhTWFuYWdlciBmcm9tIFwiLi4vLi4vU2NyaXB0L1JlY29tbWVuZC9SZWNvbW1lbmREYXRhTWFuYWdlclwiO1xyXG5cclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuLyoq5oq95bGJ54q25oCBICovXHJcbmVudW0gRHJhd2VyU3RhdGUge1xyXG4gICAgY2xvc2UsICAvL+WFs+mXreeahFxyXG4gICAgb3BlbiwgICAvL+W3suaJk+W8gFxyXG4gICAgbW92aW5nLCAvL+ato+WcqOenu+WKqFxyXG59XHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFJlY29tbWVuZERyYXdlciBleHRlbmRzIFJlY29tbWVuZENvbnRhaW5lciB7XHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByaXZhdGUgZHJhd2VyOiBjYy5Ob2RlID0gbnVsbDsgICAgIC8v5oq95bGJXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByaXZhdGUgYnRuRHJhd2VyOiBjYy5Ob2RlID0gbnVsbDsgIC8v5oq95bGJ5byA5YWz5oyJ6ZKuXHJcbiAgICBwcml2YXRlIHN0YXRlOiBEcmF3ZXJTdGF0ZTtcclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcHJpdmF0ZSBidG5DbG9zZTogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgcHJpdmF0ZSBvcGVuVGFyZ2V0WDogbnVtYmVyOyAgICAgICAgLy/mir3lsYnmiZPlvIDml7bnp7vliqjliLDnmoTnm67moIfngrlY5Z2Q5qCH5YC8XHJcbiAgICBwcml2YXRlIGNsb3NlRGlzOiBudW1iZXI7ICAgICAgICAgICAgLy/mir3lsYnmiZPlvIAv5YWz6Zet5pe255qE56e75Yqo6Led56a7XHJcbiAgICBwcml2YXRlIG9wZW5EdXJhdGlvbjogbnVtYmVyOyAgICAgICAvL+aKveWxieaJk+W8gOWKqOeUu+aXtumVv1xyXG4gICAgcHJpdmF0ZSBjbG9zZUR1cmF0aW9uOiBudW1iZXI7ICAgICAgLy/mir3lsYnlhbPpl63liqjnlLvml7bplb9cclxuICAgIHByaXZhdGUgdHlwZTsvL+aKveWxieexu+Wei1xyXG4gICAgcHJpdmF0ZSBkYXRhOiBhbnk7ICAgICAgICAgICAgICAgICAgLy/mir3lsYnphY3nva7nrYnkv6Hmga/nmoTmlbDmja5cclxuXHJcbiAgICBwdWJsaWMgaW5pdChkYXRhPzogYW55KSB7XHJcbiAgICAgICAgdGhpcy5zdGF0ZSA9IERyYXdlclN0YXRlLmNsb3NlO1xyXG4gICAgICAgIHRoaXMuYnRuQ2xvc2UuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgLy8gdGhpcy5vcGVuVGFyZ2V0WCA9IDA7Ly/mmoLorr7kuLrmiZPlvIDmir3lsYnml7bnp7vliqjliLDlsY/luZXmraPkuK3pl7RcclxuICAgICAgICBsZXQgY3ZzID0gY2MuZmluZChcIkNhbnZhc1wiKTtcclxuICAgICAgICB0aGlzLm9wZW5UYXJnZXRYID0gdGhpcy5kcmF3ZXIud2lkdGggKiB0aGlzLmRyYXdlci5hbmNob3JYIC0gY3ZzLndpZHRoICogMC41O1xyXG4gICAgICAgIHRoaXMub3BlbkR1cmF0aW9uID0gMC41O1xyXG4gICAgICAgIHRoaXMuY2xvc2VEdXJhdGlvbiA9IDAuNTtcclxuICAgICAgICB0aGlzLmluaXRUeXBlKCk7XHJcbiAgICAgICAgdGhpcy5vbkV2ZW50cygpO1xyXG4gICAgICAgIGlmICghIWRhdGEpIHtcclxuICAgICAgICAgICAgdGhpcy5zZXREYXRhKGRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBpbml0VHlwZSgpIHtcclxuICAgICAgICB0aGlzLnR5cGUgPSBHbG9iYWxFbnVtLlJlY29tbWVuZERyYXdlclR5cGUubGVmdDtcclxuICAgICAgICB0aGlzLmRyYXdlci54ID0gLTAuNSAqICh0aGlzLm5vZGUud2lkdGggKyB0aGlzLmRyYXdlci53aWR0aCk7XHJcbiAgICAgICAgdGhpcy5jbG9zZURpcyA9IHRoaXMuZHJhd2VyLnggLSB0aGlzLm9wZW5UYXJnZXRYO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uRXZlbnRzKCkge1xyXG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLlJlY29tbWVuZEV2ZW50Lm9wZW5EcmF3ZXIsIHRoaXMub25CdG5EcmF3ZXIsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLlJlY29tbWVuZEV2ZW50LmNsb3NlRHJhd2VyLCB0aGlzLm9uQnRuRHJhd2VyLCB0aGlzKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmVzZXQoKSB7XHJcbiAgICAgICAgdGhpcy5zdGF0ZSA9IERyYXdlclN0YXRlLmNsb3NlO1xyXG4gICAgICAgIHRoaXMuYnRuQ2xvc2UuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOiuvue9ruaKveWxieeahOaVsOaNrlxyXG4gICAgICog5Y+q6K6w5b2V5pWw5o2u77yM5omT5byA5oq95bGJ55qE5pe25YCZ5YaN5re75Yqg6IqC54K5XHJcbiAgICAgKiBAcGFyYW0gZGF0YSBcclxuICAgICAqIEBwYXJhbSBbZGF0YS50eXBlXSAgICAgICDmir3lsYnnsbvlnossR2xvYmFsRW51bS5SZWNvbW1lbmREcmF3ZXJUeXBl5p6a5Li+5YC8XHJcbiAgICAgKiBAcGFyYW0gW2RhdGEuaXRlbVR5cGVdICAg6IqC54K557G75Z6L77yMR2xvYmFsRW51bS5SZWNvbW1lbmRJdGVtVHlwZeaemuS4vuWAvFxyXG4gICAgICogQHBhcmFtIFtkYXRhLml0ZW1zXSAgICAgIOS6kuaOqOa4uOaIj+eahOaVsOaNruaVsOe7hO+8jOWMheWQq+a4uOaIj2lk77yM5ZCN5a2X77yM5Zu+5qCH5paH5Lu25ZCN562J5L+h5oGvXHJcbiAgICAgKi9cclxuICAgIHByb3RlY3RlZCBzZXREYXRhKGRhdGE6IGFueSkge1xyXG4gICAgICAgIHRoaXMuZGF0YSA9IGRhdGE7XHJcbiAgICAgICAgdGhpcy5zZXRUeXBlKGRhdGEudHlwZSk7XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCAhPSB0aGlzLmRhdGEuc2NhbGUpIHtcclxuICAgICAgICAgICAgdGhpcy5kcmF3ZXIuc2V0U2NhbGUodGhpcy5kYXRhLnNjYWxlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCAhPSB0aGlzLmRhdGEucG9zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZHJhd2VyLnNldFBvc2l0aW9uKHRoaXMuZGF0YS5wb3MpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoISFkYXRhLndpZGdldCkge1xyXG4gICAgICAgICAgICB0aGlzLnNldFdpZGdldCh0aGlzLmRyYXdlciwgZGF0YS53aWRnZXQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoISFkYXRhLmJ0bldpZGdldCkge1xyXG4gICAgICAgICAgICB0aGlzLnNldFdpZGdldCh0aGlzLmJ0bkRyYXdlciwgZGF0YS5idG5XaWRnZXQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKirorr7nva7mir3lsYnnsbvlnosgKi9cclxuICAgIHByb3RlY3RlZCBzZXRUeXBlKHR5cGUpIHtcclxuICAgICAgICB0aGlzLnR5cGUgPSB0eXBlO1xyXG4gICAgICAgIHN3aXRjaCAodHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlIEdsb2JhbEVudW0uUmVjb21tZW5kRHJhd2VyVHlwZS5sZWZ0OiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRyYXdlci54ID0gLTAuNSAqICh0aGlzLm5vZGUud2lkdGggKyB0aGlzLmRyYXdlci53aWR0aCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYXNlIEdsb2JhbEVudW0uUmVjb21tZW5kRHJhd2VyVHlwZS5yaWdodDoge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5kcmF3ZXIueCA9IDAuNSAqICh0aGlzLm5vZGUud2lkdGggKyB0aGlzLmRyYXdlci53aWR0aCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBkZWZhdWx0OiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnR5cGUgPSBHbG9iYWxFbnVtLlJlY29tbWVuZERyYXdlclR5cGUubGVmdDtcclxuICAgICAgICAgICAgICAgIHRoaXMuZHJhd2VyLnggPSAtMC41ICogKHRoaXMubm9kZS53aWR0aCArIHRoaXMuZHJhd2VyLndpZHRoKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY2xvc2VEaXMgPSB0aGlzLmRyYXdlci54IC0gdGhpcy5vcGVuVGFyZ2V0WDtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgb25CdG5EcmF3ZXIoKSB7XHJcbiAgICAgICAgc3dpdGNoICh0aGlzLnN0YXRlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgRHJhd2VyU3RhdGUuY2xvc2U6IHtcclxuICAgICAgICAgICAgICAgIHRoaXMub3BlbkRyYXdlcigpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2FzZSBEcmF3ZXJTdGF0ZS5vcGVuOiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNsb3NlRHJhd2VyKCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKirmiZPlvIDmir3lsYkgKi9cclxuICAgIHByb3RlY3RlZCBvcGVuRHJhd2VyKCkge1xyXG4gICAgICAgIHRoaXMuc2hvd01hc2soKTtcclxuICAgICAgICB0aGlzLnN0YXRlID0gRHJhd2VyU3RhdGUubW92aW5nO1xyXG4gICAgICAgIHRoaXMuZHJhd2VyLnN0b3BBbGxBY3Rpb25zKCk7XHJcbiAgICAgICAgbGV0IGl0ZW1zID0gdGhpcy5kYXRhLml0ZW1zO1xyXG4gICAgICAgIGlmICghaXRlbXMpIHtcclxuICAgICAgICAgICAgaXRlbXMgPSBSZWNvbW1lbmREYXRhTWFuYWdlci5nZXRBbGxSZWNvbW1lbmREYXRhKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuYWRkSXRlbXMoaXRlbXMsIHRoaXMuZGF0YS5pdGVtVHlwZSk7XHJcbiAgICAgICAgbGV0IGFjdGlvbiA9IGNjLm1vdmVUbyh0aGlzLm9wZW5EdXJhdGlvbiwgdGhpcy5vcGVuVGFyZ2V0WCwgdGhpcy5kcmF3ZXIueSk7XHJcbiAgICAgICAgYWN0aW9uLmVhc2luZyhjYy5lYXNlT3V0KDIpKTtcclxuICAgICAgICB0aGlzLmRyYXdlci5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoYWN0aW9uLCBjYy5jYWxsRnVuYyh0aGlzLm9uT3BlbkRyYXdlckZpbmlzaCwgdGhpcykpKTtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlJlY29tbWVuZEV2ZW50LmRyYXdlclN0YXJ0T3Blbik7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgb25PcGVuRHJhd2VyRmluaXNoKCkge1xyXG4gICAgICAgIHRoaXMuaGlkZU1hc2soKTtcclxuICAgICAgICB0aGlzLnN0YXRlID0gRHJhd2VyU3RhdGUub3BlbjtcclxuICAgICAgICB0aGlzLmJ0bkNsb3NlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5SZWNvbW1lbmRFdmVudC5kcmF3ZXJPcGVuZWQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKuWFs+mXreaKveWxiSAqL1xyXG4gICAgcHJvdGVjdGVkIGNsb3NlRHJhd2VyKCkge1xyXG4gICAgICAgIHRoaXMuc2hvd01hc2soKTtcclxuICAgICAgICB0aGlzLnN0YXRlID0gRHJhd2VyU3RhdGUubW92aW5nO1xyXG4gICAgICAgIHRoaXMuZHJhd2VyLnN0b3BBbGxBY3Rpb25zKCk7XHJcbiAgICAgICAgdGhpcy5kcmF3ZXIueCA9IHRoaXMub3BlblRhcmdldFg7XHJcbiAgICAgICAgbGV0IGFjdGlvbiA9IGNjLm1vdmVCeSh0aGlzLmNsb3NlRHVyYXRpb24sIHRoaXMuY2xvc2VEaXMsIDApO1xyXG4gICAgICAgIGFjdGlvbi5lYXNpbmcoY2MuZWFzZUluKDIpKTtcclxuICAgICAgICB0aGlzLmRyYXdlci5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoYWN0aW9uLCBjYy5jYWxsRnVuYyh0aGlzLm9uQ2xvc2VEcmF3ZXJGaW5pc2gsIHRoaXMpKSk7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5SZWNvbW1lbmRFdmVudC5kcmF3ZXJTdGFydENsb3NlKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBvbkNsb3NlRHJhd2VyRmluaXNoKCkge1xyXG4gICAgICAgIHRoaXMucmVzZXRJdGVtcygpO1xyXG4gICAgICAgIHRoaXMuaGlkZU1hc2soKTtcclxuICAgICAgICB0aGlzLnN0YXRlID0gRHJhd2VyU3RhdGUuY2xvc2U7XHJcbiAgICAgICAgdGhpcy5idG5DbG9zZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlJlY29tbWVuZEV2ZW50LmRyYXdlckNsb3NlZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHNob3dNYXNrKCkge1xyXG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5zaG93VG91Y2hNYXNrKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBoaWRlTWFzaygpIHtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuaGlkZVRvdWNoTWFzayk7XHJcbiAgICB9XHJcbn1cclxuIl19