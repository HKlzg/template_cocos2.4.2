
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Recommend/Script/RecommendBanner.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '69bd8zPrktOy6RlO57J+sx7', 'RecommendBanner');
// Recommend/Script/RecommendBanner.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendContainer_1 = require("../../Script/Recommend/RecommendContainer");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
//水平滚动显示的互推列表
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecommendBanner = /** @class */ (function (_super) {
    __extends(RecommendBanner, _super);
    function RecommendBanner() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**容器节点 */
        _this.banner = null;
        /**显示互推列表的容器的布局组件 */
        _this.bannerWidget = null;
        /**列表的父节点，带cc.Mask组件 */
        _this.maskNode = null;
        /**朝一个方向循环滚动时需要的列表节点的副本 */
        _this.content_copy = null;
        return _this;
    }
    RecommendBanner.prototype.init = function (data) {
        this.scrollSpd = 50;
        this.onEvents();
        if (!!data) {
            this.setData(data);
            this.startScroll();
        }
    };
    RecommendBanner.prototype.reset = function () {
        this.clearContent_copy();
        this.content.stopAllActions();
        this.resetItems();
    };
    RecommendBanner.prototype.reuse = function (data) {
        this.node.active = true;
        this.reset();
        this.setData(data);
        this.startScroll();
    };
    RecommendBanner.prototype.unuse = function () {
        this.reset();
        this.unschedule(this.startScroll);
    };
    /**
   * 设置组件数据
   * @param data
   * @param [data.type]       组件类型枚举值
   * @param [data.itemType]   互推节点类型枚举值
   * @param [data.items]      互推节点数据数组
   */
    RecommendBanner.prototype.setData = function (data) {
        this.data = data;
        var items = data.items;
        //默认使用全部互推数据
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        this.addItems(items, data.itemType);
        this.content.getComponent(cc.Layout).updateLayout();
        this.setType(data.type);
        this.setBannerPos();
    };
    /**设置坐标 */
    RecommendBanner.prototype.setBannerPos = function () {
        if (undefined != this.data.scale) {
            this.banner.setScale(this.data.scale);
        }
        if (undefined != this.data.pos) {
            this.banner.setPosition(this.data.pos);
        }
        if (undefined != this.data.widget) {
            this.setWidget(this.banner, this.data.widget);
        }
    };
    /**设置banner类型 */
    RecommendBanner.prototype.setType = function (type) {
        this.type = type;
        switch (type) {
            case GlobalEnum_1.GlobalEnum.RecommendBannerType.pingpong: {
                this.clearContent_copy();
                break;
            }
            case GlobalEnum_1.GlobalEnum.RecommendBannerType.left: {
                this.setContent_copy();
                break;
            }
        }
    };
    /**开始自动滚动显示列表 */
    RecommendBanner.prototype.startScroll = function () {
        this.scheduleOnce(this.autoScroll, 0);
    };
    RecommendBanner.prototype.autoScroll = function () {
        switch (this.type) {
            case GlobalEnum_1.GlobalEnum.RecommendBannerType.pingpong: {
                this.scrollPingPongReverse();
                break;
            }
            case GlobalEnum_1.GlobalEnum.RecommendBannerType.left: {
                this.scheduleOnce(this.scrollLeft, 0);
                break;
            }
        }
    };
    /**来回循环滚动 */
    RecommendBanner.prototype.scrollPingPongReverse = function () {
        this.content.stopAllActions();
        this.content.x = 0;
        var len = this.content.width;
        var width = this.maskNode.width;
        var dis = len - width;
        if (dis <= 0)
            return;
        var duration = dis / this.scrollSpd;
        var ping = cc.moveBy(duration, -dis, 0);
        var pong = cc.moveBy(duration, dis, 0);
        this.content.runAction(cc.repeatForever(cc.sequence(ping, pong)));
    };
    /**永远向左滚动 */
    RecommendBanner.prototype.scrollLeft = function () {
        this.content.stopAllActions();
        this.content.x = 0;
        this.moveToLeftHalf(this.content);
        this.content_copy.stopAllActions();
        this.content_copy.x = this.content.width;
        this.moveToLeftRepeat(this.content_copy);
    };
    RecommendBanner.prototype.moveToLeftRepeat = function (node) {
        var dis = node.width;
        var duration = 2 * dis / this.scrollSpd;
        var move = cc.moveBy(duration, -dis * 2, 0);
        var recover = cc.moveTo(0, dis, 0);
        node.runAction(cc.repeatForever(cc.sequence(move, recover)));
    };
    RecommendBanner.prototype.moveToLeftHalf = function (node) {
        var dis = node.width;
        var duration = dis / this.scrollSpd;
        var move = cc.moveBy(duration, -dis, 0);
        node.runAction(cc.sequence(move, cc.callFunc(this.onMoveToLeftHalfFinish, this, node)));
    };
    RecommendBanner.prototype.onMoveToLeftHalfFinish = function (node) {
        node.x = node.width;
        this.moveToLeftRepeat(node);
    };
    /**创建列表节点的副本 */
    RecommendBanner.prototype.setContent_copy = function () {
        this.clearContent_copy();
        var items = this.data.items;
        //默认使用全部互推数据
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        for (var i = 0, count = items.length; i < count; ++i) {
            var item = this.getItem(this.data.itemType, items[i]);
            this.content_copy.addChild(item);
        }
        this.content_copy.getComponent(cc.Layout).updateLayout();
    };
    /**移除列表节点的副本 */
    RecommendBanner.prototype.clearContent_copy = function () {
        this.content_copy.stopAllActions();
        GlobalPool_1.default.putAllChildren(this.content_copy);
    };
    //关闭节点
    RecommendBanner.prototype.onBtnClose = function () {
        this.node.active = false;
    };
    __decorate([
        property(cc.Node)
    ], RecommendBanner.prototype, "banner", void 0);
    __decorate([
        property(cc.Widget)
    ], RecommendBanner.prototype, "bannerWidget", void 0);
    __decorate([
        property(cc.Node)
    ], RecommendBanner.prototype, "maskNode", void 0);
    __decorate([
        property(cc.Node)
    ], RecommendBanner.prototype, "content_copy", void 0);
    RecommendBanner = __decorate([
        ccclass
    ], RecommendBanner);
    return RecommendBanner;
}(RecommendContainer_1.default));
exports.default = RecommendBanner;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcUmVjb21tZW5kXFxTY3JpcHRcXFJlY29tbWVuZEJhbm5lci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnRkFBMkU7QUFDM0Usb0ZBQStFO0FBQy9FLGtFQUFpRTtBQUNqRSw2REFBd0Q7QUFFeEQsYUFBYTtBQUNQLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQTZDLG1DQUFrQjtJQUEvRDtRQUFBLHFFQThLQztRQTVLRyxVQUFVO1FBRUEsWUFBTSxHQUFZLElBQUksQ0FBQztRQUNqQyxvQkFBb0I7UUFFVixrQkFBWSxHQUFjLElBQUksQ0FBQztRQUV6Qyx1QkFBdUI7UUFFYixjQUFRLEdBQVksSUFBSSxDQUFDO1FBRW5DLDBCQUEwQjtRQUVoQixrQkFBWSxHQUFZLElBQUksQ0FBQzs7SUErSjNDLENBQUM7SUF2SlUsOEJBQUksR0FBWCxVQUFZLElBQVU7UUFDbEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRTtZQUNSLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbkIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO0lBQ0wsQ0FBQztJQUVNLCtCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRU0sK0JBQUssR0FBWixVQUFhLElBQVM7UUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFDTSwrQkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7Ozs7S0FNQztJQUNTLGlDQUFPLEdBQWpCLFVBQWtCLElBQVM7UUFDdkIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFDakIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUN2QixZQUFZO1FBQ1osSUFBSSxDQUFDLEtBQUssRUFBRTtZQUNSLEtBQUssR0FBRyw4QkFBb0IsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1NBQ3REO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwRCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUNELFVBQVU7SUFDQSxzQ0FBWSxHQUF0QjtRQUNJLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDekM7UUFDRCxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzFDO1FBQ0QsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDL0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDakQ7SUFDTCxDQUFDO0lBQ0QsZ0JBQWdCO0lBQ04saUNBQU8sR0FBakIsVUFBa0IsSUFBSTtRQUNsQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixRQUFRLElBQUksRUFBRTtZQUNWLEtBQUssdUJBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDMUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3pCLE1BQU07YUFDVDtZQUNELEtBQUssdUJBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dCQUN2QixNQUFNO2FBQ1Q7U0FDSjtJQUNMLENBQUM7SUFFRCxnQkFBZ0I7SUFDTixxQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ1Msb0NBQVUsR0FBcEI7UUFDSSxRQUFRLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDZixLQUFLLHVCQUFVLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2dCQUM3QixNQUFNO2FBQ1Q7WUFDRCxLQUFLLHVCQUFVLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDdEMsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBQ0QsWUFBWTtJQUNGLCtDQUFxQixHQUEvQjtRQUNJLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBQzdCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO1FBQ2hDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxHQUFHLElBQUksQ0FBQztZQUFFLE9BQU87UUFDckIsSUFBSSxRQUFRLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDcEMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDeEMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFDRCxZQUFZO0lBQ0Ysb0NBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNuQixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ25DLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNTLDBDQUFnQixHQUExQixVQUEyQixJQUFJO1FBQzNCLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDckIsSUFBSSxRQUFRLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ3hDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM1QyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBQ1Msd0NBQWMsR0FBeEIsVUFBeUIsSUFBSTtRQUN6QixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3JCLElBQUksUUFBUSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ3BDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM1RixDQUFDO0lBQ1MsZ0RBQXNCLEdBQWhDLFVBQWlDLElBQUk7UUFDakMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3BCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBQ0QsZUFBZTtJQUNMLHlDQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDNUIsWUFBWTtRQUNaLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDUixLQUFLLEdBQUcsOEJBQW9CLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztTQUN0RDtRQUNELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDbEQsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNwQztRQUNELElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUM3RCxDQUFDO0lBQ0QsZUFBZTtJQUNMLDJDQUFpQixHQUEzQjtRQUNJLElBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDbkMsb0JBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFRCxNQUFNO0lBQ0Usb0NBQVUsR0FBbEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQXpLRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO21EQUNlO0lBR2pDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7eURBQ3FCO0lBSXpDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7cURBQ2lCO0lBSW5DO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7eURBQ3FCO0lBZnRCLGVBQWU7UUFEbkMsT0FBTztPQUNhLGVBQWUsQ0E4S25DO0lBQUQsc0JBQUM7Q0E5S0QsQUE4S0MsQ0E5SzRDLDRCQUFrQixHQThLOUQ7a0JBOUtvQixlQUFlIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlY29tbWVuZENvbnRhaW5lciBmcm9tIFwiLi4vLi4vU2NyaXB0L1JlY29tbWVuZC9SZWNvbW1lbmRDb250YWluZXJcIjtcclxuaW1wb3J0IFJlY29tbWVuZERhdGFNYW5hZ2VyIGZyb20gXCIuLi8uLi9TY3JpcHQvUmVjb21tZW5kL1JlY29tbWVuZERhdGFNYW5hZ2VyXCI7XHJcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcclxuaW1wb3J0IEdsb2JhbFBvb2wgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vR2xvYmFsUG9vbFwiO1xyXG5cclxuLy/msLTlubPmu5rliqjmmL7npLrnmoTkupLmjqjliJfooahcclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFJlY29tbWVuZEJhbm5lciBleHRlbmRzIFJlY29tbWVuZENvbnRhaW5lciB7XHJcblxyXG4gICAgLyoq5a655Zmo6IqC54K5ICovXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb3RlY3RlZCBiYW5uZXI6IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgLyoq5pi+56S65LqS5o6o5YiX6KGo55qE5a655Zmo55qE5biD5bGA57uE5Lu2ICovXHJcbiAgICBAcHJvcGVydHkoY2MuV2lkZ2V0KVxyXG4gICAgcHJvdGVjdGVkIGJhbm5lcldpZGdldDogY2MuV2lkZ2V0ID0gbnVsbDtcclxuXHJcbiAgICAvKirliJfooajnmoTniLboioLngrnvvIzluKZjYy5NYXNr57uE5Lu2ICovXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb3RlY3RlZCBtYXNrTm9kZTogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgLyoq5pyd5LiA5Liq5pa55ZCR5b6q546v5rua5Yqo5pe26ZyA6KaB55qE5YiX6KGo6IqC54K555qE5Ymv5pysICovXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb3RlY3RlZCBjb250ZW50X2NvcHk6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIC8qKuWIl+ihqOa7muWKqOmAn+W6pu+8jOWNleS9je+8muWDj+e0oC/np5IgKi9cclxuICAgIHByb3RlY3RlZCBzY3JvbGxTcGQ6IG51bWJlcjtcclxuXHJcbiAgICBwcm90ZWN0ZWQgdHlwZTtcclxuICAgIHByb3RlY3RlZCBkYXRhOiBhbnk7XHJcblxyXG4gICAgcHVibGljIGluaXQoZGF0YT86IGFueSkge1xyXG4gICAgICAgIHRoaXMuc2Nyb2xsU3BkID0gNTA7XHJcbiAgICAgICAgdGhpcy5vbkV2ZW50cygpO1xyXG4gICAgICAgIGlmICghIWRhdGEpIHtcclxuICAgICAgICAgICAgdGhpcy5zZXREYXRhKGRhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLnN0YXJ0U2Nyb2xsKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZXNldCgpIHtcclxuICAgICAgICB0aGlzLmNsZWFyQ29udGVudF9jb3B5KCk7XHJcbiAgICAgICAgdGhpcy5jb250ZW50LnN0b3BBbGxBY3Rpb25zKCk7XHJcbiAgICAgICAgdGhpcy5yZXNldEl0ZW1zKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJldXNlKGRhdGE6IGFueSkge1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICB0aGlzLnNldERhdGEoZGF0YSk7XHJcbiAgICAgICAgdGhpcy5zdGFydFNjcm9sbCgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHVudXNlKCkge1xyXG4gICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICB0aGlzLnVuc2NoZWR1bGUodGhpcy5zdGFydFNjcm9sbCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICog6K6+572u57uE5Lu25pWw5o2uXHJcbiAgICogQHBhcmFtIGRhdGEgXHJcbiAgICogQHBhcmFtIFtkYXRhLnR5cGVdICAgICAgIOe7hOS7tuexu+Wei+aemuS4vuWAvFxyXG4gICAqIEBwYXJhbSBbZGF0YS5pdGVtVHlwZV0gICDkupLmjqjoioLngrnnsbvlnovmnprkuL7lgLxcclxuICAgKiBAcGFyYW0gW2RhdGEuaXRlbXNdICAgICAg5LqS5o6o6IqC54K55pWw5o2u5pWw57uEXHJcbiAgICovXHJcbiAgICBwcm90ZWN0ZWQgc2V0RGF0YShkYXRhOiBhbnkpIHtcclxuICAgICAgICB0aGlzLmRhdGEgPSBkYXRhO1xyXG4gICAgICAgIGxldCBpdGVtcyA9IGRhdGEuaXRlbXM7XHJcbiAgICAgICAgLy/pu5jorqTkvb/nlKjlhajpg6jkupLmjqjmlbDmja5cclxuICAgICAgICBpZiAoIWl0ZW1zKSB7XHJcbiAgICAgICAgICAgIGl0ZW1zID0gUmVjb21tZW5kRGF0YU1hbmFnZXIuZ2V0QWxsUmVjb21tZW5kRGF0YSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmFkZEl0ZW1zKGl0ZW1zLCBkYXRhLml0ZW1UeXBlKTtcclxuICAgICAgICB0aGlzLmNvbnRlbnQuZ2V0Q29tcG9uZW50KGNjLkxheW91dCkudXBkYXRlTGF5b3V0KCk7XHJcbiAgICAgICAgdGhpcy5zZXRUeXBlKGRhdGEudHlwZSk7XHJcbiAgICAgICAgdGhpcy5zZXRCYW5uZXJQb3MoKTtcclxuICAgIH1cclxuICAgIC8qKuiuvue9ruWdkOaghyAqL1xyXG4gICAgcHJvdGVjdGVkIHNldEJhbm5lclBvcygpIHtcclxuICAgICAgICBpZiAodW5kZWZpbmVkICE9IHRoaXMuZGF0YS5zY2FsZSkge1xyXG4gICAgICAgICAgICB0aGlzLmJhbm5lci5zZXRTY2FsZSh0aGlzLmRhdGEuc2NhbGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodW5kZWZpbmVkICE9IHRoaXMuZGF0YS5wb3MpIHtcclxuICAgICAgICAgICAgdGhpcy5iYW5uZXIuc2V0UG9zaXRpb24odGhpcy5kYXRhLnBvcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh1bmRlZmluZWQgIT0gdGhpcy5kYXRhLndpZGdldCkge1xyXG4gICAgICAgICAgICB0aGlzLnNldFdpZGdldCh0aGlzLmJhbm5lciwgdGhpcy5kYXRhLndpZGdldCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLyoq6K6+572uYmFubmVy57G75Z6LICovXHJcbiAgICBwcm90ZWN0ZWQgc2V0VHlwZSh0eXBlKSB7XHJcbiAgICAgICAgdGhpcy50eXBlID0gdHlwZTtcclxuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSBHbG9iYWxFbnVtLlJlY29tbWVuZEJhbm5lclR5cGUucGluZ3Bvbmc6IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2xlYXJDb250ZW50X2NvcHkoKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhc2UgR2xvYmFsRW51bS5SZWNvbW1lbmRCYW5uZXJUeXBlLmxlZnQ6IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0Q29udGVudF9jb3B5KCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKirlvIDlp4voh6rliqjmu5rliqjmmL7npLrliJfooaggKi9cclxuICAgIHByb3RlY3RlZCBzdGFydFNjcm9sbCgpIHtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSh0aGlzLmF1dG9TY3JvbGwsIDApO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIGF1dG9TY3JvbGwoKSB7XHJcbiAgICAgICAgc3dpdGNoICh0aGlzLnR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSBHbG9iYWxFbnVtLlJlY29tbWVuZEJhbm5lclR5cGUucGluZ3Bvbmc6IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2Nyb2xsUGluZ1BvbmdSZXZlcnNlKCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYXNlIEdsb2JhbEVudW0uUmVjb21tZW5kQmFubmVyVHlwZS5sZWZ0OiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSh0aGlzLnNjcm9sbExlZnQsIDApO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKirmnaXlm57lvqrnjq/mu5rliqggKi9cclxuICAgIHByb3RlY3RlZCBzY3JvbGxQaW5nUG9uZ1JldmVyc2UoKSB7XHJcbiAgICAgICAgdGhpcy5jb250ZW50LnN0b3BBbGxBY3Rpb25zKCk7XHJcbiAgICAgICAgdGhpcy5jb250ZW50LnggPSAwO1xyXG4gICAgICAgIGxldCBsZW4gPSB0aGlzLmNvbnRlbnQud2lkdGg7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gdGhpcy5tYXNrTm9kZS53aWR0aDtcclxuICAgICAgICBsZXQgZGlzID0gbGVuIC0gd2lkdGg7XHJcbiAgICAgICAgaWYgKGRpcyA8PSAwKSByZXR1cm47XHJcbiAgICAgICAgbGV0IGR1cmF0aW9uID0gZGlzIC8gdGhpcy5zY3JvbGxTcGQ7XHJcbiAgICAgICAgbGV0IHBpbmcgPSBjYy5tb3ZlQnkoZHVyYXRpb24sIC1kaXMsIDApO1xyXG4gICAgICAgIGxldCBwb25nID0gY2MubW92ZUJ5KGR1cmF0aW9uLCBkaXMsIDApO1xyXG4gICAgICAgIHRoaXMuY29udGVudC5ydW5BY3Rpb24oY2MucmVwZWF0Rm9yZXZlcihjYy5zZXF1ZW5jZShwaW5nLCBwb25nKSkpO1xyXG4gICAgfVxyXG4gICAgLyoq5rC46L+c5ZCR5bem5rua5YqoICovXHJcbiAgICBwcm90ZWN0ZWQgc2Nyb2xsTGVmdCgpIHtcclxuICAgICAgICB0aGlzLmNvbnRlbnQuc3RvcEFsbEFjdGlvbnMoKTtcclxuICAgICAgICB0aGlzLmNvbnRlbnQueCA9IDA7XHJcbiAgICAgICAgdGhpcy5tb3ZlVG9MZWZ0SGFsZih0aGlzLmNvbnRlbnQpO1xyXG4gICAgICAgIHRoaXMuY29udGVudF9jb3B5LnN0b3BBbGxBY3Rpb25zKCk7XHJcbiAgICAgICAgdGhpcy5jb250ZW50X2NvcHkueCA9IHRoaXMuY29udGVudC53aWR0aDtcclxuICAgICAgICB0aGlzLm1vdmVUb0xlZnRSZXBlYXQodGhpcy5jb250ZW50X2NvcHkpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG1vdmVUb0xlZnRSZXBlYXQobm9kZSkge1xyXG4gICAgICAgIGxldCBkaXMgPSBub2RlLndpZHRoO1xyXG4gICAgICAgIGxldCBkdXJhdGlvbiA9IDIgKiBkaXMgLyB0aGlzLnNjcm9sbFNwZDtcclxuICAgICAgICBsZXQgbW92ZSA9IGNjLm1vdmVCeShkdXJhdGlvbiwgLWRpcyAqIDIsIDApO1xyXG4gICAgICAgIGxldCByZWNvdmVyID0gY2MubW92ZVRvKDAsIGRpcywgMCk7XHJcbiAgICAgICAgbm9kZS5ydW5BY3Rpb24oY2MucmVwZWF0Rm9yZXZlcihjYy5zZXF1ZW5jZShtb3ZlLCByZWNvdmVyKSkpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG1vdmVUb0xlZnRIYWxmKG5vZGUpIHtcclxuICAgICAgICBsZXQgZGlzID0gbm9kZS53aWR0aDtcclxuICAgICAgICBsZXQgZHVyYXRpb24gPSBkaXMgLyB0aGlzLnNjcm9sbFNwZDtcclxuICAgICAgICBsZXQgbW92ZSA9IGNjLm1vdmVCeShkdXJhdGlvbiwgLWRpcywgMCk7XHJcbiAgICAgICAgbm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UobW92ZSwgY2MuY2FsbEZ1bmModGhpcy5vbk1vdmVUb0xlZnRIYWxmRmluaXNoLCB0aGlzLCBub2RlKSkpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uTW92ZVRvTGVmdEhhbGZGaW5pc2gobm9kZSkge1xyXG4gICAgICAgIG5vZGUueCA9IG5vZGUud2lkdGg7XHJcbiAgICAgICAgdGhpcy5tb3ZlVG9MZWZ0UmVwZWF0KG5vZGUpO1xyXG4gICAgfVxyXG4gICAgLyoq5Yib5bu65YiX6KGo6IqC54K555qE5Ymv5pysICovXHJcbiAgICBwcm90ZWN0ZWQgc2V0Q29udGVudF9jb3B5KCkge1xyXG4gICAgICAgIHRoaXMuY2xlYXJDb250ZW50X2NvcHkoKTtcclxuICAgICAgICBsZXQgaXRlbXMgPSB0aGlzLmRhdGEuaXRlbXM7XHJcbiAgICAgICAgLy/pu5jorqTkvb/nlKjlhajpg6jkupLmjqjmlbDmja5cclxuICAgICAgICBpZiAoIWl0ZW1zKSB7XHJcbiAgICAgICAgICAgIGl0ZW1zID0gUmVjb21tZW5kRGF0YU1hbmFnZXIuZ2V0QWxsUmVjb21tZW5kRGF0YSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBpID0gMCwgY291bnQgPSBpdGVtcy5sZW5ndGg7IGkgPCBjb3VudDsgKytpKSB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtID0gdGhpcy5nZXRJdGVtKHRoaXMuZGF0YS5pdGVtVHlwZSwgaXRlbXNbaV0pO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnRfY29weS5hZGRDaGlsZChpdGVtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jb250ZW50X2NvcHkuZ2V0Q29tcG9uZW50KGNjLkxheW91dCkudXBkYXRlTGF5b3V0KCk7XHJcbiAgICB9XHJcbiAgICAvKirnp7vpmaTliJfooajoioLngrnnmoTlia/mnKwgKi9cclxuICAgIHByb3RlY3RlZCBjbGVhckNvbnRlbnRfY29weSgpIHtcclxuICAgICAgICB0aGlzLmNvbnRlbnRfY29weS5zdG9wQWxsQWN0aW9ucygpO1xyXG4gICAgICAgIEdsb2JhbFBvb2wucHV0QWxsQ2hpbGRyZW4odGhpcy5jb250ZW50X2NvcHkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8v5YWz6Zet6IqC54K5XHJcbiAgICBwcml2YXRlIG9uQnRuQ2xvc2UoKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==