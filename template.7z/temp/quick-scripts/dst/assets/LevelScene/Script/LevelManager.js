
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LevelScene/Script/LevelManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8a3a1r8py9NEZq3f4jOfVcp', 'LevelManager');
// LevelScene/Script/LevelManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//关卡管理器
var LevelManager = /** @class */ (function (_super) {
    __extends(LevelManager, _super);
    function LevelManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.pauseCount = 0;
        //#endregion
        //#region 对象
        /**关卡中动态添加的模型节点存放层 */
        _this.levelLayer = null;
        //#endregion
        //#region 动作管理器
        _this.actMng = null;
        //#endregion
        //#region 游戏进入首页，关卡场景作为背景
        _this.nextState = null;
        _this.needLoadCount = 0;
        return _this;
        //#endregion
    }
    /**************************************************************通用流程**************************************************************/
    //#region 初始化
    LevelManager.prototype.init = function () {
        this.initComponents();
        this.initCustomUpdateState();
        this.initLevelTimer();
        this.initActMng();
        this.initEnterLobbyState();
        this.loadLobbyItems();
        this.registAllCustomUpdate();
        this.onEvents();
        cc.warn("关卡管理器的init需由子类实现");
    };
    LevelManager.prototype.registAllCustomUpdate = function () {
        cc.warn("关卡管理器的registAllCustomUpdate需由子类实现");
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.lobby, this.stepLobby);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.win, this.stepLevelWin);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.lose, this.stepLevelLose);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.playing, this.stepLevelPlaying);
    };
    LevelManager.prototype.onEvents = function () {
        cc.warn("关卡管理器的onEvents需由子类实现");
        this.on(GameEventType_1.EventType.DirectorEvent.pauseLevel, this.pause, this);
        this.on(GameEventType_1.EventType.DirectorEvent.resumeLevel, this.resume, this);
    };
    /**加载进入首页时必须显示的内容 */
    LevelManager.prototype.loadLobbyItems = function () {
    };
    //#endregion
    //#region 重置
    LevelManager.prototype.reset = function () {
        //回收关卡中的对象
        this.resetCustomUpdateState();
        this.resetLevelTimer();
    };
    Object.defineProperty(LevelManager.prototype, "paused", {
        get: function () { return this.isPaused; },
        enumerable: false,
        configurable: true
    });
    /**暂停关卡运行 */
    LevelManager.prototype.pause = function (count) {
        if (count === void 0) { count = 1; }
        this.pauseCount += count;
        this.isPaused = true;
    };
    /**
     * 继续关卡运行
     * @param count 值为-1时强制恢复关卡运行
     */
    LevelManager.prototype.resume = function (count) {
        if (count === void 0) { count = 1; }
        if (count === -1) {
            this.pauseCount = 0;
            this.isPaused = false;
        }
        else {
            this.pauseCount -= count;
            if (this.pauseCount <= 0) {
                this.pauseCount = 0;
                this.isPaused = false;
            }
        }
    };
    LevelManager.prototype.initLevelTimer = function () {
        this.elapseTimer = 0;
        this.isPaused = false;
        this.pauseCount = 0;
    };
    LevelManager.prototype.resetLevelTimer = function () {
        this.elapseTimer = 0;
        this.isPaused = false;
        this.pauseCount = 0;
    };
    //自定义的每帧更新函数，由计时器执行
    LevelManager.prototype.customUpdate = function () {
        if (this.isPaused)
            return;
        var d = Date.now();
        var dt = d - this.lastFrameTime;
        this.lastFrameTime = d;
        if (dt > 34)
            dt = 34; //避免苹果手机打开下拉菜单再回来，dt值过大
        dt *= 0.001; //单位转换为秒
        this.elapseTimer += dt;
        if (!!this.customStep) {
            this.customStep(dt);
        }
    };
    LevelManager.prototype.running = function (dt) {
        if (!this.isPaused) {
            this.updateAction(dt);
            if (!!this.customStep)
                this.customStep(dt);
        }
    };
    LevelManager.prototype.getLevelData = function () {
        return this.levelData;
    };
    LevelManager.prototype.initActMng = function () {
        this.actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.Level);
    };
    LevelManager.prototype.updateAction = function (dt) {
        this.actMng.update(dt);
    };
    //#endregion
    /**************************************************************对外功能**************************************************************/
    //#region 进入关卡
    //进入关卡，设置关卡数据，启动关卡控制器，开始游戏
    LevelManager.prototype.enterLevel = function (levelData) {
        this.node.active = true;
        if (this.needLoadCount <= 0) {
            this.reset();
            this.levelData = levelData;
            this._enterLevel();
        }
        else {
            this.levelData = levelData;
            this.nextState = GlobalEnum_1.GlobalEnum.LevelState.playing;
        }
    };
    LevelManager.prototype._enterLevel = function () {
        this.setData();
        this.startLevel();
    };
    //关卡数据设置完毕，开始运行关卡进行游戏
    LevelManager.prototype.startLevel = function () {
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.playing);
        this.lastFrameTime = Date.now();
        // this.schedule(this.customUpdate, 0.016);
        this.emit(GameEventType_1.EventType.CtrlEvent.ctrlStart);
        this.emit(GameEventType_1.EventType.AudioEvent.playBGM, GlobalEnum_1.GlobalEnum.AudioClip.BGM, true);
        // this.emit(EventType.SDKEvent.startRecord);
        var lv = this.levelData.lv;
        if (undefined === lv) {
            lv = this.levelData.id;
        }
        this.emit(GameEventType_1.EventType.ALDEvent.levelStart, lv);
        this.emit(GameEventType_1.EventType.UIEvent.showTip, "关卡开始！"); //todo:测试用
    };
    //#endregion
    //#region 教学脚本
    LevelManager.prototype.setTeachCmp = function (js) { };
    //#endregion
    //#region 退出关卡
    //退出关卡
    LevelManager.prototype.exit = function () {
        this.reset();
        // this.node.active = false;
        // this.unschedule(this.customUpdate);
    };
    LevelManager.prototype.initEnterLobbyState = function () {
        this.nextState = null;
        this.needLoadCount = 0;
        console.warn("进入首页必须加载的预制件数量为：", this.needLoadCount);
    };
    LevelManager.prototype.enterLobby = function () {
        if (this.needLoadCount <= 0) {
            this.reset();
            this.setEnterLobbyData();
            this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.lobby);
        }
        else {
            this.nextState = GlobalEnum_1.GlobalEnum.LevelState.lobby;
        }
    };
    LevelManager.prototype.setEnterLobbyData = function () {
        console.log("设置关卡场景作为首页背景时的数据，由子类实现");
    };
    LevelManager.prototype.loadLobbyItemFinish = function () {
        this.needLoadCount--;
        if (this.needLoadCount <= 0) {
            switch (this.nextState) {
                case GlobalEnum_1.GlobalEnum.LevelState.lobby: {
                    this.setEnterLobbyData();
                    this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.lobby);
                    break;
                }
                case GlobalEnum_1.GlobalEnum.LevelState.playing: {
                    this._enterLevel();
                    break;
                }
            }
            this.emit(GameEventType_1.EventType.LevelEvent.levelSceneLoadFinish);
        }
    };
    //#endregion
    /**************************************************************流程**************************************************************/
    //#region 基础流程，子类实现
    //关卡进行中
    LevelManager.prototype.stepLevelPlaying = function (dt) {
        // console.log("关卡管理器子类未实现方法stepLevelPlaying");
    };
    //关卡胜利
    LevelManager.prototype.stepLevelWin = function (dt) {
        // console.log("关卡管理器子类未实现方法stepLevelWin");
    };
    //关卡失败
    LevelManager.prototype.stepLevelLose = function (dt) {
        // console.log("关卡管理器子类未实现方法stepLevelLose");
    };
    //游戏流程为显示首页，关卡场景作为背景
    LevelManager.prototype.stepLobby = function (dt) {
        // console.log("关卡管理器子类未实现方法stepLobby");
    };
    //#endregion
    /**************************************************************功能**************************************************************/
    //#region 结算
    /**玩家胜利 */
    LevelManager.prototype.win = function (data) {
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.win);
        this.emit(GameEventType_1.EventType.CtrlEvent.ctrlEnd);
        this.emit(GameEventType_1.EventType.DirectorEvent.playerWin, data);
        this.emit(GameEventType_1.EventType.AudioEvent.stopBGM);
        this.emit(GameEventType_1.EventType.AudioEvent.playEffect, GlobalEnum_1.GlobalEnum.AudioClip.win);
        // this.emit(EventType.SDKEvent.stopRecord);
        var lv = this.levelData.lv;
        if (undefined === lv) {
            lv = this.levelData.id;
        }
        this.emit(GameEventType_1.EventType.ALDEvent.levelWin, lv);
        this.emit(GameEventType_1.EventType.PlayerDataEvent.trySkinEnd, GlobalEnum_1.GlobalEnum.GoodsType.playerSkin);
    };
    /**玩家失败 */
    LevelManager.prototype.lose = function (data) {
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.lose);
        this.emit(GameEventType_1.EventType.CtrlEvent.ctrlEnd);
        this.emit(GameEventType_1.EventType.DirectorEvent.playerLose, data);
        this.emit(GameEventType_1.EventType.AudioEvent.stopBGM);
        this.emit(GameEventType_1.EventType.AudioEvent.playEffect, GlobalEnum_1.GlobalEnum.AudioClip.lose);
        // this.emit(EventType.SDKEvent.stopRecord);
        var lv = this.levelData.lv;
        if (undefined === lv) {
            lv = this.levelData.id;
        }
        this.emit(GameEventType_1.EventType.ALDEvent.levelLose, lv);
        this.emit(GameEventType_1.EventType.PlayerDataEvent.trySkinEnd, GlobalEnum_1.GlobalEnum.GoodsType.playerSkin);
    };
    __decorate([
        property(cc.Node)
    ], LevelManager.prototype, "levelLayer", void 0);
    LevelManager = __decorate([
        ccclass
    ], LevelManager);
    return LevelManager;
}(yyComponent_1.default));
exports.default = LevelManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxTY2VuZVxcU2NyaXB0XFxMZXZlbE1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBQzFELHdFQUFtRTtBQUNuRSx1RUFBcUY7QUFDckYsa0VBQWlFO0FBRTNELElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBQzVDLE9BQU87QUFFUDtJQUEwQyxnQ0FBVztJQUFyRDtRQUFBLHFFQWdSQztRQWpPYSxnQkFBVSxHQUFXLENBQUMsQ0FBQztRQWtFakMsWUFBWTtRQUVaLFlBQVk7UUFDWixxQkFBcUI7UUFFWCxnQkFBVSxHQUFZLElBQUksQ0FBQztRQUNyQyxZQUFZO1FBRVosZUFBZTtRQUNMLFlBQU0sR0FBb0IsSUFBSSxDQUFDO1FBdUR6QyxZQUFZO1FBRVoseUJBQXlCO1FBQ2YsZUFBUyxHQUFHLElBQUksQ0FBQztRQUNqQixtQkFBYSxHQUFXLENBQUMsQ0FBQzs7UUF5RnBDLFlBQVk7SUFFaEIsQ0FBQztJQTlRRyxrSUFBa0k7SUFDbEksYUFBYTtJQUNOLDJCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFdEIsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLEVBQUUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRVMsNENBQXFCLEdBQS9CO1FBQ0ksRUFBRSxDQUFDLElBQUksQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBVSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ3hFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBVSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDbEYsQ0FBQztJQUVTLCtCQUFRLEdBQWxCO1FBQ0ksRUFBRSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0Qsb0JBQW9CO0lBQ1YscUNBQWMsR0FBeEI7SUFDQSxDQUFDO0lBQ0QsWUFBWTtJQUVaLFlBQVk7SUFDTCw0QkFBSyxHQUFaO1FBQ0ksVUFBVTtRQUVWLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBS0Qsc0JBQVcsZ0NBQU07YUFBakIsY0FBc0IsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFFN0MsWUFBWTtJQUNMLDRCQUFLLEdBQVosVUFBYSxLQUFpQjtRQUFqQixzQkFBQSxFQUFBLFNBQWlCO1FBQzFCLElBQUksQ0FBQyxVQUFVLElBQUksS0FBSyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO0lBQ3pCLENBQUM7SUFDRDs7O09BR0c7SUFDSSw2QkFBTSxHQUFiLFVBQWMsS0FBaUI7UUFBakIsc0JBQUEsRUFBQSxTQUFpQjtRQUMzQixJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsRUFBRTtZQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1lBQ3BCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1NBQ3pCO2FBQU07WUFDSCxJQUFJLENBQUMsVUFBVSxJQUFJLEtBQUssQ0FBQztZQUN6QixJQUFJLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxFQUFFO2dCQUN0QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztnQkFDcEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7YUFDekI7U0FDSjtJQUNMLENBQUM7SUFNUyxxQ0FBYyxHQUF4QjtRQUNJLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ3hCLENBQUM7SUFDUyxzQ0FBZSxHQUF6QjtRQUNJLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ3hCLENBQUM7SUFDRCxtQkFBbUI7SUFDWixtQ0FBWSxHQUFuQjtRQUNJLElBQUksSUFBSSxDQUFDLFFBQVE7WUFBRSxPQUFPO1FBQzFCLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNuQixJQUFJLEVBQUUsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUNoQyxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztRQUV2QixJQUFJLEVBQUUsR0FBRyxFQUFFO1lBQUUsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFBLHVCQUF1QjtRQUM1QyxFQUFFLElBQUksS0FBSyxDQUFDLENBQUEsUUFBUTtRQUNwQixJQUFJLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDdkI7SUFDTCxDQUFDO0lBRU0sOEJBQU8sR0FBZCxVQUFlLEVBQVU7UUFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN0QixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzlDO0lBQ0wsQ0FBQztJQU1NLG1DQUFZLEdBQW5CO1FBQ0ksT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQzFCLENBQUM7SUFXUyxpQ0FBVSxHQUFwQjtRQUNJLElBQUksQ0FBQyxNQUFNLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsK0JBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ1MsbUNBQVksR0FBdEIsVUFBdUIsRUFBRTtRQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBQ0QsWUFBWTtJQUVaLGtJQUFrSTtJQUNsSSxjQUFjO0lBQ2QsMEJBQTBCO0lBQ25CLGlDQUFVLEdBQWpCLFVBQWtCLFNBQVM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxDQUFDLEVBQUU7WUFDekIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2IsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7WUFDM0IsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO2FBQU07WUFDSCxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLHVCQUFVLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFDUyxrQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBQ0QscUJBQXFCO0lBQ1gsaUNBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsc0JBQXNCLENBQUMsdUJBQVUsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDaEMsMkNBQTJDO1FBQzNDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsdUJBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hFLDZDQUE2QztRQUM3QyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztRQUMzQixJQUFJLFNBQVMsS0FBSyxFQUFFLEVBQUU7WUFDbEIsRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1NBQzFCO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQSxVQUFVO0lBQzVELENBQUM7SUFDRCxZQUFZO0lBRVosY0FBYztJQUNQLGtDQUFXLEdBQWxCLFVBQW1CLEVBQUUsSUFBSSxDQUFDO0lBQzFCLFlBQVk7SUFFWixjQUFjO0lBQ2QsTUFBTTtJQUNDLDJCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYiw0QkFBNEI7UUFDNUIsc0NBQXNDO0lBQzFDLENBQUM7SUFNUywwQ0FBbUIsR0FBN0I7UUFDSSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztRQUN2QixPQUFPLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ00saUNBQVUsR0FBakI7UUFDSSxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksQ0FBQyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNiLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyx1QkFBVSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM1RDthQUFNO1lBQ0gsSUFBSSxDQUFDLFNBQVMsR0FBRyx1QkFBVSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7U0FDaEQ7SUFDTCxDQUFDO0lBQ1Msd0NBQWlCLEdBQTNCO1FBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDUywwQ0FBbUIsR0FBN0I7UUFDSSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLENBQUMsRUFBRTtZQUN6QixRQUFRLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ3BCLEtBQUssdUJBQVUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQzlCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUN6QixJQUFJLENBQUMsc0JBQXNCLENBQUMsdUJBQVUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3pELE1BQU07aUJBQ1Q7Z0JBQ0QsS0FBSyx1QkFBVSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUNuQixNQUFNO2lCQUNUO2FBQ0o7WUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUM7U0FDeEQ7SUFDTCxDQUFDO0lBQ0QsWUFBWTtJQUVaLGdJQUFnSTtJQUNoSSxtQkFBbUI7SUFDbkIsT0FBTztJQUNHLHVDQUFnQixHQUExQixVQUEyQixFQUFVO1FBQ2pDLCtDQUErQztJQUNuRCxDQUFDO0lBQ0QsTUFBTTtJQUNJLG1DQUFZLEdBQXRCLFVBQXVCLEVBQVU7UUFDN0IsMkNBQTJDO0lBQy9DLENBQUM7SUFDRCxNQUFNO0lBQ0ksb0NBQWEsR0FBdkIsVUFBd0IsRUFBVTtRQUM5Qiw0Q0FBNEM7SUFDaEQsQ0FBQztJQUNELG9CQUFvQjtJQUNWLGdDQUFTLEdBQW5CLFVBQW9CLEVBQVU7UUFDMUIsd0NBQXdDO0lBQzVDLENBQUM7SUFDRCxZQUFZO0lBRVosZ0lBQWdJO0lBQ2hJLFlBQVk7SUFDWixVQUFVO0lBQ0EsMEJBQUcsR0FBYixVQUFjLElBQVU7UUFDcEIsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHVCQUFVLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZELElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdkMsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSx1QkFBVSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNyRSw0Q0FBNEM7UUFDNUMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7UUFDM0IsSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO1lBQ2xCLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztTQUMxQjtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzNDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLHVCQUFVLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFDRCxVQUFVO0lBQ0EsMkJBQUksR0FBZCxVQUFlLElBQVU7UUFDckIsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHVCQUFVLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hELElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdkMsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSx1QkFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0RSw0Q0FBNEM7UUFDNUMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7UUFDM0IsSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO1lBQ2xCLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztTQUMxQjtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLHVCQUFVLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUF2SkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztvREFDbUI7SUF0SHBCLFlBQVk7UUFEaEMsT0FBTztPQUNhLFlBQVksQ0FnUmhDO0lBQUQsbUJBQUM7Q0FoUkQsQUFnUkMsQ0FoUnlDLHFCQUFXLEdBZ1JwRDtrQkFoUm9CLFlBQVkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeXlDb21wb25lbnQgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24veXlDb21wb25lbnRcIjtcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2FtZUV2ZW50VHlwZVwiO1xuaW1wb3J0IEFjdGlvbjNkTWFuYWdlciwgeyBBY3Rpb25NbmdUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vQWN0aW9uM2RNYW5hZ2VyXCI7XG5pbXBvcnQgeyBHbG9iYWxFbnVtIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HbG9iYWxFbnVtXCI7XG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG4vL+WFs+WNoeeuoeeQhuWZqFxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIExldmVsTWFuYWdlciBleHRlbmRzIHl5Q29tcG9uZW50IHtcblxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKumAmueUqOa1geeoiyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIC8vI3JlZ2lvbiDliJ3lp4vljJZcbiAgICBwdWJsaWMgaW5pdCgpIHtcbiAgICAgICAgdGhpcy5pbml0Q29tcG9uZW50cygpO1xuICAgICAgICB0aGlzLmluaXRDdXN0b21VcGRhdGVTdGF0ZSgpO1xuICAgICAgICB0aGlzLmluaXRMZXZlbFRpbWVyKCk7XG4gICAgICAgIHRoaXMuaW5pdEFjdE1uZygpO1xuICAgICAgICB0aGlzLmluaXRFbnRlckxvYmJ5U3RhdGUoKTtcbiAgICAgICAgdGhpcy5sb2FkTG9iYnlJdGVtcygpO1xuXG4gICAgICAgIHRoaXMucmVnaXN0QWxsQ3VzdG9tVXBkYXRlKCk7XG4gICAgICAgIHRoaXMub25FdmVudHMoKTtcbiAgICAgICAgY2Mud2FybihcIuWFs+WNoeeuoeeQhuWZqOeahGluaXTpnIDnlLHlrZDnsbvlrp7njrBcIik7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHJlZ2lzdEFsbEN1c3RvbVVwZGF0ZSgpIHtcbiAgICAgICAgY2Mud2FybihcIuWFs+WNoeeuoeeQhuWZqOeahHJlZ2lzdEFsbEN1c3RvbVVwZGF0ZemcgOeUseWtkOexu+WunueOsFwiKTtcbiAgICAgICAgdGhpcy5yZWdpc3RDdXN0b21VcGRhdGUoR2xvYmFsRW51bS5MZXZlbFN0YXRlLmxvYmJ5LCB0aGlzLnN0ZXBMb2JieSk7XG4gICAgICAgIHRoaXMucmVnaXN0Q3VzdG9tVXBkYXRlKEdsb2JhbEVudW0uTGV2ZWxTdGF0ZS53aW4sIHRoaXMuc3RlcExldmVsV2luKTtcbiAgICAgICAgdGhpcy5yZWdpc3RDdXN0b21VcGRhdGUoR2xvYmFsRW51bS5MZXZlbFN0YXRlLmxvc2UsIHRoaXMuc3RlcExldmVsTG9zZSk7XG4gICAgICAgIHRoaXMucmVnaXN0Q3VzdG9tVXBkYXRlKEdsb2JhbEVudW0uTGV2ZWxTdGF0ZS5wbGF5aW5nLCB0aGlzLnN0ZXBMZXZlbFBsYXlpbmcpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBvbkV2ZW50cygpIHtcbiAgICAgICAgY2Mud2FybihcIuWFs+WNoeeuoeeQhuWZqOeahG9uRXZlbnRz6ZyA55Sx5a2Q57G75a6e546wXCIpO1xuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LnBhdXNlTGV2ZWwsIHRoaXMucGF1c2UsIHRoaXMpO1xuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LnJlc3VtZUxldmVsLCB0aGlzLnJlc3VtZSwgdGhpcyk7XG4gICAgfVxuICAgIC8qKuWKoOi9vei/m+WFpemmlumhteaXtuW/hemhu+aYvuekuueahOWGheWuuSAqL1xuICAgIHByb3RlY3RlZCBsb2FkTG9iYnlJdGVtcygpIHtcbiAgICB9XG4gICAgLy8jZW5kcmVnaW9uXG5cbiAgICAvLyNyZWdpb24g6YeN572uXG4gICAgcHVibGljIHJlc2V0KCkge1xuICAgICAgICAvL+WbnuaUtuWFs+WNoeS4reeahOWvueixoVxuXG4gICAgICAgIHRoaXMucmVzZXRDdXN0b21VcGRhdGVTdGF0ZSgpO1xuICAgICAgICB0aGlzLnJlc2V0TGV2ZWxUaW1lcigpO1xuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDlhbPljaHmmoLlgZwv5oGi5aSNXG4gICAgcHJvdGVjdGVkIGlzUGF1c2VkOiBib29sZWFuOyAgICAgICAgICAvL+WFs+WNoeaYr+WQpuaaguWBnOeKtuaAgVxuICAgIHB1YmxpYyBnZXQgcGF1c2VkKCkgeyByZXR1cm4gdGhpcy5pc1BhdXNlZDsgfVxuICAgIHByb3RlY3RlZCBwYXVzZUNvdW50OiBudW1iZXIgPSAwO1xuICAgIC8qKuaaguWBnOWFs+WNoei/kOihjCAqL1xuICAgIHB1YmxpYyBwYXVzZShjb3VudDogbnVtYmVyID0gMSkge1xuICAgICAgICB0aGlzLnBhdXNlQ291bnQgKz0gY291bnQ7XG4gICAgICAgIHRoaXMuaXNQYXVzZWQgPSB0cnVlO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiDnu6fnu63lhbPljaHov5DooYxcbiAgICAgKiBAcGFyYW0gY291bnQg5YC85Li6LTHml7blvLrliLbmgaLlpI3lhbPljaHov5DooYxcbiAgICAgKi9cbiAgICBwdWJsaWMgcmVzdW1lKGNvdW50OiBudW1iZXIgPSAxKSB7XG4gICAgICAgIGlmIChjb3VudCA9PT0gLTEpIHtcbiAgICAgICAgICAgIHRoaXMucGF1c2VDb3VudCA9IDA7XG4gICAgICAgICAgICB0aGlzLmlzUGF1c2VkID0gZmFsc2U7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnBhdXNlQ291bnQgLT0gY291bnQ7XG4gICAgICAgICAgICBpZiAodGhpcy5wYXVzZUNvdW50IDw9IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBhdXNlQ291bnQgPSAwO1xuICAgICAgICAgICAgICAgIHRoaXMuaXNQYXVzZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDlhbPljaHkuLvlvqrnjq9cbiAgICBwcm90ZWN0ZWQgZWxhcHNlVGltZXI6IG51bWJlcjsgICAgICAgIC8v5YWz5Y2h57uP5Y6G55qE5pe26Ze077yM5Y2V5L2NIOavq+enklxuICAgIHByb3RlY3RlZCBsYXN0RnJhbWVUaW1lOiBudW1iZXI7ICAgICAgLy/kuIrkuIDluKfmm7TmlrDml7bnmoTml7bpl7TmiLNcbiAgICBwcm90ZWN0ZWQgaW5pdExldmVsVGltZXIoKSB7XG4gICAgICAgIHRoaXMuZWxhcHNlVGltZXIgPSAwO1xuICAgICAgICB0aGlzLmlzUGF1c2VkID0gZmFsc2U7XG4gICAgICAgIHRoaXMucGF1c2VDb3VudCA9IDA7XG4gICAgfVxuICAgIHByb3RlY3RlZCByZXNldExldmVsVGltZXIoKSB7XG4gICAgICAgIHRoaXMuZWxhcHNlVGltZXIgPSAwO1xuICAgICAgICB0aGlzLmlzUGF1c2VkID0gZmFsc2U7XG4gICAgICAgIHRoaXMucGF1c2VDb3VudCA9IDA7XG4gICAgfVxuICAgIC8v6Ieq5a6a5LmJ55qE5q+P5bin5pu05paw5Ye95pWw77yM55Sx6K6h5pe25Zmo5omn6KGMXG4gICAgcHVibGljIGN1c3RvbVVwZGF0ZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuaXNQYXVzZWQpIHJldHVybjtcbiAgICAgICAgbGV0IGQgPSBEYXRlLm5vdygpO1xuICAgICAgICBsZXQgZHQgPSBkIC0gdGhpcy5sYXN0RnJhbWVUaW1lO1xuICAgICAgICB0aGlzLmxhc3RGcmFtZVRpbWUgPSBkO1xuXG4gICAgICAgIGlmIChkdCA+IDM0KSBkdCA9IDM0Oy8v6YG/5YWN6Iu55p6c5omL5py65omT5byA5LiL5ouJ6I+c5Y2V5YaN5Zue5p2l77yMZHTlgLzov4flpKdcbiAgICAgICAgZHQgKj0gMC4wMDE7Ly/ljZXkvY3ovazmjaLkuLrnp5JcbiAgICAgICAgdGhpcy5lbGFwc2VUaW1lciArPSBkdDtcbiAgICAgICAgaWYgKCEhdGhpcy5jdXN0b21TdGVwKSB7XG4gICAgICAgICAgICB0aGlzLmN1c3RvbVN0ZXAoZHQpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHVibGljIHJ1bm5pbmcoZHQ6IG51bWJlcikge1xuICAgICAgICBpZiAoIXRoaXMuaXNQYXVzZWQpIHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlQWN0aW9uKGR0KTtcbiAgICAgICAgICAgIGlmICghIXRoaXMuY3VzdG9tU3RlcCkgdGhpcy5jdXN0b21TdGVwKGR0KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKueuoeeQhuWvueixoeOAgeaVsOaNrioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIC8vI3JlZ2lvbiDmlbDmja5cbiAgICBwcm90ZWN0ZWQgbGV2ZWxEYXRhOiBhbnk7ICAgICAgICAgICAgIC8v5b2T5YmN5YWz5Y2h55qE5YWz5Y2h5pWw5o2uXG4gICAgcHVibGljIGdldExldmVsRGF0YSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubGV2ZWxEYXRhO1xuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDlr7nosaFcbiAgICAvKirlhbPljaHkuK3liqjmgIHmt7vliqDnmoTmqKHlnovoioLngrnlrZjmlL7lsYIgKi9cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBwcm90ZWN0ZWQgbGV2ZWxMYXllcjogY2MuTm9kZSA9IG51bGw7XG4gICAgLy8jZW5kcmVnaW9uXG5cbiAgICAvLyNyZWdpb24g5Yqo5L2c566h55CG5ZmoXG4gICAgcHJvdGVjdGVkIGFjdE1uZzogQWN0aW9uM2RNYW5hZ2VyID0gbnVsbDtcbiAgICBwcm90ZWN0ZWQgaW5pdEFjdE1uZygpIHtcbiAgICAgICAgdGhpcy5hY3RNbmcgPSBBY3Rpb24zZE1hbmFnZXIuZ2V0TW5nKEFjdGlvbk1uZ1R5cGUuTGV2ZWwpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgdXBkYXRlQWN0aW9uKGR0KSB7XG4gICAgICAgIHRoaXMuYWN0TW5nLnVwZGF0ZShkdCk7XG4gICAgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5a+55aSW5Yqf6IO9KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgLy8jcmVnaW9uIOi/m+WFpeWFs+WNoVxuICAgIC8v6L+b5YWl5YWz5Y2h77yM6K6+572u5YWz5Y2h5pWw5o2u77yM5ZCv5Yqo5YWz5Y2h5o6n5Yi25Zmo77yM5byA5aeL5ri45oiPXG4gICAgcHVibGljIGVudGVyTGV2ZWwobGV2ZWxEYXRhKSB7XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICBpZiAodGhpcy5uZWVkTG9hZENvdW50IDw9IDApIHtcbiAgICAgICAgICAgIHRoaXMucmVzZXQoKTtcbiAgICAgICAgICAgIHRoaXMubGV2ZWxEYXRhID0gbGV2ZWxEYXRhO1xuICAgICAgICAgICAgdGhpcy5fZW50ZXJMZXZlbCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5sZXZlbERhdGEgPSBsZXZlbERhdGE7XG4gICAgICAgICAgICB0aGlzLm5leHRTdGF0ZSA9IEdsb2JhbEVudW0uTGV2ZWxTdGF0ZS5wbGF5aW5nO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByb3RlY3RlZCBfZW50ZXJMZXZlbCgpIHtcbiAgICAgICAgdGhpcy5zZXREYXRhKCk7XG4gICAgICAgIHRoaXMuc3RhcnRMZXZlbCgpO1xuICAgIH1cbiAgICAvL+WFs+WNoeaVsOaNruiuvue9ruWujOavle+8jOW8gOWni+i/kOihjOWFs+WNoei/m+ihjOa4uOaIj1xuICAgIHByb3RlY3RlZCBzdGFydExldmVsKCkge1xuICAgICAgICB0aGlzLmVudGVyQ3VzdG9tVXBkYXRlU3RhdGUoR2xvYmFsRW51bS5MZXZlbFN0YXRlLnBsYXlpbmcpO1xuICAgICAgICB0aGlzLmxhc3RGcmFtZVRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICAvLyB0aGlzLnNjaGVkdWxlKHRoaXMuY3VzdG9tVXBkYXRlLCAwLjAxNik7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQ3RybEV2ZW50LmN0cmxTdGFydCk7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQXVkaW9FdmVudC5wbGF5QkdNLCBHbG9iYWxFbnVtLkF1ZGlvQ2xpcC5CR00sIHRydWUpO1xuICAgICAgICAvLyB0aGlzLmVtaXQoRXZlbnRUeXBlLlNES0V2ZW50LnN0YXJ0UmVjb3JkKTtcbiAgICAgICAgbGV0IGx2ID0gdGhpcy5sZXZlbERhdGEubHY7XG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IGx2KSB7XG4gICAgICAgICAgICBsdiA9IHRoaXMubGV2ZWxEYXRhLmlkO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQUxERXZlbnQubGV2ZWxTdGFydCwgbHYpO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuc2hvd1RpcCwgXCLlhbPljaHlvIDlp4vvvIFcIik7Ly90b2RvOua1i+ivleeUqFxuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDmlZnlrabohJrmnKxcbiAgICBwdWJsaWMgc2V0VGVhY2hDbXAoanMpIHsgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLy8jcmVnaW9uIOmAgOWHuuWFs+WNoVxuICAgIC8v6YCA5Ye65YWz5Y2hXG4gICAgcHVibGljIGV4aXQoKSB7XG4gICAgICAgIHRoaXMucmVzZXQoKTtcbiAgICAgICAgLy8gdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAvLyB0aGlzLnVuc2NoZWR1bGUodGhpcy5jdXN0b21VcGRhdGUpO1xuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8vI3JlZ2lvbiDmuLjmiI/ov5vlhaXpppbpobXvvIzlhbPljaHlnLrmma/kvZzkuLrog4zmma9cbiAgICBwcm90ZWN0ZWQgbmV4dFN0YXRlID0gbnVsbDtcbiAgICBwcm90ZWN0ZWQgbmVlZExvYWRDb3VudDogbnVtYmVyID0gMDtcbiAgICBwcm90ZWN0ZWQgaW5pdEVudGVyTG9iYnlTdGF0ZSgpIHtcbiAgICAgICAgdGhpcy5uZXh0U3RhdGUgPSBudWxsO1xuICAgICAgICB0aGlzLm5lZWRMb2FkQ291bnQgPSAwO1xuICAgICAgICBjb25zb2xlLndhcm4oXCLov5vlhaXpppbpobXlv4XpobvliqDovb3nmoTpooTliLbku7bmlbDph4/kuLrvvJpcIiwgdGhpcy5uZWVkTG9hZENvdW50KTtcbiAgICB9XG4gICAgcHVibGljIGVudGVyTG9iYnkoKSB7XG4gICAgICAgIGlmICh0aGlzLm5lZWRMb2FkQ291bnQgPD0gMCkge1xuICAgICAgICAgICAgdGhpcy5yZXNldCgpO1xuICAgICAgICAgICAgdGhpcy5zZXRFbnRlckxvYmJ5RGF0YSgpO1xuICAgICAgICAgICAgdGhpcy5lbnRlckN1c3RvbVVwZGF0ZVN0YXRlKEdsb2JhbEVudW0uTGV2ZWxTdGF0ZS5sb2JieSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLm5leHRTdGF0ZSA9IEdsb2JhbEVudW0uTGV2ZWxTdGF0ZS5sb2JieTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcm90ZWN0ZWQgc2V0RW50ZXJMb2JieURhdGEoKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwi6K6+572u5YWz5Y2h5Zy65pmv5L2c5Li66aaW6aG16IOM5pmv5pe255qE5pWw5o2u77yM55Sx5a2Q57G75a6e546wXCIpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgbG9hZExvYmJ5SXRlbUZpbmlzaCgpIHtcbiAgICAgICAgdGhpcy5uZWVkTG9hZENvdW50LS07XG4gICAgICAgIGlmICh0aGlzLm5lZWRMb2FkQ291bnQgPD0gMCkge1xuICAgICAgICAgICAgc3dpdGNoICh0aGlzLm5leHRTdGF0ZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgR2xvYmFsRW51bS5MZXZlbFN0YXRlLmxvYmJ5OiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0RW50ZXJMb2JieURhdGEoKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5lbnRlckN1c3RvbVVwZGF0ZVN0YXRlKEdsb2JhbEVudW0uTGV2ZWxTdGF0ZS5sb2JieSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXNlIEdsb2JhbEVudW0uTGV2ZWxTdGF0ZS5wbGF5aW5nOiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2VudGVyTGV2ZWwoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5MZXZlbEV2ZW50LmxldmVsU2NlbmVMb2FkRmluaXNoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyNlbmRyZWdpb25cblxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKua1geeoiyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIC8vI3JlZ2lvbiDln7rnoYDmtYHnqIvvvIzlrZDnsbvlrp7njrBcbiAgICAvL+WFs+WNoei/m+ihjOS4rVxuICAgIHByb3RlY3RlZCBzdGVwTGV2ZWxQbGF5aW5nKGR0OiBudW1iZXIpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCLlhbPljaHnrqHnkIblmajlrZDnsbvmnKrlrp7njrDmlrnms5VzdGVwTGV2ZWxQbGF5aW5nXCIpO1xuICAgIH1cbiAgICAvL+WFs+WNoeiDnOWIqVxuICAgIHByb3RlY3RlZCBzdGVwTGV2ZWxXaW4oZHQ6IG51bWJlcikge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIuWFs+WNoeeuoeeQhuWZqOWtkOexu+acquWunueOsOaWueazlXN0ZXBMZXZlbFdpblwiKTtcbiAgICB9XG4gICAgLy/lhbPljaHlpLHotKVcbiAgICBwcm90ZWN0ZWQgc3RlcExldmVsTG9zZShkdDogbnVtYmVyKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwi5YWz5Y2h566h55CG5Zmo5a2Q57G75pyq5a6e546w5pa55rOVc3RlcExldmVsTG9zZVwiKTtcbiAgICB9XG4gICAgLy/muLjmiI/mtYHnqIvkuLrmmL7npLrpppbpobXvvIzlhbPljaHlnLrmma/kvZzkuLrog4zmma9cbiAgICBwcm90ZWN0ZWQgc3RlcExvYmJ5KGR0OiBudW1iZXIpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCLlhbPljaHnrqHnkIblmajlrZDnsbvmnKrlrp7njrDmlrnms5VzdGVwTG9iYnlcIik7XG4gICAgfVxuICAgIC8vI2VuZHJlZ2lvblxuXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5Yqf6IO9KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgLy8jcmVnaW9uIOe7k+eul1xuICAgIC8qKueOqeWutuiDnOWIqSAqL1xuICAgIHByb3RlY3RlZCB3aW4oZGF0YT86IGFueSkge1xuICAgICAgICB0aGlzLmVudGVyQ3VzdG9tVXBkYXRlU3RhdGUoR2xvYmFsRW51bS5MZXZlbFN0YXRlLndpbik7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQ3RybEV2ZW50LmN0cmxFbmQpO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQucGxheWVyV2luLCBkYXRhKTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnN0b3BCR00pO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUVmZmVjdCwgR2xvYmFsRW51bS5BdWRpb0NsaXAud2luKTtcbiAgICAgICAgLy8gdGhpcy5lbWl0KEV2ZW50VHlwZS5TREtFdmVudC5zdG9wUmVjb3JkKTtcbiAgICAgICAgbGV0IGx2ID0gdGhpcy5sZXZlbERhdGEubHY7XG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IGx2KSB7XG4gICAgICAgICAgICBsdiA9IHRoaXMubGV2ZWxEYXRhLmlkO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQUxERXZlbnQubGV2ZWxXaW4sIGx2KTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5QbGF5ZXJEYXRhRXZlbnQudHJ5U2tpbkVuZCwgR2xvYmFsRW51bS5Hb29kc1R5cGUucGxheWVyU2tpbik7XG4gICAgfVxuICAgIC8qKueOqeWutuWksei0pSAqL1xuICAgIHByb3RlY3RlZCBsb3NlKGRhdGE/OiBhbnkpIHtcbiAgICAgICAgdGhpcy5lbnRlckN1c3RvbVVwZGF0ZVN0YXRlKEdsb2JhbEVudW0uTGV2ZWxTdGF0ZS5sb3NlKTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5DdHJsRXZlbnQuY3RybEVuZCk7XG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5wbGF5ZXJMb3NlLCBkYXRhKTtcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnN0b3BCR00pO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUVmZmVjdCwgR2xvYmFsRW51bS5BdWRpb0NsaXAubG9zZSk7XG4gICAgICAgIC8vIHRoaXMuZW1pdChFdmVudFR5cGUuU0RLRXZlbnQuc3RvcFJlY29yZCk7XG4gICAgICAgIGxldCBsdiA9IHRoaXMubGV2ZWxEYXRhLmx2O1xuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBsdikge1xuICAgICAgICAgICAgbHYgPSB0aGlzLmxldmVsRGF0YS5pZDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkFMREV2ZW50LmxldmVsTG9zZSwgbHYpO1xuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlBsYXllckRhdGFFdmVudC50cnlTa2luRW5kLCBHbG9iYWxFbnVtLkdvb2RzVHlwZS5wbGF5ZXJTa2luKTtcbiAgICB9XG4gICAgLy8jZW5kcmVnaW9uXG5cbn1cbiJdfQ==