
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LevelScene/Script/LevelCamera.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ade43+9RZtE46LoF1vdxOuA', 'LevelCamera');
// Level/Script/LevelCamera.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**关卡中使用的3D相机 */
var LevelCamera = /** @class */ (function (_super) {
    __extends(LevelCamera, _super);
    function LevelCamera() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**相机组件 */
        _this.camera = null;
        /**相机组件所在节点 */
        _this.cameraNode = null;
        /**相机朝向的节点 */
        _this.anchorNode = null;
        return _this;
    }
    LevelCamera.prototype.initOriginalTransform = function () {
        this._originalPos = cc.v3();
        this.cameraNode.getPosition(this._originalPos);
        this._originalEulerAngles = cc.v3();
        this._originalEulerAngles.set(this.cameraNode.eulerAngles);
    };
    /**恢复到原始视角 */
    LevelCamera.prototype.resumeOriginalTransform = function (duration, cb) {
        if (duration === void 0) { duration = 0; }
        if (!duration) {
            this.cameraNode.setPosition(this._originalPos);
            this.cameraNode.eulerAngles = this._originalEulerAngles;
            return;
        }
        this.changeCamera({
            duration: duration,
            pos: this._originalPos,
            angle: this._originalEulerAngles,
            cb: cb
        });
    };
    /**视角切换 */
    LevelCamera.prototype.changeCamera = function (data) {
        if (!data.duration) {
            if (!!data.pos)
                this.cameraNode.setPosition(data.pos);
            if (!!data.angle)
                this.cameraNode.eulerAngles = data.angle;
            if (!!data.cb)
                data.cb();
            return;
        }
        var move = null;
        var rotate = null;
        if (!!data.pos) {
            move = Action3dManager_1.default.moveTo(data.duration, data.pos);
        }
        if (!!data.angle) {
            rotate = Action3dManager_1.default.rotateTo(data.duration, data.angle);
        }
        var spawn = null;
        if (!!move && !!rotate) {
            spawn = Action3dManager_1.default.spawn(move, rotate);
        }
        else if (!!move) {
            spawn = Action3dManager_1.default.spawn(move);
        }
        else if (!!rotate) {
            spawn = Action3dManager_1.default.spawn(rotate);
        }
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.Level);
        if (!!spawn && !!data.cb) {
            var callFun = Action3dManager_1.default.callFun(data.cb);
            var sequence = Action3dManager_1.default.sequence(spawn, callFun);
            actMng.runAction(this.cameraNode, sequence);
        }
        else if (!!spawn) {
            actMng.runAction(this.cameraNode, spawn);
        }
        else if (!!data.cb) {
            data.cb();
        }
    };
    LevelCamera.prototype.init = function () {
        this.anchorNode = this.node;
        this.camera = this.node.getComponentInChildren(cc.Camera);
        this.cameraNode = this.camera.node;
        this.customStep = this.stepSlowFollow;
        this.adaptViewForWidth();
        this.initOriginalTransform();
    };
    //按宽度适配，保持水平方向的视野范围不变
    LevelCamera.prototype.adaptViewForWidth = function () {
        var p = cc.v3();
        this.cameraNode.getPosition(p);
        var L1 = Math.sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
        var H2 = cc.find("Canvas").height;
        var fov = this.camera.fov;
        var h = L1 * Math.tan(fov * 0.5 * 0.017453);
        h = h * H2 / 1334; //1334：设计分辨率
        var f2 = Math.atan2(h, L1) * 2 * 57.3;
        this.camera.fov = f2;
    };
    LevelCamera.prototype.reset = function () {
        this.followTarget = null;
        this.resumeOriginalTransform();
    };
    LevelCamera.prototype.setTarget = function (followTarget) {
        this.followTarget = followTarget;
        // let pos = cc.v3();
        // this.followTarget.getPosition(pos);
        // this.anchorNode.setPosition(pos);
        this.anchorNode.setPosition(this.followTarget.x, 0, this.followTarget.z);
    };
    LevelCamera.prototype.stepSlowFollow = function (dt) {
        if (!this.followTarget)
            return;
        //无缓动跟随：
        // this.anchorNode.setPosition(this.followTarget.x, this.followTarget.y, this.followTarget.z);
        this.anchorNode.setPosition(this.followTarget.x, 0, this.followTarget.z);
        // let pos = cc.v3();
        // this.followTarget.getPosition(pos);
        // this.convertWorldToScreen(pos);
        //缓动跟随：
        // let p1 = cc.v3();
        // this.followTarget.getPosition(p1);
        // let p2 = cc.v3();
        // this.anchorNode.getPosition(p2);
        // let offset = p1.subtract(p2);
        // // offset.multiplyScalar(dt);//todo:是否缓动跟随
        // this.anchorNode.setPosition(p2.addSelf(offset));
    };
    /**移动到指定位置 */
    LevelCamera.prototype.moveTo = function (duration, pos, cb) {
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.Level);
        var action = Action3dManager_1.default.moveTo(duration, pos);
        action.easing(Action3dManager_1.default.easeOut(3));
        if (!!cb) {
            var callFun = Action3dManager_1.default.callFun(cb);
            actMng.runAction(this.node, Action3dManager_1.default.sequence(action, callFun));
        }
        else {
            actMng.runAction(this.node, action);
        }
    };
    /****************************************坐标转换****************************************/
    /**世界坐标转屏幕坐标 */
    LevelCamera.prototype.convertWorldToScreen = function (pos) {
        var p = this.convertWorldToCanvas(pos);
        var cvs = cc.find("Canvas");
        p.x + cvs.width * 0.5;
        p.y += cvs.height * 0.5;
        return p;
    };
    /**世界坐标转换到Canvas节点坐标 */
    LevelCamera.prototype.convertWorldToCanvas = function (pos) {
        var p = this.convertWorldToCamera(pos);
        var angle = this.camera.fov;
        var z = p.z;
        var tan = Math.tan(angle * 0.5 * 0.017453);
        var h = Math.abs(z * tan);
        var x = p.x / h;
        var y = p.y / h;
        var cvs = cc.find("Canvas");
        y = cvs.height * 0.5 * y;
        x = cvs.height * 0.5 * x;
        return cc.v2(x, y);
    };
    /**世界坐标转换到相机坐标系 */
    LevelCamera.prototype.convertWorldToCamera = function (pos) {
        var center = this.getCameraPos();
        var eulerAngler = this.getCameraEulerAngles();
        var angle = eulerAngler.y;
        var p1 = cc.v2(pos.x - center.x, pos.z - center.z);
        p1 = this.rotatePos(p1, angle);
        angle = eulerAngler.x;
        var p2 = cc.v2(p1.y, pos.y - center.y);
        p2 = this.rotatePos(p2, angle);
        // return cc.v3(p1.x + center.x, p2.x + center.y, p2.y + center.z);
        return cc.v3(p1.x, p2.y, p2.x);
    };
    /**相机的世界坐标 */
    LevelCamera.prototype.getCameraPos = function () {
        var angle = this.node.eulerAngles.y;
        var p = this.rotatePos(cc.v2(this.cameraNode.x, this.cameraNode.z), -angle);
        return cc.v3(p.x + this.node.x, this.cameraNode.y + this.node.y, p.y + this.node.z);
    };
    /**相机在世界坐标系下的旋转角度 */
    LevelCamera.prototype.getCameraEulerAngles = function () {
        return cc.v3(this.cameraNode.eulerAngles.x, this.node.eulerAngles.y, 0);
    };
    /**
     * 旋转坐标点
     * @param p 坐标点
     * @param angle 旋转角度，负数表示顺时针旋转，正数表示逆时针旋转
     */
    LevelCamera.prototype.rotatePos = function (p, angle) {
        var radian = angle * 0.017453;
        var sin = Math.sin(radian);
        var cos = Math.cos(radian);
        var x = p.x * cos - p.y * sin;
        var y = p.x * sin + p.y * cos;
        return cc.v2(x, y);
    };
    /**
     * 将节点坐标系下的坐标点转换为其父节点坐标系下的坐标
     * @param node 节点
     * @param pos 坐标点
     */
    LevelCamera.prototype.convertToParent = function (node, pos) {
        var p = cc.v3(pos.x * node.scaleX, pos.y * node.scaleY, pos.z * node.scaleZ);
        var p1 = cc.v2(p.x, p.z);
        p1 = this.rotatePos(p1, node.eulerAngles.y);
        var p2 = cc.v2(p1.y, p.y);
        p2 = this.rotatePos(p2, node.eulerAngles.x);
        p.x = p1.x + node.x;
        p.y = p2.y + node.y;
        p.z = p2.x + node.z;
        return p;
    };
    /**
     * 将子节点坐标系下的坐标点转换到根节点坐标系
     * @param root 根节点
     * @param node 子节点
     * @param pos 要转换的坐标点
     */
    LevelCamera.prototype.convertToNodePos = function (root, node, pos) {
        var p = cc.v3();
        p.set(pos);
        while (!!node && node.is3DNode && node != root) {
            p = this.convertToParent(node, p);
            node = node.parent;
        }
        return p;
    };
    __decorate([
        property(cc.Camera)
    ], LevelCamera.prototype, "camera", void 0);
    __decorate([
        property(cc.Node)
    ], LevelCamera.prototype, "cameraNode", void 0);
    __decorate([
        property(cc.Node)
    ], LevelCamera.prototype, "anchorNode", void 0);
    LevelCamera = __decorate([
        ccclass
    ], LevelCamera);
    return LevelCamera;
}(yyComponent_1.default));
exports.default = LevelCamera;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxcXFNjcmlwdFxcTGV2ZWxDYW1lcmEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBQzFELHVFQUFxRjtBQUUvRSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUM1QyxnQkFBZ0I7QUFFaEI7SUFBeUMsK0JBQVc7SUFBcEQ7UUFBQSxxRUEwT0M7UUF4T0csVUFBVTtRQUVILFlBQU0sR0FBYyxJQUFJLENBQUM7UUFDaEMsY0FBYztRQUVKLGdCQUFVLEdBQVksSUFBSSxDQUFDO1FBQ3JDLGFBQWE7UUFFSCxnQkFBVSxHQUFZLElBQUksQ0FBQzs7SUFnT3pDLENBQUM7SUE3TmEsMkNBQXFCLEdBQS9CO1FBQ0ksSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFDRCxhQUFhO0lBQ04sNkNBQXVCLEdBQTlCLFVBQStCLFFBQW9CLEVBQUUsRUFBYTtRQUFuQyx5QkFBQSxFQUFBLFlBQW9CO1FBQy9DLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDWCxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3hELE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxZQUFZLENBQUM7WUFDZCxRQUFRLEVBQUUsUUFBUTtZQUNsQixHQUFHLEVBQUUsSUFBSSxDQUFDLFlBQVk7WUFDdEIsS0FBSyxFQUFFLElBQUksQ0FBQyxvQkFBb0I7WUFDaEMsRUFBRSxFQUFFLEVBQUU7U0FDVCxDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0QsVUFBVTtJQUNILGtDQUFZLEdBQW5CLFVBQW9CLElBQTBFO1FBQzFGLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2hCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHO2dCQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSztnQkFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQzNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUN6QixPQUFPO1NBQ1Y7UUFDRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWixJQUFJLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDMUQ7UUFDRCxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ2QsTUFBTSxHQUFHLHlCQUFlLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hFO1FBQ0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFO1lBQ3BCLEtBQUssR0FBRyx5QkFBZSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDL0M7YUFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUU7WUFDZixLQUFLLEdBQUcseUJBQWUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDdkM7YUFBTSxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUU7WUFDakIsS0FBSyxHQUFHLHlCQUFlLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3pDO1FBQ0QsSUFBSSxNQUFNLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsK0JBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN6RCxJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDdEIsSUFBSSxPQUFPLEdBQUcseUJBQWUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQy9DLElBQUksUUFBUSxHQUFHLHlCQUFlLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztZQUN4RCxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7U0FDL0M7YUFBTSxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUU7WUFDaEIsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQzVDO2FBQU0sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNsQixJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7U0FDYjtJQUNMLENBQUM7SUFLTSwwQkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzVCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztRQUNuQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDdEMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7SUFDakMsQ0FBQztJQUNELHFCQUFxQjtJQUNYLHVDQUFpQixHQUEzQjtRQUNJLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMvQixJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEQsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDbEMsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7UUFDMUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsQ0FBQztRQUM1QyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQSxZQUFZO1FBQzlCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDdEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFTSwyQkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7UUFDekIsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7SUFDbkMsQ0FBQztJQUNNLCtCQUFTLEdBQWhCLFVBQWlCLFlBQXFCO1FBQ2xDLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1FBQ2pDLHFCQUFxQjtRQUNyQixzQ0FBc0M7UUFDdEMsb0NBQW9DO1FBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFFUyxvQ0FBYyxHQUF4QixVQUF5QixFQUFVO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWTtZQUFFLE9BQU87UUFFL0IsUUFBUTtRQUNSLDhGQUE4RjtRQUM5RixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV6RSxxQkFBcUI7UUFDckIsc0NBQXNDO1FBQ3RDLGtDQUFrQztRQUVsQyxPQUFPO1FBQ1Asb0JBQW9CO1FBQ3BCLHFDQUFxQztRQUNyQyxvQkFBb0I7UUFDcEIsbUNBQW1DO1FBQ25DLGdDQUFnQztRQUNoQyw2Q0FBNkM7UUFDN0MsbURBQW1EO0lBQ3ZELENBQUM7SUFFRCxhQUFhO0lBQ04sNEJBQU0sR0FBYixVQUFjLFFBQWdCLEVBQUUsR0FBWSxFQUFFLEVBQWE7UUFDdkQsSUFBSSxNQUFNLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsK0JBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN6RCxJQUFJLE1BQU0sR0FBRyx5QkFBZSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyx5QkFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNOLElBQUksT0FBTyxHQUFHLHlCQUFlLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSx5QkFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztTQUMxRTthQUFNO1lBQ0gsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1NBQ3ZDO0lBQ0wsQ0FBQztJQUVELHNGQUFzRjtJQUN0RixlQUFlO0lBQ1IsMENBQW9CLEdBQTNCLFVBQTRCLEdBQVk7UUFDcEMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUN0QixDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3hCLE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUNELHVCQUF1QjtJQUNoQiwwQ0FBb0IsR0FBM0IsVUFBNEIsR0FBWTtRQUNwQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdkMsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7UUFDNUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNaLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNoQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNoQixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVCLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDekIsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUN6QixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFDRCxrQkFBa0I7SUFDUiwwQ0FBb0IsR0FBOUIsVUFBK0IsR0FBWTtRQUN2QyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDakMsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDOUMsSUFBSSxLQUFLLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUMxQixJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRCxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFL0IsS0FBSyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFDdEIsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUUvQixtRUFBbUU7UUFDbkUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELGFBQWE7SUFDSCxrQ0FBWSxHQUF0QjtRQUNJLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUNwQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN4RixDQUFDO0lBQ0Qsb0JBQW9CO0lBQ1YsMENBQW9CLEdBQTlCO1FBQ0ksT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUNEOzs7O09BSUc7SUFDTywrQkFBUyxHQUFuQixVQUFvQixDQUFVLEVBQUUsS0FBYTtRQUN6QyxJQUFJLE1BQU0sR0FBRyxLQUFLLEdBQUcsUUFBUSxDQUFDO1FBQzlCLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDM0IsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUM5QixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUM5QixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0kscUNBQWUsR0FBdEIsVUFBdUIsSUFBYSxFQUFFLEdBQVk7UUFDOUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzdFLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDekIsRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMxQixFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1QyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNwQixPQUFPLENBQUMsQ0FBQztJQUNiLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLHNDQUFnQixHQUF2QixVQUF3QixJQUFhLEVBQUUsSUFBYSxFQUFFLEdBQVk7UUFDOUQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQ2hCLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDWCxPQUFPLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO1lBQzVDLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNsQyxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztTQUN0QjtRQUNELE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQXBPRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOytDQUNZO0lBR2hDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7bURBQ21CO0lBR3JDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7bURBQ21CO0lBVnBCLFdBQVc7UUFEL0IsT0FBTztPQUNhLFdBQVcsQ0EwTy9CO0lBQUQsa0JBQUM7Q0ExT0QsQUEwT0MsQ0ExT3dDLHFCQUFXLEdBME9uRDtrQkExT29CLFdBQVciLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeXlDb21wb25lbnQgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24veXlDb21wb25lbnRcIjtcclxuaW1wb3J0IEFjdGlvbjNkTWFuYWdlciwgeyBBY3Rpb25NbmdUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vQWN0aW9uM2RNYW5hZ2VyXCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG4vKirlhbPljaHkuK3kvb/nlKjnmoQzROebuOacuiAqL1xyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMZXZlbENhbWVyYSBleHRlbmRzIHl5Q29tcG9uZW50IHtcclxuXHJcbiAgICAvKirnm7jmnLrnu4Tku7YgKi9cclxuICAgIEBwcm9wZXJ0eShjYy5DYW1lcmEpXHJcbiAgICBwdWJsaWMgY2FtZXJhOiBjYy5DYW1lcmEgPSBudWxsO1xyXG4gICAgLyoq55u45py657uE5Lu25omA5Zyo6IqC54K5ICovXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb3RlY3RlZCBjYW1lcmFOb2RlOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIC8qKuebuOacuuacneWQkeeahOiKgueCuSAqL1xyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgYW5jaG9yTm9kZTogY2MuTm9kZSA9IG51bGw7XHJcbiAgICBwcm90ZWN0ZWQgX29yaWdpbmFsUG9zOiBjYy5WZWMzO1xyXG4gICAgcHJvdGVjdGVkIF9vcmlnaW5hbEV1bGVyQW5nbGVzOiBjYy5WZWMzO1xyXG4gICAgcHJvdGVjdGVkIGluaXRPcmlnaW5hbFRyYW5zZm9ybSgpIHtcclxuICAgICAgICB0aGlzLl9vcmlnaW5hbFBvcyA9IGNjLnYzKCk7XHJcbiAgICAgICAgdGhpcy5jYW1lcmFOb2RlLmdldFBvc2l0aW9uKHRoaXMuX29yaWdpbmFsUG9zKTtcclxuICAgICAgICB0aGlzLl9vcmlnaW5hbEV1bGVyQW5nbGVzID0gY2MudjMoKTtcclxuICAgICAgICB0aGlzLl9vcmlnaW5hbEV1bGVyQW5nbGVzLnNldCh0aGlzLmNhbWVyYU5vZGUuZXVsZXJBbmdsZXMpO1xyXG4gICAgfVxyXG4gICAgLyoq5oGi5aSN5Yiw5Y6f5aeL6KeG6KeSICovXHJcbiAgICBwdWJsaWMgcmVzdW1lT3JpZ2luYWxUcmFuc2Zvcm0oZHVyYXRpb246IG51bWJlciA9IDAsIGNiPzogRnVuY3Rpb24pIHtcclxuICAgICAgICBpZiAoIWR1cmF0aW9uKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2FtZXJhTm9kZS5zZXRQb3NpdGlvbih0aGlzLl9vcmlnaW5hbFBvcyk7XHJcbiAgICAgICAgICAgIHRoaXMuY2FtZXJhTm9kZS5ldWxlckFuZ2xlcyA9IHRoaXMuX29yaWdpbmFsRXVsZXJBbmdsZXM7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jaGFuZ2VDYW1lcmEoe1xyXG4gICAgICAgICAgICBkdXJhdGlvbjogZHVyYXRpb24sXHJcbiAgICAgICAgICAgIHBvczogdGhpcy5fb3JpZ2luYWxQb3MsXHJcbiAgICAgICAgICAgIGFuZ2xlOiB0aGlzLl9vcmlnaW5hbEV1bGVyQW5nbGVzLFxyXG4gICAgICAgICAgICBjYjogY2JcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIC8qKuinhuinkuWIh+aNoiAqL1xyXG4gICAgcHVibGljIGNoYW5nZUNhbWVyYShkYXRhOiB7IGR1cmF0aW9uPzogbnVtYmVyLCBwb3M/OiBjYy5WZWMzLCBhbmdsZT86IGNjLlZlYzMsIGNiPzogRnVuY3Rpb24gfSkge1xyXG4gICAgICAgIGlmICghZGF0YS5kdXJhdGlvbikge1xyXG4gICAgICAgICAgICBpZiAoISFkYXRhLnBvcykgdGhpcy5jYW1lcmFOb2RlLnNldFBvc2l0aW9uKGRhdGEucG9zKTtcclxuICAgICAgICAgICAgaWYgKCEhZGF0YS5hbmdsZSkgdGhpcy5jYW1lcmFOb2RlLmV1bGVyQW5nbGVzID0gZGF0YS5hbmdsZTtcclxuICAgICAgICAgICAgaWYgKCEhZGF0YS5jYikgZGF0YS5jYigpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBtb3ZlID0gbnVsbDtcclxuICAgICAgICBsZXQgcm90YXRlID0gbnVsbDtcclxuICAgICAgICBpZiAoISFkYXRhLnBvcykge1xyXG4gICAgICAgICAgICBtb3ZlID0gQWN0aW9uM2RNYW5hZ2VyLm1vdmVUbyhkYXRhLmR1cmF0aW9uLCBkYXRhLnBvcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghIWRhdGEuYW5nbGUpIHtcclxuICAgICAgICAgICAgcm90YXRlID0gQWN0aW9uM2RNYW5hZ2VyLnJvdGF0ZVRvKGRhdGEuZHVyYXRpb24sIGRhdGEuYW5nbGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgc3Bhd24gPSBudWxsO1xyXG4gICAgICAgIGlmICghIW1vdmUgJiYgISFyb3RhdGUpIHtcclxuICAgICAgICAgICAgc3Bhd24gPSBBY3Rpb24zZE1hbmFnZXIuc3Bhd24obW92ZSwgcm90YXRlKTtcclxuICAgICAgICB9IGVsc2UgaWYgKCEhbW92ZSkge1xyXG4gICAgICAgICAgICBzcGF3biA9IEFjdGlvbjNkTWFuYWdlci5zcGF3bihtb3ZlKTtcclxuICAgICAgICB9IGVsc2UgaWYgKCEhcm90YXRlKSB7XHJcbiAgICAgICAgICAgIHNwYXduID0gQWN0aW9uM2RNYW5hZ2VyLnNwYXduKHJvdGF0ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBhY3RNbmcgPSBBY3Rpb24zZE1hbmFnZXIuZ2V0TW5nKEFjdGlvbk1uZ1R5cGUuTGV2ZWwpO1xyXG4gICAgICAgIGlmICghIXNwYXduICYmICEhZGF0YS5jYikge1xyXG4gICAgICAgICAgICBsZXQgY2FsbEZ1biA9IEFjdGlvbjNkTWFuYWdlci5jYWxsRnVuKGRhdGEuY2IpO1xyXG4gICAgICAgICAgICBsZXQgc2VxdWVuY2UgPSBBY3Rpb24zZE1hbmFnZXIuc2VxdWVuY2Uoc3Bhd24sIGNhbGxGdW4pO1xyXG4gICAgICAgICAgICBhY3RNbmcucnVuQWN0aW9uKHRoaXMuY2FtZXJhTm9kZSwgc2VxdWVuY2UpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoISFzcGF3bikge1xyXG4gICAgICAgICAgICBhY3RNbmcucnVuQWN0aW9uKHRoaXMuY2FtZXJhTm9kZSwgc3Bhd24pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoISFkYXRhLmNiKSB7XHJcbiAgICAgICAgICAgIGRhdGEuY2IoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoq6Lef6ZqP55qE55uu5qCH6IqC54K5ICovXHJcbiAgICBwcm90ZWN0ZWQgZm9sbG93VGFyZ2V0OiBjYy5Ob2RlO1xyXG5cclxuICAgIHB1YmxpYyBpbml0KCkge1xyXG4gICAgICAgIHRoaXMuYW5jaG9yTm9kZSA9IHRoaXMubm9kZTtcclxuICAgICAgICB0aGlzLmNhbWVyYSA9IHRoaXMubm9kZS5nZXRDb21wb25lbnRJbkNoaWxkcmVuKGNjLkNhbWVyYSk7XHJcbiAgICAgICAgdGhpcy5jYW1lcmFOb2RlID0gdGhpcy5jYW1lcmEubm9kZTtcclxuICAgICAgICB0aGlzLmN1c3RvbVN0ZXAgPSB0aGlzLnN0ZXBTbG93Rm9sbG93O1xyXG4gICAgICAgIHRoaXMuYWRhcHRWaWV3Rm9yV2lkdGgoKTtcclxuICAgICAgICB0aGlzLmluaXRPcmlnaW5hbFRyYW5zZm9ybSgpO1xyXG4gICAgfVxyXG4gICAgLy/mjInlrr3luqbpgILphY3vvIzkv53mjIHmsLTlubPmlrnlkJHnmoTop4bph47ojIPlm7TkuI3lj5hcclxuICAgIHByb3RlY3RlZCBhZGFwdFZpZXdGb3JXaWR0aCgpIHtcclxuICAgICAgICBsZXQgcCA9IGNjLnYzKCk7XHJcbiAgICAgICAgdGhpcy5jYW1lcmFOb2RlLmdldFBvc2l0aW9uKHApO1xyXG4gICAgICAgIGxldCBMMSA9IE1hdGguc3FydChwLnggKiBwLnggKyBwLnkgKiBwLnkgKyBwLnogKiBwLnopO1xyXG4gICAgICAgIGxldCBIMiA9IGNjLmZpbmQoXCJDYW52YXNcIikuaGVpZ2h0O1xyXG4gICAgICAgIGxldCBmb3YgPSB0aGlzLmNhbWVyYS5mb3Y7XHJcbiAgICAgICAgbGV0IGggPSBMMSAqIE1hdGgudGFuKGZvdiAqIDAuNSAqIDAuMDE3NDUzKTtcclxuICAgICAgICBoID0gaCAqIEgyIC8gMTMzNDsvLzEzMzTvvJrorr7orqHliIbovqjnjodcclxuICAgICAgICBsZXQgZjIgPSBNYXRoLmF0YW4yKGgsIEwxKSAqIDIgKiA1Ny4zO1xyXG4gICAgICAgIHRoaXMuY2FtZXJhLmZvdiA9IGYyO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZXNldCgpIHtcclxuICAgICAgICB0aGlzLmZvbGxvd1RhcmdldCA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5yZXN1bWVPcmlnaW5hbFRyYW5zZm9ybSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHNldFRhcmdldChmb2xsb3dUYXJnZXQ6IGNjLk5vZGUpIHtcclxuICAgICAgICB0aGlzLmZvbGxvd1RhcmdldCA9IGZvbGxvd1RhcmdldDtcclxuICAgICAgICAvLyBsZXQgcG9zID0gY2MudjMoKTtcclxuICAgICAgICAvLyB0aGlzLmZvbGxvd1RhcmdldC5nZXRQb3NpdGlvbihwb3MpO1xyXG4gICAgICAgIC8vIHRoaXMuYW5jaG9yTm9kZS5zZXRQb3NpdGlvbihwb3MpO1xyXG4gICAgICAgIHRoaXMuYW5jaG9yTm9kZS5zZXRQb3NpdGlvbih0aGlzLmZvbGxvd1RhcmdldC54LCAwLCB0aGlzLmZvbGxvd1RhcmdldC56KTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgc3RlcFNsb3dGb2xsb3coZHQ6IG51bWJlcikge1xyXG4gICAgICAgIGlmICghdGhpcy5mb2xsb3dUYXJnZXQpIHJldHVybjtcclxuXHJcbiAgICAgICAgLy/ml6DnvJPliqjot5/pmo/vvJpcclxuICAgICAgICAvLyB0aGlzLmFuY2hvck5vZGUuc2V0UG9zaXRpb24odGhpcy5mb2xsb3dUYXJnZXQueCwgdGhpcy5mb2xsb3dUYXJnZXQueSwgdGhpcy5mb2xsb3dUYXJnZXQueik7XHJcbiAgICAgICAgdGhpcy5hbmNob3JOb2RlLnNldFBvc2l0aW9uKHRoaXMuZm9sbG93VGFyZ2V0LngsIDAsIHRoaXMuZm9sbG93VGFyZ2V0LnopO1xyXG5cclxuICAgICAgICAvLyBsZXQgcG9zID0gY2MudjMoKTtcclxuICAgICAgICAvLyB0aGlzLmZvbGxvd1RhcmdldC5nZXRQb3NpdGlvbihwb3MpO1xyXG4gICAgICAgIC8vIHRoaXMuY29udmVydFdvcmxkVG9TY3JlZW4ocG9zKTtcclxuXHJcbiAgICAgICAgLy/nvJPliqjot5/pmo/vvJpcclxuICAgICAgICAvLyBsZXQgcDEgPSBjYy52MygpO1xyXG4gICAgICAgIC8vIHRoaXMuZm9sbG93VGFyZ2V0LmdldFBvc2l0aW9uKHAxKTtcclxuICAgICAgICAvLyBsZXQgcDIgPSBjYy52MygpO1xyXG4gICAgICAgIC8vIHRoaXMuYW5jaG9yTm9kZS5nZXRQb3NpdGlvbihwMik7XHJcbiAgICAgICAgLy8gbGV0IG9mZnNldCA9IHAxLnN1YnRyYWN0KHAyKTtcclxuICAgICAgICAvLyAvLyBvZmZzZXQubXVsdGlwbHlTY2FsYXIoZHQpOy8vdG9kbzrmmK/lkKbnvJPliqjot5/pmo9cclxuICAgICAgICAvLyB0aGlzLmFuY2hvck5vZGUuc2V0UG9zaXRpb24ocDIuYWRkU2VsZihvZmZzZXQpKTtcclxuICAgIH1cclxuXHJcbiAgICAvKirnp7vliqjliLDmjIflrprkvY3nva4gKi9cclxuICAgIHB1YmxpYyBtb3ZlVG8oZHVyYXRpb246IG51bWJlciwgcG9zOiBjYy5WZWMzLCBjYj86IEZ1bmN0aW9uKSB7XHJcbiAgICAgICAgbGV0IGFjdE1uZyA9IEFjdGlvbjNkTWFuYWdlci5nZXRNbmcoQWN0aW9uTW5nVHlwZS5MZXZlbCk7XHJcbiAgICAgICAgbGV0IGFjdGlvbiA9IEFjdGlvbjNkTWFuYWdlci5tb3ZlVG8oZHVyYXRpb24sIHBvcyk7XHJcbiAgICAgICAgYWN0aW9uLmVhc2luZyhBY3Rpb24zZE1hbmFnZXIuZWFzZU91dCgzKSk7XHJcbiAgICAgICAgaWYgKCEhY2IpIHtcclxuICAgICAgICAgICAgbGV0IGNhbGxGdW4gPSBBY3Rpb24zZE1hbmFnZXIuY2FsbEZ1bihjYik7XHJcbiAgICAgICAgICAgIGFjdE1uZy5ydW5BY3Rpb24odGhpcy5ub2RlLCBBY3Rpb24zZE1hbmFnZXIuc2VxdWVuY2UoYWN0aW9uLCBjYWxsRnVuKSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYWN0TW5nLnJ1bkFjdGlvbih0aGlzLm5vZGUsIGFjdGlvbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5Z2Q5qCH6L2s5o2iKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8qKuS4lueVjOWdkOagh+i9rOWxj+W5leWdkOaghyAqL1xyXG4gICAgcHVibGljIGNvbnZlcnRXb3JsZFRvU2NyZWVuKHBvczogY2MuVmVjMykge1xyXG4gICAgICAgIGxldCBwID0gdGhpcy5jb252ZXJ0V29ybGRUb0NhbnZhcyhwb3MpO1xyXG4gICAgICAgIGxldCBjdnMgPSBjYy5maW5kKFwiQ2FudmFzXCIpO1xyXG4gICAgICAgIHAueCArIGN2cy53aWR0aCAqIDAuNTtcclxuICAgICAgICBwLnkgKz0gY3ZzLmhlaWdodCAqIDAuNTtcclxuICAgICAgICByZXR1cm4gcDtcclxuICAgIH1cclxuICAgIC8qKuS4lueVjOWdkOagh+i9rOaNouWIsENhbnZhc+iKgueCueWdkOaghyAqL1xyXG4gICAgcHVibGljIGNvbnZlcnRXb3JsZFRvQ2FudmFzKHBvczogY2MuVmVjMykge1xyXG4gICAgICAgIGxldCBwID0gdGhpcy5jb252ZXJ0V29ybGRUb0NhbWVyYShwb3MpO1xyXG4gICAgICAgIGxldCBhbmdsZSA9IHRoaXMuY2FtZXJhLmZvdjtcclxuICAgICAgICBsZXQgeiA9IHAuejtcclxuICAgICAgICBsZXQgdGFuID0gTWF0aC50YW4oYW5nbGUgKiAwLjUgKiAwLjAxNzQ1Myk7XHJcbiAgICAgICAgbGV0IGggPSBNYXRoLmFicyh6ICogdGFuKTtcclxuICAgICAgICBsZXQgeCA9IHAueCAvIGg7XHJcbiAgICAgICAgbGV0IHkgPSBwLnkgLyBoO1xyXG4gICAgICAgIGxldCBjdnMgPSBjYy5maW5kKFwiQ2FudmFzXCIpO1xyXG4gICAgICAgIHkgPSBjdnMuaGVpZ2h0ICogMC41ICogeTtcclxuICAgICAgICB4ID0gY3ZzLmhlaWdodCAqIDAuNSAqIHg7XHJcbiAgICAgICAgcmV0dXJuIGNjLnYyKHgsIHkpO1xyXG4gICAgfVxyXG4gICAgLyoq5LiW55WM5Z2Q5qCH6L2s5o2i5Yiw55u45py65Z2Q5qCH57O7ICovXHJcbiAgICBwcm90ZWN0ZWQgY29udmVydFdvcmxkVG9DYW1lcmEocG9zOiBjYy5WZWMzKSB7XHJcbiAgICAgICAgbGV0IGNlbnRlciA9IHRoaXMuZ2V0Q2FtZXJhUG9zKCk7XHJcbiAgICAgICAgbGV0IGV1bGVyQW5nbGVyID0gdGhpcy5nZXRDYW1lcmFFdWxlckFuZ2xlcygpO1xyXG4gICAgICAgIGxldCBhbmdsZSA9IGV1bGVyQW5nbGVyLnk7XHJcbiAgICAgICAgbGV0IHAxID0gY2MudjIocG9zLnggLSBjZW50ZXIueCwgcG9zLnogLSBjZW50ZXIueik7XHJcbiAgICAgICAgcDEgPSB0aGlzLnJvdGF0ZVBvcyhwMSwgYW5nbGUpO1xyXG5cclxuICAgICAgICBhbmdsZSA9IGV1bGVyQW5nbGVyLng7XHJcbiAgICAgICAgbGV0IHAyID0gY2MudjIocDEueSwgcG9zLnkgLSBjZW50ZXIueSk7XHJcbiAgICAgICAgcDIgPSB0aGlzLnJvdGF0ZVBvcyhwMiwgYW5nbGUpO1xyXG5cclxuICAgICAgICAvLyByZXR1cm4gY2MudjMocDEueCArIGNlbnRlci54LCBwMi54ICsgY2VudGVyLnksIHAyLnkgKyBjZW50ZXIueik7XHJcbiAgICAgICAgcmV0dXJuIGNjLnYzKHAxLngsIHAyLnksIHAyLngpO1xyXG4gICAgfVxyXG4gICAgLyoq55u45py655qE5LiW55WM5Z2Q5qCHICovXHJcbiAgICBwcm90ZWN0ZWQgZ2V0Q2FtZXJhUG9zKCkge1xyXG4gICAgICAgIGxldCBhbmdsZSA9IHRoaXMubm9kZS5ldWxlckFuZ2xlcy55O1xyXG4gICAgICAgIGxldCBwID0gdGhpcy5yb3RhdGVQb3MoY2MudjIodGhpcy5jYW1lcmFOb2RlLngsIHRoaXMuY2FtZXJhTm9kZS56KSwgLWFuZ2xlKTtcclxuICAgICAgICByZXR1cm4gY2MudjMocC54ICsgdGhpcy5ub2RlLngsIHRoaXMuY2FtZXJhTm9kZS55ICsgdGhpcy5ub2RlLnksIHAueSArIHRoaXMubm9kZS56KTtcclxuICAgIH1cclxuICAgIC8qKuebuOacuuWcqOS4lueVjOWdkOagh+ezu+S4i+eahOaXi+i9rOinkuW6piAqL1xyXG4gICAgcHJvdGVjdGVkIGdldENhbWVyYUV1bGVyQW5nbGVzKCkge1xyXG4gICAgICAgIHJldHVybiBjYy52Myh0aGlzLmNhbWVyYU5vZGUuZXVsZXJBbmdsZXMueCwgdGhpcy5ub2RlLmV1bGVyQW5nbGVzLnksIDApO1xyXG4gICAgfVxyXG4gICAgLyoqXHJcbiAgICAgKiDml4vovazlnZDmoIfngrlcclxuICAgICAqIEBwYXJhbSBwIOWdkOagh+eCuVxyXG4gICAgICogQHBhcmFtIGFuZ2xlIOaXi+i9rOinkuW6pu+8jOi0n+aVsOihqOekuumhuuaXtumSiOaXi+i9rO+8jOato+aVsOihqOekuumAhuaXtumSiOaXi+i9rFxyXG4gICAgICovXHJcbiAgICBwcm90ZWN0ZWQgcm90YXRlUG9zKHA6IGNjLlZlYzIsIGFuZ2xlOiBudW1iZXIpIHtcclxuICAgICAgICBsZXQgcmFkaWFuID0gYW5nbGUgKiAwLjAxNzQ1MztcclxuICAgICAgICBsZXQgc2luID0gTWF0aC5zaW4ocmFkaWFuKTtcclxuICAgICAgICBsZXQgY29zID0gTWF0aC5jb3MocmFkaWFuKTtcclxuICAgICAgICBsZXQgeCA9IHAueCAqIGNvcyAtIHAueSAqIHNpbjtcclxuICAgICAgICBsZXQgeSA9IHAueCAqIHNpbiArIHAueSAqIGNvcztcclxuICAgICAgICByZXR1cm4gY2MudjIoeCwgeSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDlsIboioLngrnlnZDmoIfns7vkuIvnmoTlnZDmoIfngrnovazmjaLkuLrlhbbniLboioLngrnlnZDmoIfns7vkuIvnmoTlnZDmoIdcclxuICAgICAqIEBwYXJhbSBub2RlIOiKgueCuVxyXG4gICAgICogQHBhcmFtIHBvcyDlnZDmoIfngrlcclxuICAgICAqL1xyXG4gICAgcHVibGljIGNvbnZlcnRUb1BhcmVudChub2RlOiBjYy5Ob2RlLCBwb3M6IGNjLlZlYzMpIHtcclxuICAgICAgICBsZXQgcCA9IGNjLnYzKHBvcy54ICogbm9kZS5zY2FsZVgsIHBvcy55ICogbm9kZS5zY2FsZVksIHBvcy56ICogbm9kZS5zY2FsZVopO1xyXG4gICAgICAgIGxldCBwMSA9IGNjLnYyKHAueCwgcC56KTtcclxuICAgICAgICBwMSA9IHRoaXMucm90YXRlUG9zKHAxLCBub2RlLmV1bGVyQW5nbGVzLnkpO1xyXG4gICAgICAgIGxldCBwMiA9IGNjLnYyKHAxLnksIHAueSk7XHJcbiAgICAgICAgcDIgPSB0aGlzLnJvdGF0ZVBvcyhwMiwgbm9kZS5ldWxlckFuZ2xlcy54KTtcclxuICAgICAgICBwLnggPSBwMS54ICsgbm9kZS54O1xyXG4gICAgICAgIHAueSA9IHAyLnkgKyBub2RlLnk7XHJcbiAgICAgICAgcC56ID0gcDIueCArIG5vZGUuejtcclxuICAgICAgICByZXR1cm4gcDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOWwhuWtkOiKgueCueWdkOagh+ezu+S4i+eahOWdkOagh+eCuei9rOaNouWIsOagueiKgueCueWdkOagh+ezu1xyXG4gICAgICogQHBhcmFtIHJvb3Qg5qC56IqC54K5XHJcbiAgICAgKiBAcGFyYW0gbm9kZSDlrZDoioLngrlcclxuICAgICAqIEBwYXJhbSBwb3Mg6KaB6L2s5o2i55qE5Z2Q5qCH54K5XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjb252ZXJ0VG9Ob2RlUG9zKHJvb3Q6IGNjLk5vZGUsIG5vZGU6IGNjLk5vZGUsIHBvczogY2MuVmVjMykge1xyXG4gICAgICAgIGxldCBwID0gY2MudjMoKTtcclxuICAgICAgICBwLnNldChwb3MpO1xyXG4gICAgICAgIHdoaWxlICghIW5vZGUgJiYgbm9kZS5pczNETm9kZSAmJiBub2RlICE9IHJvb3QpIHtcclxuICAgICAgICAgICAgcCA9IHRoaXMuY29udmVydFRvUGFyZW50KG5vZGUsIHApO1xyXG4gICAgICAgICAgICBub2RlID0gbm9kZS5wYXJlbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=