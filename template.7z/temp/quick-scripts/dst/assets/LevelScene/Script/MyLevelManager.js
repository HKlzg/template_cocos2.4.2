
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LevelScene/Script/MyLevelManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '96965tMQ3pGBpQf/2vNsU/8', 'MyLevelManager');
// LevelScene/Script/MyLevelManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var LevelManager_1 = require("./LevelManager");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var LevelCamera_1 = require("./LevelCamera");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MyLevelManager = /** @class */ (function (_super) {
    __extends(MyLevelManager, _super);
    function MyLevelManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //#endregion
        //#region 相机
        _this.camera = null;
        return _this;
    }
    /**************************************************通用流程**************************************************/
    //#region 初始化
    MyLevelManager.prototype.init = function () {
        this.initCamera();
        this.initCustomUpdateState();
        this.initLevelTimer();
        this.initActMng();
        this.initEnterLobbyState();
        this.loadLobbyItems();
        this.registAllCustomUpdate();
        this.onEvents();
    };
    MyLevelManager.prototype.registAllCustomUpdate = function () {
        //通用状态
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.playing, this.stepLevelPlaying);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.win, this.stepLevelWin);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.lose, this.stepLevelLose);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.lobby, this.stepLobby);
        //其他状态
    };
    MyLevelManager.prototype.onEvents = function () {
        //游戏总流程相关
        this.on(GameEventType_1.EventType.DirectorEvent.pauseLevel, this.pause, this);
        this.on(GameEventType_1.EventType.DirectorEvent.resumeLevel, this.resume, this);
        //游戏玩法相关
        this.on(GameEventType_1.EventType.LevelEvent.testLose, this.onTestLose, this);
        this.on(GameEventType_1.EventType.LevelEvent.testWin, this.onTestWin, this);
    };
    /**加载进入首页时必须显示的内容 */
    MyLevelManager.prototype.loadLobbyItems = function () {
    };
    //#endregion
    //#region 重置
    MyLevelManager.prototype.reset = function () {
        this.resetCamera();
        this.resetCustomUpdateState();
        this.resetLevelTimer();
    };
    //#endregion
    /**************************************************对外功能**************************************************/
    //#region 进入关卡
    //进入关卡，设置关卡数据，启动关卡控制器，开始游戏
    MyLevelManager.prototype.enterLevel = function (levelData) {
        this.node.active = true;
        if (this.needLoadCount <= 0) {
            this.reset();
            this.levelData = levelData;
            this._enterLevel();
        }
        else {
            this.levelData = levelData;
            this.nextState = GlobalEnum_1.GlobalEnum.LevelState.playing;
        }
    };
    MyLevelManager.prototype._enterLevel = function () {
        this.setData();
        this.startLevel();
    };
    MyLevelManager.prototype.setData = function () {
        //关卡内容
        //玩家
        //相机
    };
    //#endregion
    //#region 教学脚本
    MyLevelManager.prototype.setTeachCmp = function (js) {
    };
    //#endregion
    //#region 进入首页
    /**设置在首页中作为背景时需要显示的内容 */
    MyLevelManager.prototype.setEnterLobbyData = function () {
    };
    //#endregion
    /**************************************************管理对象**************************************************/
    //#region  玩家
    // protected player:Player = null;
    MyLevelManager.prototype.initPlayer = function () {
    };
    MyLevelManager.prototype.resetPlayer = function () {
    };
    MyLevelManager.prototype.setPlayer = function () {
    };
    MyLevelManager.prototype.updatePlayer = function (dt) {
    };
    MyLevelManager.prototype.initCamera = function () {
        this.camera.init();
    };
    MyLevelManager.prototype.resetCamera = function () {
        this.camera.reset();
    };
    MyLevelManager.prototype.updateCamera = function (dt) {
        this.camera.customUpdate(dt);
    };
    //#endregion
    /**************************************************流程**************************************************/
    //#region 游戏中
    MyLevelManager.prototype.stepLevelPlaying = function (dt) {
        this.updateCamera(dt);
        this.updatePlayer(dt);
    };
    //#endregion
    //#region 胜利
    MyLevelManager.prototype.stepLevelWin = function (dt) {
    };
    /**关卡胜利的成绩 */
    MyLevelManager.prototype.getWinData = function () {
        var data = {};
        data.lv = this.levelData.lv;
        return data;
    };
    //#endregion
    //#region 失败
    MyLevelManager.prototype.stepLevelLose = function (dt) {
    };
    //#endregion
    //#region 状态：首页中
    MyLevelManager.prototype.stepLobby = function (dt) {
        // this.updateCamera(dt);
    };
    //#endregion
    /**************************************************事件**************************************************/
    MyLevelManager.prototype.onTestWin = function () {
        this.win();
    };
    MyLevelManager.prototype.onTestLose = function () {
        this.lose();
    };
    __decorate([
        property(LevelCamera_1.default)
    ], MyLevelManager.prototype, "camera", void 0);
    MyLevelManager = __decorate([
        ccclass
    ], MyLevelManager);
    return MyLevelManager;
}(LevelManager_1.default));
exports.default = MyLevelManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTGV2ZWxTY2VuZVxcU2NyaXB0XFxNeUxldmVsTWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrQ0FBMEM7QUFDMUMsa0VBQWlFO0FBQ2pFLHdFQUFtRTtBQUduRSw2Q0FBd0M7QUFFbEMsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBNEMsa0NBQVk7SUFBeEQ7UUFBQSxxRUFrS0M7UUF4REcsWUFBWTtRQUVaLFlBQVk7UUFFRixZQUFNLEdBQWdCLElBQUksQ0FBQzs7SUFvRHpDLENBQUM7SUFoS0csMEdBQTBHO0lBQzFHLGFBQWE7SUFDTiw2QkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDM0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRXRCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUVwQixDQUFDO0lBQ1MsOENBQXFCLEdBQS9CO1FBQ0ksTUFBTTtRQUNOLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBVSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDOUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLHVCQUFVLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDdEUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLHVCQUFVLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDeEUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLHVCQUFVLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFckUsTUFBTTtJQUVWLENBQUM7SUFDUyxpQ0FBUSxHQUFsQjtRQUNJLFNBQVM7UUFDVCxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsYUFBYSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzlELElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFaEUsUUFBUTtRQUVSLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUVoRSxDQUFDO0lBQ0Qsb0JBQW9CO0lBQ1YsdUNBQWMsR0FBeEI7SUFFQSxDQUFDO0lBQ0QsWUFBWTtJQUVaLFlBQVk7SUFDTCw4QkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBQ0QsWUFBWTtJQUVaLDBHQUEwRztJQUMxRyxjQUFjO0lBQ2QsMEJBQTBCO0lBQ25CLG1DQUFVLEdBQWpCLFVBQWtCLFNBQVM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxDQUFDLEVBQUU7WUFDekIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2IsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7WUFDM0IsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO2FBQU07WUFDSCxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLHVCQUFVLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFDUyxvQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRVMsZ0NBQU8sR0FBakI7UUFDSSxNQUFNO1FBRU4sSUFBSTtRQUVKLElBQUk7SUFFUixDQUFDO0lBQ0QsWUFBWTtJQUVaLGNBQWM7SUFDUCxvQ0FBVyxHQUFsQixVQUFtQixFQUFFO0lBQ3JCLENBQUM7SUFDRCxZQUFZO0lBRVosY0FBYztJQUNkLHdCQUF3QjtJQUNkLDBDQUFpQixHQUEzQjtJQUNBLENBQUM7SUFDRCxZQUFZO0lBRVosMEdBQTBHO0lBQzFHLGFBQWE7SUFDYixrQ0FBa0M7SUFDeEIsbUNBQVUsR0FBcEI7SUFFQSxDQUFDO0lBQ1Msb0NBQVcsR0FBckI7SUFFQSxDQUFDO0lBQ1Msa0NBQVMsR0FBbkI7SUFFQSxDQUFDO0lBQ1MscUNBQVksR0FBdEIsVUFBdUIsRUFBVTtJQUVqQyxDQUFDO0lBTVMsbUNBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFDUyxvQ0FBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUNTLHFDQUFZLEdBQXRCLFVBQXVCLEVBQVU7UUFDN0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUNELFlBQVk7SUFFWix3R0FBd0c7SUFDeEcsYUFBYTtJQUNILHlDQUFnQixHQUExQixVQUEyQixFQUFVO1FBQ2pDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUUxQixDQUFDO0lBQ0QsWUFBWTtJQUVaLFlBQVk7SUFDRixxQ0FBWSxHQUF0QixVQUF1QixFQUFVO0lBQ2pDLENBQUM7SUFDRCxhQUFhO0lBQ0gsbUNBQVUsR0FBcEI7UUFDSSxJQUFJLElBQUksR0FBUSxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztRQUU1QixPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBQ0QsWUFBWTtJQUVaLFlBQVk7SUFDRixzQ0FBYSxHQUF2QixVQUF3QixFQUFVO0lBQ2xDLENBQUM7SUFDRCxZQUFZO0lBRVosZ0JBQWdCO0lBQ04sa0NBQVMsR0FBbkIsVUFBb0IsRUFBVTtRQUMxQix5QkFBeUI7SUFDN0IsQ0FBQztJQUNELFlBQVk7SUFFWix3R0FBd0c7SUFDOUYsa0NBQVMsR0FBbkI7UUFDSSxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDZixDQUFDO0lBQ1MsbUNBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDaEIsQ0FBQztJQWxERDtRQURDLFFBQVEsQ0FBQyxxQkFBVyxDQUFDO2tEQUNlO0lBOUdwQixjQUFjO1FBRGxDLE9BQU87T0FDYSxjQUFjLENBa0tsQztJQUFELHFCQUFDO0NBbEtELEFBa0tDLENBbEsyQyxzQkFBWSxHQWtLdkQ7a0JBbEtvQixjQUFjIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExldmVsTWFuYWdlciBmcm9tIFwiLi9MZXZlbE1hbmFnZXJcIjtcclxuaW1wb3J0IHsgR2xvYmFsRW51bSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2xvYmFsRW51bVwiO1xyXG5pbXBvcnQgeyBFdmVudFR5cGUgfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcclxuaW1wb3J0IExvYWRlciBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9Mb2FkZXJcIjtcclxuaW1wb3J0IEdsb2JhbFBvb2wgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vR2xvYmFsUG9vbFwiO1xyXG5pbXBvcnQgTGV2ZWxDYW1lcmEgZnJvbSBcIi4vTGV2ZWxDYW1lcmFcIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNeUxldmVsTWFuYWdlciBleHRlbmRzIExldmVsTWFuYWdlciB7XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq6YCa55So5rWB56iLKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLyNyZWdpb24g5Yid5aeL5YyWXHJcbiAgICBwdWJsaWMgaW5pdCgpIHtcclxuICAgICAgICB0aGlzLmluaXRDYW1lcmEoKTtcclxuICAgICAgICB0aGlzLmluaXRDdXN0b21VcGRhdGVTdGF0ZSgpO1xyXG4gICAgICAgIHRoaXMuaW5pdExldmVsVGltZXIoKTtcclxuICAgICAgICB0aGlzLmluaXRBY3RNbmcoKTtcclxuICAgICAgICB0aGlzLmluaXRFbnRlckxvYmJ5U3RhdGUoKTtcclxuICAgICAgICB0aGlzLmxvYWRMb2JieUl0ZW1zKCk7XHJcblxyXG4gICAgICAgIHRoaXMucmVnaXN0QWxsQ3VzdG9tVXBkYXRlKCk7XHJcbiAgICAgICAgdGhpcy5vbkV2ZW50cygpO1xyXG5cclxuICAgIH1cclxuICAgIHByb3RlY3RlZCByZWdpc3RBbGxDdXN0b21VcGRhdGUoKSB7XHJcbiAgICAgICAgLy/pgJrnlKjnirbmgIFcclxuICAgICAgICB0aGlzLnJlZ2lzdEN1c3RvbVVwZGF0ZShHbG9iYWxFbnVtLkxldmVsU3RhdGUucGxheWluZywgdGhpcy5zdGVwTGV2ZWxQbGF5aW5nKTtcclxuICAgICAgICB0aGlzLnJlZ2lzdEN1c3RvbVVwZGF0ZShHbG9iYWxFbnVtLkxldmVsU3RhdGUud2luLCB0aGlzLnN0ZXBMZXZlbFdpbik7XHJcbiAgICAgICAgdGhpcy5yZWdpc3RDdXN0b21VcGRhdGUoR2xvYmFsRW51bS5MZXZlbFN0YXRlLmxvc2UsIHRoaXMuc3RlcExldmVsTG9zZSk7XHJcbiAgICAgICAgdGhpcy5yZWdpc3RDdXN0b21VcGRhdGUoR2xvYmFsRW51bS5MZXZlbFN0YXRlLmxvYmJ5LCB0aGlzLnN0ZXBMb2JieSk7XHJcblxyXG4gICAgICAgIC8v5YW25LuW54q25oCBXHJcblxyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uRXZlbnRzKCkge1xyXG4gICAgICAgIC8v5ri45oiP5oC75rWB56iL55u45YWzXHJcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5wYXVzZUxldmVsLCB0aGlzLnBhdXNlLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LnJlc3VtZUxldmVsLCB0aGlzLnJlc3VtZSwgdGhpcyk7XHJcblxyXG4gICAgICAgIC8v5ri45oiP546p5rOV55u45YWzXHJcblxyXG4gICAgICAgIHRoaXMub24oRXZlbnRUeXBlLkxldmVsRXZlbnQudGVzdExvc2UsIHRoaXMub25UZXN0TG9zZSwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuTGV2ZWxFdmVudC50ZXN0V2luLCB0aGlzLm9uVGVzdFdpbiwgdGhpcyk7XHJcblxyXG4gICAgfVxyXG4gICAgLyoq5Yqg6L296L+b5YWl6aaW6aG15pe25b+F6aG75pi+56S655qE5YaF5a65ICovXHJcbiAgICBwcm90ZWN0ZWQgbG9hZExvYmJ5SXRlbXMoKSB7XHJcblxyXG4gICAgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLy8jcmVnaW9uIOmHjee9rlxyXG4gICAgcHVibGljIHJlc2V0KCkge1xyXG4gICAgICAgIHRoaXMucmVzZXRDYW1lcmEoKTtcclxuICAgICAgICB0aGlzLnJlc2V0Q3VzdG9tVXBkYXRlU3RhdGUoKTtcclxuICAgICAgICB0aGlzLnJlc2V0TGV2ZWxUaW1lcigpO1xyXG4gICAgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5a+55aSW5Yqf6IO9KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLyNyZWdpb24g6L+b5YWl5YWz5Y2hXHJcbiAgICAvL+i/m+WFpeWFs+WNoe+8jOiuvue9ruWFs+WNoeaVsOaNru+8jOWQr+WKqOWFs+WNoeaOp+WItuWZqO+8jOW8gOWni+a4uOaIj1xyXG4gICAgcHVibGljIGVudGVyTGV2ZWwobGV2ZWxEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgaWYgKHRoaXMubmVlZExvYWRDb3VudCA8PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICAgICAgdGhpcy5sZXZlbERhdGEgPSBsZXZlbERhdGE7XHJcbiAgICAgICAgICAgIHRoaXMuX2VudGVyTGV2ZWwoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxldmVsRGF0YSA9IGxldmVsRGF0YTtcclxuICAgICAgICAgICAgdGhpcy5uZXh0U3RhdGUgPSBHbG9iYWxFbnVtLkxldmVsU3RhdGUucGxheWluZztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgX2VudGVyTGV2ZWwoKSB7XHJcbiAgICAgICAgdGhpcy5zZXREYXRhKCk7XHJcbiAgICAgICAgdGhpcy5zdGFydExldmVsKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHNldERhdGEoKSB7XHJcbiAgICAgICAgLy/lhbPljaHlhoXlrrlcclxuXHJcbiAgICAgICAgLy/njqnlrrZcclxuXHJcbiAgICAgICAgLy/nm7jmnLpcclxuXHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g5pWZ5a2m6ISa5pysXHJcbiAgICBwdWJsaWMgc2V0VGVhY2hDbXAoanMpIHtcclxuICAgIH1cclxuICAgIC8vI2VuZHJlZ2lvblxyXG5cclxuICAgIC8vI3JlZ2lvbiDov5vlhaXpppbpobVcclxuICAgIC8qKuiuvue9ruWcqOmmlumhteS4reS9nOS4uuiDjOaZr+aXtumcgOimgeaYvuekuueahOWGheWuuSAqL1xyXG4gICAgcHJvdGVjdGVkIHNldEVudGVyTG9iYnlEYXRhKCkge1xyXG4gICAgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq566h55CG5a+56LGhKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLyNyZWdpb24gIOeOqeWutlxyXG4gICAgLy8gcHJvdGVjdGVkIHBsYXllcjpQbGF5ZXIgPSBudWxsO1xyXG4gICAgcHJvdGVjdGVkIGluaXRQbGF5ZXIoKSB7XHJcblxyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHJlc2V0UGxheWVyKCkge1xyXG5cclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBzZXRQbGF5ZXIoKSB7XHJcblxyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVBsYXllcihkdDogbnVtYmVyKSB7XHJcblxyXG4gICAgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLy8jcmVnaW9uIOebuOaculxyXG4gICAgQHByb3BlcnR5KExldmVsQ2FtZXJhKVxyXG4gICAgcHJvdGVjdGVkIGNhbWVyYTogTGV2ZWxDYW1lcmEgPSBudWxsO1xyXG4gICAgcHJvdGVjdGVkIGluaXRDYW1lcmEoKSB7XHJcbiAgICAgICAgdGhpcy5jYW1lcmEuaW5pdCgpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHJlc2V0Q2FtZXJhKCkge1xyXG4gICAgICAgIHRoaXMuY2FtZXJhLnJlc2V0KCk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgdXBkYXRlQ2FtZXJhKGR0OiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLmNhbWVyYS5jdXN0b21VcGRhdGUoZHQpO1xyXG4gICAgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5rWB56iLKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLyNyZWdpb24g5ri45oiP5LitXHJcbiAgICBwcm90ZWN0ZWQgc3RlcExldmVsUGxheWluZyhkdDogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy51cGRhdGVDYW1lcmEoZHQpO1xyXG4gICAgICAgIHRoaXMudXBkYXRlUGxheWVyKGR0KTtcclxuXHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g6IOc5YipXHJcbiAgICBwcm90ZWN0ZWQgc3RlcExldmVsV2luKGR0OiBudW1iZXIpIHtcclxuICAgIH1cclxuICAgIC8qKuWFs+WNoeiDnOWIqeeahOaIkOe7qSAqL1xyXG4gICAgcHJvdGVjdGVkIGdldFdpbkRhdGEoKSB7XHJcbiAgICAgICAgbGV0IGRhdGE6IGFueSA9IHt9O1xyXG4gICAgICAgIGRhdGEubHYgPSB0aGlzLmxldmVsRGF0YS5sdjtcclxuXHJcbiAgICAgICAgcmV0dXJuIGRhdGE7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g5aSx6LSlXHJcbiAgICBwcm90ZWN0ZWQgc3RlcExldmVsTG9zZShkdDogbnVtYmVyKSB7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g54q25oCB77ya6aaW6aG15LitXHJcbiAgICBwcm90ZWN0ZWQgc3RlcExvYmJ5KGR0OiBudW1iZXIpIHtcclxuICAgICAgICAvLyB0aGlzLnVwZGF0ZUNhbWVyYShkdCk7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKirkuovku7YqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByb3RlY3RlZCBvblRlc3RXaW4oKSB7XHJcbiAgICAgICAgdGhpcy53aW4oKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBvblRlc3RMb3NlKCkge1xyXG4gICAgICAgIHRoaXMubG9zZSgpO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=