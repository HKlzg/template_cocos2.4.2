
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameSpecial/GameEventType.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '084fem4qwpBGKWfwMZ0bOIq', 'GameEventType');
// Script/GameSpecial/GameEventType.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventType = void 0;
var CommonEventType_1 = require("../Common/CommonEventType");
/**与游戏玩法相关的游戏过程中的事件 */
var LevelEvent;
(function (LevelEvent) {
    LevelEvent[LevelEvent["startIndex"] = 100000] = "startIndex";
    LevelEvent[LevelEvent["levelSceneLoadFinish"] = 100001] = "levelSceneLoadFinish";
    LevelEvent[LevelEvent["resurgence"] = 100002] = "resurgence";
    LevelEvent[LevelEvent["cancelResurgence"] = 100003] = "cancelResurgence";
    LevelEvent[LevelEvent["testWin"] = 100004] = "testWin";
    LevelEvent[LevelEvent["testLose"] = 100005] = "testLose";
})(LevelEvent || (LevelEvent = {}));
var EventType = /** @class */ (function (_super) {
    __extends(EventType, _super);
    function EventType() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EventType.LevelEvent = LevelEvent;
    return EventType;
}(CommonEventType_1.default));
exports.EventType = EventType;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lU3BlY2lhbFxcR2FtZUV2ZW50VHlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsNkRBQXdEO0FBQ3hELHNCQUFzQjtBQUN0QixJQUFLLFVBU0o7QUFURCxXQUFLLFVBQVU7SUFDWCw0REFBbUIsQ0FBQTtJQUNuQixnRkFBb0IsQ0FBQTtJQUNwQiw0REFBVSxDQUFBO0lBQ1Ysd0VBQWdCLENBQUE7SUFFaEIsc0RBQU8sQ0FBQTtJQUNQLHdEQUFRLENBQUE7QUFFWixDQUFDLEVBVEksVUFBVSxLQUFWLFVBQVUsUUFTZDtBQUNEO0lBQStCLDZCQUFlO0lBQTlDOztJQUVBLENBQUM7SUFEVSxvQkFBVSxHQUFHLFVBQVUsQ0FBQztJQUNuQyxnQkFBQztDQUZELEFBRUMsQ0FGOEIseUJBQWUsR0FFN0M7QUFGWSw4QkFBUyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBDb21tb25FdmVudFR5cGUgZnJvbSBcIi4uL0NvbW1vbi9Db21tb25FdmVudFR5cGVcIjtcbi8qKuS4jua4uOaIj+eOqeazleebuOWFs+eahOa4uOaIj+i/h+eoi+S4reeahOS6i+S7tiAqL1xuZW51bSBMZXZlbEV2ZW50IHtcbiAgICBzdGFydEluZGV4ID0gMTAwMDAwLFxuICAgIGxldmVsU2NlbmVMb2FkRmluaXNoLCAgICAgICAvL+WcqOmmlumhteS4reS9nOS4uuiDjOaZr+aXtuaJgOmcgOeahOmihOWItuS7tuW3suWFqOmDqOWKoOi9veWujOavlVxuICAgIHJlc3VyZ2VuY2UsICAgICAgICAgICAgICAgICAvL+ingueci+inhumikeaIkOWKn++8jOWkjea0u1xuICAgIGNhbmNlbFJlc3VyZ2VuY2UsICAgICAgICAgICAvL+WPlua2iOWkjea0u1xuXG4gICAgdGVzdFdpbiwgICAgICAgICAgICAgICAgICAgIC8v5rWL6K+V55So77yM55u05o6l5Yik5a6a5Li65YWz5Y2h6IOc5YipXG4gICAgdGVzdExvc2UsICAgICAgICAgICAgICAgICAgIC8v5rWL6K+V55So77yM55u05o6l5Yik5a6a5Li65YWz5Y2h5aSx6LSlXG5cbn1cbmV4cG9ydCBjbGFzcyBFdmVudFR5cGUgZXh0ZW5kcyBDb21tb25FdmVudFR5cGUge1xuICAgIHN0YXRpYyBMZXZlbEV2ZW50ID0gTGV2ZWxFdmVudDtcbn1cbiJdfQ==