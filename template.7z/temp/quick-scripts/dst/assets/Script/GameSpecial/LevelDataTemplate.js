
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameSpecial/LevelDataTemplate.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ff8f08lKv1NV45mBkyn71pD', 'LevelDataTemplate');
// GameSpecial/LevelDataTemplate.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//关卡数据示例
var LevelDataTemplate = /** @class */ (function () {
    function LevelDataTemplate() {
    }
    LevelDataTemplate.getData = function () {
        return {
            1: {
                id: 1,
                lv: 1,
                time: 10,
                playerData: {
                    p: cc.v3(),
                    e: cc.v3(0, 180, 0),
                },
                //其他数据
                //场景中的全部碰撞体
                collers: [
                    {
                        n: "WalkRole",
                        p: cc.v3(3, 0, 3),
                        e: cc.v3(),
                    }
                ],
            }
        };
    };
    return LevelDataTemplate;
}());
exports.default = LevelDataTemplate;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVNwZWNpYWxcXExldmVsRGF0YVRlbXBsYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUEsUUFBUTtBQUNSO0lBQ0k7SUFBd0IsQ0FBQztJQUNYLHlCQUFPLEdBQXJCO1FBQ0ksT0FBTztZQUNILENBQUMsRUFBRTtnQkFDQyxFQUFFLEVBQUUsQ0FBQztnQkFDTCxFQUFFLEVBQUUsQ0FBQztnQkFDTCxJQUFJLEVBQUUsRUFBRTtnQkFDUixVQUFVLEVBQUU7b0JBQ1IsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ1YsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7aUJBQ3RCO2dCQUNELE1BQU07Z0JBRU4sV0FBVztnQkFDWCxPQUFPLEVBQUU7b0JBQ0w7d0JBQ0ksQ0FBQyxFQUFFLFVBQVU7d0JBQ2IsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQ2pCLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFO3FCQUNiO2lCQUNKO2FBQ0o7U0FDSixDQUFDO0lBQ04sQ0FBQztJQUNMLHdCQUFDO0FBQUQsQ0F6QkEsQUF5QkMsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi9HbG9iYWxFbnVtXCI7XG5cbi8v5YWz5Y2h5pWw5o2u56S65L6LXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMZXZlbERhdGFUZW1wbGF0ZSB7XG4gICAgcHJpdmF0ZSBjb25zdHJ1Y3RvcigpIHsgfVxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0RGF0YSgpOiBhbnkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgMToge1xuICAgICAgICAgICAgICAgIGlkOiAxLFxuICAgICAgICAgICAgICAgIGx2OiAxLFxuICAgICAgICAgICAgICAgIHRpbWU6IDEwLCAgICAgICAgICAgICAgICAgICAvL+WFs+WNoeaXtumVv++8jOWNleS9je+8muenklxuICAgICAgICAgICAgICAgIHBsYXllckRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgcDogY2MudjMoKSxcbiAgICAgICAgICAgICAgICAgICAgZTogY2MudjMoMCwgMTgwLCAwKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIC8v5YW25LuW5pWw5o2uXG5cbiAgICAgICAgICAgICAgICAvL+WcuuaZr+S4reeahOWFqOmDqOeisOaSnuS9k1xuICAgICAgICAgICAgICAgIGNvbGxlcnM6IFtcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbjogXCJXYWxrUm9sZVwiLCAgICAgIC8v5a+56LGh5ZCN56ew77yM5LiO6aKE5Yi25Lu25ZCN56ew5a+55bqUXG4gICAgICAgICAgICAgICAgICAgICAgICBwOiBjYy52MygzLCAwLCAzKSwgIC8v5Z2Q5qCHXG4gICAgICAgICAgICAgICAgICAgICAgICBlOiBjYy52MygpLCAgICAgICAgIC8v6KeS5bqmXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH1cbn1cbiJdfQ==