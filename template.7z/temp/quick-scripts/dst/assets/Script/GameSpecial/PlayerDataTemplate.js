
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameSpecial/PlayerDataTemplate.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5ea36wwlGhLP6nx4W1NN5MX', 'PlayerDataTemplate');
// GameSpecial/PlayerDataTemplate.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//玩家数据示例
var PlayerDataTemplate = /** @class */ (function () {
    function PlayerDataTemplate() {
    }
    PlayerDataTemplate.getData = function () {
        return {
            gameData: {
                curLevel: 1,
                //玩家资源
                asset: {
                    gold: 0,
                    power: 10,
                },
                //主角皮肤
                PlayerSkin: {
                    cur: 0,
                    try: -1,
                    owned: [0],
                },
            },
        };
    };
    return PlayerDataTemplate;
}());
exports.default = PlayerDataTemplate;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVNwZWNpYWxcXFBsYXllckRhdGFUZW1wbGF0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLFFBQVE7QUFDUjtJQUNJO0lBQXdCLENBQUM7SUFDWCwwQkFBTyxHQUFyQjtRQUNJLE9BQU87WUFDSCxRQUFRLEVBQUU7Z0JBQ04sUUFBUSxFQUFFLENBQUM7Z0JBQ1gsTUFBTTtnQkFDTixLQUFLLEVBQUU7b0JBQ0gsSUFBSSxFQUFFLENBQUM7b0JBQ1AsS0FBSyxFQUFFLEVBQUU7aUJBQ1o7Z0JBQ0QsTUFBTTtnQkFDTixVQUFVLEVBQUU7b0JBQ1IsR0FBRyxFQUFFLENBQUM7b0JBQ04sR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFDUCxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ2I7YUFDSjtTQUNKLENBQUM7SUFDTixDQUFDO0lBQ0wseUJBQUM7QUFBRCxDQXBCQSxBQW9CQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXG4vL+eOqeWutuaVsOaNruekuuS+i1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGxheWVyRGF0YVRlbXBsYXRlIHtcbiAgICBwcml2YXRlIGNvbnN0cnVjdG9yKCkgeyB9XG4gICAgcHVibGljIHN0YXRpYyBnZXREYXRhKCk6IGFueSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBnYW1lRGF0YToge1xuICAgICAgICAgICAgICAgIGN1ckxldmVsOiAxLFxuICAgICAgICAgICAgICAgIC8v546p5a626LWE5rqQXG4gICAgICAgICAgICAgICAgYXNzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgZ29sZDogMCwgICAgICAgIC8v6YeR5biBXG4gICAgICAgICAgICAgICAgICAgIHBvd2VyOiAxMCwgICAgICAvL+S9k+WKm1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgLy/kuLvop5Lnmq7ogqRcbiAgICAgICAgICAgICAgICBQbGF5ZXJTa2luOiB7XG4gICAgICAgICAgICAgICAgICAgIGN1cjogMCwgICAgICAgICAvL+W9k+WJjeS9v+eUqOeahOearuiCpFxuICAgICAgICAgICAgICAgICAgICB0cnk6IC0xLCAgICAgICAgLy/lvZPliY3or5XnlKjnmoTnmq7ogqTvvIwtMeihqOekuuaXoOivleeUqOearuiCpFxuICAgICAgICAgICAgICAgICAgICBvd25lZDogWzBdLCAgICAgLy/lt7Lmi6XmnInnmoTnmq7ogqRcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICB9XG59XG4iXX0=