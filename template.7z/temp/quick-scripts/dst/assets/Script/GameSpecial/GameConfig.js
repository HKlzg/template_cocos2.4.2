
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameSpecial/GameConfig.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '080b4sm8OJF05ZQAgQM+TZ3', 'GameConfig');
// GameSpecial/GameConfig.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var CommonGameConfig_1 = require("../Common/CommonGameConfig");
/**
 * 全局使用的游戏配置，只包含静态数据
 */
var GameConfig = /** @class */ (function (_super) {
    __extends(GameConfig, _super);
    function GameConfig() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * 游戏规则
     */
    GameConfig.GameRule = {
        mapSize: {
            width: 400,
            height: 400,
        }
    };
    return GameConfig;
}(CommonGameConfig_1.default));
exports.default = GameConfig;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVNwZWNpYWxcXEdhbWVDb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBRTFEOztHQUVHO0FBQ0g7SUFBd0MsOEJBQWdCO0lBQXhEOztJQVdBLENBQUM7SUFWRzs7T0FFRztJQUNXLG1CQUFRLEdBQUc7UUFDckIsT0FBTyxFQUFFO1lBQ0wsS0FBSyxFQUFFLEdBQUc7WUFDVixNQUFNLEVBQUUsR0FBRztTQUNkO0tBQ0osQ0FBQztJQUVOLGlCQUFDO0NBWEQsQUFXQyxDQVh1QywwQkFBZ0IsR0FXdkQ7a0JBWG9CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ29tbW9uR2FtZUNvbmZpZyBmcm9tIFwiLi4vQ29tbW9uL0NvbW1vbkdhbWVDb25maWdcIjtcblxuLyoqXG4gKiDlhajlsYDkvb/nlKjnmoTmuLjmiI/phY3nva7vvIzlj6rljIXlkKvpnZnmgIHmlbDmja5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgR2FtZUNvbmZpZyBleHRlbmRzIENvbW1vbkdhbWVDb25maWcge1xuICAgIC8qKlxuICAgICAqIOa4uOaIj+inhOWImVxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgR2FtZVJ1bGUgPSB7XG4gICAgICAgIG1hcFNpemU6IHtcbiAgICAgICAgICAgIHdpZHRoOiA0MDAsXG4gICAgICAgICAgICBoZWlnaHQ6IDQwMCxcbiAgICAgICAgfVxuICAgIH07XG5cbn1cbiJdfQ==