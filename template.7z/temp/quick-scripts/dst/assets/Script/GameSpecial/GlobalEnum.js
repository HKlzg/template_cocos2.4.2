
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameSpecial/GlobalEnum.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2d652/6KzxHFZz3KIQFL+QK', 'GlobalEnum');
// Script/GameSpecial/GlobalEnum.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalEnum = void 0;
var CommonEnum_1 = require("../Common/CommonEnum");
/**通过全局对象池管理的预制件名称与对应的脚本名称 */
var LevelPrefab;
(function (LevelPrefab) {
    LevelPrefab["goldIcon"] = "GoldIcon";
    LevelPrefab["player"] = "Player";
    LevelPrefab["car1"] = "Car1";
    LevelPrefab["standRole"] = "StandRole";
    LevelPrefab["walkRole"] = "WalkRole";
    LevelPrefab["toiletDoor"] = "ToiletDoor";
    LevelPrefab["shi"] = "Shi";
    LevelPrefab["shiParticle"] = "ShiParticle";
})(LevelPrefab || (LevelPrefab = {}));
/**视频广告位名称 */
var VideoName;
(function (VideoName) {
    /**胜利多倍领取 */
    VideoName[VideoName["getGoldWin"] = 0] = "getGoldWin";
    /**失败多倍领取 */
    VideoName[VideoName["getGoldLose"] = 1] = "getGoldLose";
    /**观看视频获取金币 */
    VideoName[VideoName["getGold"] = 2] = "getGold";
    /**试用皮肤 */
    VideoName[VideoName["trySkin"] = 3] = "trySkin";
    /**复活 */
    VideoName[VideoName["fuHuo"] = 4] = "fuHuo";
    /**试用剑神模式 */
    VideoName[VideoName["tryJianShen"] = 5] = "tryJianShen";
    /**道具-磁铁 */
    VideoName[VideoName["ciTie"] = 6] = "ciTie";
    /**道具-护盾 */
    VideoName[VideoName["huDun"] = 7] = "huDun";
    /**道具-暴走 */
    VideoName[VideoName["baoZou"] = 8] = "baoZou";
})(VideoName || (VideoName = {}));
var GlobalEnum = /** @class */ (function (_super) {
    __extends(GlobalEnum, _super);
    function GlobalEnum() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    GlobalEnum.LevelPrefab = LevelPrefab;
    GlobalEnum.VideoName = VideoName;
    return GlobalEnum;
}(CommonEnum_1.CommonEnum));
exports.GlobalEnum = GlobalEnum;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lU3BlY2lhbFxcR2xvYmFsRW51bS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsbURBQWtEO0FBRWxELDZCQUE2QjtBQUM3QixJQUFLLFdBWUo7QUFaRCxXQUFLLFdBQVc7SUFDWixvQ0FBcUIsQ0FBQTtJQUVyQixnQ0FBaUIsQ0FBQTtJQUNqQiw0QkFBYSxDQUFBO0lBRWIsc0NBQXVCLENBQUE7SUFDdkIsb0NBQXFCLENBQUE7SUFDckIsd0NBQXlCLENBQUE7SUFFekIsMEJBQVcsQ0FBQTtJQUNYLDBDQUEyQixDQUFBO0FBQy9CLENBQUMsRUFaSSxXQUFXLEtBQVgsV0FBVyxRQVlmO0FBQ0QsYUFBYTtBQUNiLElBQUssU0FvQko7QUFwQkQsV0FBSyxTQUFTO0lBQ1YsWUFBWTtJQUNaLHFEQUFVLENBQUE7SUFDVixZQUFZO0lBQ1osdURBQVcsQ0FBQTtJQUNYLGNBQWM7SUFDZCwrQ0FBTyxDQUFBO0lBQ1AsVUFBVTtJQUNWLCtDQUFPLENBQUE7SUFDUCxRQUFRO0lBQ1IsMkNBQUssQ0FBQTtJQUNMLFlBQVk7SUFDWix1REFBVyxDQUFBO0lBQ1gsV0FBVztJQUNYLDJDQUFLLENBQUE7SUFDTCxXQUFXO0lBQ1gsMkNBQUssQ0FBQTtJQUNMLFdBQVc7SUFDWCw2Q0FBTSxDQUFBO0FBRVYsQ0FBQyxFQXBCSSxTQUFTLEtBQVQsU0FBUyxRQW9CYjtBQUNEO0lBQWdDLDhCQUFVO0lBQTFDOztJQUdBLENBQUM7SUFGVSxzQkFBVyxHQUFHLFdBQVcsQ0FBQztJQUMxQixvQkFBUyxHQUFHLFNBQVMsQ0FBQztJQUNqQyxpQkFBQztDQUhELEFBR0MsQ0FIK0IsdUJBQVUsR0FHekM7QUFIWSxnQ0FBVSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbW1vbkVudW0gfSBmcm9tIFwiLi4vQ29tbW9uL0NvbW1vbkVudW1cIjtcblxuLyoq6YCa6L+H5YWo5bGA5a+56LGh5rGg566h55CG55qE6aKE5Yi25Lu25ZCN56ew5LiO5a+55bqU55qE6ISa5pys5ZCN56ewICovXG5lbnVtIExldmVsUHJlZmFiIHtcbiAgICBnb2xkSWNvbiA9IFwiR29sZEljb25cIixcblxuICAgIHBsYXllciA9IFwiUGxheWVyXCIsXG4gICAgY2FyMSA9IFwiQ2FyMVwiLFxuXG4gICAgc3RhbmRSb2xlID0gXCJTdGFuZFJvbGVcIixcbiAgICB3YWxrUm9sZSA9IFwiV2Fsa1JvbGVcIixcbiAgICB0b2lsZXREb29yID0gXCJUb2lsZXREb29yXCIsXG5cbiAgICBzaGkgPSBcIlNoaVwiLFxuICAgIHNoaVBhcnRpY2xlID0gXCJTaGlQYXJ0aWNsZVwiLFxufVxuLyoq6KeG6aKR5bm/5ZGK5L2N5ZCN56ewICovXG5lbnVtIFZpZGVvTmFtZSB7XG4gICAgLyoq6IOc5Yip5aSa5YCN6aKG5Y+WICovXG4gICAgZ2V0R29sZFdpbixcbiAgICAvKirlpLHotKXlpJrlgI3pooblj5YgKi9cbiAgICBnZXRHb2xkTG9zZSxcbiAgICAvKirop4LnnIvop4bpopHojrflj5bph5HluIEgKi9cbiAgICBnZXRHb2xkLFxuICAgIC8qKuivleeUqOearuiCpCAqL1xuICAgIHRyeVNraW4sXG4gICAgLyoq5aSN5rS7ICovXG4gICAgZnVIdW8sXG4gICAgLyoq6K+V55So5YmR56We5qih5byPICovXG4gICAgdHJ5SmlhblNoZW4sXG4gICAgLyoq6YGT5YW3LeejgemTgSAqL1xuICAgIGNpVGllLFxuICAgIC8qKumBk+WFty3miqTnm74gKi9cbiAgICBodUR1bixcbiAgICAvKirpgZPlhbct5pq06LWwICovXG4gICAgYmFvWm91LFxuXG59XG5leHBvcnQgY2xhc3MgR2xvYmFsRW51bSBleHRlbmRzIENvbW1vbkVudW0ge1xuICAgIHN0YXRpYyBMZXZlbFByZWZhYiA9IExldmVsUHJlZmFiO1xuICAgIHN0YXRpYyBWaWRlb05hbWUgPSBWaWRlb05hbWU7XG59XG4iXX0=