
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameSpecial/SkinDataTemplate.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '41dcfb5SZFDr7K15+0tMdni', 'SkinDataTemplate');
// GameSpecial/SkinDataTemplate.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SkinDataTemplate = /** @class */ (function () {
    function SkinDataTemplate() {
    }
    SkinDataTemplate.getData = function () {
        return {
            //key：对应皮肤id
            1: {
                id: 1,
                model: "Cube",
                skin: "1",
                itemUrl: "1",
                price: 200,
                displayUrl: "",
                name: "" //皮肤名称
            },
        };
    };
    return SkinDataTemplate;
}());
exports.default = SkinDataTemplate;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVNwZWNpYWxcXFNraW5EYXRhVGVtcGxhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtJQUNJO0lBQXdCLENBQUM7SUFDWCx3QkFBTyxHQUFyQjtRQUNJLE9BQU87WUFDSCxZQUFZO1lBQ1osQ0FBQyxFQUFFO2dCQUNDLEVBQUUsRUFBRSxDQUFDO2dCQUNMLEtBQUssRUFBRSxNQUFNO2dCQUNiLElBQUksRUFBRSxHQUFHO2dCQUNULE9BQU8sRUFBRSxHQUFHO2dCQUNaLEtBQUssRUFBRSxHQUFHO2dCQUNWLFVBQVUsRUFBRSxFQUFFO2dCQUNkLElBQUksRUFBRSxFQUFFLENBQVksTUFBTTthQUM3QjtTQUNKLENBQUE7SUFDTCxDQUFDO0lBQ0wsdUJBQUM7QUFBRCxDQWhCQSxBQWdCQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2tpbkRhdGFUZW1wbGF0ZSB7XHJcbiAgICBwcml2YXRlIGNvbnN0cnVjdG9yKCkgeyB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGdldERhdGEoKSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgLy9rZXnvvJrlr7nlupTnmq7ogqRpZFxyXG4gICAgICAgICAgICAxOiB7XHJcbiAgICAgICAgICAgICAgICBpZDogMSxcclxuICAgICAgICAgICAgICAgIG1vZGVsOiBcIkN1YmVcIiwgICAgICAvL+earuiCpOWvueW6lOeahDNE5qih5Z6L6aKE5Yi25Lu255qE5ZCN56ewXHJcbiAgICAgICAgICAgICAgICBza2luOiBcIjFcIiwgICAgICAgICAgLy/nmq7ogqTotLTlm77mlofku7blkI1cclxuICAgICAgICAgICAgICAgIGl0ZW1Vcmw6IFwiMVwiLCAgICAgICAvL+WcqOWVhuWfjuS4reaYvuekuueahOWVhuWTgemhueeahOWbvueJh+WQjeensFxyXG4gICAgICAgICAgICAgICAgcHJpY2U6IDIwMCwgICAgICAgICAvL+S7t+agvFxyXG4gICAgICAgICAgICAgICAgZGlzcGxheVVybDogXCJcIiwgICAgIC8v5Zyo5ZWG5Z+O5Lit6YCJ5Lit5ZWG5ZOB5pe277yM5Zyo5bGV56S65Y+w5LiK6KaB5pi+56S655qE5Zu+54mH77yI5bGV56S65pa55byP5Li6MkTlm77niYfml7bmnInmlYjvvIlcclxuICAgICAgICAgICAgICAgIG5hbWU6IFwiXCIgICAgICAgICAgICAvL+earuiCpOWQjeensFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ==