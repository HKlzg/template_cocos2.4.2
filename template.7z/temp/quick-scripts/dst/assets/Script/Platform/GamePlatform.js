
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/GamePlatform.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'da1cfQrGnNAE4bDQ9RN6h+7', 'GamePlatform');
// Script/Platform/GamePlatform.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GamePlatformConfig_1 = require("./GamePlatformConfig");
var GamePlatformType_1 = require("./GamePlatformType");
var SDK_1 = require("./SDK/SDK");
var WXSDK_1 = require("./SDK/WXSDK");
var TTSDK_1 = require("./SDK/TTSDK");
var OPPOSDK_1 = require("./SDK/OPPOSDK");
var VIVOSDK_1 = require("./SDK/VIVOSDK");
var QQSDK_1 = require("./SDK/QQSDK");
var PCSDK_1 = require("./SDK/PCSDK");
var GamePlatform = /** @class */ (function () {
    function GamePlatform() {
        this._config = null;
        this._sdk = null;
    }
    Object.defineProperty(GamePlatform, "instance", {
        get: function () {
            if (!GamePlatform._instance) {
                GamePlatform._instance = new GamePlatform();
            }
            return GamePlatform._instance;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GamePlatform.prototype, "Config", {
        /**
         * 平台设置参数
         */
        get: function () {
            return this._config;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GamePlatform, "SDK", {
        /**
         * SDK
         */
        get: function () {
            if (!GamePlatform.instance._sdk) {
                GamePlatform.instance.setDefaultSdk();
            }
            return GamePlatform.instance._sdk;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 初始化SDK
     */
    GamePlatform.prototype.init = function (param) {
        console.log(param);
        this._config = param;
        switch (param.type) {
            case GamePlatformType_1.GamePlatformType.PC:
                this._sdk = new SDK_1.default(); //默认不继承。
                break;
            case GamePlatformType_1.GamePlatformType.WX:
                this._sdk = new WXSDK_1.default();
                break;
            case GamePlatformType_1.GamePlatformType.TT:
                this._sdk = new TTSDK_1.default();
                break;
            case GamePlatformType_1.GamePlatformType.QQ:
                this._sdk = new QQSDK_1.default();
                break;
            case GamePlatformType_1.GamePlatformType.OPPO:
                this._sdk = new OPPOSDK_1.default();
                break;
            case GamePlatformType_1.GamePlatformType.VIVO:
                this._sdk = new VIVOSDK_1.default();
                break;
            default: {
                this._sdk = new PCSDK_1.default();
                break;
            }
        }
        this._sdk.init();
        this._sdk.onEvents();
        this._sdk.loadRecord();
    };
    /**
     * 设置默认sdk[PC];
     */
    GamePlatform.prototype.setDefaultSdk = function () {
        var param = new GamePlatformConfig_1.default();
        param.type = GamePlatformType_1.GamePlatformType.PC;
        param.appId = "";
        param.secret = "";
        param.share = true;
        param.video = true;
        param.banner = false;
        param.interstitial = false;
        param.vibrate = true;
        param.videoAdUnitId = [""];
        param.BannerAdUnitId = [""];
        param.InterstitialAdUnitId = [""];
        param.appBoxUnitId = [""];
        param.blockAdUnitId = [""];
        this.init(param);
    };
    return GamePlatform;
}());
exports.default = GamePlatform;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcR2FtZVBsYXRmb3JtLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsMkRBQXNEO0FBQ3RELHVEQUFzRDtBQUN0RCxpQ0FBNEI7QUFDNUIscUNBQWdDO0FBQ2hDLHFDQUFnQztBQUNoQyx5Q0FBb0M7QUFDcEMseUNBQW9DO0FBQ3BDLHFDQUFnQztBQUNoQyxxQ0FBZ0M7QUFHaEM7SUFBQTtRQWVZLFlBQU8sR0FBdUIsSUFBSSxDQUFDO1FBV25DLFNBQUksR0FBUSxJQUFJLENBQUM7SUE0RDdCLENBQUM7SUFwRkcsc0JBQWtCLHdCQUFRO2FBQTFCO1lBQ0ksSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUU7Z0JBQ3pCLFlBQVksQ0FBQyxTQUFTLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQzthQUMvQztZQUNELE9BQU8sWUFBWSxDQUFDLFNBQVMsQ0FBQztRQUNsQyxDQUFDOzs7T0FBQTtJQUtELHNCQUFXLGdDQUFNO1FBSGpCOztXQUVHO2FBQ0g7WUFDSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDeEIsQ0FBQzs7O09BQUE7SUFNRCxzQkFBa0IsbUJBQUc7UUFIckI7O1dBRUc7YUFDSDtZQUNJLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtnQkFDN0IsWUFBWSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN6QztZQUNELE9BQU8sWUFBWSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDdEMsQ0FBQzs7O09BQUE7SUFHRDs7T0FFRztJQUNJLDJCQUFJLEdBQVgsVUFBWSxLQUF5QjtRQUNqQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1FBQ3JCLFFBQVEsS0FBSyxDQUFDLElBQUksRUFBRTtZQUNoQixLQUFLLG1DQUFnQixDQUFDLEVBQUU7Z0JBQ3BCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxhQUFHLEVBQUUsQ0FBQyxDQUFDLFFBQVE7Z0JBQy9CLE1BQU07WUFDVixLQUFLLG1DQUFnQixDQUFDLEVBQUU7Z0JBQ3BCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxlQUFLLEVBQUUsQ0FBQztnQkFDeEIsTUFBTTtZQUNWLEtBQUssbUNBQWdCLENBQUMsRUFBRTtnQkFDcEIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLGVBQUssRUFBRSxDQUFDO2dCQUN4QixNQUFNO1lBQ1YsS0FBSyxtQ0FBZ0IsQ0FBQyxFQUFFO2dCQUNwQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksZUFBSyxFQUFFLENBQUM7Z0JBQ3hCLE1BQU07WUFDVixLQUFLLG1DQUFnQixDQUFDLElBQUk7Z0JBQ3RCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxpQkFBTyxFQUFFLENBQUM7Z0JBQzFCLE1BQU07WUFDVixLQUFLLG1DQUFnQixDQUFDLElBQUk7Z0JBQ3RCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxpQkFBTyxFQUFFLENBQUM7Z0JBQzFCLE1BQU07WUFFVixPQUFPLENBQUMsQ0FBQztnQkFDTCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksZUFBSyxFQUFFLENBQUM7Z0JBQ3hCLE1BQU07YUFDVDtTQUNKO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVEOztPQUVHO0lBQ0ssb0NBQWEsR0FBckI7UUFDSSxJQUFJLEtBQUssR0FBdUIsSUFBSSw0QkFBa0IsRUFBRSxDQUFDO1FBQ3pELEtBQUssQ0FBQyxJQUFJLEdBQUcsbUNBQWdCLENBQUMsRUFBRSxDQUFDO1FBQ2pDLEtBQUssQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ25CLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ25CLEtBQUssQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3JCLEtBQUssQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO1FBQzNCLEtBQUssQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLEtBQUssQ0FBQyxhQUFhLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMzQixLQUFLLENBQUMsY0FBYyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDNUIsS0FBSyxDQUFDLG9CQUFvQixHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbEMsS0FBSyxDQUFDLFlBQVksR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzFCLEtBQUssQ0FBQyxhQUFhLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUUzQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFDTCxtQkFBQztBQUFELENBdEZBLEFBc0ZDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgR2FtZVBsYXRmb3JtQ29uZmlnIGZyb20gXCIuL0dhbWVQbGF0Zm9ybUNvbmZpZ1wiO1xuaW1wb3J0IHsgR2FtZVBsYXRmb3JtVHlwZSB9IGZyb20gXCIuL0dhbWVQbGF0Zm9ybVR5cGVcIjtcbmltcG9ydCBTREsgZnJvbSBcIi4vU0RLL1NES1wiO1xuaW1wb3J0IFdYU0RLIGZyb20gXCIuL1NESy9XWFNES1wiO1xuaW1wb3J0IFRUU0RLIGZyb20gXCIuL1NESy9UVFNES1wiO1xuaW1wb3J0IE9QUE9TREsgZnJvbSBcIi4vU0RLL09QUE9TREtcIjtcbmltcG9ydCBWSVZPU0RLIGZyb20gXCIuL1NESy9WSVZPU0RLXCI7XG5pbXBvcnQgUVFTREsgZnJvbSBcIi4vU0RLL1FRU0RLXCI7XG5pbXBvcnQgUENTREsgZnJvbSBcIi4vU0RLL1BDU0RLXCI7XG5cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgR2FtZVBsYXRmb3JtIHtcbiAgICBwcml2YXRlIHN0YXRpYyBfaW5zdGFuY2U6IEdhbWVQbGF0Zm9ybTtcbiAgICBwdWJsaWMgc3RhdGljIGdldCBpbnN0YW5jZSgpOiBHYW1lUGxhdGZvcm0ge1xuICAgICAgICBpZiAoIUdhbWVQbGF0Zm9ybS5faW5zdGFuY2UpIHtcbiAgICAgICAgICAgIEdhbWVQbGF0Zm9ybS5faW5zdGFuY2UgPSBuZXcgR2FtZVBsYXRmb3JtKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIEdhbWVQbGF0Zm9ybS5faW5zdGFuY2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5bmz5Y+w6K6+572u5Y+C5pWwXG4gICAgICovXG4gICAgcHVibGljIGdldCBDb25maWcoKTogR2FtZVBsYXRmb3JtQ29uZmlnIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NvbmZpZztcbiAgICB9XG4gICAgcHJpdmF0ZSBfY29uZmlnOiBHYW1lUGxhdGZvcm1Db25maWcgPSBudWxsO1xuXG4gICAgLyoqXG4gICAgICogU0RLXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXQgU0RLKCk6IFNESyB7XG4gICAgICAgIGlmICghR2FtZVBsYXRmb3JtLmluc3RhbmNlLl9zZGspIHtcbiAgICAgICAgICAgIEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5zZXREZWZhdWx0U2RrKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5fc2RrO1xuICAgIH1cbiAgICBwcml2YXRlIF9zZGs6IFNESyA9IG51bGw7XG5cbiAgICAvKipcbiAgICAgKiDliJ3lp4vljJZTREtcbiAgICAgKi9cbiAgICBwdWJsaWMgaW5pdChwYXJhbTogR2FtZVBsYXRmb3JtQ29uZmlnKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKHBhcmFtKTtcbiAgICAgICAgdGhpcy5fY29uZmlnID0gcGFyYW07XG4gICAgICAgIHN3aXRjaCAocGFyYW0udHlwZSkge1xuICAgICAgICAgICAgY2FzZSBHYW1lUGxhdGZvcm1UeXBlLlBDOlxuICAgICAgICAgICAgICAgIHRoaXMuX3NkayA9IG5ldyBTREsoKTsgLy/pu5jorqTkuI3nu6fmib/jgIJcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5XWDpcbiAgICAgICAgICAgICAgICB0aGlzLl9zZGsgPSBuZXcgV1hTREsoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5UVDpcbiAgICAgICAgICAgICAgICB0aGlzLl9zZGsgPSBuZXcgVFRTREsoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5RUTpcbiAgICAgICAgICAgICAgICB0aGlzLl9zZGsgPSBuZXcgUVFTREsoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5PUFBPOlxuICAgICAgICAgICAgICAgIHRoaXMuX3NkayA9IG5ldyBPUFBPU0RLKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIEdhbWVQbGF0Zm9ybVR5cGUuVklWTzpcbiAgICAgICAgICAgICAgICB0aGlzLl9zZGsgPSBuZXcgVklWT1NESygpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBkZWZhdWx0OiB7XG4gICAgICAgICAgICAgICAgdGhpcy5fc2RrID0gbmV3IFBDU0RLKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9zZGsuaW5pdCgpO1xuICAgICAgICB0aGlzLl9zZGsub25FdmVudHMoKTtcbiAgICAgICAgdGhpcy5fc2RrLmxvYWRSZWNvcmQoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDorr7nva7pu5jorqRzZGtbUENdO1xuICAgICAqL1xuICAgIHByaXZhdGUgc2V0RGVmYXVsdFNkaygpIHtcbiAgICAgICAgdmFyIHBhcmFtOiBHYW1lUGxhdGZvcm1Db25maWcgPSBuZXcgR2FtZVBsYXRmb3JtQ29uZmlnKCk7XG4gICAgICAgIHBhcmFtLnR5cGUgPSBHYW1lUGxhdGZvcm1UeXBlLlBDO1xuICAgICAgICBwYXJhbS5hcHBJZCA9IFwiXCI7XG4gICAgICAgIHBhcmFtLnNlY3JldCA9IFwiXCI7XG4gICAgICAgIHBhcmFtLnNoYXJlID0gdHJ1ZTtcbiAgICAgICAgcGFyYW0udmlkZW8gPSB0cnVlO1xuICAgICAgICBwYXJhbS5iYW5uZXIgPSBmYWxzZTtcbiAgICAgICAgcGFyYW0uaW50ZXJzdGl0aWFsID0gZmFsc2U7XG4gICAgICAgIHBhcmFtLnZpYnJhdGUgPSB0cnVlO1xuICAgICAgICBwYXJhbS52aWRlb0FkVW5pdElkID0gW1wiXCJdO1xuICAgICAgICBwYXJhbS5CYW5uZXJBZFVuaXRJZCA9IFtcIlwiXTtcbiAgICAgICAgcGFyYW0uSW50ZXJzdGl0aWFsQWRVbml0SWQgPSBbXCJcIl07XG4gICAgICAgIHBhcmFtLmFwcEJveFVuaXRJZCA9IFtcIlwiXTtcbiAgICAgICAgcGFyYW0uYmxvY2tBZFVuaXRJZCA9IFtcIlwiXTtcblxuICAgICAgICB0aGlzLmluaXQocGFyYW0pO1xuICAgIH1cbn1cbiJdfQ==