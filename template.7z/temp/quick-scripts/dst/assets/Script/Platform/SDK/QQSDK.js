
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/SDK/QQSDK.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b3854A5MblBFaGgmx+n2v1Y', 'QQSDK');
// Script/Platform/SDK/QQSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var QQSDK = /** @class */ (function (_super) {
    __extends(QQSDK, _super);
    function QQSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'qq';
        //盒子广告
        _this.appBox = null;
        return _this;
    }
    QQSDK.prototype.init = function () {
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        console.log("QQ小游戏系统信息：");
        console.log(this.systemInfo);
        this.api.showShareMenu({ withShareTicket: false });
    };
    /**
     * 视频广告
     */
    QQSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        if (!this.canApiUseVideo()) {
            this.onVideoSuccess();
            return;
        }
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("获取视频id失败");
            return;
        }
        var rewardedVideoAd = this.api.createRewardedVideoAd({
            adUnitId: id,
        });
        rewardedVideoAd.onLoad(this.onVideoShow.bind(this));
        rewardedVideoAd.onError(this.onVideoFail.bind(this));
        var closefun = (function (res) {
            rewardedVideoAd.offLoad(_this.onVideoShow.bind(_this));
            rewardedVideoAd.offError(_this.onVideoFail.bind(_this));
            rewardedVideoAd.offClose(closefun);
            rewardedVideoAd = null;
            if (res && res.isEnded) {
                _this.onVideoSuccess();
            }
            else {
                _this.onVideoQuit();
                _this.onVideoHide();
            }
        });
        rewardedVideoAd.onClose(closefun);
        //开始加载视频广告
        rewardedVideoAd.load().then(function () {
            rewardedVideoAd.show().catch(function (err) {
                _this.onVideoFail(err);
                rewardedVideoAd.offLoad(_this.onVideoShow.bind(_this));
                rewardedVideoAd.offError(_this.onVideoFail.bind(_this));
                rewardedVideoAd.offClose(closefun);
                rewardedVideoAd = null;
            });
        });
    };
    /**能否使用api：video */
    QQSDK.prototype.canApiUseVideo = function () {
        return true;
    };
    /**
     * 打开banner
     */
    QQSDK.prototype.showBanner = function () {
        if (!this.canApiUseBanner()) {
            return;
        }
        // if (this.insertAdRecord.isShowing) {
        //     console.log("有插屏显示，不再显示banner");
        //     this.removeBanner();
        //     return;
        // }
        if (!!this._bannerAd) {
            this._bannerAd.show().then(this.onBannerShow.bind(this));
            return;
        }
        var id = this.getBannerId();
        if (!id)
            return;
        // this.removeBanner();
        var banner = this.createBanner(id);
        banner.show().then(this.onBannerShow.bind(this));
    };
    /**能否使用api：banner */
    QQSDK.prototype.canApiUseBanner = function () {
        return true;
    };
    QQSDK.prototype.createBanner = function (id) {
        var _this = this;
        this._bannerAd = this.api.createBannerAd({
            adUnitId: id,
            style: {
                left: 0,
                top: this.systemInfo.screenHeight - 130,
                width: this.systemInfo.screenWidth + 50,
            }
        });
        this._bannerAd.onError(this.onBannerErr.bind(this));
        // this._bannerAd.show().then(this.onBannerShow.bind(this));
        this._bannerAd.onResize(function (res) {
            if (_this.systemInfo.platform == "ios" && cc.visibleRect["height"] / cc.visibleRect["width"] >= 2) {
                console.log("苹果刘海屏手机调用banner");
                _this._bannerAd.style.top = _this.systemInfo.screenHeight - res.height - 20;
            }
            else {
                _this._bannerAd.style.top = _this.systemInfo.screenHeight - res.height;
            }
        });
        return this._bannerAd;
    };
    /**
     * 关闭广告
     */
    QQSDK.prototype.removeBanner = function () {
        if (this._bannerAd) {
            this._bannerAd.offError(this.onBannerErr.bind(this));
            this._bannerAd.offResize();
            this._bannerAd.destroy(); //要先把旧的广告给销毁，不然会导致其监听的事件无法释放，影响性能
            this._bannerAd = null;
        }
        //销毁当前banner后，立即创建新的banner，但不显示出来
        var id = this.getBannerId();
        if (!id)
            return;
        this.createBanner(id);
    };
    /**
     * 插屏广告
     */
    QQSDK.prototype.showInterstitialAd = function (banner) {
        var _this = this;
        if (banner === void 0) { banner = false; }
        this.showBanner();
        return;
        this.useBannerInsteadInsert = banner;
        if (!this.canApiUseInsert()) {
            this.showBannerInsteadInsert();
            return;
        }
        var id = this.getInsertAdUnitId();
        if (!id) {
            this.showBannerInsteadInsert();
            return;
        }
        var ad = this.api.createInterstitialAd({ adUnitId: id });
        // ad.show().then(() => {
        //     this.removeBanner();
        //     this.onInsertShow();
        // });
        try {
            ad.show().then(function () {
                _this.removeBanner();
                _this.onInsertShow();
            }).catch(function (err) {
                _this.onInsertErr(err);
                _this.showBannerInsteadInsert();
            });
        }
        catch (err) {
            this.onInsertErr(err);
            this.showBannerInsteadInsert();
        }
        ad.onClose(function () {
            _this.onInsertHide();
            ad.destroy();
        });
        ad.onError(function (err) {
            _this.onInsertErr(err);
            _this.showBannerInsteadInsert();
        });
    };
    /**能否使用api：insert */
    QQSDK.prototype.canApiUseInsert = function () {
        var version = this.systemInfo.SDKVersion;
        if (this.lessThan(version, '1.12.0')) {
            console.log('基础库版本低于1.12.0，插屏无法显示');
            return false;
        }
        return true;
    };
    /**
     * 短震动
     */
    QQSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    QQSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    QQSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ""; }
        var index = Math.floor((Math.random() * this.shareTitleArr.length));
        var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
        this.api.shareAppMessage({
            title: "" + this.shareTitleArr[index],
            imageUrl: "" + this.shareImgArr[indeximg],
            query: "" + query,
        });
    };
    /**
     * 激励分享&&带参分享
     */
    QQSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
        if (!GamePlatform_1.default.instance.Config.share) {
            // success();
            return;
        }
        this.shareAppMessage(query);
        success();
    };
    //订阅
    QQSDK.prototype.subscribeMsg = function (data) {
        if (undefined === data) {
            data = {
                subscribe: true,
                success: function (res) {
                    console.log("订阅成功");
                },
                fail: function (res) {
                    console.log("订阅失败");
                },
            };
        }
        this.api.subscribeAppMsg(data);
    };
    //彩签
    QQSDK.prototype.addColorSign = function (data) {
        if (this.lessThan(this.systemInfo.SDKVersion, "1.10.0")) {
            console.log("基础库版本低于1.10.0，无法使用彩签功能");
            return;
        }
        if (undefined === data) {
            data = {
                success: function (res) {
                    console.log("彩签添加成功,", res);
                },
                fail: function (res) {
                    console.log("彩签添加失败,", res);
                },
                complete: function (res) {
                    console.log("彩签接口调用完成，", res);
                }
            };
        }
        this.api.addColorSign(data);
    };
    QQSDK.prototype.showAppBox = function () {
        var _this = this;
        if (this.lessThan(this.systemInfo.SDKVersion, "1.7.1")) {
            console.log("基础库版本低于1.7.1，盒子广告无法显示");
            return;
        }
        if (!!this.appBox) {
            this.appBox.show();
            return;
        }
        var id = this.getAppBoxId();
        var appBox = this.api.createAppBox({
            adUnitId: id,
        });
        appBox.load().then(function () {
            console.log("盒子广告加载完成");
            appBox.show();
            console.log("盒子广告显示成功");
        }).catch(function (err) {
            console.log("盒子广告加载失败：", err);
            appBox.destroy();
            _this.appBox = null;
        });
        this.appBox = appBox;
    };
    //积木广告
    QQSDK.prototype.showBlockAd = function () {
    };
    return QQSDK;
}(SDK_1.default));
exports.default = QQSDK;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcU0RLXFxRUVNESy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw2QkFBd0I7QUFDeEIsZ0RBQTJDO0FBQzNDO0lBQW1DLHlCQUFHO0lBQXRDO1FBQUEscUVBOFNDO1FBN1NhLGFBQU8sR0FBVyxJQUFJLENBQUM7UUE2UWpDLE1BQU07UUFDSSxZQUFNLEdBQVEsSUFBSSxDQUFDOztJQStCakMsQ0FBQztJQTNTVSxvQkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDMUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsRUFBRSxlQUFlLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7O09BRUc7SUFDSSwyQkFBVyxHQUFsQixVQUFtQixTQUFlO1FBQWxDLGlCQXlDQztRQXhDRyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN0QixPQUFPO1NBQ1Y7UUFDRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNMLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDN0IsT0FBTztTQUNWO1FBQ0QsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztZQUNqRCxRQUFRLEVBQUUsRUFBRTtTQUNmLENBQUMsQ0FBQztRQUVILGVBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUVwRCxlQUFlLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDckQsSUFBSSxRQUFRLEdBQUcsQ0FBQyxVQUFDLEdBQUc7WUFDaEIsZUFBZSxDQUFDLE9BQU8sQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3JELGVBQWUsQ0FBQyxRQUFRLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLENBQUMsQ0FBQztZQUN0RCxlQUFlLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ25DLGVBQWUsR0FBRyxJQUFJLENBQUM7WUFDdkIsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLE9BQU8sRUFBRTtnQkFDcEIsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQ3pCO2lCQUFNO2dCQUNILEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbkIsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3RCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDSCxlQUFlLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2xDLFVBQVU7UUFDVixlQUFlLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBQ3hCLGVBQWUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBQSxHQUFHO2dCQUM1QixLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN0QixlQUFlLENBQUMsT0FBTyxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3JELGVBQWUsQ0FBQyxRQUFRLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLENBQUMsQ0FBQztnQkFDdEQsZUFBZSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDbkMsZUFBZSxHQUFHLElBQUksQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBRVAsQ0FBQztJQUNELG1CQUFtQjtJQUNULDhCQUFjLEdBQXhCO1FBQ0ksT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUlEOztPQUVHO0lBQ0ksMEJBQVUsR0FBakI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFO1lBQ3pCLE9BQU87U0FDVjtRQUNELHVDQUF1QztRQUN2Qyx1Q0FBdUM7UUFDdkMsMkJBQTJCO1FBQzNCLGNBQWM7UUFDZCxJQUFJO1FBQ0osSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3pELE9BQU87U0FDVjtRQUNELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsRUFBRTtZQUFFLE9BQU87UUFDaEIsdUJBQXVCO1FBQ3ZCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbkMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxvQkFBb0I7SUFDViwrQkFBZSxHQUF6QjtRQUNJLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDUyw0QkFBWSxHQUF0QixVQUF1QixFQUFVO1FBQWpDLGlCQXNCQztRQXJCRyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1lBQ3JDLFFBQVEsRUFBRSxFQUFFO1lBQ1osS0FBSyxFQUFFO2dCQUNILElBQUksRUFBRSxDQUFDO2dCQUNQLEdBQUcsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxHQUFHO2dCQUN2QyxLQUFLLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsRUFBRTthQUMxQztTQUNKLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDcEQsNERBQTREO1FBRTVELElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFVBQUEsR0FBRztZQUN2QixJQUFJLEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM5RixPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUM7Z0JBQy9CLEtBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQzthQUM3RTtpQkFBTTtnQkFDSCxLQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQzthQUN4RTtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQzFCLENBQUM7SUFFRDs7T0FFRztJQUNJLDRCQUFZLEdBQW5CO1FBQ0ksSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsaUNBQWlDO1lBQzNELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1NBQ3pCO1FBQ0QsaUNBQWlDO1FBQ2pDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsRUFBRTtZQUFFLE9BQU87UUFDaEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBR0Q7O09BRUc7SUFDSSxrQ0FBa0IsR0FBekIsVUFBMEIsTUFBdUI7UUFBakQsaUJBc0NDO1FBdEN5Qix1QkFBQSxFQUFBLGNBQXVCO1FBQzdDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixPQUFPO1FBQ1AsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQztRQUNyQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFO1lBQ3pCLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1lBQy9CLE9BQU87U0FDVjtRQUNELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ2xDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDTCxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUMvQixPQUFPO1NBQ1Y7UUFDRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDekQseUJBQXlCO1FBQ3pCLDJCQUEyQjtRQUMzQiwyQkFBMkI7UUFDM0IsTUFBTTtRQUNOLElBQUk7WUFDQSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO2dCQUNYLEtBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDcEIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFDLEdBQUc7Z0JBQ1QsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDdEIsS0FBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDbkMsQ0FBQyxDQUFDLENBQUM7U0FDTjtRQUFDLE9BQU8sR0FBRyxFQUFFO1lBQ1YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0QixJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztTQUNsQztRQUNELEVBQUUsQ0FBQyxPQUFPLENBQUM7WUFDUCxLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2pCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsRUFBRSxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUc7WUFDWCxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3RCLEtBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1FBQ25DLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELG9CQUFvQjtJQUNWLCtCQUFlLEdBQXpCO1FBQ0ksSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7UUFDM0MsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsRUFBRTtZQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUM7WUFDcEMsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRUQ7O09BRUc7SUFDSSw0QkFBWSxHQUFuQjtRQUNJLElBQUksc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtZQUN0QyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLDJCQUFXLEdBQWxCO1FBQ0ksSUFBSSxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzVCO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsK0JBQWUsR0FBZixVQUFnQixLQUFrQjtRQUFsQixzQkFBQSxFQUFBLFVBQWtCO1FBQzlCLElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQzVFLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQzdFLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDO1lBQ3JCLEtBQUssRUFBRSxLQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFHO1lBQ3JDLFFBQVEsRUFBRSxLQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFHO1lBQ3pDLEtBQUssRUFBRSxLQUFHLEtBQU87U0FDcEIsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOztPQUVHO0lBQ0gsNkJBQWEsR0FBYixVQUFjLE9BQWlCLEVBQUUsSUFBZSxFQUFFLEtBQWtCO1FBQWxCLHNCQUFBLEVBQUEsVUFBa0I7UUFDaEUsSUFBSSxDQUFDLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDckMsYUFBYTtZQUNiLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUIsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQsSUFBSTtJQUNHLDRCQUFZLEdBQW5CLFVBQW9CLElBS25CO1FBQ0csSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLElBQUksR0FBRztnQkFDSCxTQUFTLEVBQUUsSUFBSTtnQkFDZixPQUFPLEVBQUUsVUFBQyxHQUFHO29CQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3hCLENBQUM7Z0JBQ0QsSUFBSSxFQUFFLFVBQUMsR0FBRztvQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN4QixDQUFDO2FBQ0osQ0FBQztTQUNMO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUk7SUFDRyw0QkFBWSxHQUFuQixVQUFvQixJQUluQjtRQUNHLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsRUFBRTtZQUNyRCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7WUFDdEMsT0FBTztTQUNWO1FBQ0QsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLElBQUksR0FBRztnQkFDSCxPQUFPLEVBQUUsVUFBQyxHQUFHO29CQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUNoQyxDQUFDO2dCQUNELElBQUksRUFBRSxVQUFDLEdBQUc7b0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ2hDLENBQUM7Z0JBQ0QsUUFBUSxFQUFFLFVBQUMsR0FBRztvQkFDVixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDbEMsQ0FBQzthQUNKLENBQUM7U0FDTDtRQUNELElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFHTSwwQkFBVSxHQUFqQjtRQUFBLGlCQXVCQztRQXRCRyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBQ3JDLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ25CLE9BQU87U0FDVjtRQUNELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM1QixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQztZQUMvQixRQUFRLEVBQUUsRUFBRTtTQUNmLENBQUMsQ0FBQztRQUNILE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUM7WUFDZixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3hCLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUMsR0FBRztZQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNqQixLQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ3pCLENBQUM7SUFFRCxNQUFNO0lBQ0MsMkJBQVcsR0FBbEI7SUFFQSxDQUFDO0lBRUwsWUFBQztBQUFELENBOVNBLEFBOFNDLENBOVNrQyxhQUFHLEdBOFNyQyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBTREsgZnJvbSBcIi4vU0RLXCI7XG5pbXBvcnQgR2FtZVBsYXRmb3JtIGZyb20gXCIuLi9HYW1lUGxhdGZvcm1cIjtcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFFRU0RLIGV4dGVuZHMgU0RLIHtcbiAgICBwcm90ZWN0ZWQgYXBpTmFtZTogc3RyaW5nID0gJ3FxJztcblxuICAgIHB1YmxpYyBpbml0KCkge1xuICAgICAgICB0aGlzLmFwaSA9IHdpbmRvd1t0aGlzLmFwaU5hbWVdO1xuICAgICAgICB0aGlzLnN5c3RlbUluZm8gPSB0aGlzLmFwaS5nZXRTeXN0ZW1JbmZvU3luYygpO1xuICAgICAgICBjb25zb2xlLmxvZyhcIlFR5bCP5ri45oiP57O757uf5L+h5oGv77yaXCIpO1xuICAgICAgICBjb25zb2xlLmxvZyh0aGlzLnN5c3RlbUluZm8pO1xuICAgICAgICB0aGlzLmFwaS5zaG93U2hhcmVNZW51KHsgd2l0aFNoYXJlVGlja2V0OiBmYWxzZSB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDop4bpopHlub/lkYpcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hvd1ZpZGVvQWQodmlkZW9OYW1lPzogYW55KSB7XG4gICAgICAgIGlmICghdGhpcy5jYW5BcGlVc2VWaWRlbygpKSB7XG4gICAgICAgICAgICB0aGlzLm9uVmlkZW9TdWNjZXNzKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGlkID0gdGhpcy5nZXRWaWRlb0FkVW5pdElkKHZpZGVvTmFtZSk7XG4gICAgICAgIGlmICghaWQpIHtcbiAgICAgICAgICAgIHRoaXMub25WaWRlb0ZhaWwoXCLojrflj5bop4bpopFpZOWksei0pVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgcmV3YXJkZWRWaWRlb0FkID0gdGhpcy5hcGkuY3JlYXRlUmV3YXJkZWRWaWRlb0FkKHtcbiAgICAgICAgICAgIGFkVW5pdElkOiBpZCxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV3YXJkZWRWaWRlb0FkLm9uTG9hZCh0aGlzLm9uVmlkZW9TaG93LmJpbmQodGhpcykpO1xuXG4gICAgICAgIHJld2FyZGVkVmlkZW9BZC5vbkVycm9yKHRoaXMub25WaWRlb0ZhaWwuYmluZCh0aGlzKSk7XG4gICAgICAgIGxldCBjbG9zZWZ1biA9ICgocmVzKSA9PiB7XG4gICAgICAgICAgICByZXdhcmRlZFZpZGVvQWQub2ZmTG9hZCh0aGlzLm9uVmlkZW9TaG93LmJpbmQodGhpcykpO1xuICAgICAgICAgICAgcmV3YXJkZWRWaWRlb0FkLm9mZkVycm9yKHRoaXMub25WaWRlb0ZhaWwuYmluZCh0aGlzKSk7XG4gICAgICAgICAgICByZXdhcmRlZFZpZGVvQWQub2ZmQ2xvc2UoY2xvc2VmdW4pO1xuICAgICAgICAgICAgcmV3YXJkZWRWaWRlb0FkID0gbnVsbDtcbiAgICAgICAgICAgIGlmIChyZXMgJiYgcmVzLmlzRW5kZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9uVmlkZW9TdWNjZXNzKCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb1F1aXQoKTtcbiAgICAgICAgICAgICAgICB0aGlzLm9uVmlkZW9IaWRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXdhcmRlZFZpZGVvQWQub25DbG9zZShjbG9zZWZ1bik7XG4gICAgICAgIC8v5byA5aeL5Yqg6L296KeG6aKR5bm/5ZGKXG4gICAgICAgIHJld2FyZGVkVmlkZW9BZC5sb2FkKCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICByZXdhcmRlZFZpZGVvQWQuc2hvdygpLmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5vblZpZGVvRmFpbChlcnIpO1xuICAgICAgICAgICAgICAgIHJld2FyZGVkVmlkZW9BZC5vZmZMb2FkKHRoaXMub25WaWRlb1Nob3cuYmluZCh0aGlzKSk7XG4gICAgICAgICAgICAgICAgcmV3YXJkZWRWaWRlb0FkLm9mZkVycm9yKHRoaXMub25WaWRlb0ZhaWwuYmluZCh0aGlzKSk7XG4gICAgICAgICAgICAgICAgcmV3YXJkZWRWaWRlb0FkLm9mZkNsb3NlKGNsb3NlZnVuKTtcbiAgICAgICAgICAgICAgICByZXdhcmRlZFZpZGVvQWQgPSBudWxsO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgfVxuICAgIC8qKuiDveWQpuS9v+eUqGFwae+8mnZpZGVvICovXG4gICAgcHJvdGVjdGVkIGNhbkFwaVVzZVZpZGVvKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICAvL+W9k+WJjeW5v+WRiuOAglxuICAgIHByaXZhdGUgX2Jhbm5lckFkOiBhbnk7XG4gICAgLyoqXG4gICAgICog5omT5byAYmFubmVyXG4gICAgICovXG4gICAgcHVibGljIHNob3dCYW5uZXIoKSB7XG4gICAgICAgIGlmICghdGhpcy5jYW5BcGlVc2VCYW5uZXIoKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIGlmICh0aGlzLmluc2VydEFkUmVjb3JkLmlzU2hvd2luZykge1xuICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCLmnInmj5LlsY/mmL7npLrvvIzkuI3lho3mmL7npLpiYW5uZXJcIik7XG4gICAgICAgIC8vICAgICB0aGlzLnJlbW92ZUJhbm5lcigpO1xuICAgICAgICAvLyAgICAgcmV0dXJuO1xuICAgICAgICAvLyB9XG4gICAgICAgIGlmICghIXRoaXMuX2Jhbm5lckFkKSB7XG4gICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5zaG93KCkudGhlbih0aGlzLm9uQmFubmVyU2hvdy5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgaWQgPSB0aGlzLmdldEJhbm5lcklkKCk7XG4gICAgICAgIGlmICghaWQpIHJldHVybjtcbiAgICAgICAgLy8gdGhpcy5yZW1vdmVCYW5uZXIoKTtcbiAgICAgICAgbGV0IGJhbm5lciA9IHRoaXMuY3JlYXRlQmFubmVyKGlkKTtcbiAgICAgICAgYmFubmVyLnNob3coKS50aGVuKHRoaXMub25CYW5uZXJTaG93LmJpbmQodGhpcykpO1xuICAgIH1cbiAgICAvKirog73lkKbkvb/nlKhhcGnvvJpiYW5uZXIgKi9cbiAgICBwcm90ZWN0ZWQgY2FuQXBpVXNlQmFubmVyKCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIGNyZWF0ZUJhbm5lcihpZDogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX2Jhbm5lckFkID0gdGhpcy5hcGkuY3JlYXRlQmFubmVyQWQoe1xuICAgICAgICAgICAgYWRVbml0SWQ6IGlkLFxuICAgICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgICAgICBsZWZ0OiAwLFxuICAgICAgICAgICAgICAgIHRvcDogdGhpcy5zeXN0ZW1JbmZvLnNjcmVlbkhlaWdodCAtIDEzMCxcbiAgICAgICAgICAgICAgICB3aWR0aDogdGhpcy5zeXN0ZW1JbmZvLnNjcmVlbldpZHRoICsgNTAsXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuX2Jhbm5lckFkLm9uRXJyb3IodGhpcy5vbkJhbm5lckVyci5iaW5kKHRoaXMpKTtcbiAgICAgICAgLy8gdGhpcy5fYmFubmVyQWQuc2hvdygpLnRoZW4odGhpcy5vbkJhbm5lclNob3cuYmluZCh0aGlzKSk7XG5cbiAgICAgICAgdGhpcy5fYmFubmVyQWQub25SZXNpemUocmVzID0+IHtcbiAgICAgICAgICAgIGlmICh0aGlzLnN5c3RlbUluZm8ucGxhdGZvcm0gPT0gXCJpb3NcIiAmJiBjYy52aXNpYmxlUmVjdFtcImhlaWdodFwiXSAvIGNjLnZpc2libGVSZWN0W1wid2lkdGhcIl0gPj0gMikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6Iu55p6c5YiY5rW35bGP5omL5py66LCD55SoYmFubmVyXCIpO1xuICAgICAgICAgICAgICAgIHRoaXMuX2Jhbm5lckFkLnN0eWxlLnRvcCA9IHRoaXMuc3lzdGVtSW5mby5zY3JlZW5IZWlnaHQgLSByZXMuaGVpZ2h0IC0gMjA7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuX2Jhbm5lckFkLnN0eWxlLnRvcCA9IHRoaXMuc3lzdGVtSW5mby5zY3JlZW5IZWlnaHQgLSByZXMuaGVpZ2h0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jhbm5lckFkO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOWFs+mXreW5v+WRilxuICAgICAqL1xuICAgIHB1YmxpYyByZW1vdmVCYW5uZXIoKSB7XG4gICAgICAgIGlmICh0aGlzLl9iYW5uZXJBZCkge1xuICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQub2ZmRXJyb3IodGhpcy5vbkJhbm5lckVyci5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIHRoaXMuX2Jhbm5lckFkLm9mZlJlc2l6ZSgpO1xuICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQuZGVzdHJveSgpOyAvL+imgeWFiOaKiuaXp+eahOW5v+WRiue7memUgOavge+8jOS4jeeEtuS8muWvvOiHtOWFtuebkeWQrOeahOS6i+S7tuaXoOazlemHiuaUvu+8jOW9seWTjeaAp+iDvVxuICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIC8v6ZSA5q+B5b2T5YmNYmFubmVy5ZCO77yM56uL5Y2z5Yib5bu65paw55qEYmFubmVy77yM5L2G5LiN5pi+56S65Ye65p2lXG4gICAgICAgIGxldCBpZCA9IHRoaXMuZ2V0QmFubmVySWQoKTtcbiAgICAgICAgaWYgKCFpZCkgcmV0dXJuO1xuICAgICAgICB0aGlzLmNyZWF0ZUJhbm5lcihpZCk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiDmj5LlsY/lub/lkYpcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hvd0ludGVyc3RpdGlhbEFkKGJhbm5lcjogYm9vbGVhbiA9IGZhbHNlKSB7XG4gICAgICAgIHRoaXMuc2hvd0Jhbm5lcigpO1xuICAgICAgICByZXR1cm47XG4gICAgICAgIHRoaXMudXNlQmFubmVySW5zdGVhZEluc2VydCA9IGJhbm5lcjtcbiAgICAgICAgaWYgKCF0aGlzLmNhbkFwaVVzZUluc2VydCgpKSB7XG4gICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGlkID0gdGhpcy5nZXRJbnNlcnRBZFVuaXRJZCgpO1xuICAgICAgICBpZiAoIWlkKSB7XG4gICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGFkID0gdGhpcy5hcGkuY3JlYXRlSW50ZXJzdGl0aWFsQWQoeyBhZFVuaXRJZDogaWQgfSk7XG4gICAgICAgIC8vIGFkLnNob3coKS50aGVuKCgpID0+IHtcbiAgICAgICAgLy8gICAgIHRoaXMucmVtb3ZlQmFubmVyKCk7XG4gICAgICAgIC8vICAgICB0aGlzLm9uSW5zZXJ0U2hvdygpO1xuICAgICAgICAvLyB9KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGFkLnNob3coKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZUJhbm5lcigpO1xuICAgICAgICAgICAgICAgIHRoaXMub25JbnNlcnRTaG93KCk7XG4gICAgICAgICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5vbkluc2VydEVycihlcnIpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHRoaXMub25JbnNlcnRFcnIoZXJyKTtcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgfVxuICAgICAgICBhZC5vbkNsb3NlKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMub25JbnNlcnRIaWRlKCk7XG4gICAgICAgICAgICBhZC5kZXN0cm95KCk7XG4gICAgICAgIH0pO1xuICAgICAgICBhZC5vbkVycm9yKChlcnIpID0+IHtcbiAgICAgICAgICAgIHRoaXMub25JbnNlcnRFcnIoZXJyKTtcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKuiDveWQpuS9v+eUqGFwae+8mmluc2VydCAqL1xuICAgIHByb3RlY3RlZCBjYW5BcGlVc2VJbnNlcnQoKSB7XG4gICAgICAgIGNvbnN0IHZlcnNpb24gPSB0aGlzLnN5c3RlbUluZm8uU0RLVmVyc2lvbjtcbiAgICAgICAgaWYgKHRoaXMubGVzc1RoYW4odmVyc2lvbiwgJzEuMTIuMCcpKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygn5Z+656GA5bqT54mI5pys5L2O5LqOMS4xMi4w77yM5o+S5bGP5peg5rOV5pi+56S6Jyk7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog55+t6ZyH5YqoXG4gICAgICovXG4gICAgcHVibGljIHZpYnJhdGVTaG9ydCgpIHtcbiAgICAgICAgaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlicmF0ZSkge1xuICAgICAgICAgICAgdGhpcy5hcGkudmlicmF0ZVNob3J0KHt9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOmVv+mch+WKqFxuICAgICAqL1xuICAgIHB1YmxpYyB2aWJyYXRlTG9uZygpIHtcbiAgICAgICAgaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlicmF0ZSkge1xuICAgICAgICAgICAgdGhpcy5hcGkudmlicmF0ZUxvbmcoe30pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5peg5r+A5Yqx5YiG5LqrJibluKblj4LliIbkuqtcbiAgICAgKi9cbiAgICBzaGFyZUFwcE1lc3NhZ2UocXVlcnk6IHN0cmluZyA9IFwiXCIpIHtcbiAgICAgICAgbGV0IGluZGV4OiBudW1iZXIgPSBNYXRoLmZsb29yKChNYXRoLnJhbmRvbSgpICogdGhpcy5zaGFyZVRpdGxlQXJyLmxlbmd0aCkpO1xuICAgICAgICBsZXQgaW5kZXhpbWc6IG51bWJlciA9IE1hdGguZmxvb3IoKE1hdGgucmFuZG9tKCkgKiB0aGlzLnNoYXJlSW1nQXJyLmxlbmd0aCkpO1xuICAgICAgICB0aGlzLmFwaS5zaGFyZUFwcE1lc3NhZ2Uoe1xuICAgICAgICAgICAgdGl0bGU6IGAke3RoaXMuc2hhcmVUaXRsZUFycltpbmRleF19YCxcbiAgICAgICAgICAgIGltYWdlVXJsOiBgJHt0aGlzLnNoYXJlSW1nQXJyW2luZGV4aW1nXX1gLFxuICAgICAgICAgICAgcXVlcnk6IGAke3F1ZXJ5fWAsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOa/gOWKseWIhuS6qyYm5bim5Y+C5YiG5LqrXG4gICAgICovXG4gICAgc2hhcmVUb0FueU9uZShzdWNjZXNzOiBGdW5jdGlvbiwgZmFpbD86IEZ1bmN0aW9uLCBxdWVyeTogc3RyaW5nID0gJycpIHtcbiAgICAgICAgaWYgKCFHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLnNoYXJlKSB7XG4gICAgICAgICAgICAvLyBzdWNjZXNzKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zaGFyZUFwcE1lc3NhZ2UocXVlcnkpO1xuICAgICAgICBzdWNjZXNzKCk7XG4gICAgfVxuXG4gICAgLy/orqLpmIVcbiAgICBwdWJsaWMgc3Vic2NyaWJlTXNnKGRhdGE/OiB7XG4gICAgICAgIHRtcGxJZHM/OiBzdHJpbmdbXSwgICAgIC8v6ZyA6K6i6ZiF55qE5raI5oGv5qih5p2/55qEaWTnmoTpm4blkIjvvIzkuIDmrKHosIPnlKjmnIDlpJrlj6/orqLpmIUz5p2h5raI5oGv44CCXG4gICAgICAgIHN1YnNjcmliZTogYm9vbGVhbiwgICAgIC8vdHJ1ZTrorqLpmIUsZmFsc2U65Y+W5raI6K6i6ZiFXG4gICAgICAgIHN1Y2Nlc3M6IChyZXMpID0+IHZvaWQsIC8v5o6l5Y+j6LCD55So5oiQ5Yqf5Zue6LCDXG4gICAgICAgIGZhaWw6IChyZXMpID0+IHZvaWQsICAgIC8v5o6l5Y+j6LCD55So5aSx6LSl5Zue6LCDXG4gICAgfSkge1xuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBkYXRhKSB7XG4gICAgICAgICAgICBkYXRhID0ge1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiAocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6K6i6ZiF5oiQ5YqfXCIpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZmFpbDogKHJlcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuiuoumYheWksei0pVwiKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFwaS5zdWJzY3JpYmVBcHBNc2coZGF0YSk7XG4gICAgfVxuICAgIC8v5b2p562+XG4gICAgcHVibGljIGFkZENvbG9yU2lnbihkYXRhPzoge1xuICAgICAgICBzdWNjZXNzOiAocmVzKSA9PiB2b2lkLFxuICAgICAgICBmYWlsOiAocmVzKSA9PiB2b2lkLFxuICAgICAgICBjb21wbGV0ZTogKHJlcykgPT4gdm9pZCxcbiAgICB9KSB7XG4gICAgICAgIGlmICh0aGlzLmxlc3NUaGFuKHRoaXMuc3lzdGVtSW5mby5TREtWZXJzaW9uLCBcIjEuMTAuMFwiKSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLln7rnoYDlupPniYjmnKzkvY7kuo4xLjEwLjDvvIzml6Dms5Xkvb/nlKjlvannrb7lip/og71cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gZGF0YSkge1xuICAgICAgICAgICAgZGF0YSA9IHtcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiAocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2p562+5re75Yqg5oiQ5YqfLFwiLCByZXMpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZmFpbDogKHJlcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuW9qeetvua3u+WKoOWksei0pSxcIiwgcmVzKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGNvbXBsZXRlOiAocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2p562+5o6l5Y+j6LCD55So5a6M5oiQ77yMXCIsIHJlcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFwaS5hZGRDb2xvclNpZ24oZGF0YSk7XG4gICAgfVxuICAgIC8v55uS5a2Q5bm/5ZGKXG4gICAgcHJvdGVjdGVkIGFwcEJveDogYW55ID0gbnVsbDtcbiAgICBwdWJsaWMgc2hvd0FwcEJveCgpIHtcbiAgICAgICAgaWYgKHRoaXMubGVzc1RoYW4odGhpcy5zeXN0ZW1JbmZvLlNES1ZlcnNpb24sIFwiMS43LjFcIikpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Z+656GA5bqT54mI5pys5L2O5LqOMS43LjHvvIznm5LlrZDlub/lkYrml6Dms5XmmL7npLpcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCEhdGhpcy5hcHBCb3gpIHtcbiAgICAgICAgICAgIHRoaXMuYXBwQm94LnNob3coKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgaWQgPSB0aGlzLmdldEFwcEJveElkKCk7XG4gICAgICAgIGxldCBhcHBCb3ggPSB0aGlzLmFwaS5jcmVhdGVBcHBCb3goe1xuICAgICAgICAgICAgYWRVbml0SWQ6IGlkLFxuICAgICAgICB9KTtcbiAgICAgICAgYXBwQm94LmxvYWQoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi55uS5a2Q5bm/5ZGK5Yqg6L295a6M5oiQXCIpO1xuICAgICAgICAgICAgYXBwQm94LnNob3coKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi55uS5a2Q5bm/5ZGK5pi+56S65oiQ5YqfXCIpO1xuICAgICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuebkuWtkOW5v+WRiuWKoOi9veWksei0pe+8mlwiLCBlcnIpO1xuICAgICAgICAgICAgYXBwQm94LmRlc3Ryb3koKTtcbiAgICAgICAgICAgIHRoaXMuYXBwQm94ID0gbnVsbDtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuYXBwQm94ID0gYXBwQm94O1xuICAgIH1cblxuICAgIC8v56ev5pyo5bm/5ZGKXG4gICAgcHVibGljIHNob3dCbG9ja0FkKCkge1xuXG4gICAgfVxuXG59XG4iXX0=