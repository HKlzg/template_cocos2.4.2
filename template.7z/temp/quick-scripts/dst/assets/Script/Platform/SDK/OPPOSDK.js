
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/SDK/OPPOSDK.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b2ee8QFZcVH4Zq3haa/D1pm', 'OPPOSDK');
// Script/Platform/SDK/OPPOSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var EventManager_1 = require("../../Common/EventManager");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var OPPOSDK = /** @class */ (function (_super) {
    __extends(OPPOSDK, _super);
    function OPPOSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'qg';
        /*******************************************原生广告*******************************************/
        /**广告类型对应的广告信息 */
        _this.nativeData = {};
        return _this;
    }
    /**
     * 初始化
     */
    OPPOSDK.prototype.init = function () {
        var _this = this;
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        console.log("系统信息：");
        console.log(JSON.stringify(this.systemInfo));
        // this.setSystemInfo(this.systemInfo.platformVersionName, this.systemInfo.system)
        this.enterTime = Date.now();
        if (this.enterTime.toString().length === 10) {
            this.enterTime *= 1000;
        }
        //初始化信息
        var self = this;
        // this.api.setLoadingProgress({
        //     progress: 0
        // });
        this.api.setEnableDebug({
            enableDebug: false,
            // enableDebug: true, // true 为打开，false 为关闭
            success: function () {
                console.log('oppo信息', JSON.stringify(self.systemInfo));
            },
            complete: function () {
            },
            fail: function () {
            }
        });
        // 初始化广告。
        // if (GamePlatform.instance.Config.video || GamePlatform.instance.Config.videoAdUnitId[0] != '') {
        //     this.api.initAdService({
        //         appId: GamePlatform.instance.Config.videoAdUnitId[0],
        //         isDebug: true,
        //         success: function (res) {
        //             console.log("初始化广告success");
        //         },
        //         fail: function (res) {
        //             console.log("初始化广告fail:" + res.code + res.msg);
        //         },
        //         complete: function (res) {
        //             console.log("complete");
        //         }
        //     })
        // }
        this.reportMonitor();
        //预先拉取原生广告数据
        setTimeout(function () {
            _this.preCreateNativeAd();
        }, 11000);
    };
    //video
    OPPOSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        console.log("展示激励视频");
        if (this.systemInfo.platformVersion < 1040) {
            this.onVideoFail('视频广告播放失败：平台版本过低');
            return;
        }
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("获取视频id失败");
            return;
        }
        if (this.videoAd) {
            this.videoAd.destroy();
        }
        this.videoAd = this.api.createRewardedVideoAd({ posId: id });
        this.videoAd.load();
        this.videoAd.onLoad(function () {
            _this.videoAd.show();
            _this.onVideoShow();
        });
        this.videoAd.onClose(function (res) {
            if (res.isEnded) {
                _this.onVideoSuccess();
            }
            else {
                _this.onVideoHide();
                _this.onVideoQuit();
            }
        });
        this.videoAd.onError(function (err) {
            _this.onVideoFail(err);
        });
    };
    OPPOSDK.prototype.showBanner = function () {
        console.log("展示banner");
        if (this.insertAdRecord.isShowing) {
            console.log("插屏广告正在显示，无法同时显示banner");
            this.removeBanner();
            return;
        }
        if (!!this.bannerShowing) {
            console.log("banner尚未隐藏，无需再次显示");
            return;
        }
        var t = Date.now();
        if (t.toString().length === 10) {
            t *= 1000;
        }
        if (Date.now() - this.enterTime < 10000) {
            console.log("为避免闪屏页出现banner，进入游戏10秒后才可以显示banner");
            return;
        }
        if (this.bannerRecord.dayHideCount >= 5) {
            console.log("用户当天已主动关闭banner达到" + this.bannerRecord.dayHideCount + "次，不再显示banner");
            return;
        }
        if (this.systemInfo.platformVersion < '1031') {
            console.log('平台版本过低');
            return;
        }
        var id = this.getBannerId();
        if (!!id)
            this.createBanner(id);
    };
    OPPOSDK.prototype.createBanner = function (id) {
        var banner = this.api.createBannerAd({ posId: id });
        if (!this.bannerAd) {
            this.bannerAd = banner;
            this.bannerAd.onShow(this.onBannerShow.bind(this));
            this.bannerAd.onError(this.onBannerErr.bind(this));
            this.bannerAd.onHide(this.onBannerHide.bind(this));
        }
        this.bannerAd.show();
        this.bannerShowing = true;
    };
    OPPOSDK.prototype.removeBanner = function () {
        if (this.bannerAd) {
            this.bannerAd.hide();
            //非玩家点击关闭按钮，还原关闭次数的记录
            this.bannerRecord.dayHideCount -= 1;
            this.bannerRecord.gameHideCount -= 1;
        }
        this.bannerShowing = false;
    };
    //插屏广告
    // protected insertAd: any;
    OPPOSDK.prototype.showInterstitialAd = function (banner) {
        if (banner === void 0) { banner = false; }
        this.useBannerInsteadInsert = banner;
        //OPPO已取消插屏广告
        this.showBannerInsteadInsert();
        return;
        console.log("展示插屏");
        if (this.systemInfo.platformVersion < 1051) {
            console.log('平台版本过低');
            this.showBannerInsteadInsert();
            return;
        }
        if (this.insertAdRecord.getShowSpaceTime() < 60) {
            console.log("两次插屏展示时间小于60秒");
            this.showBannerInsteadInsert();
            return;
        }
        if (this.insertAdRecord.dayShowCount >= 8) {
            console.log("插屏广告单用户展示一天不能超过8次");
            this.showBannerInsteadInsert();
            return;
        }
        var id = this.getInsertAdUnitId();
        if (!id)
            return;
        this.createInsertAd(id);
    };
    OPPOSDK.prototype.createInsertAd = function (id) {
        var _this = this;
        // if (!!this.insertAd) {
        //     this.insertAd.show();
        //     this.onInsertShow();
        //     return;
        // }
        var ad = this.api.createInsertAd({ posId: id }); //旧版API
        // let ad = this.api.createInterstitialAd({ adUnitId: id });//新版API，会报错导致游戏卡死……
        if (!ad) {
            this.showBannerInsteadInsert();
            return;
        }
        // this.insertAd = ad;
        ad.onLoad(function () {
            ad.show();
            _this.removeBanner();
            _this.onInsertShow();
        });
        ad.onClose(this.onInsertHide.bind(this));
        ad.onError(function (err) {
            _this.onInsertErr(err);
            _this.showBannerInsteadInsert();
        });
        ad.load();
        return ad;
    };
    /**
     * 短震动
     */
    OPPOSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    OPPOSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    OPPOSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ''; }
    };
    /**
     * 激励分享&&带参分享
     */
    OPPOSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
    };
    /**
     * 消息提示
     */
    OPPOSDK.prototype.showMessage = function (msg, icon) {
        if (icon === void 0) { icon = 'none'; }
        // this.api.showToast({
        //     title: msg,
        //     duration: 2000,
        //     icon: icon,
        //     success: (res) => { }
        // });
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTip, msg);
    };
    OPPOSDK.prototype.navigateToMiniProgram = function (data) {
        if (this.systemInfo.platformVersion < '1050') {
            console.log('平台版本过低');
            return;
        }
        this.api.navigateToMiniGame({
            pkgName: data.gameId,
        });
    };
    /**
     * 游戏运行中上报数据，主要监控游戏崩溃等异常, 目前只支持进入到游戏主界面时上报数据。
     * 注意：数据上报接口为平台必须接入的能力。
     * 接入后测试环境会默认弹出 "reportMonitor: 0"，正式环境下不会；
     * 并且需要在游戏加载的生命周期调用，只能调一次。
     */
    OPPOSDK.prototype.reportMonitor = function () {
        if (this.systemInfo.platformVersion < '1060') {
            console.log('平台版本过低');
            return;
        }
        this.api.reportMonitor('game_scene', 0);
    };
    OPPOSDK.prototype.showNativeAd = function (data) {
        var t = Date.now();
        if (t.toString().length === 10) {
            t *= 1000;
        }
        if (t - this.enterTime < 10000)
            return;
        if (undefined === this.nativeData[data.type]) {
            this.nativeData[data.type] = new NativeData();
            this.nativeData[data.type].type = data.type;
            this.nativeData[data.type].setParent(data);
            this.nativeData[data.type].needShow = true;
        }
        else {
            this.nativeData[data.type].setParent(data);
            this.nativeData[data.type].show();
        }
    };
    /**预先拉取原生广告数据，并创建对应的节点 */
    OPPOSDK.prototype.preCreateNativeAd = function () {
        var _this = this;
        var ids = this.getAllNativeAdIds();
        var _loop_1 = function (i) {
            setTimeout(function () {
                var id = ids[i];
                var ad = _this.api.createNativeAd({
                    adUnitId: id,
                });
                ad.onLoad(function (res) {
                    console.log("原生广告加载成功：" + id, res);
                    console.log("原生广告节点数据是否存在：", _this.nativeData[res.adList[0].creativeType]);
                    var index = Math.round(Math.random() * (res.adList.length - 1));
                    console.log("随机index==", index);
                    var data = res.adList[index];
                    var type = data.creativeType;
                    if (undefined === _this.nativeData[type]) {
                        console.log("新建原生广告节点数据,id==", id);
                        _this.nativeData[type] = new NativeData();
                        _this.nativeData[type].type = type;
                    }
                    _this.nativeData[type].id = id;
                    _this.nativeData[type].ad = ad;
                    _this.nativeData[type].adData = data;
                    _this.nativeData[type].dataState = 2;
                    console.log("原生广告节点状态：", _this.nativeData[type].nodeState);
                    _this.nativeData[type].createNode();
                    // this.nativeData[type].setNodeData();
                    if (_this.nativeData[type].needShow) {
                        _this.nativeData[type].showNode();
                    }
                });
                ad.onError(function (err) {
                    console.error("原生广告拉取错误：" + id);
                    console.error(err);
                    ad.offLoad();
                    ad.offError();
                    ad.destroy();
                });
                ad.load();
            }, i * 33);
        };
        for (var i = ids.length - 1; i >= 0; --i) {
            _loop_1(i);
        }
    };
    OPPOSDK.prototype.hideNativeAd = function (type) {
        if (undefined === this.nativeData[type]) {
            this.nativeData[type] = new NativeData();
            this.nativeData[type].type = type;
            this.nativeData[type].needShow = false;
        }
        else {
            this.nativeData[type].hide();
        }
    };
    OPPOSDK.prototype.hideAllNativeAd = function () {
        for (var key in this.nativeData) {
            this.nativeData[key].hide();
        }
    };
    //快速显示原生广告，暂时与常规显示相同
    OPPOSDK.prototype.quickShowNativeAd = function (data) {
        var t = Date.now();
        if (t.toString().length === 10) {
            t *= 1000;
        }
        if (t - this.enterTime < 10000)
            return;
        if (undefined === this.nativeData[data.type]) {
            this.nativeData[data.type] = new NativeData();
            this.nativeData[data.type].type = data.type;
            this.nativeData[data.type].setParent(data);
            this.nativeData[data.type].needShow = true;
        }
        else {
            this.nativeData[data.type].setParent(data);
            this.nativeData[data.type].quickShow();
        }
    };
    //快速隐藏原生广告，与常规隐藏相比，广告未被点击过时不会刷新数据
    OPPOSDK.prototype.quickHideNativeAd = function (type) {
        if (undefined === this.nativeData[type]) {
            this.nativeData[type] = new NativeData();
            this.nativeData[type].type = type;
            this.nativeData[type].needShow = false;
        }
        else {
            this.nativeData[type].quickHide();
        }
    };
    return OPPOSDK;
}(SDK_1.default));
exports.default = OPPOSDK;
var NativeData = /** @class */ (function () {
    function NativeData() {
        /**广告对象状态:0-未创建/已销毁，1-已创建，数据加载中，2-数据已加载完成 */
        this.dataState = 0;
        /**广告节点的父节点 */
        this.parent = null;
        /**节点的适配数据 */
        this.widget = {};
        /**节点状态：0-未创建，1-已创建，未设置数据，2-已设置数据，未显示，3-已显示，未点击，4-已被点击，5-已隐藏 */
        this.nodeState = 0;
        this.dataState = 0;
        this.nodeState = 0;
        this.needShow = false;
    }
    NativeData.prototype.setParent = function (data) {
        if (!data.parent) {
            this.parent = cc.find("Canvas/NativeAd");
            if (!this.parent) {
                this.parent = cc.find("Canvas");
            }
        }
        else {
            this.parent = data.parent;
        }
        this.widget = data.widget;
        if (!!this.node) {
            this.node.parent = this.parent;
            this.setWidget(this.node, this.widget);
        }
    };
    NativeData.prototype.show = function () {
        console.log("显示原生广告方法，dataState:", this.dataState);
        switch (this.dataState) {
            case 0: {
                this.needShow = true;
                this.loadNativeAd();
                break;
            }
            case 1: {
                this.needShow = true;
                break;
            }
            case 2: {
                switch (this.nodeState) {
                    case 0: {
                        this.needShow = true;
                        break;
                    }
                    case 1: {
                        this.setNodeData();
                        this.showNode();
                        break;
                    }
                    case 2: {
                        this.showNode();
                        break;
                    }
                    case 5: {
                        this.showNode();
                        break;
                    }
                }
            }
        }
    };
    NativeData.prototype.hide = function () {
        this.needShow = false;
        //数据
        switch (this.dataState) {
            case 0: {
                this.loadNativeAd();
                break;
            }
            case 1: {
                break;
            }
            case 2: {
                if (this.nodeState === 3
                    || this.nodeState === 4) {
                    this.destroyAd();
                    this.loadNativeAd();
                }
                break;
            }
        }
        //节点
        this.hideNode();
    };
    //快速显示
    NativeData.prototype.quickShow = function () {
        this.show();
    };
    //快速隐藏，广告未被点击过时，不会刷新数据
    NativeData.prototype.quickHide = function () {
        this.needShow = false;
        //数据
        switch (this.dataState) {
            case 0: {
                this.loadNativeAd();
                break;
            }
            case 1: {
                break;
            }
            case 2: {
                if (this.nodeState === 4) {
                    this.destroyAd();
                    this.loadNativeAd();
                }
                break;
            }
        }
        //节点
        this.hideNode();
    };
    NativeData.prototype.loadNativeAd = function () {
        var _this = this;
        console.log("预加载下次需要显示的原生广告数据");
        var ad = window["qg"].createNativeAd({
            adUnitId: this.id,
        });
        ad.onLoad(function (res) {
            console.log("原生广告加载成功：", res);
            _this.dataState = 2;
            var index = Math.round(Math.random() * (res.adList.length - 1));
            var data = res.adList[index];
            _this.adData = data;
            //todo:创建节点，设置数据
            _this.createNode();
            _this.setNodeData();
            if (_this.needShow) {
                _this.showNode();
            }
        });
        ad.onError(function (err) {
            console.error("原生广告拉取错误：");
            console.error(err);
            _this.destroyAd();
        });
        ad.load();
        this.ad = ad;
        this.dataState = 1;
    };
    NativeData.prototype.destroyAd = function () {
        if (!!this.ad) {
            this.ad.offLoad();
            this.ad.offError();
            this.ad.destroy();
            this.ad = null;
        }
        this.dataState = 0;
        if (!!this.node) {
            var js = this.node.getComponent("NativeAd" + this.type);
            js.reset();
            this.nodeState = 1;
        }
    };
    NativeData.prototype.setNodeData = function () {
        //todo
        if (!this.node) {
            return;
        }
        var js = this.node.getComponent("NativeAd" + this.type);
        js.setData(this.adData);
        this.nodeState = 2;
    };
    NativeData.prototype.showNode = function () {
        if (!!this.node) {
            console.log("显示原生广告节点，type==", this.type);
            this.node.active = true;
            this.node.parent = this.parent;
            this.setWidget(this.node, this.widget);
            this.nodeState = 3;
        }
    };
    NativeData.prototype.onClickNode = function () {
        this.ad.reportAdClick({
            adId: this.adData.adId,
        });
        this.nodeState = 4;
    };
    NativeData.prototype.hideNode = function () {
        if (!!this.node) {
            this.node.active = false;
        }
        this.nodeState = 5;
    };
    NativeData.prototype.createNode = function () {
        var _this = this;
        if (!!this.node)
            return;
        // return;
        cc.loader.loadRes("NativeAd/OPPO/NativeAd" + this.type, cc.Prefab, function (err, res) {
            if (!!err) {
                console.error("原生广告预制件加载失败，type：", _this.type);
                console.error(err);
                return;
            }
            var node = cc.instantiate(res);
            node.on("touchend", _this.onClickNode, _this);
            _this.node = node;
            if (!!_this.parent) {
                _this.node.parent = _this.parent;
                _this.setWidget(_this.node, _this.widget);
            }
            _this.nodeState = 1;
            _this.setNodeData();
            console.log("加载原生广告预制件" + _this.type + "完成，是否显示：", _this.needShow);
            if (_this.needShow) {
                _this.showNode();
            }
        });
    };
    //设置布局组件
    NativeData.prototype.setWidget = function (node, widget, targetNode) {
        var wg = node.getComponent(cc.Widget);
        if (!wg) {
            wg = node.addComponent(cc.Widget);
        }
        wg.isAbsoluteBottom = true;
        wg.isAbsoluteLeft = true;
        wg.isAbsoluteRight = true;
        wg.isAbsoluteTop = true;
        wg.isAbsoluteHorizontalCenter = true;
        wg.isAbsoluteVerticalCenter = true;
        if (!widget)
            return;
        if (!!targetNode) {
            wg.target = targetNode;
        }
        else {
            wg.target = node.parent;
        }
        if (undefined != widget.top) {
            wg.isAlignTop = true;
            wg.top = parseFloat(widget.top);
        }
        else {
            wg.isAlignTop = false;
        }
        if (undefined != widget.bottom) {
            wg.isAlignBottom = true;
            wg.bottom = parseFloat(widget.bottom);
        }
        else {
            wg.isAlignBottom = false;
        }
        if (undefined != widget.left) {
            wg.isAlignLeft = true;
            wg.left = parseFloat(widget.left);
        }
        else {
            wg.isAlignLeft = false;
        }
        if (undefined != widget.right) {
            wg.isAlignRight = true;
            wg.right = parseFloat(widget.right);
        }
        else {
            wg.isAlignRight = false;
        }
        wg.isAlignHorizontalCenter = !!widget.horizontalCenter;
        wg.isAlignVerticalCenter = !!widget.verticalCenter;
        wg.updateAlignment();
    };
    return NativeData;
}());

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcU0RLXFxPUFBPU0RLLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDZCQUF3QjtBQUN4QixnREFBMkM7QUFDM0MsMERBQXFEO0FBQ3JELGlFQUE0RDtBQUU1RDtJQUFxQywyQkFBRztJQUF4QztRQUFBLHFFQTRYQztRQTNYVyxhQUFPLEdBQVcsSUFBSSxDQUFDO1FBMlEvQiw0RkFBNEY7UUFDNUYsaUJBQWlCO1FBQ1AsZ0JBQVUsR0FBbUMsRUFBRSxDQUFDOztJQThHOUQsQ0FBQztJQXpYRzs7T0FFRztJQUNJLHNCQUFJLEdBQVg7UUFBQSxpQkFnREM7UUEvQ0csSUFBSSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBQzdDLGtGQUFrRjtRQUNsRixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUM1QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxLQUFLLEVBQUUsRUFBRTtZQUN6QyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQztTQUMxQjtRQUNELE9BQU87UUFDUCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsZ0NBQWdDO1FBQ2hDLGtCQUFrQjtRQUNsQixNQUFNO1FBQ04sSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7WUFDcEIsV0FBVyxFQUFFLEtBQUs7WUFDbEIsMkNBQTJDO1lBQzNDLE9BQU8sRUFBRTtnQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFBO1lBQzFELENBQUM7WUFDRCxRQUFRLEVBQUU7WUFDVixDQUFDO1lBQ0QsSUFBSSxFQUFFO1lBQ04sQ0FBQztTQUNKLENBQUMsQ0FBQztRQUNILFNBQVM7UUFDVCxtR0FBbUc7UUFDbkcsK0JBQStCO1FBQy9CLGdFQUFnRTtRQUNoRSx5QkFBeUI7UUFDekIsb0NBQW9DO1FBQ3BDLDJDQUEyQztRQUMzQyxhQUFhO1FBQ2IsaUNBQWlDO1FBQ2pDLDhEQUE4RDtRQUM5RCxhQUFhO1FBQ2IscUNBQXFDO1FBQ3JDLHVDQUF1QztRQUN2QyxZQUFZO1FBQ1osU0FBUztRQUNULElBQUk7UUFDSixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIsWUFBWTtRQUNaLFVBQVUsQ0FBQztZQUNQLEtBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQzdCLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNkLENBQUM7SUFFRCxPQUFPO0lBQ0EsNkJBQVcsR0FBbEIsVUFBbUIsU0FBZTtRQUFsQyxpQkFnQ0M7UUEvQkcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN0QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLElBQUksRUFBRTtZQUN4QyxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDcEMsT0FBTztTQUNWO1FBQ0QsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDTCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzdCLE9BQU87U0FDVjtRQUVELElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNkLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFDRCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO1lBQ2hCLEtBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDcEIsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsVUFBQyxHQUFHO1lBQ3JCLElBQUksR0FBRyxDQUFDLE9BQU8sRUFBRTtnQkFDYixLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7YUFDekI7aUJBQU07Z0JBQ0gsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixLQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDdEI7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQUMsR0FBRztZQUNyQixLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUtNLDRCQUFVLEdBQWpCO1FBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN4QixJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFO1lBQy9CLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQztZQUNyQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUN0QixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDakMsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sS0FBSyxFQUFFLEVBQUU7WUFDNUIsQ0FBQyxJQUFJLElBQUksQ0FBQztTQUNiO1FBQ0QsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLEVBQUU7WUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO1lBQ2xELE9BQU87U0FDVjtRQUNELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLElBQUksQ0FBQyxFQUFFO1lBQ3JDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEdBQUcsY0FBYyxDQUFDLENBQUM7WUFDbkYsT0FBTztTQUNWO1FBQ0QsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxNQUFNLEVBQUU7WUFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN0QixPQUFPO1NBQ1Y7UUFDRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNTLDhCQUFZLEdBQXRCLFVBQXVCLEVBQVU7UUFDN0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNoQixJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQztZQUN2QixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ25ELElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDbkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN0RDtRQUNELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7SUFDOUIsQ0FBQztJQUNNLDhCQUFZLEdBQW5CO1FBQ0ksSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNyQixxQkFBcUI7WUFDckIsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLElBQUksQ0FBQyxDQUFDO1lBQ3BDLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxJQUFJLENBQUMsQ0FBQztTQUN4QztRQUNELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFFRCxNQUFNO0lBQ04sMkJBQTJCO0lBQ3BCLG9DQUFrQixHQUF6QixVQUEwQixNQUF1QjtRQUF2Qix1QkFBQSxFQUFBLGNBQXVCO1FBQzdDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxNQUFNLENBQUM7UUFDckMsYUFBYTtRQUNiLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1FBQy9CLE9BQU87UUFDUCxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsSUFBSSxFQUFFO1lBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDdEIsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0IsT0FBTztTQUNWO1FBQ0QsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQzdDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDN0IsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0IsT0FBTztTQUNWO1FBQ0QsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksSUFBSSxDQUFDLEVBQUU7WUFDdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQ2pDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1lBQy9CLE9BQU87U0FDVjtRQUNELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ2xDLElBQUksQ0FBQyxFQUFFO1lBQUUsT0FBTztRQUNoQixJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFDUyxnQ0FBYyxHQUF4QixVQUF5QixFQUFVO1FBQW5DLGlCQXlCQztRQXhCRyx5QkFBeUI7UUFDekIsNEJBQTRCO1FBQzVCLDJCQUEyQjtRQUMzQixjQUFjO1FBQ2QsSUFBSTtRQUNKLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQSxPQUFPO1FBQ3ZELCtFQUErRTtRQUMvRSxJQUFJLENBQUMsRUFBRSxFQUFFO1lBQ0wsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0IsT0FBTztTQUNWO1FBQ0Qsc0JBQXNCO1FBQ3RCLEVBQUUsQ0FBQyxNQUFNLENBQUM7WUFDTixFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDVixLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3pDLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBQyxHQUFHO1lBQ1gsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0QixLQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztRQUNILEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNWLE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOztPQUVHO0lBQ0ksOEJBQVksR0FBbkI7UUFDSSxJQUFJLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7WUFDdEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSw2QkFBVyxHQUFsQjtRQUNJLElBQUksc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtZQUN0QyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM1QjtJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLGlDQUFlLEdBQXRCLFVBQXVCLEtBQWtCO1FBQWxCLHNCQUFBLEVBQUEsVUFBa0I7SUFFekMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksK0JBQWEsR0FBcEIsVUFBcUIsT0FBaUIsRUFBRSxJQUFlLEVBQUUsS0FBa0I7UUFBbEIsc0JBQUEsRUFBQSxVQUFrQjtJQUUzRSxDQUFDO0lBRUQ7O09BRUc7SUFDSSw2QkFBVyxHQUFsQixVQUFtQixHQUFXLEVBQUUsSUFBcUI7UUFBckIscUJBQUEsRUFBQSxhQUFxQjtRQUNqRCx1QkFBdUI7UUFDdkIsa0JBQWtCO1FBQ2xCLHNCQUFzQjtRQUN0QixrQkFBa0I7UUFDbEIsNEJBQTRCO1FBQzVCLE1BQU07UUFDTixzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVNLHVDQUFxQixHQUE1QixVQUE2QixJQUFTO1FBQ2xDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsTUFBTSxFQUFFO1lBQzFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDdEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztZQUN4QixPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU07U0FDdkIsQ0FBQyxDQUFBO0lBQ04sQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksK0JBQWEsR0FBcEI7UUFDSSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLE1BQU0sRUFBRTtZQUMxQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RCLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBS00sOEJBQVksR0FBbkIsVUFBb0IsSUFJbkI7UUFDRyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxLQUFLLEVBQUUsRUFBRTtZQUM1QixDQUFDLElBQUksSUFBSSxDQUFDO1NBQ2I7UUFDRCxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUs7WUFBRSxPQUFPO1FBRXZDLElBQUksU0FBUyxLQUFLLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksVUFBVSxFQUFFLENBQUM7WUFDOUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzNDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7U0FDOUM7YUFBTTtZQUNILElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUNyQztJQUNMLENBQUM7SUFFRCx5QkFBeUI7SUFDbEIsbUNBQWlCLEdBQXhCO1FBQUEsaUJBeUNDO1FBeENHLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2dDQUMxQixDQUFDO1lBQ04sVUFBVSxDQUFDO2dCQUNQLElBQUksRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIsSUFBSSxFQUFFLEdBQUcsS0FBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7b0JBQzdCLFFBQVEsRUFBRSxFQUFFO2lCQUNmLENBQUMsQ0FBQztnQkFDSCxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQUMsR0FBRztvQkFDVixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7b0JBQ25DLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO29CQUMxRSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2hFLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUNoQyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUM3QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO29CQUM3QixJQUFJLFNBQVMsS0FBSyxLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEVBQUUsQ0FBQyxDQUFDO3dCQUNuQyxLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksVUFBVSxFQUFFLENBQUM7d0JBQ3pDLEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztxQkFDckM7b0JBQ0QsS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO29CQUM5QixLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUM7b0JBQzlCLEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztvQkFDcEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO29CQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUMxRCxLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO29CQUNuQyx1Q0FBdUM7b0JBQ3ZDLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUU7d0JBQ2hDLEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO2dCQUNILEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBQyxHQUFHO29CQUNYLE9BQU8sQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQyxDQUFDO29CQUNoQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNuQixFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ2IsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNkLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDakIsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2QsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs7UUFyQ2YsS0FBSyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztvQkFBL0IsQ0FBQztTQXNDVDtJQUNMLENBQUM7SUFFTSw4QkFBWSxHQUFuQixVQUFvQixJQUFZO1FBQzVCLElBQUksU0FBUyxLQUFLLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLFVBQVUsRUFBRSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztZQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7U0FDMUM7YUFBTTtZQUNILElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDaEM7SUFDTCxDQUFDO0lBRU0saUNBQWUsR0FBdEI7UUFDSSxLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFDRCxvQkFBb0I7SUFDYixtQ0FBaUIsR0FBeEIsVUFBeUIsSUFBSTtRQUN6QixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxLQUFLLEVBQUUsRUFBRTtZQUM1QixDQUFDLElBQUksSUFBSSxDQUFDO1NBQ2I7UUFDRCxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUs7WUFBRSxPQUFPO1FBRXZDLElBQUksU0FBUyxLQUFLLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksVUFBVSxFQUFFLENBQUM7WUFDOUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzNDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7U0FDOUM7YUFBTTtZQUNILElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztTQUMxQztJQUNMLENBQUM7SUFDRCxpQ0FBaUM7SUFDMUIsbUNBQWlCLEdBQXhCLFVBQXlCLElBQUk7UUFDekIsSUFBSSxTQUFTLEtBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksVUFBVSxFQUFFLENBQUM7WUFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztTQUMxQzthQUFNO1lBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztTQUNyQztJQUNMLENBQUM7SUFDTCxjQUFDO0FBQUQsQ0E1WEEsQUE0WEMsQ0E1WG9DLGFBQUcsR0E0WHZDOztBQUVEO0lBd0JJO1FBZkEsNENBQTRDO1FBQ3JDLGNBQVMsR0FBVyxDQUFDLENBQUM7UUFJN0IsY0FBYztRQUNQLFdBQU0sR0FBWSxJQUFJLENBQUM7UUFDOUIsYUFBYTtRQUNOLFdBQU0sR0FBUSxFQUFFLENBQUM7UUFFeEIsK0RBQStEO1FBQ3hELGNBQVMsR0FBVyxDQUFDLENBQUM7UUFLekIsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUVNLDhCQUFTLEdBQWhCLFVBQWlCLElBQUk7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDZCxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUN6QyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDZCxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDbkM7U0FDSjthQUFNO1lBQ0gsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1NBQzdCO1FBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzFCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQy9CLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDMUM7SUFDTCxDQUFDO0lBRU0seUJBQUksR0FBWDtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25ELFFBQVEsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNwQixLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUNKLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO2dCQUNyQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3BCLE1BQU07YUFDVDtZQUNELEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ0osSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7Z0JBQ3JCLE1BQU07YUFDVDtZQUNELEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ0osUUFBUSxJQUFJLENBQUMsU0FBUyxFQUFFO29CQUNwQixLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUNKLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO3dCQUNyQixNQUFNO3FCQUNUO29CQUNELEtBQUssQ0FBQyxDQUFDLENBQUM7d0JBQ0osSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUNuQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ2hCLE1BQU07cUJBQ1Q7b0JBQ0QsS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDSixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ2hCLE1BQU07cUJBQ1Q7b0JBQ0QsS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDSixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ2hCLE1BQU07cUJBQ1Q7aUJBRUo7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUNNLHlCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztRQUN0QixJQUFJO1FBQ0osUUFBUSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ3BCLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ0osSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNwQixNQUFNO2FBQ1Q7WUFDRCxLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUNKLE1BQU07YUFDVDtZQUNELEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ0osSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLENBQUM7dUJBQ2pCLElBQUksQ0FBQyxTQUFTLEtBQUssQ0FBQyxFQUFFO29CQUN6QixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ2pCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztpQkFDdkI7Z0JBQ0QsTUFBTTthQUNUO1NBQ0o7UUFDRCxJQUFJO1FBQ0osSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFDRCxNQUFNO0lBQ0MsOEJBQVMsR0FBaEI7UUFDSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDaEIsQ0FBQztJQUNELHNCQUFzQjtJQUNmLDhCQUFTLEdBQWhCO1FBQ0ksSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSTtRQUNKLFFBQVEsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNwQixLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUNKLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDcEIsTUFBTTthQUNUO1lBQ0QsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDSixNQUFNO2FBQ1Q7WUFDRCxLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUNKLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxDQUFDLEVBQUU7b0JBQ3RCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDakIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2lCQUN2QjtnQkFDRCxNQUFNO2FBQ1Q7U0FDSjtRQUNELElBQUk7UUFDSixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVNLGlDQUFZLEdBQW5CO1FBQUEsaUJBMkJDO1FBMUJHLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUNoQyxJQUFJLEVBQUUsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDO1lBQ2pDLFFBQVEsRUFBRSxJQUFJLENBQUMsRUFBRTtTQUNwQixDQUFDLENBQUM7UUFDSCxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQUMsR0FBRztZQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLEtBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1lBQ25CLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoRSxJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzdCLEtBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1lBQ25CLGdCQUFnQjtZQUNoQixLQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDbEIsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ25CLElBQUksS0FBSSxDQUFDLFFBQVEsRUFBRTtnQkFDZixLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDbkI7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNILEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBQyxHQUFHO1lBQ1gsT0FBTyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMzQixPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ25CLEtBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNyQixDQUFDLENBQUMsQ0FBQztRQUNILEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUVWLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7SUFDdkIsQ0FBQztJQUNNLDhCQUFTLEdBQWhCO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNYLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDO1NBQ2xCO1FBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNiLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDeEQsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ1gsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7U0FDdEI7SUFDTCxDQUFDO0lBRU0sZ0NBQVcsR0FBbEI7UUFDSSxNQUFNO1FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDWixPQUFPO1NBQ1Y7UUFDRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hELEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFDTSw2QkFBUSxHQUFmO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQy9CLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7U0FDdEI7SUFDTCxDQUFDO0lBQ00sZ0NBQVcsR0FBbEI7UUFDSSxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQztZQUNsQixJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJO1NBQ3pCLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFDTSw2QkFBUSxHQUFmO1FBQ0ksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNiLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztTQUM1QjtRQUNELElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFDTSwrQkFBVSxHQUFqQjtRQUFBLGlCQXVCQztRQXRCRyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSTtZQUFFLE9BQU87UUFDeEIsVUFBVTtRQUNWLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxVQUFDLEdBQUcsRUFBRSxHQUFHO1lBQ3hFLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRTtnQkFDUCxPQUFPLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDOUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDbkIsT0FBTzthQUNWO1lBQ0QsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMvQixJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxLQUFJLENBQUMsV0FBVyxFQUFFLEtBQUksQ0FBQyxDQUFDO1lBQzVDLEtBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQ2pCLElBQUksQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsS0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSSxDQUFDLE1BQU0sQ0FBQztnQkFDL0IsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFJLENBQUMsSUFBSSxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUMxQztZQUNELEtBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1lBQ25CLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxLQUFJLENBQUMsSUFBSSxHQUFHLFVBQVUsRUFBRSxLQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDakUsSUFBSSxLQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNmLEtBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUNuQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELFFBQVE7SUFDRSw4QkFBUyxHQUFuQixVQUFvQixJQUFhLEVBQUUsTUFBVyxFQUFFLFVBQW9CO1FBQ2hFLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDTCxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDckM7UUFDRCxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBQzNCLEVBQUUsQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQ3pCLEVBQUUsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQzFCLEVBQUUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLEVBQUUsQ0FBQywwQkFBMEIsR0FBRyxJQUFJLENBQUM7UUFDckMsRUFBRSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQztRQUNuQyxJQUFJLENBQUMsTUFBTTtZQUFFLE9BQU87UUFDcEIsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFO1lBQ2QsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7U0FDMUI7YUFBTTtZQUNILEVBQUUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztTQUMzQjtRQUNELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxHQUFHLEVBQUU7WUFDekIsRUFBRSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDckIsRUFBRSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ25DO2FBQU07WUFDSCxFQUFFLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztTQUN6QjtRQUNELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEVBQUU7WUFDNUIsRUFBRSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7WUFDeEIsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3pDO2FBQU07WUFDSCxFQUFFLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztTQUM1QjtRQUNELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEVBQUU7WUFDMUIsRUFBRSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFDdEIsRUFBRSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3JDO2FBQU07WUFDSCxFQUFFLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUMxQjtRQUNELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDM0IsRUFBRSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDdkIsRUFBRSxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3ZDO2FBQU07WUFDSCxFQUFFLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztTQUMzQjtRQUNELEVBQUUsQ0FBQyx1QkFBdUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1FBQ3ZELEVBQUUsQ0FBQyxxQkFBcUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQztRQUNuRCxFQUFFLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUNMLGlCQUFDO0FBQUQsQ0FwUkEsQUFvUkMsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBTREsgZnJvbSBcIi4vU0RLXCI7XG5pbXBvcnQgR2FtZVBsYXRmb3JtIGZyb20gXCIuLi9HYW1lUGxhdGZvcm1cIjtcbmltcG9ydCBFdmVudE1hbmFnZXIgZnJvbSBcIi4uLy4uL0NvbW1vbi9FdmVudE1hbmFnZXJcIjtcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi8uLi9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE9QUE9TREsgZXh0ZW5kcyBTREsge1xuICAgIHByaXZhdGUgYXBpTmFtZTogc3RyaW5nID0gJ3FnJztcblxuICAgIC8qKlxuICAgICAqIOWIneWni+WMllxuICAgICAqL1xuICAgIHB1YmxpYyBpbml0KCkge1xuICAgICAgICB0aGlzLmFwaSA9IHdpbmRvd1t0aGlzLmFwaU5hbWVdO1xuICAgICAgICB0aGlzLnN5c3RlbUluZm8gPSB0aGlzLmFwaS5nZXRTeXN0ZW1JbmZvU3luYygpO1xuICAgICAgICBjb25zb2xlLmxvZyhcIuezu+e7n+S/oeaBr++8mlwiKTtcbiAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkodGhpcy5zeXN0ZW1JbmZvKSk7XG4gICAgICAgIC8vIHRoaXMuc2V0U3lzdGVtSW5mbyh0aGlzLnN5c3RlbUluZm8ucGxhdGZvcm1WZXJzaW9uTmFtZSwgdGhpcy5zeXN0ZW1JbmZvLnN5c3RlbSlcbiAgICAgICAgdGhpcy5lbnRlclRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICBpZiAodGhpcy5lbnRlclRpbWUudG9TdHJpbmcoKS5sZW5ndGggPT09IDEwKSB7XG4gICAgICAgICAgICB0aGlzLmVudGVyVGltZSAqPSAxMDAwO1xuICAgICAgICB9XG4gICAgICAgIC8v5Yid5aeL5YyW5L+h5oGvXG4gICAgICAgIGxldCBzZWxmID0gdGhpcztcbiAgICAgICAgLy8gdGhpcy5hcGkuc2V0TG9hZGluZ1Byb2dyZXNzKHtcbiAgICAgICAgLy8gICAgIHByb2dyZXNzOiAwXG4gICAgICAgIC8vIH0pO1xuICAgICAgICB0aGlzLmFwaS5zZXRFbmFibGVEZWJ1Zyh7XG4gICAgICAgICAgICBlbmFibGVEZWJ1ZzogZmFsc2UsIC8vIHRydWUg5Li65omT5byA77yMZmFsc2Ug5Li65YWz6ZetXG4gICAgICAgICAgICAvLyBlbmFibGVEZWJ1ZzogdHJ1ZSwgLy8gdHJ1ZSDkuLrmiZPlvIDvvIxmYWxzZSDkuLrlhbPpl61cbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnb3Bwb+S/oeaBrycsIEpTT04uc3RyaW5naWZ5KHNlbGYuc3lzdGVtSW5mbykpXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY29tcGxldGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBmYWlsOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICAvLyDliJ3lp4vljJblub/lkYrjgIJcbiAgICAgICAgLy8gaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlkZW8gfHwgR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy52aWRlb0FkVW5pdElkWzBdICE9ICcnKSB7XG4gICAgICAgIC8vICAgICB0aGlzLmFwaS5pbml0QWRTZXJ2aWNlKHtcbiAgICAgICAgLy8gICAgICAgICBhcHBJZDogR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy52aWRlb0FkVW5pdElkWzBdLFxuICAgICAgICAvLyAgICAgICAgIGlzRGVidWc6IHRydWUsXG4gICAgICAgIC8vICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuWIneWni+WMluW5v+WRinN1Y2Nlc3NcIik7XG4gICAgICAgIC8vICAgICAgICAgfSxcbiAgICAgICAgLy8gICAgICAgICBmYWlsOiBmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Yid5aeL5YyW5bm/5ZGKZmFpbDpcIiArIHJlcy5jb2RlICsgcmVzLm1zZyk7XG4gICAgICAgIC8vICAgICAgICAgfSxcbiAgICAgICAgLy8gICAgICAgICBjb21wbGV0ZTogZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImNvbXBsZXRlXCIpO1xuICAgICAgICAvLyAgICAgICAgIH1cbiAgICAgICAgLy8gICAgIH0pXG4gICAgICAgIC8vIH1cbiAgICAgICAgdGhpcy5yZXBvcnRNb25pdG9yKCk7XG5cbiAgICAgICAgLy/pooTlhYjmi4nlj5bljp/nlJ/lub/lkYrmlbDmja5cbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnByZUNyZWF0ZU5hdGl2ZUFkKCk7XG4gICAgICAgIH0sIDExMDAwKTtcbiAgICB9XG5cbiAgICAvL3ZpZGVvXG4gICAgcHVibGljIHNob3dWaWRlb0FkKHZpZGVvTmFtZT86IGFueSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIuWxleekuua/gOWKseinhumikVwiKTtcbiAgICAgICAgaWYgKHRoaXMuc3lzdGVtSW5mby5wbGF0Zm9ybVZlcnNpb24gPCAxMDQwKSB7XG4gICAgICAgICAgICB0aGlzLm9uVmlkZW9GYWlsKCfop4bpopHlub/lkYrmkq3mlL7lpLHotKXvvJrlubPlj7DniYjmnKzov4fkvY4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgaWQgPSB0aGlzLmdldFZpZGVvQWRVbml0SWQodmlkZW9OYW1lKTtcbiAgICAgICAgaWYgKCFpZCkge1xuICAgICAgICAgICAgdGhpcy5vblZpZGVvRmFpbChcIuiOt+WPluinhumikWlk5aSx6LSlXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMudmlkZW9BZCkge1xuICAgICAgICAgICAgdGhpcy52aWRlb0FkLmRlc3Ryb3koKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnZpZGVvQWQgPSB0aGlzLmFwaS5jcmVhdGVSZXdhcmRlZFZpZGVvQWQoeyBwb3NJZDogaWQgfSk7XG4gICAgICAgIHRoaXMudmlkZW9BZC5sb2FkKCk7XG4gICAgICAgIHRoaXMudmlkZW9BZC5vbkxvYWQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy52aWRlb0FkLnNob3coKTtcbiAgICAgICAgICAgIHRoaXMub25WaWRlb1Nob3coKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMudmlkZW9BZC5vbkNsb3NlKChyZXMpID0+IHtcbiAgICAgICAgICAgIGlmIChyZXMuaXNFbmRlZCkge1xuICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb1N1Y2Nlc3MoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5vblZpZGVvSGlkZSgpO1xuICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb1F1aXQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMudmlkZW9BZC5vbkVycm9yKChlcnIpID0+IHtcbiAgICAgICAgICAgIHRoaXMub25WaWRlb0ZhaWwoZXJyKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy9iYW5uZXJcbiAgICAvKipvcHBv5paH5qGj6K+05piO77ya5Yib5bu6IEJhbm5lciDlub/lkYrnu4Tku7bvvIzlpoLmnpzlt7Lnu4/liJvlu7rov4cgQmFubmVyIOW5v+WRiue7hOS7tu+8jOWImeS8muS9v+eUqOW3suWIm+W7uueahOW5v+WRiue7hOS7tuWvueixoSAqL1xuICAgIHByb3RlY3RlZCBiYW5uZXJBZDogYW55O1xuICAgIHB1YmxpYyBzaG93QmFubmVyKCkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIuWxleekumJhbm5lclwiKTtcbiAgICAgICAgaWYgKHRoaXMuaW5zZXJ0QWRSZWNvcmQuaXNTaG93aW5nKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaPkuWxj+W5v+WRiuato+WcqOaYvuekuu+8jOaXoOazleWQjOaXtuaYvuekumJhbm5lclwiKTtcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlQmFubmVyKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCEhdGhpcy5iYW5uZXJTaG93aW5nKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImJhbm5lcuWwmuacqumakOiXj++8jOaXoOmcgOWGjeasoeaYvuekulwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgdCA9IERhdGUubm93KCk7XG4gICAgICAgIGlmICh0LnRvU3RyaW5nKCkubGVuZ3RoID09PSAxMCkge1xuICAgICAgICAgICAgdCAqPSAxMDAwO1xuICAgICAgICB9XG4gICAgICAgIGlmIChEYXRlLm5vdygpIC0gdGhpcy5lbnRlclRpbWUgPCAxMDAwMCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLkuLrpgb/lhY3pl6rlsY/pobXlh7rnjrBiYW5uZXLvvIzov5vlhaXmuLjmiI8xMOenkuWQjuaJjeWPr+S7peaYvuekumJhbm5lclwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5iYW5uZXJSZWNvcmQuZGF5SGlkZUNvdW50ID49IDUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi55So5oi35b2T5aSp5bey5Li75Yqo5YWz6ZetYmFubmVy6L6+5YiwXCIgKyB0aGlzLmJhbm5lclJlY29yZC5kYXlIaWRlQ291bnQgKyBcIuasoe+8jOS4jeWGjeaYvuekumJhbm5lclwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5zeXN0ZW1JbmZvLnBsYXRmb3JtVmVyc2lvbiA8ICcxMDMxJykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ+W5s+WPsOeJiOacrOi/h+S9jicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGxldCBpZCA9IHRoaXMuZ2V0QmFubmVySWQoKTtcbiAgICAgICAgaWYgKCEhaWQpIHRoaXMuY3JlYXRlQmFubmVyKGlkKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIGNyZWF0ZUJhbm5lcihpZDogc3RyaW5nKSB7XG4gICAgICAgIGxldCBiYW5uZXIgPSB0aGlzLmFwaS5jcmVhdGVCYW5uZXJBZCh7IHBvc0lkOiBpZCB9KTtcbiAgICAgICAgaWYgKCF0aGlzLmJhbm5lckFkKSB7XG4gICAgICAgICAgICB0aGlzLmJhbm5lckFkID0gYmFubmVyO1xuICAgICAgICAgICAgdGhpcy5iYW5uZXJBZC5vblNob3codGhpcy5vbkJhbm5lclNob3cuYmluZCh0aGlzKSk7XG4gICAgICAgICAgICB0aGlzLmJhbm5lckFkLm9uRXJyb3IodGhpcy5vbkJhbm5lckVyci5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIHRoaXMuYmFubmVyQWQub25IaWRlKHRoaXMub25CYW5uZXJIaWRlLmJpbmQodGhpcykpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYmFubmVyQWQuc2hvdygpO1xuICAgICAgICB0aGlzLmJhbm5lclNob3dpbmcgPSB0cnVlO1xuICAgIH1cbiAgICBwdWJsaWMgcmVtb3ZlQmFubmVyKCkge1xuICAgICAgICBpZiAodGhpcy5iYW5uZXJBZCkge1xuICAgICAgICAgICAgdGhpcy5iYW5uZXJBZC5oaWRlKCk7XG4gICAgICAgICAgICAvL+mdnueOqeWutueCueWHu+WFs+mXreaMiemSru+8jOi/mOWOn+WFs+mXreasoeaVsOeahOiusOW9lVxuICAgICAgICAgICAgdGhpcy5iYW5uZXJSZWNvcmQuZGF5SGlkZUNvdW50IC09IDE7XG4gICAgICAgICAgICB0aGlzLmJhbm5lclJlY29yZC5nYW1lSGlkZUNvdW50IC09IDE7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5iYW5uZXJTaG93aW5nID0gZmFsc2U7XG4gICAgfVxuXG4gICAgLy/mj5LlsY/lub/lkYpcbiAgICAvLyBwcm90ZWN0ZWQgaW5zZXJ0QWQ6IGFueTtcbiAgICBwdWJsaWMgc2hvd0ludGVyc3RpdGlhbEFkKGJhbm5lcjogYm9vbGVhbiA9IGZhbHNlKSB7XG4gICAgICAgIHRoaXMudXNlQmFubmVySW5zdGVhZEluc2VydCA9IGJhbm5lcjtcbiAgICAgICAgLy9PUFBP5bey5Y+W5raI5o+S5bGP5bm/5ZGKXG4gICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgICBjb25zb2xlLmxvZyhcIuWxleekuuaPkuWxj1wiKTtcbiAgICAgICAgaWYgKHRoaXMuc3lzdGVtSW5mby5wbGF0Zm9ybVZlcnNpb24gPCAxMDUxKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygn5bmz5Y+w54mI5pys6L+H5L2OJyk7XG4gICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuaW5zZXJ0QWRSZWNvcmQuZ2V0U2hvd1NwYWNlVGltZSgpIDwgNjApIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Lik5qyh5o+S5bGP5bGV56S65pe26Ze05bCP5LqONjDnp5JcIik7XG4gICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuaW5zZXJ0QWRSZWNvcmQuZGF5U2hvd0NvdW50ID49IDgpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5o+S5bGP5bm/5ZGK5Y2V55So5oi35bGV56S65LiA5aSp5LiN6IO96LaF6L+HOOasoVwiKTtcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgaWQgPSB0aGlzLmdldEluc2VydEFkVW5pdElkKCk7XG4gICAgICAgIGlmICghaWQpIHJldHVybjtcbiAgICAgICAgdGhpcy5jcmVhdGVJbnNlcnRBZChpZCk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBjcmVhdGVJbnNlcnRBZChpZDogc3RyaW5nKSB7XG4gICAgICAgIC8vIGlmICghIXRoaXMuaW5zZXJ0QWQpIHtcbiAgICAgICAgLy8gICAgIHRoaXMuaW5zZXJ0QWQuc2hvdygpO1xuICAgICAgICAvLyAgICAgdGhpcy5vbkluc2VydFNob3coKTtcbiAgICAgICAgLy8gICAgIHJldHVybjtcbiAgICAgICAgLy8gfVxuICAgICAgICBsZXQgYWQgPSB0aGlzLmFwaS5jcmVhdGVJbnNlcnRBZCh7IHBvc0lkOiBpZCB9KTsvL+aXp+eJiEFQSVxuICAgICAgICAvLyBsZXQgYWQgPSB0aGlzLmFwaS5jcmVhdGVJbnRlcnN0aXRpYWxBZCh7IGFkVW5pdElkOiBpZCB9KTsvL+aWsOeJiEFQSe+8jOS8muaKpemUmeWvvOiHtOa4uOaIj+WNoeatu+KApuKAplxuICAgICAgICBpZiAoIWFkKSB7XG4gICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gdGhpcy5pbnNlcnRBZCA9IGFkO1xuICAgICAgICBhZC5vbkxvYWQoKCkgPT4ge1xuICAgICAgICAgICAgYWQuc2hvdygpO1xuICAgICAgICAgICAgdGhpcy5yZW1vdmVCYW5uZXIoKTtcbiAgICAgICAgICAgIHRoaXMub25JbnNlcnRTaG93KCk7XG4gICAgICAgIH0pO1xuICAgICAgICBhZC5vbkNsb3NlKHRoaXMub25JbnNlcnRIaWRlLmJpbmQodGhpcykpO1xuICAgICAgICBhZC5vbkVycm9yKChlcnIpID0+IHtcbiAgICAgICAgICAgIHRoaXMub25JbnNlcnRFcnIoZXJyKTtcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGFkLmxvYWQoKTtcbiAgICAgICAgcmV0dXJuIGFkO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOefremch+WKqFxuICAgICAqL1xuICAgIHB1YmxpYyB2aWJyYXRlU2hvcnQoKSB7XG4gICAgICAgIGlmIChHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLnZpYnJhdGUpIHtcbiAgICAgICAgICAgIHRoaXMuYXBpLnZpYnJhdGVTaG9ydCh7fSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDplb/pnIfliqhcbiAgICAgKi9cbiAgICBwdWJsaWMgdmlicmF0ZUxvbmcoKSB7XG4gICAgICAgIGlmIChHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLnZpYnJhdGUpIHtcbiAgICAgICAgICAgIHRoaXMuYXBpLnZpYnJhdGVMb25nKHt9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOaXoOa/gOWKseWIhuS6qyYm5bim5Y+C5YiG5LqrXG4gICAgICovXG4gICAgcHVibGljIHNoYXJlQXBwTWVzc2FnZShxdWVyeTogc3RyaW5nID0gJycpIHtcblxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOa/gOWKseWIhuS6qyYm5bim5Y+C5YiG5LqrXG4gICAgICovXG4gICAgcHVibGljIHNoYXJlVG9BbnlPbmUoc3VjY2VzczogRnVuY3Rpb24sIGZhaWw/OiBGdW5jdGlvbiwgcXVlcnk6IHN0cmluZyA9ICcnKSB7XG5cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDmtojmga/mj5DnpLpcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hvd01lc3NhZ2UobXNnOiBzdHJpbmcsIGljb246IHN0cmluZyA9ICdub25lJykge1xuICAgICAgICAvLyB0aGlzLmFwaS5zaG93VG9hc3Qoe1xuICAgICAgICAvLyAgICAgdGl0bGU6IG1zZyxcbiAgICAgICAgLy8gICAgIGR1cmF0aW9uOiAyMDAwLFxuICAgICAgICAvLyAgICAgaWNvbjogaWNvbixcbiAgICAgICAgLy8gICAgIHN1Y2Nlc3M6IChyZXMpID0+IHsgfVxuICAgICAgICAvLyB9KTtcbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuc2hvd1RpcCwgbXNnKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgbmF2aWdhdGVUb01pbmlQcm9ncmFtKGRhdGE6IGFueSkge1xuICAgICAgICBpZiAodGhpcy5zeXN0ZW1JbmZvLnBsYXRmb3JtVmVyc2lvbiA8ICcxMDUwJykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ+W5s+WPsOeJiOacrOi/h+S9jicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYXBpLm5hdmlnYXRlVG9NaW5pR2FtZSh7XG4gICAgICAgICAgICBwa2dOYW1lOiBkYXRhLmdhbWVJZCxcbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDmuLjmiI/ov5DooYzkuK3kuIrmiqXmlbDmja7vvIzkuLvopoHnm5HmjqfmuLjmiI/ltKnmuoPnrYnlvILluLgsIOebruWJjeWPquaUr+aMgei/m+WFpeWIsOa4uOaIj+S4u+eVjOmdouaXtuS4iuaKpeaVsOaNruOAglxuICAgICAqIOazqOaEj++8muaVsOaNruS4iuaKpeaOpeWPo+S4uuW5s+WPsOW/hemhu+aOpeWFpeeahOiDveWKm+OAglxuICAgICAqIOaOpeWFpeWQjua1i+ivleeOr+Wig+S8mum7mOiupOW8ueWHuiBcInJlcG9ydE1vbml0b3I6IDBcIu+8jOato+W8j+eOr+Wig+S4i+S4jeS8mu+8m1xuICAgICAqIOW5tuS4lOmcgOimgeWcqOa4uOaIj+WKoOi9veeahOeUn+WRveWRqOacn+iwg+eUqO+8jOWPquiDveiwg+S4gOasoeOAglxuICAgICAqL1xuICAgIHB1YmxpYyByZXBvcnRNb25pdG9yKCkge1xuICAgICAgICBpZiAodGhpcy5zeXN0ZW1JbmZvLnBsYXRmb3JtVmVyc2lvbiA8ICcxMDYwJykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ+W5s+WPsOeJiOacrOi/h+S9jicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYXBpLnJlcG9ydE1vbml0b3IoJ2dhbWVfc2NlbmUnLCAwKTtcbiAgICB9XG5cbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKuWOn+eUn+W5v+WRiioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgLyoq5bm/5ZGK57G75Z6L5a+55bqU55qE5bm/5ZGK5L+h5oGvICovXG4gICAgcHJvdGVjdGVkIG5hdGl2ZURhdGE6IHsgW3R5cGU6IG51bWJlcl06IE5hdGl2ZURhdGEgfSA9IHt9O1xuICAgIHB1YmxpYyBzaG93TmF0aXZlQWQoZGF0YToge1xuICAgICAgICBwYXJlbnQ6IGNjLk5vZGUsICAgIC8v5bm/5ZGK6IqC54K56KaB5re75Yqg5Yiw55qE54i26IqC54K5XG4gICAgICAgIHR5cGU6IG51bWJlciwgICAgICAgLy/lub/lkYrnsbvlnovmnprkuL7lgLxcbiAgICAgICAgd2lkZ2V0OiBhbnksICAgICAgICAvL+W5v+WRiuiKgueCueebuOWvueeItuiKgueCueeahOmAgumFjeaVsOaNrlxuICAgIH0pIHtcbiAgICAgICAgbGV0IHQgPSBEYXRlLm5vdygpO1xuICAgICAgICBpZiAodC50b1N0cmluZygpLmxlbmd0aCA9PT0gMTApIHtcbiAgICAgICAgICAgIHQgKj0gMTAwMDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodCAtIHRoaXMuZW50ZXJUaW1lIDwgMTAwMDApIHJldHVybjtcblxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSB0aGlzLm5hdGl2ZURhdGFbZGF0YS50eXBlXSkge1xuICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW2RhdGEudHlwZV0gPSBuZXcgTmF0aXZlRGF0YSgpO1xuICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW2RhdGEudHlwZV0udHlwZSA9IGRhdGEudHlwZTtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVtkYXRhLnR5cGVdLnNldFBhcmVudChkYXRhKTtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVtkYXRhLnR5cGVdLm5lZWRTaG93ID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVtkYXRhLnR5cGVdLnNldFBhcmVudChkYXRhKTtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVtkYXRhLnR5cGVdLnNob3coKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKumihOWFiOaLieWPluWOn+eUn+W5v+WRiuaVsOaNru+8jOW5tuWIm+W7uuWvueW6lOeahOiKgueCuSAqL1xuICAgIHB1YmxpYyBwcmVDcmVhdGVOYXRpdmVBZCgpIHtcbiAgICAgICAgbGV0IGlkcyA9IHRoaXMuZ2V0QWxsTmF0aXZlQWRJZHMoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IGlkcy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IGlkID0gaWRzW2ldO1xuICAgICAgICAgICAgICAgIGxldCBhZCA9IHRoaXMuYXBpLmNyZWF0ZU5hdGl2ZUFkKHtcbiAgICAgICAgICAgICAgICAgICAgYWRVbml0SWQ6IGlkLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGFkLm9uTG9hZCgocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Y6f55Sf5bm/5ZGK5Yqg6L295oiQ5Yqf77yaXCIgKyBpZCwgcmVzKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLljp/nlJ/lub/lkYroioLngrnmlbDmja7mmK/lkKblrZjlnKjvvJpcIiwgdGhpcy5uYXRpdmVEYXRhW3Jlcy5hZExpc3RbMF0uY3JlYXRpdmVUeXBlXSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBpbmRleCA9IE1hdGgucm91bmQoTWF0aC5yYW5kb20oKSAqIChyZXMuYWRMaXN0Lmxlbmd0aCAtIDEpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLpmo/mnLppbmRleD09XCIsIGluZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGEgPSByZXMuYWRMaXN0W2luZGV4XTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHR5cGUgPSBkYXRhLmNyZWF0aXZlVHlwZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gdGhpcy5uYXRpdmVEYXRhW3R5cGVdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaWsOW7uuWOn+eUn+W5v+WRiuiKgueCueaVsOaNrixpZD09XCIsIGlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVt0eXBlXSA9IG5ldyBOYXRpdmVEYXRhKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbdHlwZV0udHlwZSA9IHR5cGU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW3R5cGVdLmlkID0gaWQ7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVt0eXBlXS5hZCA9IGFkO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbdHlwZV0uYWREYXRhID0gZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW3R5cGVdLmRhdGFTdGF0ZSA9IDI7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Y6f55Sf5bm/5ZGK6IqC54K554q25oCB77yaXCIsIHRoaXMubmF0aXZlRGF0YVt0eXBlXS5ub2RlU3RhdGUpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbdHlwZV0uY3JlYXRlTm9kZSgpO1xuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLm5hdGl2ZURhdGFbdHlwZV0uc2V0Tm9kZURhdGEoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubmF0aXZlRGF0YVt0eXBlXS5uZWVkU2hvdykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW3R5cGVdLnNob3dOb2RlKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBhZC5vbkVycm9yKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIuWOn+eUn+W5v+WRiuaLieWPlumUmeivr++8mlwiICsgaWQpO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgICAgIGFkLm9mZkxvYWQoKTtcbiAgICAgICAgICAgICAgICAgICAgYWQub2ZmRXJyb3IoKTtcbiAgICAgICAgICAgICAgICAgICAgYWQuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGFkLmxvYWQoKTtcbiAgICAgICAgICAgIH0sIGkgKiAzMyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwdWJsaWMgaGlkZU5hdGl2ZUFkKHR5cGU6IG51bWJlcikge1xuICAgICAgICBpZiAodW5kZWZpbmVkID09PSB0aGlzLm5hdGl2ZURhdGFbdHlwZV0pIHtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVt0eXBlXSA9IG5ldyBOYXRpdmVEYXRhKCk7XG4gICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbdHlwZV0udHlwZSA9IHR5cGU7XG4gICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbdHlwZV0ubmVlZFNob3cgPSBmYWxzZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVt0eXBlXS5oaWRlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwdWJsaWMgaGlkZUFsbE5hdGl2ZUFkKCkge1xuICAgICAgICBmb3IgKGxldCBrZXkgaW4gdGhpcy5uYXRpdmVEYXRhKSB7XG4gICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFba2V5XS5oaWRlKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy/lv6vpgJ/mmL7npLrljp/nlJ/lub/lkYrvvIzmmoLml7bkuI7luLjop4TmmL7npLrnm7jlkIxcbiAgICBwdWJsaWMgcXVpY2tTaG93TmF0aXZlQWQoZGF0YSkge1xuICAgICAgICBsZXQgdCA9IERhdGUubm93KCk7XG4gICAgICAgIGlmICh0LnRvU3RyaW5nKCkubGVuZ3RoID09PSAxMCkge1xuICAgICAgICAgICAgdCAqPSAxMDAwO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0IC0gdGhpcy5lbnRlclRpbWUgPCAxMDAwMCkgcmV0dXJuO1xuXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IHRoaXMubmF0aXZlRGF0YVtkYXRhLnR5cGVdKSB7XG4gICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbZGF0YS50eXBlXSA9IG5ldyBOYXRpdmVEYXRhKCk7XG4gICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbZGF0YS50eXBlXS50eXBlID0gZGF0YS50eXBlO1xuICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW2RhdGEudHlwZV0uc2V0UGFyZW50KGRhdGEpO1xuICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW2RhdGEudHlwZV0ubmVlZFNob3cgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW2RhdGEudHlwZV0uc2V0UGFyZW50KGRhdGEpO1xuICAgICAgICAgICAgdGhpcy5uYXRpdmVEYXRhW2RhdGEudHlwZV0ucXVpY2tTaG93KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy/lv6vpgJ/pmpDol4/ljp/nlJ/lub/lkYrvvIzkuI7luLjop4TpmpDol4/nm7jmr5TvvIzlub/lkYrmnKrooqvngrnlh7vov4fml7bkuI3kvJrliLfmlrDmlbDmja5cbiAgICBwdWJsaWMgcXVpY2tIaWRlTmF0aXZlQWQodHlwZSkge1xuICAgICAgICBpZiAodW5kZWZpbmVkID09PSB0aGlzLm5hdGl2ZURhdGFbdHlwZV0pIHtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVt0eXBlXSA9IG5ldyBOYXRpdmVEYXRhKCk7XG4gICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbdHlwZV0udHlwZSA9IHR5cGU7XG4gICAgICAgICAgICB0aGlzLm5hdGl2ZURhdGFbdHlwZV0ubmVlZFNob3cgPSBmYWxzZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlRGF0YVt0eXBlXS5xdWlja0hpZGUoKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuY2xhc3MgTmF0aXZlRGF0YSB7XG4gICAgLyoq5bm/5ZGKaWQgKi9cbiAgICBwdWJsaWMgaWQ6IHN0cmluZztcbiAgICAvKirlub/lkYrnsbvlnosgKi9cbiAgICBwdWJsaWMgdHlwZTogbnVtYmVyO1xuICAgIC8qKuW5v+WRiuWvueixoSAqL1xuICAgIHB1YmxpYyBhZDogYW55O1xuICAgIC8qKuW5v+WRiuaVsOaNriAqL1xuICAgIHB1YmxpYyBhZERhdGE6IGFueTtcbiAgICAvKirlub/lkYrlr7nosaHnirbmgIE6MC3mnKrliJvlu7ov5bey6ZSA5q+B77yMMS3lt7LliJvlu7rvvIzmlbDmja7liqDovb3kuK3vvIwyLeaVsOaNruW3suWKoOi9veWujOaIkCAqL1xuICAgIHB1YmxpYyBkYXRhU3RhdGU6IG51bWJlciA9IDA7XG4gICAgLyoq5bm/5ZGK6IqC54K5ICovXG4gICAgcHVibGljIG5vZGU6IGNjLk5vZGU7XG5cbiAgICAvKirlub/lkYroioLngrnnmoTniLboioLngrkgKi9cbiAgICBwdWJsaWMgcGFyZW50OiBjYy5Ob2RlID0gbnVsbDtcbiAgICAvKiroioLngrnnmoTpgILphY3mlbDmja4gKi9cbiAgICBwdWJsaWMgd2lkZ2V0OiBhbnkgPSB7fTtcblxuICAgIC8qKuiKgueCueeKtuaAge+8mjAt5pyq5Yib5bu677yMMS3lt7LliJvlu7rvvIzmnKrorr7nva7mlbDmja7vvIwyLeW3suiuvue9ruaVsOaNru+8jOacquaYvuekuu+8jDMt5bey5pi+56S677yM5pyq54K55Ye777yMNC3lt7Looqvngrnlh7vvvIw1LeW3sumakOiXjyAqL1xuICAgIHB1YmxpYyBub2RlU3RhdGU6IG51bWJlciA9IDA7XG4gICAgLyoq5Yqg6L295pWw5o2u5bm26K6+572u5a6M5oiQ5ZCO5piv5ZCm6ZyA6KaB56uL5Y2z5pi+56S6ICovXG4gICAgcHVibGljIG5lZWRTaG93OiBib29sZWFuO1xuXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLmRhdGFTdGF0ZSA9IDA7XG4gICAgICAgIHRoaXMubm9kZVN0YXRlID0gMDtcbiAgICAgICAgdGhpcy5uZWVkU2hvdyA9IGZhbHNlO1xuICAgIH1cblxuICAgIHB1YmxpYyBzZXRQYXJlbnQoZGF0YSkge1xuICAgICAgICBpZiAoIWRhdGEucGFyZW50KSB7XG4gICAgICAgICAgICB0aGlzLnBhcmVudCA9IGNjLmZpbmQoXCJDYW52YXMvTmF0aXZlQWRcIik7XG4gICAgICAgICAgICBpZiAoIXRoaXMucGFyZW50KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wYXJlbnQgPSBjYy5maW5kKFwiQ2FudmFzXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5wYXJlbnQgPSBkYXRhLnBhcmVudDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLndpZGdldCA9IGRhdGEud2lkZ2V0O1xuICAgICAgICBpZiAoISF0aGlzLm5vZGUpIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5wYXJlbnQgPSB0aGlzLnBhcmVudDtcbiAgICAgICAgICAgIHRoaXMuc2V0V2lkZ2V0KHRoaXMubm9kZSwgdGhpcy53aWRnZXQpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHVibGljIHNob3coKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwi5pi+56S65Y6f55Sf5bm/5ZGK5pa55rOV77yMZGF0YVN0YXRlOlwiLCB0aGlzLmRhdGFTdGF0ZSk7XG4gICAgICAgIHN3aXRjaCAodGhpcy5kYXRhU3RhdGUpIHtcbiAgICAgICAgICAgIGNhc2UgMDoge1xuICAgICAgICAgICAgICAgIHRoaXMubmVlZFNob3cgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZE5hdGl2ZUFkKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIDE6IHtcbiAgICAgICAgICAgICAgICB0aGlzLm5lZWRTaG93ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgMjoge1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGhpcy5ub2RlU3RhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5lZWRTaG93ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMToge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXROb2RlRGF0YSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zaG93Tm9kZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2FzZSAyOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNob3dOb2RlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYXNlIDU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvd05vZGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHVibGljIGhpZGUoKSB7XG4gICAgICAgIHRoaXMubmVlZFNob3cgPSBmYWxzZTtcbiAgICAgICAgLy/mlbDmja5cbiAgICAgICAgc3dpdGNoICh0aGlzLmRhdGFTdGF0ZSkge1xuICAgICAgICAgICAgY2FzZSAwOiB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkTmF0aXZlQWQoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgMToge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAyOiB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubm9kZVN0YXRlID09PSAzXG4gICAgICAgICAgICAgICAgICAgIHx8IHRoaXMubm9kZVN0YXRlID09PSA0KSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGVzdHJveUFkKCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZE5hdGl2ZUFkKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8v6IqC54K5XG4gICAgICAgIHRoaXMuaGlkZU5vZGUoKTtcbiAgICB9XG4gICAgLy/lv6vpgJ/mmL7npLpcbiAgICBwdWJsaWMgcXVpY2tTaG93KCkge1xuICAgICAgICB0aGlzLnNob3coKTtcbiAgICB9XG4gICAgLy/lv6vpgJ/pmpDol4/vvIzlub/lkYrmnKrooqvngrnlh7vov4fml7bvvIzkuI3kvJrliLfmlrDmlbDmja5cbiAgICBwdWJsaWMgcXVpY2tIaWRlKCkge1xuICAgICAgICB0aGlzLm5lZWRTaG93ID0gZmFsc2U7XG4gICAgICAgIC8v5pWw5o2uXG4gICAgICAgIHN3aXRjaCAodGhpcy5kYXRhU3RhdGUpIHtcbiAgICAgICAgICAgIGNhc2UgMDoge1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZE5hdGl2ZUFkKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIDE6IHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgMjoge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLm5vZGVTdGF0ZSA9PT0gNCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmRlc3Ryb3lBZCgpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWROYXRpdmVBZCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvL+iKgueCuVxuICAgICAgICB0aGlzLmhpZGVOb2RlKCk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBhcGk6IGFueTtcbiAgICBwdWJsaWMgbG9hZE5hdGl2ZUFkKCkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIumihOWKoOi9veS4i+asoemcgOimgeaYvuekuueahOWOn+eUn+W5v+WRiuaVsOaNrlwiKTtcbiAgICAgICAgbGV0IGFkID0gd2luZG93W1wicWdcIl0uY3JlYXRlTmF0aXZlQWQoe1xuICAgICAgICAgICAgYWRVbml0SWQ6IHRoaXMuaWQsXG4gICAgICAgIH0pO1xuICAgICAgICBhZC5vbkxvYWQoKHJlcykgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLljp/nlJ/lub/lkYrliqDovb3miJDlip/vvJpcIiwgcmVzKTtcbiAgICAgICAgICAgIHRoaXMuZGF0YVN0YXRlID0gMjtcbiAgICAgICAgICAgIGxldCBpbmRleCA9IE1hdGgucm91bmQoTWF0aC5yYW5kb20oKSAqIChyZXMuYWRMaXN0Lmxlbmd0aCAtIDEpKTtcbiAgICAgICAgICAgIGxldCBkYXRhID0gcmVzLmFkTGlzdFtpbmRleF07XG4gICAgICAgICAgICB0aGlzLmFkRGF0YSA9IGRhdGE7XG4gICAgICAgICAgICAvL3RvZG865Yib5bu66IqC54K577yM6K6+572u5pWw5o2uXG4gICAgICAgICAgICB0aGlzLmNyZWF0ZU5vZGUoKTtcbiAgICAgICAgICAgIHRoaXMuc2V0Tm9kZURhdGEoKTtcbiAgICAgICAgICAgIGlmICh0aGlzLm5lZWRTaG93KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93Tm9kZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgYWQub25FcnJvcigoZXJyKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwi5Y6f55Sf5bm/5ZGK5ouJ5Y+W6ZSZ6K+v77yaXCIpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICAgICAgdGhpcy5kZXN0cm95QWQoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGFkLmxvYWQoKTtcblxuICAgICAgICB0aGlzLmFkID0gYWQ7XG4gICAgICAgIHRoaXMuZGF0YVN0YXRlID0gMTtcbiAgICB9XG4gICAgcHVibGljIGRlc3Ryb3lBZCgpIHtcbiAgICAgICAgaWYgKCEhdGhpcy5hZCkge1xuICAgICAgICAgICAgdGhpcy5hZC5vZmZMb2FkKCk7XG4gICAgICAgICAgICB0aGlzLmFkLm9mZkVycm9yKCk7XG4gICAgICAgICAgICB0aGlzLmFkLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIHRoaXMuYWQgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZGF0YVN0YXRlID0gMDtcbiAgICAgICAgaWYgKCEhdGhpcy5ub2RlKSB7XG4gICAgICAgICAgICBsZXQganMgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KFwiTmF0aXZlQWRcIiArIHRoaXMudHlwZSk7XG4gICAgICAgICAgICBqcy5yZXNldCgpO1xuICAgICAgICAgICAgdGhpcy5ub2RlU3RhdGUgPSAxO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHVibGljIHNldE5vZGVEYXRhKCkge1xuICAgICAgICAvL3RvZG9cbiAgICAgICAgaWYgKCF0aGlzLm5vZGUpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQganMgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KFwiTmF0aXZlQWRcIiArIHRoaXMudHlwZSk7XG4gICAgICAgIGpzLnNldERhdGEodGhpcy5hZERhdGEpO1xuICAgICAgICB0aGlzLm5vZGVTdGF0ZSA9IDI7XG4gICAgfVxuICAgIHB1YmxpYyBzaG93Tm9kZSgpIHtcbiAgICAgICAgaWYgKCEhdGhpcy5ub2RlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaYvuekuuWOn+eUn+W5v+WRiuiKgueCue+8jHR5cGU9PVwiLCB0aGlzLnR5cGUpO1xuICAgICAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50ID0gdGhpcy5wYXJlbnQ7XG4gICAgICAgICAgICB0aGlzLnNldFdpZGdldCh0aGlzLm5vZGUsIHRoaXMud2lkZ2V0KTtcbiAgICAgICAgICAgIHRoaXMubm9kZVN0YXRlID0gMztcbiAgICAgICAgfVxuICAgIH1cbiAgICBwdWJsaWMgb25DbGlja05vZGUoKSB7XG4gICAgICAgIHRoaXMuYWQucmVwb3J0QWRDbGljayh7XG4gICAgICAgICAgICBhZElkOiB0aGlzLmFkRGF0YS5hZElkLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5ub2RlU3RhdGUgPSA0O1xuICAgIH1cbiAgICBwdWJsaWMgaGlkZU5vZGUoKSB7XG4gICAgICAgIGlmICghIXRoaXMubm9kZSkge1xuICAgICAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubm9kZVN0YXRlID0gNTtcbiAgICB9XG4gICAgcHVibGljIGNyZWF0ZU5vZGUoKSB7XG4gICAgICAgIGlmICghIXRoaXMubm9kZSkgcmV0dXJuO1xuICAgICAgICAvLyByZXR1cm47XG4gICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKFwiTmF0aXZlQWQvT1BQTy9OYXRpdmVBZFwiICsgdGhpcy50eXBlLCBjYy5QcmVmYWIsIChlcnIsIHJlcykgPT4ge1xuICAgICAgICAgICAgaWYgKCEhZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIuWOn+eUn+W5v+WRiumihOWItuS7tuWKoOi9veWksei0pe+8jHR5cGXvvJpcIiwgdGhpcy50eXBlKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IG5vZGUgPSBjYy5pbnN0YW50aWF0ZShyZXMpO1xuICAgICAgICAgICAgbm9kZS5vbihcInRvdWNoZW5kXCIsIHRoaXMub25DbGlja05vZGUsIHRoaXMpO1xuICAgICAgICAgICAgdGhpcy5ub2RlID0gbm9kZTtcbiAgICAgICAgICAgIGlmICghIXRoaXMucGFyZW50KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLnBhcmVudCA9IHRoaXMucGFyZW50O1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0V2lkZ2V0KHRoaXMubm9kZSwgdGhpcy53aWRnZXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5ub2RlU3RhdGUgPSAxO1xuICAgICAgICAgICAgdGhpcy5zZXROb2RlRGF0YSgpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLliqDovb3ljp/nlJ/lub/lkYrpooTliLbku7ZcIiArIHRoaXMudHlwZSArIFwi5a6M5oiQ77yM5piv5ZCm5pi+56S677yaXCIsIHRoaXMubmVlZFNob3cpO1xuICAgICAgICAgICAgaWYgKHRoaXMubmVlZFNob3cpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dOb2RlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvL+iuvue9ruW4g+WxgOe7hOS7tlxuICAgIHByb3RlY3RlZCBzZXRXaWRnZXQobm9kZTogY2MuTm9kZSwgd2lkZ2V0OiBhbnksIHRhcmdldE5vZGU/OiBjYy5Ob2RlKSB7XG4gICAgICAgIGxldCB3ZyA9IG5vZGUuZ2V0Q29tcG9uZW50KGNjLldpZGdldCk7XG4gICAgICAgIGlmICghd2cpIHtcbiAgICAgICAgICAgIHdnID0gbm9kZS5hZGRDb21wb25lbnQoY2MuV2lkZ2V0KTtcbiAgICAgICAgfVxuICAgICAgICB3Zy5pc0Fic29sdXRlQm90dG9tID0gdHJ1ZTtcbiAgICAgICAgd2cuaXNBYnNvbHV0ZUxlZnQgPSB0cnVlO1xuICAgICAgICB3Zy5pc0Fic29sdXRlUmlnaHQgPSB0cnVlO1xuICAgICAgICB3Zy5pc0Fic29sdXRlVG9wID0gdHJ1ZTtcbiAgICAgICAgd2cuaXNBYnNvbHV0ZUhvcml6b250YWxDZW50ZXIgPSB0cnVlO1xuICAgICAgICB3Zy5pc0Fic29sdXRlVmVydGljYWxDZW50ZXIgPSB0cnVlO1xuICAgICAgICBpZiAoIXdpZGdldCkgcmV0dXJuO1xuICAgICAgICBpZiAoISF0YXJnZXROb2RlKSB7XG4gICAgICAgICAgICB3Zy50YXJnZXQgPSB0YXJnZXROb2RlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgd2cudGFyZ2V0ID0gbm9kZS5wYXJlbnQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHVuZGVmaW5lZCAhPSB3aWRnZXQudG9wKSB7XG4gICAgICAgICAgICB3Zy5pc0FsaWduVG9wID0gdHJ1ZTtcbiAgICAgICAgICAgIHdnLnRvcCA9IHBhcnNlRmxvYXQod2lkZ2V0LnRvcCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB3Zy5pc0FsaWduVG9wID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHVuZGVmaW5lZCAhPSB3aWRnZXQuYm90dG9tKSB7XG4gICAgICAgICAgICB3Zy5pc0FsaWduQm90dG9tID0gdHJ1ZTtcbiAgICAgICAgICAgIHdnLmJvdHRvbSA9IHBhcnNlRmxvYXQod2lkZ2V0LmJvdHRvbSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB3Zy5pc0FsaWduQm90dG9tID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHVuZGVmaW5lZCAhPSB3aWRnZXQubGVmdCkge1xuICAgICAgICAgICAgd2cuaXNBbGlnbkxlZnQgPSB0cnVlO1xuICAgICAgICAgICAgd2cubGVmdCA9IHBhcnNlRmxvYXQod2lkZ2V0LmxlZnQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgd2cuaXNBbGlnbkxlZnQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodW5kZWZpbmVkICE9IHdpZGdldC5yaWdodCkge1xuICAgICAgICAgICAgd2cuaXNBbGlnblJpZ2h0ID0gdHJ1ZTtcbiAgICAgICAgICAgIHdnLnJpZ2h0ID0gcGFyc2VGbG9hdCh3aWRnZXQucmlnaHQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgd2cuaXNBbGlnblJpZ2h0ID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgd2cuaXNBbGlnbkhvcml6b250YWxDZW50ZXIgPSAhIXdpZGdldC5ob3Jpem9udGFsQ2VudGVyO1xuICAgICAgICB3Zy5pc0FsaWduVmVydGljYWxDZW50ZXIgPSAhIXdpZGdldC52ZXJ0aWNhbENlbnRlcjtcbiAgICAgICAgd2cudXBkYXRlQWxpZ25tZW50KCk7XG4gICAgfVxufVxuIl19