
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/SDK/TTSDK.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ce8bdT8m8hNvbQVO6NcG6Ss', 'TTSDK');
// Script/Platform/SDK/TTSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var EventManager_1 = require("../../Common/EventManager");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var TTSDK = /** @class */ (function (_super) {
    __extends(TTSDK, _super);
    function TTSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'tt';
        _this.appName = null;
        /**创建新的banner的时间 */
        _this.createBannerTime = 0;
        /**banner加载成功后是否需要立即显示 */
        _this.needShowBanner = false;
        /**banner是否已加载完毕 */
        _this.bannerLoaded = false;
        //插屏
        _this.insertAd = null;
        //当前录屏是否已成功发布过一次
        _this.isShared = false;
        //录屏错误。
        _this.IsRecordError = false;
        //视频地址
        _this.videoPath = '';
        _this.recordMng = null;
        return _this;
    }
    /**
     * 记录字节跳动平台下的应用程序的类型，
     * 参考文档：https://microapp.bytedance.com/dev/cn/mini-app/develop/basic-library/compatibility-description
     */
    TTSDK.prototype.initAppType = function () {
        var appName = this.systemInfo.appName.toUpperCase();
        switch (appName) {
            case "TOUTIAO": {
                this.appName = AppName.touTiao;
                break;
            }
            case "DOUYIN": {
                this.appName = AppName.douYin;
                break;
            }
            case "XIGUA": {
                this.appName = AppName.xiGua;
                break;
            }
            case "NEWS_ARTICLE_LITE": {
                this.appName = AppName.jiSuTT;
                break;
            }
            default: {
                this.appName = AppName.devtools;
                break;
            }
        }
    };
    TTSDK.prototype.init = function () {
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        this.initAppType();
        this.setSystemInfo(this.systemInfo.platform, this.systemInfo.version, this.systemInfo.SDKVersion);
        console.log("系统信息：");
        console.log(JSON.stringify(this.systemInfo));
        this.api.showShareMenu({ withShareTicket: false });
        this.preCreateBanner();
    };
    //video
    TTSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        if (!this.canApiUseVideo()) {
            this.onVideoSuccess();
            return;
        }
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("获取视频id失败");
            return;
        }
        //不支持在开发工具运行，只能在真机运行 返回值是个单例
        var rewardedVideoAd = this.api.createRewardedVideoAd({ adUnitId: id });
        var load = (function () {
            _this.onVideoShow();
        });
        rewardedVideoAd.onLoad(load);
        var error = (function (err) {
            _this.onVideoFail(err);
        });
        rewardedVideoAd.onError(error);
        var closefun = (function (res) {
            rewardedVideoAd.offLoad(load);
            rewardedVideoAd.offError(error);
            rewardedVideoAd.offClose(closefun);
            rewardedVideoAd = null;
            if (res && res.isEnded || res === undefined) {
                _this.onVideoSuccess();
            }
            else {
                _this.onVideoQuit();
                _this.onVideoHide();
            }
        });
        rewardedVideoAd.onClose(closefun);
        //开始加载视频广告
        rewardedVideoAd.load().then(function () {
            rewardedVideoAd.show().catch(function (err) {
                _this.onVideoFail(err);
                rewardedVideoAd.offLoad(load);
                rewardedVideoAd.offError(error);
                rewardedVideoAd.offClose(closefun);
                rewardedVideoAd = null;
            });
        });
    };
    /**能否使用api：video */
    TTSDK.prototype.canApiUseVideo = function () {
        if (this.appName == AppName.devtools) {
            console.log("开发者工具上无法显示视频广告");
            return false;
        }
        return true;
    };
    /**
     * 打开banner广告
     */
    TTSDK.prototype.showBanner = function (cb) {
        var _this = this;
        if (!this.canApiUseBanner()) {
            return;
        }
        if (this.insertAdRecord.isShowing) {
            console.log("有插屏显示，不再显示banner");
            this.removeBanner();
            return;
        }
        if (this.bannerRecord.getShowSpaceTime() < 1) {
            console.log("距离上次显示banner时间小于1s，不再创建");
            return;
        }
        if (this.bannerShowing)
            return;
        //已经创建了banner：
        if (!!this._bannerAd) {
            //创建的banner已经加载成功，直接显示：
            if (this.bannerLoaded) {
                this._bannerAd.show().then(function () {
                    _this.onBannerShow();
                    _this.bannerShowing = true;
                    if (!!cb) {
                        cb();
                    }
                });
            }
            else {
                //创建的banner还没加载完成时，设置标记，使其在加载完成后显示
                this.needShowBanner = true;
            }
        }
        else {
            //尚未创建banner，则设置标记，创建banner，并使其在加载完成后显示
            this.needShowBanner = true;
            this.preCreateBanner();
        }
    };
    /**能否使用api：banner */
    TTSDK.prototype.canApiUseBanner = function () {
        if (this.appName == AppName.douYin) {
            console.log("抖音平台无banner");
            return false;
        }
        return true;
    };
    /**预先创建banner，创建的banner在加载完成时，会根据 needShowBanner 确定是否需要立即显示 */
    TTSDK.prototype.preCreateBanner = function () {
        var _this = this;
        var id = this.getBannerId();
        if (!id)
            return null;
        var targetBannerAdWidth = 200;
        this._bannerAd = this.api.createBannerAd({
            adUnitId: id,
            style: {
                width: targetBannerAdWidth,
                top: this.systemInfo.windowHeight - (targetBannerAdWidth / 16 * 9),
            }
        });
        this._bannerAd.onError(function (err) {
            _this.onBannerErr(err);
            _this.destroyBanner();
        });
        // 尺寸调整时会触发回调，通过回调拿到的广告真实宽高再进行定位适配处理
        // 注意：如果在回调里再次调整尺寸，要确保不要触发死循环！！！
        this._bannerAd.onResize(function (size) {
            // good
            _this._bannerAd.style.top = _this.systemInfo.windowHeight - size.height;
            _this._bannerAd.style.left = (_this.systemInfo.windowWidth - size.width) / 2;
            // bad，会触发死循环
            // bannerAd.style.width++;
        });
        this._bannerAd.onLoad(function () {
            _this.bannerLoaded = true;
            if (_this.needShowBanner) {
                _this.showBanner();
                _this.needShowBanner = false;
            }
        });
        this.createBannerTime = Date.now();
        return this._bannerAd;
    };
    /**
     * 关闭banner广告
     */
    TTSDK.prototype.removeBanner = function () {
        if (this._bannerAd) {
            var t = Date.now();
            if (t - this.createBannerTime > 60000) {
                console.log("距上次显示banner已超过60秒，创建新的banner");
                this.destroyBanner();
                this.preCreateBanner();
            }
            else {
                this._bannerAd.hide();
            }
        }
        this.bannerShowing = false;
        this.needShowBanner = false;
    };
    /**销毁banner */
    TTSDK.prototype.destroyBanner = function () {
        if (this._bannerAd) {
            // this._bannerAd.offLoad();
            // this._bannerAd.offError();
            // this._bannerAd.offResize();
            this._bannerAd.destroy(); //要先把旧的广告给销毁，不然会导致其监听的事件无法释放，影响性能
            this._bannerAd = null;
        }
        this.bannerLoaded = false;
    };
    TTSDK.prototype.showInterstitialAd = function (banner) {
        var _this = this;
        this.useBannerInsteadInsert = banner;
        if (!this.canApiUseInsert()) {
            this.showBannerInsteadInsert();
            return;
        }
        var id = this.getInsertAdUnitId();
        if (!id) {
            this.showBannerInsteadInsert();
            return;
        }
        if (!!this.insertAd) {
            this.insertAd.destroy();
            this.insertAd = null;
        }
        var interstitialAd = this.api.createInterstitialAd({ adUnitId: id });
        if (!interstitialAd) {
            this.onInsertErr("插屏创建失败");
            this.showBannerInsteadInsert();
            return;
        }
        this.insertAd = interstitialAd;
        interstitialAd.onClose(this.onInsertHide.bind(this));
        interstitialAd.onError(function (err) {
            _this.onInsertErr(err);
            _this.showBannerInsteadInsert();
        });
        interstitialAd.load().then(function () {
            try {
                interstitialAd.show().then(function () {
                    _this.removeBanner();
                    _this.onInsertShow();
                }).catch(function (err) {
                    _this.onInsertErr(err);
                    _this.showBannerInsteadInsert();
                });
            }
            catch (err) {
                _this.onInsertErr(err);
                _this.showBannerInsteadInsert();
            }
        });
    };
    /**能否是否api：insert */
    TTSDK.prototype.canApiUseInsert = function () {
        //插屏只支持安卓头条客户端
        if (this.appName !== AppName.touTiao
            || this.platform == SDK_1.Platform.ios) {
            return false;
        }
        return true;
    };
    /**
     * 短震动
     */
    TTSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    TTSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    TTSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ''; }
        var index = Math.floor((Math.random() * this.shareTitleArr.length));
        var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
        var self = this;
        this.api.shareAppMessage({
            title: "" + this.shareTitleArr[index],
            imageUrl: "" + this.shareImgArr[indeximg],
            query: query,
            success: function (res) {
                self.showMessage('分享成功');
            },
            fail: function (res) {
                self.showMessage('分享失败');
            },
        });
    };
    /**
     * 激励分享&&带参分享
     */
    TTSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
        var index = Math.floor((Math.random() * this.shareTitleArr.length));
        var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
        var self = this;
        this.api.shareAppMessage({
            title: "" + this.shareTitleArr[index],
            imageUrl: "" + this.shareImgArr[indeximg],
            query: query,
            success: function (res) {
                self.showMessage('分享成功');
                success();
            },
            fail: function (res) {
                self.showMessage('分享失败');
                fail && fail();
            },
        });
    };
    /**
     * 录屏
     */
    TTSDK.prototype.recordVideo = function (type) {
        if (type === void 0) { type = 'start'; }
        var self = this;
        if (null === this.recordMng) {
            this.recordMng = this.api.getGameRecorderManager();
            this.recordMng.onStart(function (res) {
                console.log('录屏开始', res);
            });
            this.recordMng.onPause(function (res) {
                console.log("暂停录屏，", res);
            });
            this.recordMng.onResume(function (res) {
                console.log("继续录屏", res);
            });
            this.recordMng.onStop(function (res) {
                console.log('监听录屏结束', res);
                self.videoPath = res.videoPath + "";
                EventManager_1.default.emit(GameEventType_1.EventType.SDKEvent.recordSaved);
            });
            this.recordMng.onError(function (errMsg) {
                console.log('录屏错误：', JSON.stringify(errMsg));
                self.IsRecordError = true;
                EventManager_1.default.emit(GameEventType_1.EventType.SDKEvent.recordError);
            });
        }
        var recorder = this.recordMng;
        switch (type) {
            case "start": {
                this.IsRecordError = false;
                this.isShared = false;
                recorder.start({
                    duration: 120,
                });
                break;
            }
            case "pause": {
                recorder.pause();
                break;
            }
            case "resume": {
                recorder.resume();
                break;
            }
            case "stop": {
                recorder.stop();
                break;
            }
        }
    };
    /**分享录屏 */
    TTSDK.prototype.shareRecordVideo = function (success, fail) {
        var _this = this;
        var time = this.recordVideoData.totalTime;
        if (time <= 3) {
            this.showMessage("录屏时间短于3s不能分享哦~~");
            if (!!fail)
                fail();
            return;
        }
        console.log('视频地址', this.videoPath, this.IsRecordError);
        var self = this;
        if (this.videoPath && this.IsRecordError == false) {
            var index = Math.floor((Math.random() * this.shareTitleArr.length));
            var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
            this.api.shareAppMessage({
                channel: 'video',
                title: "" + this.shareTitleArr[index],
                imageUrl: "" + this.shareImgArr[indeximg],
                extra: {
                    videoPath: this.videoPath,
                },
                success: function (res) {
                    console.log('录屏发布成功:', JSON.stringify(res));
                    self.showMessage("发布成功");
                    if (!self.isShared) {
                        self.recordVideoData.onShare();
                        self.isShared = true;
                        success();
                    }
                },
                fail: function (res) {
                    console.log('录屏发布失败', JSON.stringify(res));
                    if (res.errMsg.indexOf("short") >= 0) {
                        self.showMessage("录屏时间短于3秒不能分享哦~~");
                    }
                    else if (res.errMsg.indexOf("cancel") >= 0) {
                        self.showMessage("发布取消");
                    }
                    if (!!fail)
                        fail();
                    return;
                    if (_this.appName == AppName.touTiao) { //头条版
                        if (self.systemInfo.platform == "ios") { //苹果手机 安卓手机为 android
                            if (res.errMsg == 'shareAppMessage:fail video duration is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('分享取消');
                            }
                        }
                        else {
                            var msg = res.errMsg.split(',')[0];
                            console.log('msg', msg);
                            if (msg == 'shareAppMessage:fail video file is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                    }
                    else if (_this.appName == AppName.jiSuTT) { //头条极速版
                        if (self.systemInfo.platform == "ios") { //苹果手机 安卓手机为 android
                            if (res.errMsg == 'shareAppMessage:fail video duration is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                        else {
                            var msg = res.errMsg.split(',')[0];
                            console.log('msg', msg);
                            if (msg == 'shareAppMessage:fail video file is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                    }
                    else if (_this.appName == AppName.douYin) { //抖音
                        if (self.systemInfo.platform == "ios") { //苹果手机 安卓手机为 android
                            if (res.errMsg == 'shareAppMessage:fail video duration is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                        else {
                            var msg = res.errMsg.split(',')[0];
                            console.log('msg', msg);
                            if (msg == 'shareAppMessageDirectly:fail') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                    }
                    else {
                        self.showMessage('发布取消');
                    }
                }
            });
        }
        else {
            self.showMessage('录屏错误');
            if (!!fail)
                fail();
        }
    };
    // /**
    //  * 消息提示
    //  */
    // public showMessage(msg: string, icon: string = 'none') {
    //     this.api.showToast({
    //         title: msg,
    //         duration: 2000,
    //         icon: icon,
    //         success: (res) => { }
    //     });
    // }
    TTSDK.prototype.navigateToMiniProgram = function (data) {
        this.api.navigateToMiniProgram({
            appId: data.gameId,
        });
    };
    return TTSDK;
}(SDK_1.default));
exports.default = TTSDK;
/**字节跳动平台的应用名称 */
var AppName;
(function (AppName) {
    /**开发者工具 */
    AppName[AppName["devtools"] = 0] = "devtools";
    /**今日头条 */
    AppName[AppName["touTiao"] = 1] = "touTiao";
    /**今日头条极速版 */
    AppName[AppName["jiSuTT"] = 2] = "jiSuTT";
    /**抖音 */
    AppName[AppName["douYin"] = 3] = "douYin";
    /**西瓜 */
    AppName[AppName["xiGua"] = 4] = "xiGua";
})(AppName || (AppName = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcU0RLXFxUVFNESy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw2QkFBc0M7QUFDdEMsZ0RBQTJDO0FBQzNDLDBEQUFxRDtBQUNyRCxpRUFBNEQ7QUFFNUQ7SUFBbUMseUJBQUc7SUFBdEM7UUFBQSxxRUErZkM7UUE5ZlcsYUFBTyxHQUFXLElBQUksQ0FBQztRQUVyQixhQUFPLEdBQVksSUFBSSxDQUFDO1FBc0psQyxtQkFBbUI7UUFDVCxzQkFBZ0IsR0FBVyxDQUFDLENBQUM7UUFDdkMseUJBQXlCO1FBQ2Ysb0JBQWMsR0FBWSxLQUFLLENBQUM7UUFDMUMsbUJBQW1CO1FBQ1Qsa0JBQVksR0FBWSxLQUFLLENBQUM7UUFpRXhDLElBQUk7UUFDTSxjQUFRLEdBQVEsSUFBSSxDQUFDO1FBaUgvQixnQkFBZ0I7UUFDVCxjQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLE9BQU87UUFDQyxtQkFBYSxHQUFZLEtBQUssQ0FBQztRQUN2QyxNQUFNO1FBQ0UsZUFBUyxHQUFXLEVBQUUsQ0FBQztRQUNyQixlQUFTLEdBQVEsSUFBSSxDQUFDOztJQXdLcEMsQ0FBQztJQTNmRzs7O09BR0c7SUFDTywyQkFBVyxHQUFyQjtRQUNJLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BELFFBQVEsT0FBTyxFQUFFO1lBQ2IsS0FBSyxTQUFTLENBQUMsQ0FBQztnQkFDWixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUM7Z0JBQy9CLE1BQU07YUFDVDtZQUNELEtBQUssUUFBUSxDQUFDLENBQUM7Z0JBQ1gsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUM5QixNQUFNO2FBQ1Q7WUFDRCxLQUFLLE9BQU8sQ0FBQyxDQUFDO2dCQUNWLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQztnQkFDN0IsTUFBTTthQUNUO1lBQ0QsS0FBSyxtQkFBbUIsQ0FBQyxDQUFDO2dCQUN0QixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQzlCLE1BQU07YUFDVDtZQUNELE9BQU8sQ0FBQyxDQUFDO2dCQUNMLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQztnQkFDaEMsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBRU0sb0JBQUksR0FBWDtRQUNJLElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVoQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUMvQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2xHLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBRTdDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsZUFBZSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFFbkQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFHRCxPQUFPO0lBQ0EsMkJBQVcsR0FBbEIsVUFBbUIsU0FBZTtRQUFsQyxpQkE0Q0M7UUEzQ0csSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRTtZQUN4QixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDTCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzdCLE9BQU87U0FDVjtRQUNELDRCQUE0QjtRQUM1QixJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdkUsSUFBSSxJQUFJLEdBQUcsQ0FBQztZQUNSLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQTtRQUNGLGVBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0IsSUFBSSxLQUFLLEdBQUcsQ0FBQyxVQUFDLEdBQUc7WUFDYixLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLENBQUMsQ0FBQyxDQUFBO1FBQ0YsZUFBZSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMvQixJQUFJLFFBQVEsR0FBRyxDQUFDLFVBQUMsR0FBRztZQUNoQixlQUFlLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzlCLGVBQWUsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1lBQ3ZCLElBQUksR0FBRyxJQUFJLEdBQUcsQ0FBQyxPQUFPLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRTtnQkFDekMsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQ3pCO2lCQUFNO2dCQUNILEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbkIsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3RCO1FBQ0wsQ0FBQyxDQUFDLENBQUE7UUFDRixlQUFlLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2xDLFVBQVU7UUFDVixlQUFlLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBQ3hCLGVBQWUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQ3hCLFVBQUEsR0FBRztnQkFDQyxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN0QixlQUFlLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM5QixlQUFlLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNoQyxlQUFlLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNuQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1lBQzNCLENBQUMsQ0FBQyxDQUFDO1FBQ1gsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0QsbUJBQW1CO0lBQ1QsOEJBQWMsR0FBeEI7UUFDSSxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksT0FBTyxDQUFDLFFBQVEsRUFBRTtZQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDOUIsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBSUQ7O09BRUc7SUFDSSwwQkFBVSxHQUFqQixVQUFrQixFQUFhO1FBQS9CLGlCQWtDQztRQWpDRyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFO1lBQ3pCLE9BQU87U0FDVjtRQUNELElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUU7WUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ2hDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNwQixPQUFPO1NBQ1Y7UUFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxDQUFDLEVBQUU7WUFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1lBQ3ZDLE9BQU87U0FDVjtRQUNELElBQUksSUFBSSxDQUFDLGFBQWE7WUFBRSxPQUFPO1FBQy9CLGNBQWM7UUFDZCxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2xCLHVCQUF1QjtZQUN2QixJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ25CLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO29CQUN2QixLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7b0JBQ3BCLEtBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO29CQUMxQixJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7d0JBQ04sRUFBRSxFQUFFLENBQUM7cUJBQ1I7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7YUFDTjtpQkFBTTtnQkFDSCxrQ0FBa0M7Z0JBQ2xDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2FBQzlCO1NBQ0o7YUFBTTtZQUNILHVDQUF1QztZQUN2QyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7U0FDMUI7SUFDTCxDQUFDO0lBQ0Qsb0JBQW9CO0lBQ1YsK0JBQWUsR0FBekI7UUFDSSxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQzNCLE9BQU8sS0FBSyxDQUFDO1NBQ2hCO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQVFELDhEQUE4RDtJQUN2RCwrQkFBZSxHQUF0QjtRQUFBLGlCQWlDQztRQWhDRyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLEVBQUU7WUFBRSxPQUFPLElBQUksQ0FBQztRQUNyQixJQUFJLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztRQUM5QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1lBQ3JDLFFBQVEsRUFBRSxFQUFFO1lBQ1osS0FBSyxFQUFFO2dCQUNILEtBQUssRUFBRSxtQkFBbUI7Z0JBQzFCLEdBQUcsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxDQUFDLG1CQUFtQixHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7YUFDckU7U0FDSixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUc7WUFDdkIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0QixLQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7UUFDSCxvQ0FBb0M7UUFDcEMsZ0NBQWdDO1FBQ2hDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFVBQUEsSUFBSTtZQUN4QixPQUFPO1lBQ1AsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDdEUsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMzRSxhQUFhO1lBQ2IsMEJBQTBCO1FBQzlCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7WUFDbEIsS0FBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDekIsSUFBSSxLQUFJLENBQUMsY0FBYyxFQUFFO2dCQUNyQixLQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2xCLEtBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO2FBQy9CO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ25DLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUMxQixDQUFDO0lBQ0Q7O09BRUc7SUFDSSw0QkFBWSxHQUFuQjtRQUNJLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDbkIsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssRUFBRTtnQkFDbkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO2dCQUM1QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzthQUMxQjtpQkFBTTtnQkFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ3pCO1NBQ0o7UUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUNoQyxDQUFDO0lBQ0QsY0FBYztJQUNKLDZCQUFhLEdBQXZCO1FBQ0ksSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLDRCQUE0QjtZQUM1Qiw2QkFBNkI7WUFDN0IsOEJBQThCO1lBQzlCLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxpQ0FBaUM7WUFDM0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7U0FDekI7UUFDRCxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztJQUM5QixDQUFDO0lBSU0sa0NBQWtCLEdBQXpCLFVBQTBCLE1BQWdCO1FBQTFDLGlCQXlDQztRQXhDRyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsTUFBTSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLEVBQUU7WUFDekIsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0IsT0FBTztTQUNWO1FBQ0QsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDbEMsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNMLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1lBQy9CLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDakIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztTQUN4QjtRQUNELElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsY0FBYyxFQUFFO1lBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDM0IsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0IsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUM7UUFDL0IsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3JELGNBQWMsQ0FBQyxPQUFPLENBQUMsVUFBQyxHQUFHO1lBQ3ZCLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsS0FBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDbkMsQ0FBQyxDQUFDLENBQUM7UUFDSCxjQUFjLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBQ3ZCLElBQUk7Z0JBQ0EsY0FBYyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQztvQkFDdkIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO29CQUNwQixLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3hCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFDLEdBQUc7b0JBQ1QsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDdEIsS0FBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7Z0JBQ25DLENBQUMsQ0FBQyxDQUFDO2FBQ047WUFBQyxPQUFPLEdBQUcsRUFBRTtnQkFDVixLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN0QixLQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQzthQUNsQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELG9CQUFvQjtJQUNWLCtCQUFlLEdBQXpCO1FBQ0ksY0FBYztRQUNkLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxPQUFPLENBQUMsT0FBTztlQUM3QixJQUFJLENBQUMsUUFBUSxJQUFJLGNBQVEsQ0FBQyxHQUFHLEVBQUU7WUFDbEMsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRUQ7O09BRUc7SUFDSSw0QkFBWSxHQUFuQjtRQUNJLElBQUksc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtZQUN0QyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLDJCQUFXLEdBQWxCO1FBQ0ksSUFBSSxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzVCO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksK0JBQWUsR0FBdEIsVUFBdUIsS0FBa0I7UUFBbEIsc0JBQUEsRUFBQSxVQUFrQjtRQUNyQyxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUM1RSxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUM3RSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUE7UUFDZixJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQztZQUNyQixLQUFLLEVBQUUsS0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBRztZQUNyQyxRQUFRLEVBQUUsS0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBRztZQUN6QyxLQUFLLEVBQUUsS0FBSztZQUNaLE9BQU8sRUFBRSxVQUFVLEdBQUc7Z0JBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDN0IsQ0FBQztZQUNELElBQUksRUFBRSxVQUFVLEdBQUc7Z0JBQ2YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM3QixDQUFDO1NBQ0osQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOztPQUVHO0lBQ0ksNkJBQWEsR0FBcEIsVUFBcUIsT0FBaUIsRUFBRSxJQUFlLEVBQUUsS0FBa0I7UUFBbEIsc0JBQUEsRUFBQSxVQUFrQjtRQUN2RSxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUM1RSxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUM3RSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUE7UUFDZixJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQztZQUNyQixLQUFLLEVBQUUsS0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBRztZQUNyQyxRQUFRLEVBQUUsS0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBRztZQUN6QyxLQUFLLEVBQUUsS0FBSztZQUNaLE9BQU8sRUFBRSxVQUFVLEdBQUc7Z0JBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3pCLE9BQU8sRUFBRSxDQUFDO1lBQ2QsQ0FBQztZQUNELElBQUksRUFBRSxVQUFVLEdBQUc7Z0JBQ2YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDekIsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ25CLENBQUM7U0FDSixDQUFDLENBQUM7SUFDUCxDQUFDO0lBU0Q7O09BRUc7SUFDSSwyQkFBVyxHQUFsQixVQUFtQixJQUFzQjtRQUF0QixxQkFBQSxFQUFBLGNBQXNCO1FBQ3JDLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUNoQixJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ25ELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztnQkFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDN0IsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUc7Z0JBQ3ZCLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsVUFBQyxHQUFHO2dCQUN4QixPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQztZQUM3QixDQUFDLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQUEsR0FBRztnQkFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7Z0JBQ3BDLHNCQUFZLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBQyxNQUFNO2dCQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQzdDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUMxQixzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUN0RCxDQUFDLENBQUMsQ0FBQztTQUNOO1FBQ0QsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUM5QixRQUFRLElBQUksRUFBRTtZQUNWLEtBQUssT0FBTyxDQUFDLENBQUM7Z0JBQ1YsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2dCQUN0QixRQUFRLENBQUMsS0FBSyxDQUFDO29CQUNYLFFBQVEsRUFBRSxHQUFHO2lCQUNoQixDQUFDLENBQUE7Z0JBQ0YsTUFBTTthQUNUO1lBQ0QsS0FBSyxPQUFPLENBQUMsQ0FBQztnQkFDVixRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ2pCLE1BQU07YUFDVDtZQUNELEtBQUssUUFBUSxDQUFDLENBQUM7Z0JBQ1gsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNsQixNQUFNO2FBQ1Q7WUFDRCxLQUFLLE1BQU0sQ0FBQyxDQUFDO2dCQUNULFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDaEIsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBRUQsVUFBVTtJQUNILGdDQUFnQixHQUF2QixVQUF3QixPQUFpQixFQUFFLElBQWU7UUFBMUQsaUJBK0ZDO1FBOUZHLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDO1FBQzFDLElBQUksSUFBSSxJQUFJLENBQUMsRUFBRTtZQUNYLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsQ0FBQyxJQUFJO2dCQUFFLElBQUksRUFBRSxDQUFDO1lBQ25CLE9BQU87U0FDVjtRQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFBO1FBQ3ZELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUNoQixJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLEVBQUU7WUFDL0MsSUFBSSxLQUFLLEdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDNUUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDN0UsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7Z0JBQ3JCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixLQUFLLEVBQUUsS0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBRztnQkFDckMsUUFBUSxFQUFFLEtBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUc7Z0JBQ3pDLEtBQUssRUFBRTtvQkFDSCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUJBRTVCO2dCQUNELE9BQU8sRUFBRSxVQUFDLEdBQUc7b0JBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUM1QyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTt3QkFDaEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQzt3QkFDL0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7d0JBQ3JCLE9BQU8sRUFBRSxDQUFDO3FCQUNiO2dCQUNMLENBQUM7Z0JBQ0QsSUFBSSxFQUFFLFVBQUMsR0FBRztvQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQzNDLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUM7cUJBQ3ZDO3lCQUFNLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUMxQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUM1QjtvQkFDRCxJQUFJLENBQUMsQ0FBQyxJQUFJO3dCQUFFLElBQUksRUFBRSxDQUFDO29CQUNuQixPQUFPO29CQUNQLElBQUksS0FBSSxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFLEVBQUUsS0FBSzt3QkFDeEMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxLQUFLLEVBQUUsRUFBRSxvQkFBb0I7NEJBQ3pELElBQUksR0FBRyxDQUFDLE1BQU0sSUFBSSxrREFBa0QsRUFBRTtnQ0FDbEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFBOzZCQUN0QztpQ0FBTTtnQ0FDSCxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBOzZCQUMzQjt5QkFDSjs2QkFBTTs0QkFDSCxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUE7NEJBQ3ZCLElBQUksR0FBRyxJQUFJLDhDQUE4QyxFQUFFO2dDQUN2RCxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUE7NkJBQ3RDO2lDQUFNO2dDQUNILElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7NkJBQzNCO3lCQUNKO3FCQUNKO3lCQUFNLElBQUksS0FBSSxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsT0FBTzt3QkFDaEQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxLQUFLLEVBQUUsRUFBRSxvQkFBb0I7NEJBQ3pELElBQUksR0FBRyxDQUFDLE1BQU0sSUFBSSxrREFBa0QsRUFBRTtnQ0FDbEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFBOzZCQUN0QztpQ0FBTTtnQ0FDSCxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBOzZCQUMzQjt5QkFDSjs2QkFBTTs0QkFDSCxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUE7NEJBQ3ZCLElBQUksR0FBRyxJQUFJLDhDQUE4QyxFQUFFO2dDQUN2RCxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUE7NkJBQ3RDO2lDQUFNO2dDQUNILElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7NkJBQzNCO3lCQUNKO3FCQUNKO3lCQUFNLElBQUksS0FBSSxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUMsSUFBSTt3QkFDNUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxLQUFLLEVBQUUsRUFBRSxvQkFBb0I7NEJBQ3pELElBQUksR0FBRyxDQUFDLE1BQU0sSUFBSSxrREFBa0QsRUFBRTtnQ0FDbEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFBOzZCQUN0QztpQ0FBTTtnQ0FDSCxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBOzZCQUMzQjt5QkFDSjs2QkFBTTs0QkFDSCxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTs0QkFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUE7NEJBQ3ZCLElBQUksR0FBRyxJQUFJLDhCQUE4QixFQUFFO2dDQUN2QyxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUE7NkJBQ3RDO2lDQUFNO2dDQUNILElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7NkJBQzNCO3lCQUNKO3FCQUNKO3lCQUFNO3dCQUNILElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7cUJBQzNCO2dCQUNMLENBQUM7YUFDSixDQUFDLENBQUM7U0FDTjthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6QixJQUFJLENBQUMsQ0FBQyxJQUFJO2dCQUFFLElBQUksRUFBRSxDQUFDO1NBQ3RCO0lBQ0wsQ0FBQztJQUVELE1BQU07SUFDTixVQUFVO0lBQ1YsTUFBTTtJQUNOLDJEQUEyRDtJQUMzRCwyQkFBMkI7SUFDM0Isc0JBQXNCO0lBQ3RCLDBCQUEwQjtJQUMxQixzQkFBc0I7SUFDdEIsZ0NBQWdDO0lBQ2hDLFVBQVU7SUFDVixJQUFJO0lBRUcscUNBQXFCLEdBQTVCLFVBQTZCLElBQVM7UUFDbEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztZQUMzQixLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU07U0FDckIsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNMLFlBQUM7QUFBRCxDQS9mQSxBQStmQyxDQS9ma0MsYUFBRyxHQStmckM7O0FBRUQsaUJBQWlCO0FBQ2pCLElBQUssT0FXSjtBQVhELFdBQUssT0FBTztJQUNSLFdBQVc7SUFDWCw2Q0FBUSxDQUFBO0lBQ1IsVUFBVTtJQUNWLDJDQUFPLENBQUE7SUFDUCxhQUFhO0lBQ2IseUNBQU0sQ0FBQTtJQUNOLFFBQVE7SUFDUix5Q0FBTSxDQUFBO0lBQ04sUUFBUTtJQUNSLHVDQUFLLENBQUE7QUFDVCxDQUFDLEVBWEksT0FBTyxLQUFQLE9BQU8sUUFXWCIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBTREssIHsgUGxhdGZvcm0gfSBmcm9tIFwiLi9TREtcIjtcbmltcG9ydCBHYW1lUGxhdGZvcm0gZnJvbSBcIi4uL0dhbWVQbGF0Zm9ybVwiO1xuaW1wb3J0IEV2ZW50TWFuYWdlciBmcm9tIFwiLi4vLi4vQ29tbW9uL0V2ZW50TWFuYWdlclwiO1xuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVFRTREsgZXh0ZW5kcyBTREsge1xuICAgIHByaXZhdGUgYXBpTmFtZTogc3RyaW5nID0gJ3R0JztcblxuICAgIHByb3RlY3RlZCBhcHBOYW1lOiBBcHBOYW1lID0gbnVsbDtcbiAgICAvKipcbiAgICAgKiDorrDlvZXlrZfoioLot7PliqjlubPlj7DkuIvnmoTlupTnlKjnqIvluo/nmoTnsbvlnovvvIxcbiAgICAgKiDlj4LogIPmlofmoaPvvJpodHRwczovL21pY3JvYXBwLmJ5dGVkYW5jZS5jb20vZGV2L2NuL21pbmktYXBwL2RldmVsb3AvYmFzaWMtbGlicmFyeS9jb21wYXRpYmlsaXR5LWRlc2NyaXB0aW9uXG4gICAgICovXG4gICAgcHJvdGVjdGVkIGluaXRBcHBUeXBlKCkge1xuICAgICAgICBsZXQgYXBwTmFtZSA9IHRoaXMuc3lzdGVtSW5mby5hcHBOYW1lLnRvVXBwZXJDYXNlKCk7XG4gICAgICAgIHN3aXRjaCAoYXBwTmFtZSkge1xuICAgICAgICAgICAgY2FzZSBcIlRPVVRJQU9cIjoge1xuICAgICAgICAgICAgICAgIHRoaXMuYXBwTmFtZSA9IEFwcE5hbWUudG91VGlhbztcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgXCJET1VZSU5cIjoge1xuICAgICAgICAgICAgICAgIHRoaXMuYXBwTmFtZSA9IEFwcE5hbWUuZG91WWluO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBcIlhJR1VBXCI6IHtcbiAgICAgICAgICAgICAgICB0aGlzLmFwcE5hbWUgPSBBcHBOYW1lLnhpR3VhO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBcIk5FV1NfQVJUSUNMRV9MSVRFXCI6IHtcbiAgICAgICAgICAgICAgICB0aGlzLmFwcE5hbWUgPSBBcHBOYW1lLmppU3VUVDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgICAgICAgICB0aGlzLmFwcE5hbWUgPSBBcHBOYW1lLmRldnRvb2xzO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHVibGljIGluaXQoKSB7XG4gICAgICAgIHRoaXMuYXBpID0gd2luZG93W3RoaXMuYXBpTmFtZV07XG5cbiAgICAgICAgdGhpcy5zeXN0ZW1JbmZvID0gdGhpcy5hcGkuZ2V0U3lzdGVtSW5mb1N5bmMoKTtcbiAgICAgICAgdGhpcy5pbml0QXBwVHlwZSgpO1xuICAgICAgICB0aGlzLnNldFN5c3RlbUluZm8odGhpcy5zeXN0ZW1JbmZvLnBsYXRmb3JtLCB0aGlzLnN5c3RlbUluZm8udmVyc2lvbiwgdGhpcy5zeXN0ZW1JbmZvLlNES1ZlcnNpb24pO1xuICAgICAgICBjb25zb2xlLmxvZyhcIuezu+e7n+S/oeaBr++8mlwiKTtcbiAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkodGhpcy5zeXN0ZW1JbmZvKSk7XG5cbiAgICAgICAgdGhpcy5hcGkuc2hvd1NoYXJlTWVudSh7IHdpdGhTaGFyZVRpY2tldDogZmFsc2UgfSk7XG5cbiAgICAgICAgdGhpcy5wcmVDcmVhdGVCYW5uZXIoKTtcbiAgICB9XG5cblxuICAgIC8vdmlkZW9cbiAgICBwdWJsaWMgc2hvd1ZpZGVvQWQodmlkZW9OYW1lPzogYW55KSB7XG4gICAgICAgIGlmICghdGhpcy5jYW5BcGlVc2VWaWRlbygpKSB7XG4gICAgICAgICAgICB0aGlzLm9uVmlkZW9TdWNjZXNzKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGlkID0gdGhpcy5nZXRWaWRlb0FkVW5pdElkKHZpZGVvTmFtZSk7XG4gICAgICAgIGlmICghaWQpIHtcbiAgICAgICAgICAgIHRoaXMub25WaWRlb0ZhaWwoXCLojrflj5bop4bpopFpZOWksei0pVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvL+S4jeaUr+aMgeWcqOW8gOWPkeW3peWFt+i/kOihjO+8jOWPquiDveWcqOecn+acuui/kOihjCDov5Tlm57lgLzmmK/kuKrljZXkvotcbiAgICAgICAgdmFyIHJld2FyZGVkVmlkZW9BZCA9IHRoaXMuYXBpLmNyZWF0ZVJld2FyZGVkVmlkZW9BZCh7IGFkVW5pdElkOiBpZCB9KTtcbiAgICAgICAgbGV0IGxvYWQgPSAoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5vblZpZGVvU2hvdygpO1xuICAgICAgICB9KVxuICAgICAgICByZXdhcmRlZFZpZGVvQWQub25Mb2FkKGxvYWQpO1xuICAgICAgICBsZXQgZXJyb3IgPSAoKGVycikgPT4ge1xuICAgICAgICAgICAgdGhpcy5vblZpZGVvRmFpbChlcnIpO1xuICAgICAgICB9KVxuICAgICAgICByZXdhcmRlZFZpZGVvQWQub25FcnJvcihlcnJvcik7XG4gICAgICAgIGxldCBjbG9zZWZ1biA9ICgocmVzKSA9PiB7XG4gICAgICAgICAgICByZXdhcmRlZFZpZGVvQWQub2ZmTG9hZChsb2FkKTtcbiAgICAgICAgICAgIHJld2FyZGVkVmlkZW9BZC5vZmZFcnJvcihlcnJvcik7XG4gICAgICAgICAgICByZXdhcmRlZFZpZGVvQWQub2ZmQ2xvc2UoY2xvc2VmdW4pO1xuICAgICAgICAgICAgcmV3YXJkZWRWaWRlb0FkID0gbnVsbDtcbiAgICAgICAgICAgIGlmIChyZXMgJiYgcmVzLmlzRW5kZWQgfHwgcmVzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9uVmlkZW9TdWNjZXNzKCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb1F1aXQoKTtcbiAgICAgICAgICAgICAgICB0aGlzLm9uVmlkZW9IaWRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICAgIHJld2FyZGVkVmlkZW9BZC5vbkNsb3NlKGNsb3NlZnVuKTtcbiAgICAgICAgLy/lvIDlp4vliqDovb3op4bpopHlub/lkYpcbiAgICAgICAgcmV3YXJkZWRWaWRlb0FkLmxvYWQoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHJld2FyZGVkVmlkZW9BZC5zaG93KCkuY2F0Y2goXG4gICAgICAgICAgICAgICAgZXJyID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vblZpZGVvRmFpbChlcnIpO1xuICAgICAgICAgICAgICAgICAgICByZXdhcmRlZFZpZGVvQWQub2ZmTG9hZChsb2FkKTtcbiAgICAgICAgICAgICAgICAgICAgcmV3YXJkZWRWaWRlb0FkLm9mZkVycm9yKGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgcmV3YXJkZWRWaWRlb0FkLm9mZkNsb3NlKGNsb3NlZnVuKTtcbiAgICAgICAgICAgICAgICAgICAgcmV3YXJkZWRWaWRlb0FkID0gbnVsbDtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKuiDveWQpuS9v+eUqGFwae+8mnZpZGVvICovXG4gICAgcHJvdGVjdGVkIGNhbkFwaVVzZVZpZGVvKCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAodGhpcy5hcHBOYW1lID09IEFwcE5hbWUuZGV2dG9vbHMpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5byA5Y+R6ICF5bel5YW35LiK5peg5rOV5pi+56S66KeG6aKR5bm/5ZGKXCIpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIC8v5b2T5YmN5bm/5ZGKXG4gICAgcHJpdmF0ZSBfYmFubmVyQWQ6IGFueTtcbiAgICAvKipcbiAgICAgKiDmiZPlvIBiYW5uZXLlub/lkYpcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hvd0Jhbm5lcihjYj86IEZ1bmN0aW9uKSB7XG4gICAgICAgIGlmICghdGhpcy5jYW5BcGlVc2VCYW5uZXIoKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmluc2VydEFkUmVjb3JkLmlzU2hvd2luZykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLmnInmj5LlsY/mmL7npLrvvIzkuI3lho3mmL7npLpiYW5uZXJcIik7XG4gICAgICAgICAgICB0aGlzLnJlbW92ZUJhbm5lcigpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmJhbm5lclJlY29yZC5nZXRTaG93U3BhY2VUaW1lKCkgPCAxKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIui3neemu+S4iuasoeaYvuekumJhbm5lcuaXtumXtOWwj+S6jjFz77yM5LiN5YaN5Yib5bu6XCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmJhbm5lclNob3dpbmcpIHJldHVybjtcbiAgICAgICAgLy/lt7Lnu4/liJvlu7rkuoZiYW5uZXLvvJpcbiAgICAgICAgaWYgKCEhdGhpcy5fYmFubmVyQWQpIHtcbiAgICAgICAgICAgIC8v5Yib5bu655qEYmFubmVy5bey57uP5Yqg6L295oiQ5Yqf77yM55u05o6l5pi+56S677yaXG4gICAgICAgICAgICBpZiAodGhpcy5iYW5uZXJMb2FkZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5zaG93KCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25CYW5uZXJTaG93KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYmFubmVyU2hvd2luZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGlmICghIWNiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYigpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8v5Yib5bu655qEYmFubmVy6L+Y5rKh5Yqg6L295a6M5oiQ5pe277yM6K6+572u5qCH6K6w77yM5L2/5YW25Zyo5Yqg6L295a6M5oiQ5ZCO5pi+56S6XG4gICAgICAgICAgICAgICAgdGhpcy5uZWVkU2hvd0Jhbm5lciA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvL+WwmuacquWIm+W7umJhbm5lcu+8jOWImeiuvue9ruagh+iusO+8jOWIm+W7umJhbm5lcu+8jOW5tuS9v+WFtuWcqOWKoOi9veWujOaIkOWQjuaYvuekulxuICAgICAgICAgICAgdGhpcy5uZWVkU2hvd0Jhbm5lciA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLnByZUNyZWF0ZUJhbm5lcigpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKuiDveWQpuS9v+eUqGFwae+8mmJhbm5lciAqL1xuICAgIHByb3RlY3RlZCBjYW5BcGlVc2VCYW5uZXIoKSB7XG4gICAgICAgIGlmICh0aGlzLmFwcE5hbWUgPT0gQXBwTmFtZS5kb3VZaW4pIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5oqW6Z+z5bmz5Y+w5pegYmFubmVyXCIpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIC8qKuWIm+W7uuaWsOeahGJhbm5lcueahOaXtumXtCAqL1xuICAgIHByb3RlY3RlZCBjcmVhdGVCYW5uZXJUaW1lOiBudW1iZXIgPSAwO1xuICAgIC8qKmJhbm5lcuWKoOi9veaIkOWKn+WQjuaYr+WQpumcgOimgeeri+WNs+aYvuekuiAqL1xuICAgIHByb3RlY3RlZCBuZWVkU2hvd0Jhbm5lcjogYm9vbGVhbiA9IGZhbHNlO1xuICAgIC8qKmJhbm5lcuaYr+WQpuW3suWKoOi9veWujOavlSAqL1xuICAgIHByb3RlY3RlZCBiYW5uZXJMb2FkZWQ6IGJvb2xlYW4gPSBmYWxzZTtcbiAgICAvKirpooTlhYjliJvlu7piYW5uZXLvvIzliJvlu7rnmoRiYW5uZXLlnKjliqDovb3lrozmiJDml7bvvIzkvJrmoLnmja4gbmVlZFNob3dCYW5uZXIg56Gu5a6a5piv5ZCm6ZyA6KaB56uL5Y2z5pi+56S6ICovXG4gICAgcHVibGljIHByZUNyZWF0ZUJhbm5lcigpIHtcbiAgICAgICAgbGV0IGlkID0gdGhpcy5nZXRCYW5uZXJJZCgpO1xuICAgICAgICBpZiAoIWlkKSByZXR1cm4gbnVsbDtcbiAgICAgICAgbGV0IHRhcmdldEJhbm5lckFkV2lkdGggPSAyMDA7XG4gICAgICAgIHRoaXMuX2Jhbm5lckFkID0gdGhpcy5hcGkuY3JlYXRlQmFubmVyQWQoe1xuICAgICAgICAgICAgYWRVbml0SWQ6IGlkLFxuICAgICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgICAgICB3aWR0aDogdGFyZ2V0QmFubmVyQWRXaWR0aCxcbiAgICAgICAgICAgICAgICB0b3A6IHRoaXMuc3lzdGVtSW5mby53aW5kb3dIZWlnaHQgLSAodGFyZ2V0QmFubmVyQWRXaWR0aCAvIDE2ICogOSksIC8vIOagueaNruezu+e7n+e6puWumuWwuuWvuOiuoeeul+WHuuW5v+WRiumrmOW6plxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fYmFubmVyQWQub25FcnJvcigoZXJyKSA9PiB7XG4gICAgICAgICAgICB0aGlzLm9uQmFubmVyRXJyKGVycik7XG4gICAgICAgICAgICB0aGlzLmRlc3Ryb3lCYW5uZXIoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIOWwuuWvuOiwg+aVtOaXtuS8muinpuWPkeWbnuiwg++8jOmAmui/h+Wbnuiwg+aLv+WIsOeahOW5v+WRiuecn+WunuWuvemrmOWGjei/m+ihjOWumuS9jemAgumFjeWkhOeQhlxuICAgICAgICAvLyDms6jmhI/vvJrlpoLmnpzlnKjlm57osIPph4zlho3mrKHosIPmlbTlsLrlr7jvvIzopoHnoa7kv53kuI3opoHop6blj5Hmrbvlvqrnjq/vvIHvvIHvvIFcbiAgICAgICAgdGhpcy5fYmFubmVyQWQub25SZXNpemUoc2l6ZSA9PiB7XG4gICAgICAgICAgICAvLyBnb29kXG4gICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5zdHlsZS50b3AgPSB0aGlzLnN5c3RlbUluZm8ud2luZG93SGVpZ2h0IC0gc2l6ZS5oZWlnaHQ7XG4gICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5zdHlsZS5sZWZ0ID0gKHRoaXMuc3lzdGVtSW5mby53aW5kb3dXaWR0aCAtIHNpemUud2lkdGgpIC8gMjtcbiAgICAgICAgICAgIC8vIGJhZO+8jOS8muinpuWPkeatu+W+queOr1xuICAgICAgICAgICAgLy8gYmFubmVyQWQuc3R5bGUud2lkdGgrKztcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuX2Jhbm5lckFkLm9uTG9hZCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmJhbm5lckxvYWRlZCA9IHRydWU7XG4gICAgICAgICAgICBpZiAodGhpcy5uZWVkU2hvd0Jhbm5lcikge1xuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lcigpO1xuICAgICAgICAgICAgICAgIHRoaXMubmVlZFNob3dCYW5uZXIgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY3JlYXRlQmFubmVyVGltZSA9IERhdGUubm93KCk7XG4gICAgICAgIHJldHVybiB0aGlzLl9iYW5uZXJBZDtcbiAgICB9XG4gICAgLyoqXG4gICAgICog5YWz6ZetYmFubmVy5bm/5ZGKXG4gICAgICovXG4gICAgcHVibGljIHJlbW92ZUJhbm5lcigpIHtcbiAgICAgICAgaWYgKHRoaXMuX2Jhbm5lckFkKSB7XG4gICAgICAgICAgICBsZXQgdCA9IERhdGUubm93KCk7XG4gICAgICAgICAgICBpZiAodCAtIHRoaXMuY3JlYXRlQmFubmVyVGltZSA+IDYwMDAwKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLot53kuIrmrKHmmL7npLpiYW5uZXLlt7LotoXov4c2MOenku+8jOWIm+W7uuaWsOeahGJhbm5lclwiKTtcbiAgICAgICAgICAgICAgICB0aGlzLmRlc3Ryb3lCYW5uZXIoKTtcbiAgICAgICAgICAgICAgICB0aGlzLnByZUNyZWF0ZUJhbm5lcigpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5oaWRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5iYW5uZXJTaG93aW5nID0gZmFsc2U7XG4gICAgICAgIHRoaXMubmVlZFNob3dCYW5uZXIgPSBmYWxzZTtcbiAgICB9XG4gICAgLyoq6ZSA5q+BYmFubmVyICovXG4gICAgcHJvdGVjdGVkIGRlc3Ryb3lCYW5uZXIoKSB7XG4gICAgICAgIGlmICh0aGlzLl9iYW5uZXJBZCkge1xuICAgICAgICAgICAgLy8gdGhpcy5fYmFubmVyQWQub2ZmTG9hZCgpO1xuICAgICAgICAgICAgLy8gdGhpcy5fYmFubmVyQWQub2ZmRXJyb3IoKTtcbiAgICAgICAgICAgIC8vIHRoaXMuX2Jhbm5lckFkLm9mZlJlc2l6ZSgpO1xuICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQuZGVzdHJveSgpOyAvL+imgeWFiOaKiuaXp+eahOW5v+WRiue7memUgOavge+8jOS4jeeEtuS8muWvvOiHtOWFtuebkeWQrOeahOS6i+S7tuaXoOazlemHiuaUvu+8jOW9seWTjeaAp+iDvVxuICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYmFubmVyTG9hZGVkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgLy/mj5LlsY9cbiAgICBwcm90ZWN0ZWQgaW5zZXJ0QWQ6IGFueSA9IG51bGw7XG4gICAgcHVibGljIHNob3dJbnRlcnN0aXRpYWxBZChiYW5uZXI/OiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMudXNlQmFubmVySW5zdGVhZEluc2VydCA9IGJhbm5lcjtcbiAgICAgICAgaWYgKCF0aGlzLmNhbkFwaVVzZUluc2VydCgpKSB7XG4gICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGlkID0gdGhpcy5nZXRJbnNlcnRBZFVuaXRJZCgpO1xuICAgICAgICBpZiAoIWlkKSB7XG4gICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCEhdGhpcy5pbnNlcnRBZCkge1xuICAgICAgICAgICAgdGhpcy5pbnNlcnRBZC5kZXN0cm95KCk7XG4gICAgICAgICAgICB0aGlzLmluc2VydEFkID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBsZXQgaW50ZXJzdGl0aWFsQWQgPSB0aGlzLmFwaS5jcmVhdGVJbnRlcnN0aXRpYWxBZCh7IGFkVW5pdElkOiBpZCB9KTtcbiAgICAgICAgaWYgKCFpbnRlcnN0aXRpYWxBZCkge1xuICAgICAgICAgICAgdGhpcy5vbkluc2VydEVycihcIuaPkuWxj+WIm+W7uuWksei0pVwiKTtcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmluc2VydEFkID0gaW50ZXJzdGl0aWFsQWQ7XG4gICAgICAgIGludGVyc3RpdGlhbEFkLm9uQ2xvc2UodGhpcy5vbkluc2VydEhpZGUuYmluZCh0aGlzKSk7XG4gICAgICAgIGludGVyc3RpdGlhbEFkLm9uRXJyb3IoKGVycikgPT4ge1xuICAgICAgICAgICAgdGhpcy5vbkluc2VydEVycihlcnIpO1xuICAgICAgICAgICAgdGhpcy5zaG93QmFubmVySW5zdGVhZEluc2VydCgpO1xuICAgICAgICB9KTtcbiAgICAgICAgaW50ZXJzdGl0aWFsQWQubG9hZCgpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBpbnRlcnN0aXRpYWxBZC5zaG93KCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlQmFubmVyKCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25JbnNlcnRTaG93KCk7XG4gICAgICAgICAgICAgICAgfSkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uSW5zZXJ0RXJyKGVycik7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIHRoaXMub25JbnNlcnRFcnIoZXJyKTtcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKirog73lkKbmmK/lkKZhcGnvvJppbnNlcnQgKi9cbiAgICBwcm90ZWN0ZWQgY2FuQXBpVXNlSW5zZXJ0KCkge1xuICAgICAgICAvL+aPkuWxj+WPquaUr+aMgeWuieWNk+WktOadoeWuouaIt+err1xuICAgICAgICBpZiAodGhpcy5hcHBOYW1lICE9PSBBcHBOYW1lLnRvdVRpYW9cbiAgICAgICAgICAgIHx8IHRoaXMucGxhdGZvcm0gPT0gUGxhdGZvcm0uaW9zKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog55+t6ZyH5YqoXG4gICAgICovXG4gICAgcHVibGljIHZpYnJhdGVTaG9ydCgpIHtcbiAgICAgICAgaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlicmF0ZSkge1xuICAgICAgICAgICAgdGhpcy5hcGkudmlicmF0ZVNob3J0KHt9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOmVv+mch+WKqFxuICAgICAqL1xuICAgIHB1YmxpYyB2aWJyYXRlTG9uZygpIHtcbiAgICAgICAgaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlicmF0ZSkge1xuICAgICAgICAgICAgdGhpcy5hcGkudmlicmF0ZUxvbmcoe30pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5peg5r+A5Yqx5YiG5LqrJibluKblj4LliIbkuqtcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hhcmVBcHBNZXNzYWdlKHF1ZXJ5OiBzdHJpbmcgPSAnJykge1xuICAgICAgICBsZXQgaW5kZXg6IG51bWJlciA9IE1hdGguZmxvb3IoKE1hdGgucmFuZG9tKCkgKiB0aGlzLnNoYXJlVGl0bGVBcnIubGVuZ3RoKSk7XG4gICAgICAgIGxldCBpbmRleGltZzogbnVtYmVyID0gTWF0aC5mbG9vcigoTWF0aC5yYW5kb20oKSAqIHRoaXMuc2hhcmVJbWdBcnIubGVuZ3RoKSk7XG4gICAgICAgIGxldCBzZWxmID0gdGhpc1xuICAgICAgICB0aGlzLmFwaS5zaGFyZUFwcE1lc3NhZ2Uoe1xuICAgICAgICAgICAgdGl0bGU6IGAke3RoaXMuc2hhcmVUaXRsZUFycltpbmRleF19YCxcbiAgICAgICAgICAgIGltYWdlVXJsOiBgJHt0aGlzLnNoYXJlSW1nQXJyW2luZGV4aW1nXX1gLFxuICAgICAgICAgICAgcXVlcnk6IHF1ZXJ5LFxuICAgICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICAgIHNlbGYuc2hvd01lc3NhZ2UoJ+WIhuS6q+aIkOWKnycpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGZhaWw6IGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgICAgICAgICBzZWxmLnNob3dNZXNzYWdlKCfliIbkuqvlpLHotKUnKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOa/gOWKseWIhuS6qyYm5bim5Y+C5YiG5LqrXG4gICAgICovXG4gICAgcHVibGljIHNoYXJlVG9BbnlPbmUoc3VjY2VzczogRnVuY3Rpb24sIGZhaWw/OiBGdW5jdGlvbiwgcXVlcnk6IHN0cmluZyA9ICcnKSB7XG4gICAgICAgIGxldCBpbmRleDogbnVtYmVyID0gTWF0aC5mbG9vcigoTWF0aC5yYW5kb20oKSAqIHRoaXMuc2hhcmVUaXRsZUFyci5sZW5ndGgpKTtcbiAgICAgICAgbGV0IGluZGV4aW1nOiBudW1iZXIgPSBNYXRoLmZsb29yKChNYXRoLnJhbmRvbSgpICogdGhpcy5zaGFyZUltZ0Fyci5sZW5ndGgpKTtcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzXG4gICAgICAgIHRoaXMuYXBpLnNoYXJlQXBwTWVzc2FnZSh7XG4gICAgICAgICAgICB0aXRsZTogYCR7dGhpcy5zaGFyZVRpdGxlQXJyW2luZGV4XX1gLFxuICAgICAgICAgICAgaW1hZ2VVcmw6IGAke3RoaXMuc2hhcmVJbWdBcnJbaW5kZXhpbWddfWAsXG4gICAgICAgICAgICBxdWVyeTogcXVlcnksXG4gICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICAgICAgc2VsZi5zaG93TWVzc2FnZSgn5YiG5Lqr5oiQ5YqfJyk7XG4gICAgICAgICAgICAgICAgc3VjY2VzcygpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGZhaWw6IGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgICAgICAgICBzZWxmLnNob3dNZXNzYWdlKCfliIbkuqvlpLHotKUnKTtcbiAgICAgICAgICAgICAgICBmYWlsICYmIGZhaWwoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8v5b2T5YmN5b2V5bGP5piv5ZCm5bey5oiQ5Yqf5Y+R5biD6L+H5LiA5qyhXG4gICAgcHVibGljIGlzU2hhcmVkID0gZmFsc2U7XG4gICAgLy/lvZXlsY/plJnor6/jgIJcbiAgICBwcml2YXRlIElzUmVjb3JkRXJyb3I6IGJvb2xlYW4gPSBmYWxzZTtcbiAgICAvL+inhumikeWcsOWdgFxuICAgIHByaXZhdGUgdmlkZW9QYXRoOiBzdHJpbmcgPSAnJztcbiAgICBwcm90ZWN0ZWQgcmVjb3JkTW5nOiBhbnkgPSBudWxsO1xuICAgIC8qKlxuICAgICAqIOW9leWxj1xuICAgICAqL1xuICAgIHB1YmxpYyByZWNvcmRWaWRlbyh0eXBlOiBzdHJpbmcgPSAnc3RhcnQnKSB7XG4gICAgICAgIGxldCBzZWxmID0gdGhpcztcbiAgICAgICAgaWYgKG51bGwgPT09IHRoaXMucmVjb3JkTW5nKSB7XG4gICAgICAgICAgICB0aGlzLnJlY29yZE1uZyA9IHRoaXMuYXBpLmdldEdhbWVSZWNvcmRlck1hbmFnZXIoKTtcbiAgICAgICAgICAgIHRoaXMucmVjb3JkTW5nLm9uU3RhcnQocmVzID0+IHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn5b2V5bGP5byA5aeLJywgcmVzKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5yZWNvcmRNbmcub25QYXVzZSgocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLmmoLlgZzlvZXlsY/vvIxcIiwgcmVzKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5yZWNvcmRNbmcub25SZXN1bWUoKHJlcykgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi57un57ut5b2V5bGPXCIsIHJlcyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMucmVjb3JkTW5nLm9uU3RvcChyZXMgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnm5HlkKzlvZXlsY/nu5PmnZ8nLCByZXMpO1xuICAgICAgICAgICAgICAgIHNlbGYudmlkZW9QYXRoID0gcmVzLnZpZGVvUGF0aCArIFwiXCI7XG4gICAgICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlNES0V2ZW50LnJlY29yZFNhdmVkKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5yZWNvcmRNbmcub25FcnJvcigoZXJyTXNnKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+W9leWxj+mUmeivr++8micsIEpTT04uc3RyaW5naWZ5KGVyck1zZykpO1xuICAgICAgICAgICAgICAgIHNlbGYuSXNSZWNvcmRFcnJvciA9IHRydWU7XG4gICAgICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlNES0V2ZW50LnJlY29yZEVycm9yKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGxldCByZWNvcmRlciA9IHRoaXMucmVjb3JkTW5nO1xuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgXCJzdGFydFwiOiB7XG4gICAgICAgICAgICAgICAgdGhpcy5Jc1JlY29yZEVycm9yID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5pc1NoYXJlZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHJlY29yZGVyLnN0YXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246IDEyMCxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBcInBhdXNlXCI6IHtcbiAgICAgICAgICAgICAgICByZWNvcmRlci5wYXVzZSgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBcInJlc3VtZVwiOiB7XG4gICAgICAgICAgICAgICAgcmVjb3JkZXIucmVzdW1lKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIFwic3RvcFwiOiB7XG4gICAgICAgICAgICAgICAgcmVjb3JkZXIuc3RvcCgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoq5YiG5Lqr5b2V5bGPICovXG4gICAgcHVibGljIHNoYXJlUmVjb3JkVmlkZW8oc3VjY2VzczogRnVuY3Rpb24sIGZhaWw/OiBGdW5jdGlvbikge1xuICAgICAgICBsZXQgdGltZSA9IHRoaXMucmVjb3JkVmlkZW9EYXRhLnRvdGFsVGltZTtcbiAgICAgICAgaWYgKHRpbWUgPD0gMykge1xuICAgICAgICAgICAgdGhpcy5zaG93TWVzc2FnZShcIuW9leWxj+aXtumXtOefreS6jjNz5LiN6IO95YiG5Lqr5ZOmfn5cIik7XG4gICAgICAgICAgICBpZiAoISFmYWlsKSBmYWlsKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2coJ+inhumikeWcsOWdgCcsIHRoaXMudmlkZW9QYXRoLCB0aGlzLklzUmVjb3JkRXJyb3IpXG4gICAgICAgIGxldCBzZWxmID0gdGhpcztcbiAgICAgICAgaWYgKHRoaXMudmlkZW9QYXRoICYmIHRoaXMuSXNSZWNvcmRFcnJvciA9PSBmYWxzZSkge1xuICAgICAgICAgICAgbGV0IGluZGV4OiBudW1iZXIgPSBNYXRoLmZsb29yKChNYXRoLnJhbmRvbSgpICogdGhpcy5zaGFyZVRpdGxlQXJyLmxlbmd0aCkpO1xuICAgICAgICAgICAgbGV0IGluZGV4aW1nOiBudW1iZXIgPSBNYXRoLmZsb29yKChNYXRoLnJhbmRvbSgpICogdGhpcy5zaGFyZUltZ0Fyci5sZW5ndGgpKTtcbiAgICAgICAgICAgIHRoaXMuYXBpLnNoYXJlQXBwTWVzc2FnZSh7XG4gICAgICAgICAgICAgICAgY2hhbm5lbDogJ3ZpZGVvJyxcbiAgICAgICAgICAgICAgICB0aXRsZTogYCR7dGhpcy5zaGFyZVRpdGxlQXJyW2luZGV4XX1gLFxuICAgICAgICAgICAgICAgIGltYWdlVXJsOiBgJHt0aGlzLnNoYXJlSW1nQXJyW2luZGV4aW1nXX1gLFxuICAgICAgICAgICAgICAgIGV4dHJhOiB7XG4gICAgICAgICAgICAgICAgICAgIHZpZGVvUGF0aDogdGhpcy52aWRlb1BhdGgsXG4gICAgICAgICAgICAgICAgICAgIC8vIHZpZGVvVG9waWNzOicnXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiAocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCflvZXlsY/lj5HluIPmiJDlip86JywgSlNPTi5zdHJpbmdpZnkocmVzKSk7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuc2hvd01lc3NhZ2UoXCLlj5HluIPmiJDlip9cIik7XG4gICAgICAgICAgICAgICAgICAgIGlmICghc2VsZi5pc1NoYXJlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5yZWNvcmRWaWRlb0RhdGEub25TaGFyZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5pc1NoYXJlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWNjZXNzKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGZhaWw6IChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+W9leWxj+WPkeW4g+Wksei0pScsIEpTT04uc3RyaW5naWZ5KHJlcykpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmVyck1zZy5pbmRleE9mKFwic2hvcnRcIikgPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zaG93TWVzc2FnZShcIuW9leWxj+aXtumXtOefreS6jjPnp5LkuI3og73liIbkuqvlk6Z+flwiKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChyZXMuZXJyTXNnLmluZGV4T2YoXCJjYW5jZWxcIikgPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zaG93TWVzc2FnZShcIuWPkeW4g+WPlua2iFwiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoISFmYWlsKSBmYWlsKCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuYXBwTmFtZSA9PSBBcHBOYW1lLnRvdVRpYW8pIHsgLy/lpLTmnaHniYhcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxmLnN5c3RlbUluZm8ucGxhdGZvcm0gPT0gXCJpb3NcIikgeyAvL+iLueaenOaJi+acuiDlronljZPmiYvmnLrkuLogYW5kcm9pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXMuZXJyTXNnID09ICdzaGFyZUFwcE1lc3NhZ2U6ZmFpbCB2aWRlbyBkdXJhdGlvbiBpcyB0b28gc2hvcnQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuc2hvd01lc3NhZ2UoJ+W9leWxj+aXtumXtOefreS6jjNz5LiN6IO95YiG5Lqr5ZOmfn4nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuc2hvd01lc3NhZ2UoJ+WIhuS6q+WPlua2iCcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbXNnID0gcmVzLmVyck1zZy5zcGxpdCgnLCcpWzBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ21zZycsIG1zZylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobXNnID09ICdzaGFyZUFwcE1lc3NhZ2U6ZmFpbCB2aWRlbyBmaWxlIGlzIHRvbyBzaG9ydCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zaG93TWVzc2FnZSgn5b2V5bGP5pe26Ze055+t5LqOM3PkuI3og73liIbkuqvlk6Z+ficpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zaG93TWVzc2FnZSgn5Y+R5biD5Y+W5raIJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5hcHBOYW1lID09IEFwcE5hbWUuamlTdVRUKSB7IC8v5aS05p2h5p6B6YCf54mIXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZi5zeXN0ZW1JbmZvLnBsYXRmb3JtID09IFwiaW9zXCIpIHsgLy/oi7nmnpzmiYvmnLog5a6J5Y2T5omL5py65Li6IGFuZHJvaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmVyck1zZyA9PSAnc2hhcmVBcHBNZXNzYWdlOmZhaWwgdmlkZW8gZHVyYXRpb24gaXMgdG9vIHNob3J0Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnNob3dNZXNzYWdlKCflvZXlsY/ml7bpl7Tnn63kuo4zc+S4jeiDveWIhuS6q+WTpn5+JylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnNob3dNZXNzYWdlKCflj5HluIPlj5bmtognKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG1zZyA9IHJlcy5lcnJNc2cuc3BsaXQoJywnKVswXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdtc2cnLCBtc2cpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1zZyA9PSAnc2hhcmVBcHBNZXNzYWdlOmZhaWwgdmlkZW8gZmlsZSBpcyB0b28gc2hvcnQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuc2hvd01lc3NhZ2UoJ+W9leWxj+aXtumXtOefreS6jjNz5LiN6IO95YiG5Lqr5ZOmfn4nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuc2hvd01lc3NhZ2UoJ+WPkeW4g+WPlua2iCcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuYXBwTmFtZSA9PSBBcHBOYW1lLmRvdVlpbikgey8v5oqW6Z+zXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZi5zeXN0ZW1JbmZvLnBsYXRmb3JtID09IFwiaW9zXCIpIHsgLy/oi7nmnpzmiYvmnLog5a6J5Y2T5omL5py65Li6IGFuZHJvaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmVyck1zZyA9PSAnc2hhcmVBcHBNZXNzYWdlOmZhaWwgdmlkZW8gZHVyYXRpb24gaXMgdG9vIHNob3J0Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnNob3dNZXNzYWdlKCflvZXlsY/ml7bpl7Tnn63kuo4zc+S4jeiDveWIhuS6q+WTpn5+JylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnNob3dNZXNzYWdlKCflj5HluIPlj5bmtognKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG1zZyA9IHJlcy5lcnJNc2cuc3BsaXQoJywnKVswXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdtc2cnLCBtc2cpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1zZyA9PSAnc2hhcmVBcHBNZXNzYWdlRGlyZWN0bHk6ZmFpbCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zaG93TWVzc2FnZSgn5b2V5bGP5pe26Ze055+t5LqOM3PkuI3og73liIbkuqvlk6Z+ficpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zaG93TWVzc2FnZSgn5Y+R5biD5Y+W5raIJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnNob3dNZXNzYWdlKCflj5HluIPlj5bmtognKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZWxmLnNob3dNZXNzYWdlKCflvZXlsY/plJnor68nKTtcbiAgICAgICAgICAgIGlmICghIWZhaWwpIGZhaWwoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIC8qKlxuICAgIC8vICAqIOa2iOaBr+aPkOekulxuICAgIC8vICAqL1xuICAgIC8vIHB1YmxpYyBzaG93TWVzc2FnZShtc2c6IHN0cmluZywgaWNvbjogc3RyaW5nID0gJ25vbmUnKSB7XG4gICAgLy8gICAgIHRoaXMuYXBpLnNob3dUb2FzdCh7XG4gICAgLy8gICAgICAgICB0aXRsZTogbXNnLFxuICAgIC8vICAgICAgICAgZHVyYXRpb246IDIwMDAsXG4gICAgLy8gICAgICAgICBpY29uOiBpY29uLFxuICAgIC8vICAgICAgICAgc3VjY2VzczogKHJlcykgPT4geyB9XG4gICAgLy8gICAgIH0pO1xuICAgIC8vIH1cblxuICAgIHB1YmxpYyBuYXZpZ2F0ZVRvTWluaVByb2dyYW0oZGF0YTogYW55KSB7XG4gICAgICAgIHRoaXMuYXBpLm5hdmlnYXRlVG9NaW5pUHJvZ3JhbSh7XG4gICAgICAgICAgICBhcHBJZDogZGF0YS5nYW1lSWQsXG4gICAgICAgIH0pO1xuICAgIH1cbn1cblxuLyoq5a2X6IqC6Lez5Yqo5bmz5Y+w55qE5bqU55So5ZCN56ewICovXG5lbnVtIEFwcE5hbWUge1xuICAgIC8qKuW8gOWPkeiAheW3peWFtyAqL1xuICAgIGRldnRvb2xzLFxuICAgIC8qKuS7iuaXpeWktOadoSAqL1xuICAgIHRvdVRpYW8sXG4gICAgLyoq5LuK5pel5aS05p2h5p6B6YCf54mIICovXG4gICAgamlTdVRULFxuICAgIC8qKuaKlumfsyAqL1xuICAgIGRvdVlpbixcbiAgICAvKiropb/nk5wgKi9cbiAgICB4aUd1YSxcbn0iXX0=