
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/SDK/VIVOSDK.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b09a0FKoPRKd5JE74TASulT', 'VIVOSDK');
// Script/Platform/SDK/VIVOSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var EventManager_1 = require("../../Common/EventManager");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var VIVOSDK = /** @class */ (function (_super) {
    __extends(VIVOSDK, _super);
    function VIVOSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'qg';
        //视频广告
        _this.rewardedAd = null;
        return _this;
    }
    /**
     * 初始化
     */
    VIVOSDK.prototype.init = function () {
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        console.log("系统信息：");
        console.log(JSON.stringify(this.systemInfo));
    };
    VIVOSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        if (this.systemInfo.platformVersionCode < 1041) {
            this.onVideoFail('基础库版本过低，不能使用视频功能');
            return;
        }
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("视频id获取失败");
            return;
        }
        if (!this.rewardedAd) {
            var rewardedAd_1 = this.api.createRewardedVideoAd({
                posId: id,
                style: {}
            });
            rewardedAd_1.onClose(function (res) {
                if (res && res.isEnded) {
                    _this.onVideoSuccess();
                }
                else {
                    _this.onVideoQuit();
                    _this.onVideoHide();
                }
            });
            rewardedAd_1.onError(function (err) {
                switch (err.errCode) {
                    case -3: {
                        console.log("激励广告加载失败---调用太频繁", JSON.stringify(err));
                        break;
                    }
                    case -4: {
                        console.log("激励广告加载失败--- 一分钟内不能重复加载", JSON.stringify(err));
                        break;
                    }
                    case 30008: {
                        // 当前启动来源不支持激励视频广告，请选择其他激励策略
                        break;
                    }
                    default: {
                        // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                        console.log("激励广告展示失败");
                        console.log(JSON.stringify(err));
                        break;
                    }
                }
                _this.onVideoFail(err);
            });
            rewardedAd_1.onLoad(function () {
                var adshow = rewardedAd_1.show();
                _this.onVideoShow();
                // 捕捉show失败的错误
                adshow && adshow.catch(function (err) {
                    _this.onVideoFail(err);
                });
            });
            this.rewardedAd = rewardedAd_1;
        }
        var adLoad = this.rewardedAd.load(); //第一次调用 可能会报-3  广告能正常展示就可以忽略
        // 捕捉load失败的错误
        !!adLoad && adLoad.catch(function (err) {
            _this.onVideoFail(err);
        });
    };
    /**
     * 打开banner广告
     */
    VIVOSDK.prototype.showBanner = function () {
        var _this = this;
        if (this.systemInfo.platformVersionCode < 1031) {
            console.log("基础库版本过低，不能使用广告功能");
            return;
        }
        // if (this.insertAdRecord.isShowing) {
        //     console.log("插屏广告正在显示，无法同时显示banner");
        //     return;
        // }
        if (this.bannerRecord.getShowSpaceTime() < 12) {
            console.log("距离上一次展示banner的时间间隔小于12秒，不进行展示");
            return;
        }
        if (!!this._bannerAd) {
            console.log("上一次创建的banner未销毁，直接显示");
            this._bannerAd.show().then(function () {
                console.log("再次显示已创建的banner成功");
                _this.onBannerShow();
            }).catch(function (err) {
                _this.onBannerErr(err);
                _this.removeBanner();
                _this.createBanner();
            });
        }
        else {
            this.removeBanner();
            this.createBanner();
        }
    };
    VIVOSDK.prototype.createBanner = function () {
        var _this = this;
        var id = this.getBannerId();
        if (!id)
            return;
        //style内无需设置任何字段，banner会在屏幕底部居中显示，
        // 没有style字段，banner会在上边显示
        var bannerAd = this.api.createBannerAd({
            posId: id,
            style: {}
        });
        this._bannerAd = bannerAd;
        var adshow = bannerAd.show();
        // 调用then和catch之前需要对show的结果做下判空处理，防止出错（如果没有判空，在平台版本为1052以及以下的手机上将会出现错误）
        if (!adshow) {
            console.log("banner show fail");
        }
        adshow && adshow.then(function () {
            console.log("banner广告展示成功");
            _this.onBannerShow();
        }).catch(function (err) {
            switch (err.code) {
                case 30003: {
                    console.log("新用户7天内不能曝光Banner，请将手机时间调整为7天后，退出游戏重新进入");
                    break;
                }
                case 30009: {
                    console.log("10秒内调用广告次数超过1次，10秒后再调用");
                    break;
                }
                case 30002: {
                    console.log("加载广告失败，重新加载广告");
                    break;
                }
                default: {
                    // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                    console.log("banner广告展示失败");
                    console.log(JSON.stringify(err));
                    break;
                }
            }
        });
    };
    /**
     * 关闭banner广告
     */
    VIVOSDK.prototype.removeBanner = function () {
        var _this = this;
        if (this._bannerAd) {
            //距离上一次创建时间少于12秒时，隐藏banner，下次需要显示时不再创建新的banner
            if (this.bannerRecord.getShowSpaceTime() < 12) {
                console.log("距离上一次创建时间少于12秒，不销毁banner，只隐藏");
                this._bannerAd.hide();
            }
            else {
                var addestroy = this._bannerAd.destroy();
                addestroy && addestroy.then(function () {
                    console.log("banner广告销毁成功");
                    _this._bannerAd = null;
                }).catch(function (err) {
                    console.log("banner广告销毁失败", err);
                    _this._bannerAd.hide();
                });
            }
            this.onBannerHide();
        }
    };
    /**
     * 插屏广告
     */
    VIVOSDK.prototype.showInterstitialAd = function (banner) {
        var _this = this;
        if (banner === void 0) { banner = false; }
        this.useBannerInsteadInsert = banner;
        if (this.systemInfo.platformVersionCode < 1031) {
            console.log("基础库版本过低，不能使用插屏广告功能");
            this.showBannerInsteadInsert();
            return;
        }
        var id = this.getInsertAdUnitId();
        if (!id) {
            this.showBannerInsteadInsert();
            return;
        }
        var interstitialAd = this.api.createInterstitialAd({
            posId: id,
            style: {}
        });
        interstitialAd.onClose(this.onInsertHide.bind(this));
        var adshow = interstitialAd.show();
        if (!adshow) {
            console.log("insertAd show fail");
            this.showBannerInsteadInsert();
            return;
        }
        // 调用then和catch之前需要对show的结果做下判空处理，防止出错（如果没有判空，在平台版本为1052以及以下的手机上将会出现错误）
        !!adshow && adshow.then(function () {
            // this.removeBanner();
            _this.onInsertShow();
            _this.showBannerInsteadInsert();
        }).catch(function (err) {
            switch (err.code) {
                case 30003: {
                    console.log("新用户7天内不能曝光Banner，请将手机时间调整为7天后，退出游戏重新进入");
                    break;
                }
                case 30009: {
                    console.log("10秒内调用广告次数超过1次，10秒后再调用");
                    break;
                }
                case 30002: {
                    console.log("load广告失败，重新加载广告");
                    break;
                }
                default: {
                    // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                    console.log("插屏广告展示失败");
                    console.log(JSON.stringify(err));
                    break;
                }
            }
            _this.onInsertErr(err);
            _this.showBannerInsteadInsert();
        });
    };
    /**
     * 短震动
     */
    VIVOSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    VIVOSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    VIVOSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ''; }
    };
    /**
     * 激励分享&&带参分享
     */
    VIVOSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
    };
    /**
     * 消息提示
     */
    VIVOSDK.prototype.showMessage = function (msg, icon) {
        if (icon === void 0) { icon = 'none'; }
        // this.api.showToast({
        //     title: msg,
        //     duration: 2000,
        //     icon: icon,
        //     success: (res) => { }
        // });
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTip, msg);
    };
    return VIVOSDK;
}(SDK_1.default));
exports.default = VIVOSDK;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcU0RLXFxWSVZPU0RLLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDZCQUF3QjtBQUN4QixnREFBMkM7QUFDM0MsMERBQXFEO0FBQ3JELGlFQUE0RDtBQUU1RDtJQUFxQywyQkFBRztJQUF4QztRQUFBLHFFQXVSQztRQXRSVyxhQUFPLEdBQVcsSUFBSSxDQUFDO1FBWS9CLE1BQU07UUFDSSxnQkFBVSxHQUFRLElBQUksQ0FBQzs7SUF5UXJDLENBQUM7SUFwUkc7O09BRUc7SUFDSSxzQkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFJTSw2QkFBVyxHQUFsQixVQUFtQixTQUFlO1FBQWxDLGlCQThEQztRQTdERyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxFQUFFO1lBQzVDLElBQUksQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUNyQyxPQUFPO1NBQ1Y7UUFDRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNMLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDN0IsT0FBTztTQUNWO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbEIsSUFBSSxZQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztnQkFDNUMsS0FBSyxFQUFFLEVBQUU7Z0JBQ1QsS0FBSyxFQUFFLEVBQUU7YUFDWixDQUFDLENBQUM7WUFDSCxZQUFVLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztnQkFDbEIsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLE9BQU8sRUFBRTtvQkFDcEIsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2lCQUN6QjtxQkFBTTtvQkFDSCxLQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBQ25CLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztpQkFDdEI7WUFDTCxDQUFDLENBQUMsQ0FBQztZQUNILFlBQVUsQ0FBQyxPQUFPLENBQUMsVUFBQSxHQUFHO2dCQUNsQixRQUFRLEdBQUcsQ0FBQyxPQUFPLEVBQUU7b0JBQ2pCLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDckQsTUFBTTtxQkFDVDtvQkFDRCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQzNELE1BQU07cUJBQ1Q7b0JBQ0QsS0FBSyxLQUFLLENBQUMsQ0FBQzt3QkFDUiw0QkFBNEI7d0JBQzVCLE1BQU07cUJBQ1Q7b0JBQ0QsT0FBTyxDQUFDLENBQUM7d0JBQ0wsMEZBQTBGO3dCQUMxRixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFBO3dCQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTt3QkFDaEMsTUFBTTtxQkFDVDtpQkFDSjtnQkFDRCxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLENBQUMsQ0FBQyxDQUFDO1lBQ0gsWUFBVSxDQUFDLE1BQU0sQ0FBQztnQkFDZCxJQUFJLE1BQU0sR0FBRyxZQUFVLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQy9CLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbkIsY0FBYztnQkFDZCxNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFBLEdBQUc7b0JBQ3RCLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzFCLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsVUFBVSxHQUFHLFlBQVUsQ0FBQztTQUNoQztRQUNELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQSw0QkFBNEI7UUFDaEUsY0FBYztRQUNkLENBQUMsQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFBLEdBQUc7WUFDeEIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMxQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFJRDs7T0FFRztJQUNJLDRCQUFVLEdBQWpCO1FBQUEsaUJBMkJDO1FBMUJHLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLEVBQUU7WUFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ2hDLE9BQU87U0FDVjtRQUNELHVDQUF1QztRQUN2Qyw0Q0FBNEM7UUFDNUMsY0FBYztRQUNkLElBQUk7UUFDSixJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDM0MsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1lBQzdDLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3BDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO2dCQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7Z0JBQ2hDLEtBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUN4QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQyxHQUFHO2dCQUNULEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3RCLEtBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDcEIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFBO1NBQ0w7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDdkI7SUFDTCxDQUFDO0lBQ1MsOEJBQVksR0FBdEI7UUFBQSxpQkF3Q0M7UUF2Q0csSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxFQUFFO1lBQUUsT0FBTztRQUNoQixrQ0FBa0M7UUFDbEMseUJBQXlCO1FBQ3pCLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1lBQ25DLEtBQUssRUFBRSxFQUFFO1lBQ1QsS0FBSyxFQUFFLEVBQUU7U0FDWixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQztRQUMxQixJQUFJLE1BQU0sR0FBRyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDN0IsdUVBQXVFO1FBQ3ZFLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDVCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7U0FDbkM7UUFDRCxNQUFNLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQztZQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQzVCLEtBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQyxHQUFHO1lBQ1QsUUFBUSxHQUFHLENBQUMsSUFBSSxFQUFFO2dCQUNkLEtBQUssS0FBSyxDQUFDLENBQUM7b0JBQ1IsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO29CQUN0RCxNQUFNO2lCQUNUO2dCQUNELEtBQUssS0FBSyxDQUFDLENBQUM7b0JBQ1IsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO29CQUN0QyxNQUFNO2lCQUNUO2dCQUNELEtBQUssS0FBSyxDQUFDLENBQUM7b0JBQ1IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQztvQkFDN0IsTUFBTTtpQkFDVDtnQkFDRCxPQUFPLENBQUMsQ0FBQztvQkFDTCwwRkFBMEY7b0JBQzFGLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7b0JBQzVCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUNqQyxNQUFNO2lCQUNUO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7T0FFRztJQUNJLDhCQUFZLEdBQW5CO1FBQUEsaUJBa0JDO1FBakJHLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQiw4Q0FBOEM7WUFDOUMsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLGdCQUFnQixFQUFFLEdBQUcsRUFBRSxFQUFFO2dCQUMzQyxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUM7Z0JBQzVDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDekI7aUJBQU07Z0JBQ0gsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDekMsU0FBUyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUM7b0JBQ3hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7b0JBQzVCLEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2dCQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQSxHQUFHO29CQUNSLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUNqQyxLQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUMxQixDQUFDLENBQUMsQ0FBQzthQUNOO1lBQ0QsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ3ZCO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksb0NBQWtCLEdBQXpCLFVBQTBCLE1BQXVCO1FBQWpELGlCQXFEQztRQXJEeUIsdUJBQUEsRUFBQSxjQUF1QjtRQUM3QyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsTUFBTSxDQUFDO1FBQ3JDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLEVBQUU7WUFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1lBQy9CLE9BQU07U0FDVDtRQUNELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ2xDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDTCxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUMvQixPQUFPO1NBQ1Y7UUFDRCxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDO1lBQy9DLEtBQUssRUFBRSxFQUFFO1lBQ1QsS0FBSyxFQUFFLEVBQUU7U0FDWixDQUFDLENBQUM7UUFDSCxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDckQsSUFBSSxNQUFNLEdBQUcsY0FBYyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ25DLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDVCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0IsT0FBTztTQUNWO1FBRUQsdUVBQXVFO1FBQ3ZFLENBQUMsQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQztZQUNwQix1QkFBdUI7WUFDdkIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3BCLEtBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1FBQ25DLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFDLEdBQUc7WUFDVCxRQUFRLEdBQUcsQ0FBQyxJQUFJLEVBQUU7Z0JBQ2QsS0FBSyxLQUFLLENBQUMsQ0FBQztvQkFDUixPQUFPLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxDQUFDLENBQUM7b0JBQ3RELE1BQU07aUJBQ1Q7Z0JBQ0QsS0FBSyxLQUFLLENBQUMsQ0FBQztvQkFDUixPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7b0JBQ3RDLE1BQU07aUJBQ1Q7Z0JBQ0QsS0FBSyxLQUFLLENBQUMsQ0FBQztvQkFDUixPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUM7b0JBQy9CLE1BQU07aUJBQ1Q7Z0JBQ0QsT0FBTyxDQUFDLENBQUM7b0JBQ0wsMEZBQTBGO29CQUMxRixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUN4QixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDakMsTUFBTTtpQkFDVDthQUNKO1lBQ0QsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0QixLQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7T0FFRztJQUNJLDhCQUFZLEdBQW5CO1FBQ0ksSUFBSSxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksNkJBQVcsR0FBbEI7UUFDSSxJQUFJLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7WUFDdEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxpQ0FBZSxHQUF0QixVQUF1QixLQUFrQjtRQUFsQixzQkFBQSxFQUFBLFVBQWtCO0lBRXpDLENBQUM7SUFFRDs7T0FFRztJQUNJLCtCQUFhLEdBQXBCLFVBQXFCLE9BQWlCLEVBQUUsSUFBZSxFQUFFLEtBQWtCO1FBQWxCLHNCQUFBLEVBQUEsVUFBa0I7SUFFM0UsQ0FBQztJQUVEOztPQUVHO0lBQ0ksNkJBQVcsR0FBbEIsVUFBbUIsR0FBVyxFQUFFLElBQXFCO1FBQXJCLHFCQUFBLEVBQUEsYUFBcUI7UUFDakQsdUJBQXVCO1FBQ3ZCLGtCQUFrQjtRQUNsQixzQkFBc0I7UUFDdEIsa0JBQWtCO1FBQ2xCLDRCQUE0QjtRQUM1QixNQUFNO1FBQ04sc0JBQVksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFDTCxjQUFDO0FBQUQsQ0F2UkEsQUF1UkMsQ0F2Um9DLGFBQUcsR0F1UnZDIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFNESyBmcm9tIFwiLi9TREtcIjtcbmltcG9ydCBHYW1lUGxhdGZvcm0gZnJvbSBcIi4uL0dhbWVQbGF0Zm9ybVwiO1xuaW1wb3J0IEV2ZW50TWFuYWdlciBmcm9tIFwiLi4vLi4vQ29tbW9uL0V2ZW50TWFuYWdlclwiO1xuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVklWT1NESyBleHRlbmRzIFNESyB7XG4gICAgcHJpdmF0ZSBhcGlOYW1lOiBzdHJpbmcgPSAncWcnO1xuXG4gICAgLyoqXG4gICAgICog5Yid5aeL5YyWXG4gICAgICovXG4gICAgcHVibGljIGluaXQoKSB7XG4gICAgICAgIHRoaXMuYXBpID0gd2luZG93W3RoaXMuYXBpTmFtZV07XG4gICAgICAgIHRoaXMuc3lzdGVtSW5mbyA9IHRoaXMuYXBpLmdldFN5c3RlbUluZm9TeW5jKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwi57O757uf5L+h5oGv77yaXCIpO1xuICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeSh0aGlzLnN5c3RlbUluZm8pKTtcbiAgICB9XG5cbiAgICAvL+inhumikeW5v+WRilxuICAgIHByb3RlY3RlZCByZXdhcmRlZEFkOiBhbnkgPSBudWxsO1xuICAgIHB1YmxpYyBzaG93VmlkZW9BZCh2aWRlb05hbWU/OiBhbnkpIHtcbiAgICAgICAgaWYgKHRoaXMuc3lzdGVtSW5mby5wbGF0Zm9ybVZlcnNpb25Db2RlIDwgMTA0MSkge1xuICAgICAgICAgICAgdGhpcy5vblZpZGVvRmFpbCgn5Z+656GA5bqT54mI5pys6L+H5L2O77yM5LiN6IO95L2/55So6KeG6aKR5Yqf6IO9Jyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGlkID0gdGhpcy5nZXRWaWRlb0FkVW5pdElkKHZpZGVvTmFtZSk7XG4gICAgICAgIGlmICghaWQpIHtcbiAgICAgICAgICAgIHRoaXMub25WaWRlb0ZhaWwoXCLop4bpopFpZOiOt+WPluWksei0pVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghdGhpcy5yZXdhcmRlZEFkKSB7XG4gICAgICAgICAgICBsZXQgcmV3YXJkZWRBZCA9IHRoaXMuYXBpLmNyZWF0ZVJld2FyZGVkVmlkZW9BZCh7XG4gICAgICAgICAgICAgICAgcG9zSWQ6IGlkLFxuICAgICAgICAgICAgICAgIHN0eWxlOiB7fVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXdhcmRlZEFkLm9uQ2xvc2UocmVzID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzICYmIHJlcy5pc0VuZGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb1N1Y2Nlc3MoKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uVmlkZW9RdWl0KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb0hpZGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJld2FyZGVkQWQub25FcnJvcihlcnIgPT4ge1xuICAgICAgICAgICAgICAgIHN3aXRjaCAoZXJyLmVyckNvZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAtMzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLmv4DlirHlub/lkYrliqDovb3lpLHotKUtLS3osIPnlKjlpKrpopHnuYFcIiwgSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYXNlIC00OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIua/gOWKseW5v+WRiuWKoOi9veWksei0pS0tLSDkuIDliIbpkp/lhoXkuI3og73ph43lpI3liqDovb1cIiwgSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYXNlIDMwMDA4OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyDlvZPliY3lkK/liqjmnaXmupDkuI3mlK/mjIHmv4DlirHop4bpopHlub/lkYrvvIzor7fpgInmi6nlhbbku5bmv4DlirHnrZbnlaVcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIOWPguiAgyBodHRwczovL21pbmlnYW1lLnZpdm8uY29tLmNuL2RvY3VtZW50cy8jL2xlc3Nvbi9vcGVuLWFiaWxpdHkvYWQ/aWQ95bm/5ZGK6ZSZ6K+v56CB5L+h5oGvIOWvuemUmeivr+eggeWBmuWIhuexu+WkhOeQhlxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLmv4DlirHlub/lkYrlsZXnpLrlpLHotKVcIilcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGVycikpXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLm9uVmlkZW9GYWlsKGVycik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJld2FyZGVkQWQub25Mb2FkKCgpID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgYWRzaG93ID0gcmV3YXJkZWRBZC5zaG93KCk7XG4gICAgICAgICAgICAgICAgdGhpcy5vblZpZGVvU2hvdygpO1xuICAgICAgICAgICAgICAgIC8vIOaNleaNiXNob3flpLHotKXnmoTplJnor69cbiAgICAgICAgICAgICAgICBhZHNob3cgJiYgYWRzaG93LmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb0ZhaWwoZXJyKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5yZXdhcmRlZEFkID0gcmV3YXJkZWRBZDtcbiAgICAgICAgfVxuICAgICAgICBsZXQgYWRMb2FkID0gdGhpcy5yZXdhcmRlZEFkLmxvYWQoKTsvL+esrOS4gOasoeiwg+eUqCDlj6/og73kvJrmiqUtMyAg5bm/5ZGK6IO95q2j5bi45bGV56S65bCx5Y+v5Lul5b+955WlXG4gICAgICAgIC8vIOaNleaNiWxvYWTlpLHotKXnmoTplJnor69cbiAgICAgICAgISFhZExvYWQgJiYgYWRMb2FkLmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICB0aGlzLm9uVmlkZW9GYWlsKGVycik7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8v5b2T5YmNYmFubmVyXG4gICAgcHJpdmF0ZSBfYmFubmVyQWQ6IGFueTtcbiAgICAvKipcbiAgICAgKiDmiZPlvIBiYW5uZXLlub/lkYpcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hvd0Jhbm5lcigpIHtcbiAgICAgICAgaWYgKHRoaXMuc3lzdGVtSW5mby5wbGF0Zm9ybVZlcnNpb25Db2RlIDwgMTAzMSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLln7rnoYDlupPniYjmnKzov4fkvY7vvIzkuI3og73kvb/nlKjlub/lkYrlip/og71cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gaWYgKHRoaXMuaW5zZXJ0QWRSZWNvcmQuaXNTaG93aW5nKSB7XG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhcIuaPkuWxj+W5v+WRiuato+WcqOaYvuekuu+8jOaXoOazleWQjOaXtuaYvuekumJhbm5lclwiKTtcbiAgICAgICAgLy8gICAgIHJldHVybjtcbiAgICAgICAgLy8gfVxuICAgICAgICBpZiAodGhpcy5iYW5uZXJSZWNvcmQuZ2V0U2hvd1NwYWNlVGltZSgpIDwgMTIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6Led56a75LiK5LiA5qyh5bGV56S6YmFubmVy55qE5pe26Ze06Ze06ZqU5bCP5LqOMTLnp5LvvIzkuI3ov5vooYzlsZXnpLpcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCEhdGhpcy5fYmFubmVyQWQpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5LiK5LiA5qyh5Yib5bu655qEYmFubmVy5pyq6ZSA5q+B77yM55u05o6l5pi+56S6XCIpO1xuICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQuc2hvdygpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5YaN5qyh5pi+56S65bey5Yib5bu655qEYmFubmVy5oiQ5YqfXCIpO1xuICAgICAgICAgICAgICAgIHRoaXMub25CYW5uZXJTaG93KCk7XG4gICAgICAgICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5vbkJhbm5lckVycihlcnIpO1xuICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlQmFubmVyKCk7XG4gICAgICAgICAgICAgICAgdGhpcy5jcmVhdGVCYW5uZXIoKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnJlbW92ZUJhbm5lcigpO1xuICAgICAgICAgICAgdGhpcy5jcmVhdGVCYW5uZXIoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcm90ZWN0ZWQgY3JlYXRlQmFubmVyKCkge1xuICAgICAgICBsZXQgaWQgPSB0aGlzLmdldEJhbm5lcklkKCk7XG4gICAgICAgIGlmICghaWQpIHJldHVybjtcbiAgICAgICAgLy9zdHlsZeWGheaXoOmcgOiuvue9ruS7u+S9leWtl+aute+8jGJhbm5lcuS8muWcqOWxj+W5leW6lemDqOWxheS4reaYvuekuu+8jFxuICAgICAgICAvLyDmsqHmnIlzdHlsZeWtl+aute+8jGJhbm5lcuS8muWcqOS4iui+ueaYvuekulxuICAgICAgICBsZXQgYmFubmVyQWQgPSB0aGlzLmFwaS5jcmVhdGVCYW5uZXJBZCh7XG4gICAgICAgICAgICBwb3NJZDogaWQsXG4gICAgICAgICAgICBzdHlsZToge31cbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuX2Jhbm5lckFkID0gYmFubmVyQWQ7XG4gICAgICAgIGxldCBhZHNob3cgPSBiYW5uZXJBZC5zaG93KCk7XG4gICAgICAgIC8vIOiwg+eUqHRoZW7lkoxjYXRjaOS5i+WJjemcgOimgeWvuXNob3fnmoTnu5PmnpzlgZrkuIvliKTnqbrlpITnkIbvvIzpmLLmraLlh7rplJnvvIjlpoLmnpzmsqHmnInliKTnqbrvvIzlnKjlubPlj7DniYjmnKzkuLoxMDUy5Lul5Y+K5Lul5LiL55qE5omL5py65LiK5bCG5Lya5Ye6546w6ZSZ6K+v77yJXG4gICAgICAgIGlmICghYWRzaG93KSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImJhbm5lciBzaG93IGZhaWxcIik7XG4gICAgICAgIH1cbiAgICAgICAgYWRzaG93ICYmIGFkc2hvdy50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYmFubmVy5bm/5ZGK5bGV56S65oiQ5YqfXCIpO1xuICAgICAgICAgICAgdGhpcy5vbkJhbm5lclNob3coKTtcbiAgICAgICAgfSkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgc3dpdGNoIChlcnIuY29kZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgMzAwMDM6IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLmlrDnlKjmiLc35aSp5YaF5LiN6IO95pud5YWJQmFubmVy77yM6K+35bCG5omL5py65pe26Ze06LCD5pW05Li6N+WkqeWQju+8jOmAgOWHuua4uOaIj+mHjeaWsOi/m+WFpVwiKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhc2UgMzAwMDk6IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCIxMOenkuWGheiwg+eUqOW5v+WRiuasoeaVsOi2hei/hzHmrKHvvIwxMOenkuWQjuWGjeiwg+eUqFwiKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhc2UgMzAwMDI6IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLliqDovb3lub/lkYrlpLHotKXvvIzph43mlrDliqDovb3lub/lkYpcIik7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBkZWZhdWx0OiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIOWPguiAgyBodHRwczovL21pbmlnYW1lLnZpdm8uY29tLmNuL2RvY3VtZW50cy8jL2xlc3Nvbi9vcGVuLWFiaWxpdHkvYWQ/aWQ95bm/5ZGK6ZSZ6K+v56CB5L+h5oGvIOWvuemUmeivr+eggeWBmuWIhuexu+WkhOeQhlxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImJhbm5lcuW5v+WRiuWxleekuuWksei0pVwiKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5YWz6ZetYmFubmVy5bm/5ZGKXG4gICAgICovXG4gICAgcHVibGljIHJlbW92ZUJhbm5lcigpIHtcbiAgICAgICAgaWYgKHRoaXMuX2Jhbm5lckFkKSB7XG4gICAgICAgICAgICAvL+i3neemu+S4iuS4gOasoeWIm+W7uuaXtumXtOWwkeS6jjEy56eS5pe277yM6ZqQ6JePYmFubmVy77yM5LiL5qyh6ZyA6KaB5pi+56S65pe25LiN5YaN5Yib5bu65paw55qEYmFubmVyXG4gICAgICAgICAgICBpZiAodGhpcy5iYW5uZXJSZWNvcmQuZ2V0U2hvd1NwYWNlVGltZSgpIDwgMTIpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIui3neemu+S4iuS4gOasoeWIm+W7uuaXtumXtOWwkeS6jjEy56eS77yM5LiN6ZSA5q+BYmFubmVy77yM5Y+q6ZqQ6JePXCIpO1xuICAgICAgICAgICAgICAgIHRoaXMuX2Jhbm5lckFkLmhpZGUoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbGV0IGFkZGVzdHJveSA9IHRoaXMuX2Jhbm5lckFkLmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICBhZGRlc3Ryb3kgJiYgYWRkZXN0cm95LnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImJhbm5lcuW5v+WRiumUgOavgeaIkOWKn1wiKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQgPSBudWxsO1xuICAgICAgICAgICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYmFubmVy5bm/5ZGK6ZSA5q+B5aSx6LSlXCIsIGVycik7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2Jhbm5lckFkLmhpZGUoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMub25CYW5uZXJIaWRlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDmj5LlsY/lub/lkYpcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hvd0ludGVyc3RpdGlhbEFkKGJhbm5lcjogYm9vbGVhbiA9IGZhbHNlKSB7XG4gICAgICAgIHRoaXMudXNlQmFubmVySW5zdGVhZEluc2VydCA9IGJhbm5lcjtcbiAgICAgICAgaWYgKHRoaXMuc3lzdGVtSW5mby5wbGF0Zm9ybVZlcnNpb25Db2RlIDwgMTAzMSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLln7rnoYDlupPniYjmnKzov4fkvY7vvIzkuI3og73kvb/nlKjmj5LlsY/lub/lkYrlip/og71cIik7XG4gICAgICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICBsZXQgaWQgPSB0aGlzLmdldEluc2VydEFkVW5pdElkKCk7XG4gICAgICAgIGlmICghaWQpIHtcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgaW50ZXJzdGl0aWFsQWQgPSB0aGlzLmFwaS5jcmVhdGVJbnRlcnN0aXRpYWxBZCh7XG4gICAgICAgICAgICBwb3NJZDogaWQsXG4gICAgICAgICAgICBzdHlsZToge31cbiAgICAgICAgfSk7XG4gICAgICAgIGludGVyc3RpdGlhbEFkLm9uQ2xvc2UodGhpcy5vbkluc2VydEhpZGUuYmluZCh0aGlzKSk7XG4gICAgICAgIGxldCBhZHNob3cgPSBpbnRlcnN0aXRpYWxBZC5zaG93KCk7XG4gICAgICAgIGlmICghYWRzaG93KSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImluc2VydEFkIHNob3cgZmFpbFwiKTtcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOiwg+eUqHRoZW7lkoxjYXRjaOS5i+WJjemcgOimgeWvuXNob3fnmoTnu5PmnpzlgZrkuIvliKTnqbrlpITnkIbvvIzpmLLmraLlh7rplJnvvIjlpoLmnpzmsqHmnInliKTnqbrvvIzlnKjlubPlj7DniYjmnKzkuLoxMDUy5Lul5Y+K5Lul5LiL55qE5omL5py65LiK5bCG5Lya5Ye6546w6ZSZ6K+v77yJXG4gICAgICAgICEhYWRzaG93ICYmIGFkc2hvdy50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIC8vIHRoaXMucmVtb3ZlQmFubmVyKCk7XG4gICAgICAgICAgICB0aGlzLm9uSW5zZXJ0U2hvdygpO1xuICAgICAgICAgICAgdGhpcy5zaG93QmFubmVySW5zdGVhZEluc2VydCgpO1xuICAgICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgICBzd2l0Y2ggKGVyci5jb2RlKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAzMDAwMzoge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaWsOeUqOaItzflpKnlhoXkuI3og73mm53lhYlCYW5uZXLvvIzor7flsIbmiYvmnLrml7bpl7TosIPmlbTkuLo35aSp5ZCO77yM6YCA5Ye65ri45oiP6YeN5paw6L+b5YWlXCIpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2FzZSAzMDAwOToge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIjEw56eS5YaF6LCD55So5bm/5ZGK5qyh5pWw6LaF6L+HMeasoe+8jDEw56eS5ZCO5YaN6LCD55SoXCIpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2FzZSAzMDAwMjoge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImxvYWTlub/lkYrlpLHotKXvvIzph43mlrDliqDovb3lub/lkYpcIik7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBkZWZhdWx0OiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIOWPguiAgyBodHRwczovL21pbmlnYW1lLnZpdm8uY29tLmNuL2RvY3VtZW50cy8jL2xlc3Nvbi9vcGVuLWFiaWxpdHkvYWQ/aWQ95bm/5ZGK6ZSZ6K+v56CB5L+h5oGvIOWvuemUmeivr+eggeWBmuWIhuexu+WkhOeQhlxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaPkuWxj+W5v+WRiuWxleekuuWksei0pVwiKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMub25JbnNlcnRFcnIoZXJyKTtcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lckluc3RlYWRJbnNlcnQoKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog55+t6ZyH5YqoXG4gICAgICovXG4gICAgcHVibGljIHZpYnJhdGVTaG9ydCgpIHtcbiAgICAgICAgaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlicmF0ZSkge1xuICAgICAgICAgICAgdGhpcy5hcGkudmlicmF0ZVNob3J0KHt9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOmVv+mch+WKqFxuICAgICAqL1xuICAgIHB1YmxpYyB2aWJyYXRlTG9uZygpIHtcbiAgICAgICAgaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlicmF0ZSkge1xuICAgICAgICAgICAgdGhpcy5hcGkudmlicmF0ZUxvbmcoe30pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5peg5r+A5Yqx5YiG5LqrJibluKblj4LliIbkuqtcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hhcmVBcHBNZXNzYWdlKHF1ZXJ5OiBzdHJpbmcgPSAnJykge1xuXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5r+A5Yqx5YiG5LqrJibluKblj4LliIbkuqtcbiAgICAgKi9cbiAgICBwdWJsaWMgc2hhcmVUb0FueU9uZShzdWNjZXNzOiBGdW5jdGlvbiwgZmFpbD86IEZ1bmN0aW9uLCBxdWVyeTogc3RyaW5nID0gJycpIHtcblxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOa2iOaBr+aPkOekulxuICAgICAqL1xuICAgIHB1YmxpYyBzaG93TWVzc2FnZShtc2c6IHN0cmluZywgaWNvbjogc3RyaW5nID0gJ25vbmUnKSB7XG4gICAgICAgIC8vIHRoaXMuYXBpLnNob3dUb2FzdCh7XG4gICAgICAgIC8vICAgICB0aXRsZTogbXNnLFxuICAgICAgICAvLyAgICAgZHVyYXRpb246IDIwMDAsXG4gICAgICAgIC8vICAgICBpY29uOiBpY29uLFxuICAgICAgICAvLyAgICAgc3VjY2VzczogKHJlcykgPT4geyB9XG4gICAgICAgIC8vIH0pO1xuICAgICAgICBFdmVudE1hbmFnZXIuZW1pdChFdmVudFR5cGUuVUlFdmVudC5zaG93VGlwLCBtc2cpO1xuICAgIH1cbn1cbiJdfQ==