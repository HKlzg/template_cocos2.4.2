
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/SDK/SDK.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '58947sP21dHI6brMjcbkNmW', 'SDK');
// Script/Platform/SDK/SDK.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Platform = void 0;
var EventManager_1 = require("../../Common/EventManager");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var GamePlatform_1 = require("../GamePlatform");
var GameConfig_1 = require("../../GameSpecial/GameConfig");
var GlobalEnum_1 = require("../../GameSpecial/GlobalEnum");
var SDK = /** @class */ (function () {
    function SDK() {
        /**
         * 分享游戏时的描述
         */
        this.shareTitleArr = [
            '',
            ''
        ];
        /**
         * 分享游戏时的图片
         */
        this.shareImgArr = [
            '',
            ''
        ];
        /**手机操作系统类型 */
        this.platform = null;
        this.videoRecord = null;
        /**数据分析工具使用的数据 */
        this.videoTongJi = null;
        /*******************************************banner*******************************************/
        this.bannerRecord = null;
        /**当前是否显示了banner(部分平台关闭banner无回调) */
        this.bannerShowing = false;
        /*******************************************插屏*******************************************/
        this.insertAdRecord = null;
        /**插屏显示失败时，是否使用banner代替 */
        this.useBannerInsteadInsert = false;
        this.recordVideoData = null;
    }
    /**
     * 记录SDK与系统信息
     *
     * 将不同平台的系统信息中通用的内容用统一的字段存储
     * @param platform      SDK获取的系统信息中的操作系统
     * @param version       SDK获取的系统信息中的操作系统版本号
     * @param sdkVersion    SDK获取的系统信息中的SDK版本号
     */
    SDK.prototype.setSystemInfo = function (platform, systemVersion, sdkVersion) {
        this.systemVersion = systemVersion;
        this.sdkVersion = sdkVersion;
        var str = platform.toUpperCase();
        switch (str) {
            case Platform.ios: {
                this.platform = Platform.ios;
                break;
            }
            case Platform.android: {
                this.platform = Platform.android;
                break;
            }
            default: {
                this.platform = Platform.pc;
                break;
            }
        }
    };
    /**手机操作系统是否低于指定版本 */
    SDK.prototype.systemLessThan = function (v) {
        return this.lessThan(this.systemVersion, v);
    };
    /**平台sdk是否低于指定版本 */
    SDK.prototype.sdkLessThan = function (v) {
        return this.lessThan(this.sdkVersion, v);
    };
    /**比较版本号v1是否低于v2 */
    SDK.prototype.lessThan = function (v1, v2) {
        var arr1 = v1.split('.');
        var arr2 = v2.split('.');
        var len = Math.max(arr2.length, arr2.length);
        while (arr1.length < len) {
            arr1.push('0');
        }
        while (arr2.length < len) {
            arr2.push('0');
        }
        for (var i = 0; i < len; i++) {
            var num1 = parseInt(arr1[i]);
            var num2 = parseInt(arr2[i]);
            if (num1 < num2) {
                return true;
            }
            else if (num1 > num2) {
                return false;
            }
        }
        return false;
    };
    /**判断基础库版本号 */
    SDK.prototype.compareVersion = function (v1, v2) {
        v1 = v1.split('.');
        v2 = v2.split('.');
        var len = Math.max(v1.length, v2.length);
        while (v1.length < len) {
            v1.push('0');
        }
        while (v2.length < len) {
            v2.push('0');
        }
        for (var i = 0; i < len; i++) {
            var num1 = parseInt(v1[i]);
            var num2 = parseInt(v2[i]);
            if (num1 > num2) {
                return 1;
            }
            else if (num1 < num2) {
                return -1;
            }
        }
        return 0;
    };
    /**
     * 初始化
     */
    SDK.prototype.init = function () { };
    SDK.prototype.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showBanner, this.showBanner, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.hideBanner, this.removeBanner, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showVideo, this.showVideo, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.startRecord, this.startRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.pauseRecord, this.pauseRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.resumeRecord, this.resumeRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.stopRecord, this.stopRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.shareRecord, this.shareRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showMsg, this.showMessage, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showInsertAd, this.showInterstitialAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.navigateToMiniProgram, this.navigateToMiniProgram, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.vibrateLong, this.onVibrateLong, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.vibrateShort, this.onVibrateShort, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.show, this.onShow, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.hide, this.onHide, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showInsertByPauseLevel, this.showInsertAdByPauseLevel, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.triggerGC, this.triggerGC, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showNativeAd, this.showNativeAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.hideNativeAd, this.hideNativeAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.hideAllNativeAd, this.hideAllNativeAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.quickShowNativeAd, this.quickShowNativeAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.quickHideNativeAd, this.quickHideNativeAd, this);
        //qq平台功能：
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showAppBox, this.showAppBox, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showBlockAd, this.showBlockAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.addColorSign, this.addColorSign, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.subscribeMsg, this.subscribeMsg, this);
    };
    SDK.prototype.triggerGC = function () { };
    /**暂停游戏时显示插屏，插屏显示失败时不显示banner */
    SDK.prototype.showInsertAdByPauseLevel = function () {
        this.showInterstitialAd(false);
    };
    //广告记录
    SDK.prototype.loadRecord = function () {
        var data = {
            video: null,
            banner: null,
            insert: null,
            recordVideoData: null,
            time: 0,
        };
        var record = cc.sys.localStorage.getItem("AdRecord");
        if (!!record) {
            var d = JSON.parse(record);
            var now = new Date();
            var old = new Date(d.time);
            if (now.getMonth() == old.getMonth() && now.getDate() == old.getDate()) {
                data = d;
            }
        }
        this.bannerRecord = new AdRecord(data.banner);
        this.videoRecord = new AdRecord(data.video);
        this.insertAdRecord = new AdRecord(data.insert);
        this.recordVideoData = new RecordVideoData(data.recordVideoData);
    };
    SDK.prototype.saveRecord = function () {
        var data = {
            video: this.videoRecord,
            banner: this.bannerRecord,
            insert: this.insertAdRecord,
            recordVideoData: this.recordVideoData,
            time: Date.now(),
        };
        cc.sys.localStorage.setItem("AdRecord", JSON.stringify(data));
    };
    /*******************************************录屏*******************************************/
    //开始录屏（头条）
    SDK.prototype.startRecord = function () {
        this.recordVideo("start");
        this.recordVideoData.onStart();
    };
    SDK.prototype.pauseRecord = function () {
        this.recordVideo("pause");
    };
    SDK.prototype.resumeRecord = function () {
        this.recordVideo("resume");
    };
    //停止录屏（头条）
    SDK.prototype.stopRecord = function () {
        this.recordVideoData.onEnd();
        this.recordVideo("stop");
    };
    //分享录屏（头条）
    SDK.prototype.shareRecord = function (success, fail) {
        if (fail === void 0) { fail = null; }
        this.shareRecordVideo(success, fail);
    };
    /**
     * 视频广告
     * @param success   广告观看完毕的回调
     * @param quit      中途退出广告观看的回调
     * @param fail      广告加载失败的回调
     */
    SDK.prototype.showVideo = function (success, quit, fail, videoName) {
        this.videoTongJi = null;
        if (!this.canApiUseVideo()) {
            if (typeof success === "object") {
                if (!!success.page) {
                    EventManager_1.default.emit(GameEventType_1.EventType.TongJi.video, {
                        type: success.page,
                        subType: GlobalEnum_1.GlobalEnum.VideoSubType.videoFail,
                        battle: success.battle
                    });
                }
                if (!!success.fail) {
                    success.fail();
                }
            }
            else if (!!fail) {
                fail();
            }
            return;
        }
        this.resetVideoCb();
        if (typeof success === "object") {
            this.videoSuccess = success.success;
            this.videoQuit = success.quit;
            this.videoFail = success.fail;
            if (undefined !== success.page) {
                this.videoTongJi = {
                    type: success.page,
                    battle: success.battle,
                };
            }
            videoName = success.videoName;
        }
        else {
            this.videoSuccess = success;
            this.videoQuit = quit;
            this.videoFail = fail;
        }
        if (!this.videoFail) {
            this.videoFail = this.tipVideoFail.bind(this);
        }
        this.sendVideoTongJi(GlobalEnum_1.GlobalEnum.VideoSubType.clickBtnVideo);
        this.onVideoStart();
        if (!this.getVideoAdUnitId()) {
            setTimeout(this.onVideoSuccess.bind(this), 0);
        }
        else {
            this.showVideoAd(videoName);
        }
    };
    /**视频广告开始播放时，处理与游戏逻辑相关的事件 */
    SDK.prototype.onVideoStart = function () {
        EventManager_1.default.emit(GameEventType_1.EventType.AudioEvent.pause);
        EventManager_1.default.emit(GameEventType_1.EventType.DirectorEvent.pauseLevel);
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTouchMask);
    };
    /**视频广告播放结束或加载失败后，处理与游戏逻辑相关的事件 */
    SDK.prototype.onVideoEnd = function () {
        EventManager_1.default.emit(GameEventType_1.EventType.AudioEvent.resume);
        EventManager_1.default.emit(GameEventType_1.EventType.DirectorEvent.resumeLevel);
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.hideTouchMask);
    };
    /**能否使用api：video ，子类实现 */
    SDK.prototype.canApiUseVideo = function () { return true; };
    SDK.prototype.tipVideoFail = function () {
        this.showMessage("视频加载失败，请稍后再试~");
    };
    SDK.prototype.showVideoAd = function (videoName) {
        this.onVideoSuccess();
    };
    /**获取视频广告id */
    SDK.prototype.getVideoAdUnitId = function (videoName) {
        if (!GamePlatform_1.default.instance.Config.video) {
            console.log("广告开关未打开");
            return null;
        }
        if (!GamePlatform_1.default.instance.Config.videoAdUnitId || !GamePlatform_1.default.instance.Config.videoAdUnitId[0]) {
            console.log("广告参数未填写");
            return null;
        }
        if (undefined === videoName) {
            return GamePlatform_1.default.instance.Config.videoAdUnitId[0];
        }
        if (videoName >= GamePlatform_1.default.instance.Config.videoAdUnitId.length) {
            return GamePlatform_1.default.instance.Config.videoAdUnitId[0];
        }
        return GamePlatform_1.default.instance.Config.videoAdUnitId[videoName];
    };
    SDK.prototype.onVideoShow = function () {
        console.log("视频广告展示成功");
        this.videoRecord.onShow();
    };
    SDK.prototype.onVideoHide = function () {
        console.log("视频广告未播放完即被关闭");
        this.videoRecord.onHide();
    };
    SDK.prototype.onVideoSuccess = function () {
        console.log("视频广告观看成功！");
        this.sendVideoTongJi(GlobalEnum_1.GlobalEnum.VideoSubType.videoSuc);
        this.onVideoEnd();
        var cb = this.videoSuccess;
        this.resetVideoCb();
        if (!!cb) {
            cb();
        }
    };
    SDK.prototype.onVideoFail = function (err) {
        console.log("视频广告加载出错  ", err);
        this.sendVideoTongJi(GlobalEnum_1.GlobalEnum.VideoSubType.videoFail);
        this.onVideoEnd();
        var cb = this.videoFail;
        this.resetVideoCb();
        if (!!cb) {
            cb();
        }
    };
    SDK.prototype.onVideoQuit = function () {
        console.log("视频广告观看未完成");
        this.sendVideoTongJi(GlobalEnum_1.GlobalEnum.VideoSubType.videoQuit);
        this.onVideoEnd();
        var cb = this.videoQuit;
        this.resetVideoCb();
        if (!!cb) {
            cb();
        }
    };
    /**发送视频数据进行统计 */
    SDK.prototype.sendVideoTongJi = function (subType) {
        if (!!this.videoTongJi) {
            EventManager_1.default.emit(GameEventType_1.EventType.TongJi.video, {
                type: this.videoTongJi.type,
                subType: subType,
                battle: this.videoTongJi.battle,
            });
        }
    };
    SDK.prototype.resetVideoCb = function () {
        this.videoSuccess = null;
        this.videoQuit = null;
        this.videoFail = null;
    };
    SDK.prototype.showBanner = function () { };
    /**能否使用api：banner ，子类实现 */
    SDK.prototype.canApiUseBanner = function () { return true; };
    SDK.prototype.removeBanner = function () { };
    SDK.prototype.getBannerId = function () {
        if (!GamePlatform_1.default.instance.Config.banner) {
            console.log("banner开关未打开");
            return null;
        }
        if (!GamePlatform_1.default.instance.Config.BannerAdUnitId || !GamePlatform_1.default.instance.Config.BannerAdUnitId[0]) {
            console.log("banner ID 未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.BannerAdUnitId[0];
    };
    SDK.prototype.onBannerShow = function () {
        console.log("banner 显示成功");
        this.bannerRecord.onShow();
        this.bannerShowing = true;
        EventManager_1.default.emit(GameEventType_1.EventType.SDKEvent.showBannerFinish);
    };
    SDK.prototype.onBannerHide = function () {
        console.log("banner 广告隐藏");
        this.bannerRecord.onHide();
        this.bannerShowing = false;
    };
    SDK.prototype.onBannerErr = function (err) {
        console.log('banner 显示失败:', JSON.stringify(err));
        this.bannerRecord.isShowing = false;
    };
    /**
     * 插屏广告
     * @param banner    插屏显示失败时是否显示banner
     */
    SDK.prototype.showInterstitialAd = function (banner) { };
    /**能否使用api：insert ，子类实现 */
    SDK.prototype.canApiUseInsert = function () { return true; };
    /**获取插屏广告id */
    SDK.prototype.getInsertAdUnitId = function () {
        if (!GamePlatform_1.default.instance.Config.interstitial) {
            console.log("插屏广告开关未打开");
            return null;
        }
        if (!GamePlatform_1.default.instance.Config.InterstitialAdUnitId || !GamePlatform_1.default.instance.Config.InterstitialAdUnitId[0]) {
            console.log("插屏广告参数未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.InterstitialAdUnitId[0];
    };
    SDK.prototype.onInsertShow = function () {
        console.log("插屏显示成功");
        this.insertAdRecord.onShow();
    };
    SDK.prototype.onInsertHide = function () {
        console.log("关闭插屏");
        this.insertAdRecord.onHide();
    };
    SDK.prototype.onInsertErr = function (err) {
        console.log("插屏广告加载失败：" + JSON.stringify(err));
        this.insertAdRecord.isShowing = false;
    };
    SDK.prototype.showBannerInsteadInsert = function () {
        if (this.useBannerInsteadInsert) {
            console.log("显示banner代替插屏");
            this.showBanner();
        }
        this.useBannerInsteadInsert = false;
    };
    /*******************************************震动*******************************************/
    /**短震动 */
    SDK.prototype.onVibrateShort = function () {
        if (!GameConfig_1.default.driveConfig.vibrate)
            return;
        this.vibrateShort();
    };
    SDK.prototype.vibrateShort = function () { };
    /**长震动 */
    SDK.prototype.onVibrateLong = function () {
        if (!GameConfig_1.default.driveConfig.vibrate)
            return;
        this.vibrateLong();
    };
    SDK.prototype.vibrateLong = function () { };
    /*******************************************分享*******************************************/
    /**无激励分享&&带参分享 */
    SDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ''; }
    };
    /**激励分享&&带参分享 */
    SDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
        success();
    };
    /**弹出消息 */
    SDK.prototype.showMessage = function (msg, icon) {
        if (icon === void 0) { icon = 'none'; }
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTip, msg);
    };
    /**录屏功能 */
    SDK.prototype.recordVideo = function (type) {
        if (type === void 0) { type = 'start'; }
    };
    /**录屏分享 */
    SDK.prototype.shareRecordVideo = function (success, fail) { };
    /*******************************************跳转*******************************************/
    /**跳转到其他小游戏 */
    SDK.prototype.navigateToMiniProgram = function (data) {
        console.log("跳转小游戏，子类实现，data:", data);
    };
    /**游戏切到后台 */
    SDK.prototype.onHide = function () { };
    /**从后台回到游戏 */
    SDK.prototype.onShow = function () { };
    //QQ平台功能：
    /*******************************************盒子广告*******************************************/
    SDK.prototype.showAppBox = function () { };
    SDK.prototype.getAppBoxId = function () {
        if (!GamePlatform_1.default.instance.Config.appBoxUnitId || !GamePlatform_1.default.instance.Config.appBoxUnitId[0]) {
            console.log("盒子广告参数未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.appBoxUnitId[0];
    };
    /*******************************************积木广告*******************************************/
    SDK.prototype.showBlockAd = function () { };
    SDK.prototype.getBlockAdId = function () {
        if (!GamePlatform_1.default.instance.Config.blockAdUnitId || !GamePlatform_1.default.instance.Config.blockAdUnitId[0]) {
            console.log("积木广告参数未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.blockAdUnitId[0];
    };
    /*******************************************彩签*******************************************/
    SDK.prototype.addColorSign = function (data) { };
    SDK.prototype.subscribeMsg = function (data) { };
    /*******************************************原生广告*******************************************/
    /**原生广告id */
    SDK.prototype.getNativeAdId = function () {
        if (!GamePlatform_1.default.instance.Config.nativeAdUnitId[0]) {
            console.log("原生广告参数未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.nativeAdUnitId[0];
    };
    SDK.prototype.getAllNativeAdIds = function () {
        if (!GamePlatform_1.default.instance.Config.nativeAdUnitId[0]) {
            console.log("原生广告参数未填写");
            return [];
        }
        return GamePlatform_1.default.instance.Config.nativeAdUnitId;
    };
    /**显示原生广告 */
    SDK.prototype.showNativeAd = function (data) { };
    SDK.prototype.hideNativeAd = function (data) { };
    SDK.prototype.hideAllNativeAd = function (data) { };
    SDK.prototype.quickShowNativeAd = function (data) { };
    SDK.prototype.quickHideNativeAd = function (data) { };
    return SDK;
}());
exports.default = SDK;
var AdRecord = /** @class */ (function () {
    function AdRecord(data) {
        this.isShowing = false;
        this.gameShowCount = 0;
        this.gameHideCount = 0;
        if (!data) {
            this.dayShowCount = 0;
            this.dayHideCount = 0;
            this.preShowTime = 0;
            this.preHideTime = 0;
        }
        else {
            this.dayShowCount = data.dayShowCount;
            this.dayHideCount = data.dayHideCount;
            this.preShowTime = data.preShowTime;
            this.preHideTime = data.preHideTime;
        }
    }
    AdRecord.prototype.onShow = function () {
        this.isShowing = true;
        this.dayShowCount++;
        this.gameShowCount++;
        this.preShowTime = Date.now();
    };
    AdRecord.prototype.onHide = function () {
        this.isShowing = false;
        this.dayHideCount++;
        this.gameHideCount++;
        this.preHideTime = Date.now();
    };
    /**当前时间距离上一次展示的时间间隔，单位：秒 */
    AdRecord.prototype.getShowSpaceTime = function () {
        var d = Date.now() - this.preShowTime;
        return d * 0.001;
    };
    /**当前时间距离上一次关闭的时间间隔，单位：秒 */
    AdRecord.prototype.getHideSpaceTime = function () {
        var d = Date.now() - this.preHideTime;
        return d * 0.001;
    };
    return AdRecord;
}());
/**录屏数据记录 */
var RecordVideoData = /** @class */ (function () {
    function RecordVideoData(data) {
        this.startTime = 0;
        this.endTime = 0;
        this.gameShareCount = 0;
        if (!!data) {
            this.dayShareCount = data.dayShareCount;
        }
        else {
            this.dayShareCount = 0;
        }
    }
    /**录屏开始 */
    RecordVideoData.prototype.onStart = function () {
        this.startTime = Date.now();
        this.endTime = Date.now();
    };
    /**录屏结束 */
    RecordVideoData.prototype.onEnd = function () {
        this.endTime = Date.now();
    };
    Object.defineProperty(RecordVideoData.prototype, "totalTime", {
        /**录屏时长，单位：秒 */
        get: function () {
            return (this.endTime - this.startTime) * 0.001;
        },
        enumerable: false,
        configurable: true
    });
    /**分享成功 */
    RecordVideoData.prototype.onShare = function () {
        this.gameShareCount++;
        this.dayShareCount++;
    };
    return RecordVideoData;
}());
/**
 * 手机平台类型
 */
var Platform;
(function (Platform) {
    /**电脑上调试时使用 */
    Platform["pc"] = "PC";
    /**苹果 */
    Platform["ios"] = "IOS";
    /**安卓 */
    Platform["android"] = "ANDROID";
})(Platform = exports.Platform || (exports.Platform = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcU0RLXFxTREsudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsMERBQXFEO0FBQ3JELGlFQUE0RDtBQUM1RCxnREFBMkM7QUFDM0MsMkRBQXNEO0FBQ3RELDJEQUEwRDtBQUUxRDtJQUFBO1FBQ0k7O1dBRUc7UUFDTyxrQkFBYSxHQUFHO1lBQ3RCLEVBQUU7WUFDRixFQUFFO1NBQ0wsQ0FBQTtRQUNEOztXQUVHO1FBQ08sZ0JBQVcsR0FBRztZQUNwQixFQUFFO1lBQ0YsRUFBRTtTQUNMLENBQUE7UUFZRCxjQUFjO1FBQ0osYUFBUSxHQUFhLElBQUksQ0FBQztRQTJMMUIsZ0JBQVcsR0FBYSxJQUFJLENBQUM7UUFpSHZDLGlCQUFpQjtRQUNQLGdCQUFXLEdBQXNDLElBQUksQ0FBQztRQStDaEUsOEZBQThGO1FBQ3BGLGlCQUFZLEdBQWEsSUFBSSxDQUFDO1FBQ3hDLG9DQUFvQztRQUMxQixrQkFBYSxHQUFZLEtBQUssQ0FBQztRQWdDekMsMEZBQTBGO1FBQ2hGLG1CQUFjLEdBQWEsSUFBSSxDQUFDO1FBZ0MxQywwQkFBMEI7UUFDaEIsMkJBQXNCLEdBQVksS0FBSyxDQUFDO1FBbUN4QyxvQkFBZSxHQUFvQixJQUFJLENBQUM7SUFnRXRELENBQUM7SUEvZkc7Ozs7Ozs7T0FPRztJQUNPLDJCQUFhLEdBQXZCLFVBQXdCLFFBQWdCLEVBQUUsYUFBcUIsRUFBRSxVQUFrQjtRQUMvRSxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztRQUNuQyxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUM3QixJQUFJLEdBQUcsR0FBRyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDakMsUUFBUSxHQUFHLEVBQUU7WUFDVCxLQUFLLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDZixJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUM7Z0JBQzdCLE1BQU07YUFDVDtZQUNELEtBQUssUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNuQixJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUM7Z0JBQ2pDLE1BQU07YUFDVDtZQUNELE9BQU8sQ0FBQyxDQUFDO2dCQUNMLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLEVBQUUsQ0FBQztnQkFDNUIsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBQ0Qsb0JBQW9CO0lBQ1YsNEJBQWMsR0FBeEIsVUFBeUIsQ0FBUztRQUM5QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsbUJBQW1CO0lBQ1QseUJBQVcsR0FBckIsVUFBc0IsQ0FBUztRQUMzQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsbUJBQW1CO0lBQ1Qsc0JBQVEsR0FBbEIsVUFBbUIsRUFBVSxFQUFFLEVBQVU7UUFDckMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN6QixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3pCLElBQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDL0MsT0FBTyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRTtZQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2xCO1FBQ0QsT0FBTyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRTtZQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2xCO1FBQ0QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMxQixJQUFNLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0IsSUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9CLElBQUksSUFBSSxHQUFHLElBQUksRUFBRTtnQkFDYixPQUFPLElBQUksQ0FBQzthQUNmO2lCQUFNLElBQUksSUFBSSxHQUFHLElBQUksRUFBRTtnQkFDcEIsT0FBTyxLQUFLLENBQUM7YUFDaEI7U0FDSjtRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFDRCxjQUFjO0lBQ0osNEJBQWMsR0FBeEIsVUFBeUIsRUFBRSxFQUFFLEVBQUU7UUFDM0IsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbkIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbkIsSUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMzQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFO1lBQ3BCLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDaEI7UUFDRCxPQUFPLEVBQUUsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFO1lBQ3BCLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDaEI7UUFDRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFCLElBQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM3QixJQUFNLElBQUksR0FBRyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDN0IsSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFO2dCQUNiLE9BQU8sQ0FBQyxDQUFDO2FBQ1o7aUJBQU0sSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFO2dCQUNwQixPQUFPLENBQUMsQ0FBQyxDQUFDO2FBQ2I7U0FDSjtRQUNELE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUVEOztPQUVHO0lBQ0ksa0JBQUksR0FBWCxjQUFnQixDQUFDO0lBRVYsc0JBQVEsR0FBZjtRQUNJLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDaEYsc0JBQVksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVGLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVFLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVELHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVELHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUFFLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNoRyxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNwRSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMxRSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMxRSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNoRixzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDcEYsc0JBQVksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBR3BGLFNBQVM7UUFDVCxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN0RSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN4RSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMxRSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUU5RSxDQUFDO0lBQ00sdUJBQVMsR0FBaEIsY0FBcUIsQ0FBQztJQUV0QixnQ0FBZ0M7SUFDdEIsc0NBQXdCLEdBQWxDO1FBQ0ksSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCxNQUFNO0lBQ0Msd0JBQVUsR0FBakI7UUFDSSxJQUFJLElBQUksR0FBRztZQUNQLEtBQUssRUFBRSxJQUFJO1lBQ1gsTUFBTSxFQUFFLElBQUk7WUFDWixNQUFNLEVBQUUsSUFBSTtZQUNaLGVBQWUsRUFBRSxJQUFJO1lBQ3JCLElBQUksRUFBRSxDQUFDO1NBQ1YsQ0FBQztRQUNGLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUU7WUFDVixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzNCLElBQUksR0FBRyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7WUFDckIsSUFBSSxHQUFHLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzNCLElBQUksR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLEdBQUcsQ0FBQyxRQUFRLEVBQUUsSUFBSSxHQUFHLENBQUMsT0FBTyxFQUFFLElBQUksR0FBRyxDQUFDLE9BQU8sRUFBRSxFQUFFO2dCQUNwRSxJQUFJLEdBQUcsQ0FBQyxDQUFDO2FBQ1o7U0FDSjtRQUNELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzlDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFDTSx3QkFBVSxHQUFqQjtRQUNJLElBQUksSUFBSSxHQUFHO1lBQ1AsS0FBSyxFQUFFLElBQUksQ0FBQyxXQUFXO1lBQ3ZCLE1BQU0sRUFBRSxJQUFJLENBQUMsWUFBWTtZQUN6QixNQUFNLEVBQUUsSUFBSSxDQUFDLGNBQWM7WUFDM0IsZUFBZSxFQUFFLElBQUksQ0FBQyxlQUFlO1lBQ3JDLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFO1NBQ25CLENBQUM7UUFDRixFQUFFLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRUQsMEZBQTBGO0lBQzFGLFVBQVU7SUFDQSx5QkFBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUNuQyxDQUFDO0lBQ1MseUJBQVcsR0FBckI7UUFDSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFDUywwQkFBWSxHQUF0QjtRQUNJLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUNELFVBQVU7SUFDQSx3QkFBVSxHQUFwQjtRQUNJLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBQ0QsVUFBVTtJQUNBLHlCQUFXLEdBQXJCLFVBQXNCLE9BQWlCLEVBQUUsSUFBcUI7UUFBckIscUJBQUEsRUFBQSxXQUFxQjtRQUMxRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFLRDs7Ozs7T0FLRztJQUNJLHVCQUFTLEdBQWhCLFVBQWlCLE9BT2hCLEVBQUUsSUFBZSxFQUFFLElBQWUsRUFBRSxTQUF1QztRQUN4RSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFO1lBQ3hCLElBQUksT0FBTyxPQUFPLEtBQUssUUFBUSxFQUFFO2dCQUM3QixJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFO29CQUNoQixzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7d0JBQ3RDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTt3QkFDbEIsT0FBTyxFQUFFLHVCQUFVLENBQUMsWUFBWSxDQUFDLFNBQVM7d0JBQzFDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTTtxQkFDekIsQ0FBQyxDQUFDO2lCQUNOO2dCQUNELElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUU7b0JBQ2hCLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztpQkFDbEI7YUFDSjtpQkFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLENBQUM7YUFDVjtZQUNELE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLE9BQU8sT0FBTyxLQUFLLFFBQVEsRUFBRTtZQUM3QixJQUFJLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDcEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO1lBQzlCLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQztZQUM5QixJQUFJLFNBQVMsS0FBSyxPQUFPLENBQUMsSUFBSSxFQUFFO2dCQUM1QixJQUFJLENBQUMsV0FBVyxHQUFHO29CQUNmLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtvQkFDbEIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO2lCQUN6QixDQUFBO2FBQ0o7WUFDRCxTQUFTLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQztTQUNqQzthQUFNO1lBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUM7WUFDNUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDdEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7U0FDekI7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ2pEO1FBQ0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyx1QkFBVSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUM1RCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFO1lBQzFCLFVBQVUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNqRDthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFDRCw0QkFBNEI7SUFDbEIsMEJBQVksR0FBdEI7UUFDSSxzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM5QyxzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN0RCxzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBQ0QsaUNBQWlDO0lBQ3ZCLHdCQUFVLEdBQXBCO1FBQ0ksc0JBQVksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDL0Msc0JBQVksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDdkQsc0JBQVksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUNELHlCQUF5QjtJQUNmLDRCQUFjLEdBQXhCLGNBQTZCLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNqQywwQkFBWSxHQUF0QjtRQUNJLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNNLHlCQUFXLEdBQWxCLFVBQW1CLFNBQXVDO1FBQ3RELElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBQ0QsY0FBYztJQUNKLDhCQUFnQixHQUExQixVQUEyQixTQUFrQjtRQUN6QyxJQUFJLENBQUMsc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3ZCLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFDRCxJQUFJLENBQUMsc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsSUFBSSxDQUFDLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDL0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUN2QixPQUFPLElBQUksQ0FBQztTQUNmO1FBQ0QsSUFBSSxTQUFTLEtBQUssU0FBUyxFQUFFO1lBQ3pCLE9BQU8sc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4RDtRQUNELElBQUksU0FBUyxJQUFJLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFO1lBQ2hFLE9BQU8sc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4RDtRQUNELE9BQU8sc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBQ1MseUJBQVcsR0FBckI7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUNTLHlCQUFXLEdBQXJCO1FBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUM1QixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFTUyw0QkFBYyxHQUF4QjtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDekIsSUFBSSxDQUFDLGVBQWUsQ0FBQyx1QkFBVSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN2RCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUMzQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ04sRUFBRSxFQUFFLENBQUM7U0FDUjtJQUNMLENBQUM7SUFDUyx5QkFBVyxHQUFyQixVQUFzQixHQUFTO1FBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxlQUFlLENBQUMsdUJBQVUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDeEQsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDeEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNOLEVBQUUsRUFBRSxDQUFDO1NBQ1I7SUFDTCxDQUFDO0lBQ1MseUJBQVcsR0FBckI7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxlQUFlLENBQUMsdUJBQVUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDeEQsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDeEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNOLEVBQUUsRUFBRSxDQUFDO1NBQ1I7SUFDTCxDQUFDO0lBQ0QsZ0JBQWdCO0lBQ04sNkJBQWUsR0FBekIsVUFBMEIsT0FBZTtRQUNyQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ3BCLHNCQUFZLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtnQkFDdEMsSUFBSSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSTtnQkFDM0IsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU07YUFDbEMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBQ1MsMEJBQVksR0FBdEI7UUFDSSxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztRQUN6QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztJQUMxQixDQUFDO0lBTU0sd0JBQVUsR0FBakIsY0FBc0IsQ0FBQztJQUN2QiwwQkFBMEI7SUFDaEIsNkJBQWUsR0FBekIsY0FBOEIsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3JDLDBCQUFZLEdBQW5CLGNBQXdCLENBQUM7SUFDZix5QkFBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO1lBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDM0IsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUNELElBQUksQ0FBQyxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsY0FBYyxJQUFJLENBQUMsc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNqRyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQzdCLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFDRCxPQUFPLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUNTLDBCQUFZLEdBQXRCO1FBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQzFCLHNCQUFZLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUNTLDBCQUFZLEdBQXRCO1FBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDUyx5QkFBVyxHQUFyQixVQUFzQixHQUFHO1FBQ3JCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQztJQUlEOzs7T0FHRztJQUNJLGdDQUFrQixHQUF6QixVQUEwQixNQUFnQixJQUFJLENBQUM7SUFDL0MsMEJBQTBCO0lBQ2hCLDZCQUFlLEdBQXpCLGNBQThCLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM1QyxjQUFjO0lBQ0osK0JBQWlCLEdBQTNCO1FBQ0ksSUFBSSxDQUFDLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUU7WUFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUN6QixPQUFPLElBQUksQ0FBQztTQUNmO1FBQ0QsSUFBSSxDQUFDLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsSUFBSSxDQUFDLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUM3RyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3pCLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFDRCxPQUFPLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBQ1MsMEJBQVksR0FBdEI7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUNTLDBCQUFZLEdBQXRCO1FBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQixJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFDUyx5QkFBVyxHQUFyQixVQUFzQixHQUFHO1FBQ3JCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFDMUMsQ0FBQztJQUdTLHFDQUF1QixHQUFqQztRQUNJLElBQUksSUFBSSxDQUFDLHNCQUFzQixFQUFFO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDNUIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1NBQ3JCO1FBQ0QsSUFBSSxDQUFDLHNCQUFzQixHQUFHLEtBQUssQ0FBQztJQUN4QyxDQUFDO0lBRUQsMEZBQTBGO0lBQzFGLFNBQVM7SUFDRiw0QkFBYyxHQUFyQjtRQUNJLElBQUksQ0FBQyxvQkFBVSxDQUFDLFdBQVcsQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUM1QyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUNNLDBCQUFZLEdBQW5CLGNBQXdCLENBQUM7SUFDekIsU0FBUztJQUNGLDJCQUFhLEdBQXBCO1FBQ0ksSUFBSSxDQUFDLG9CQUFVLENBQUMsV0FBVyxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQzVDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBQ00seUJBQVcsR0FBbEIsY0FBdUIsQ0FBQztJQUd4QiwwRkFBMEY7SUFDMUYsaUJBQWlCO0lBQ1YsNkJBQWUsR0FBdEIsVUFBdUIsS0FBa0I7UUFBbEIsc0JBQUEsRUFBQSxVQUFrQjtJQUFJLENBQUM7SUFDOUMsZ0JBQWdCO0lBQ1QsMkJBQWEsR0FBcEIsVUFBcUIsT0FBaUIsRUFBRSxJQUFlLEVBQUUsS0FBa0I7UUFBbEIsc0JBQUEsRUFBQSxVQUFrQjtRQUFJLE9BQU8sRUFBRSxDQUFBO0lBQUMsQ0FBQztJQUUxRixVQUFVO0lBQ0gseUJBQVcsR0FBbEIsVUFBbUIsR0FBVyxFQUFFLElBQXFCO1FBQXJCLHFCQUFBLEVBQUEsYUFBcUI7UUFDakQsc0JBQVksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFHRCxVQUFVO0lBQ0gseUJBQVcsR0FBbEIsVUFBbUIsSUFBc0I7UUFBdEIscUJBQUEsRUFBQSxjQUFzQjtJQUFJLENBQUM7SUFDOUMsVUFBVTtJQUNILDhCQUFnQixHQUF2QixVQUF3QixPQUFpQixFQUFFLElBQWUsSUFBSSxDQUFDO0lBRS9ELDBGQUEwRjtJQUMxRixjQUFjO0lBQ1AsbUNBQXFCLEdBQTVCLFVBQTZCLElBQVM7UUFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQsWUFBWTtJQUNMLG9CQUFNLEdBQWIsY0FBa0IsQ0FBQztJQUNuQixhQUFhO0lBQ04sb0JBQU0sR0FBYixjQUFrQixDQUFDO0lBRW5CLFNBQVM7SUFFVCw0RkFBNEY7SUFDckYsd0JBQVUsR0FBakIsY0FBc0IsQ0FBQztJQUNiLHlCQUFXLEdBQXJCO1FBQ0ksSUFBSSxDQUFDLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLElBQUksQ0FBQyxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQzdGLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDekIsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUNELE9BQU8sc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsNEZBQTRGO0lBQ3JGLHlCQUFXLEdBQWxCLGNBQXVCLENBQUM7SUFDZCwwQkFBWSxHQUF0QjtRQUNJLElBQUksQ0FBQyxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsYUFBYSxJQUFJLENBQUMsc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUMvRixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3pCLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFDRCxPQUFPLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDekQsQ0FBQztJQUVELDBGQUEwRjtJQUNuRiwwQkFBWSxHQUFuQixVQUFvQixJQUFVLElBQUksQ0FBQztJQUM1QiwwQkFBWSxHQUFuQixVQUFvQixJQUFVLElBQUksQ0FBQztJQUVuQyw0RkFBNEY7SUFDNUYsWUFBWTtJQUNMLDJCQUFhLEdBQXBCO1FBQ0ksSUFBSSxDQUFDLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUN6QixPQUFPLElBQUksQ0FBQztTQUNmO1FBQ0QsT0FBTyxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFDTSwrQkFBaUIsR0FBeEI7UUFDSSxJQUFJLENBQUMsc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3pCLE9BQU8sRUFBRSxDQUFDO1NBQ2I7UUFDRCxPQUFPLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUM7SUFDdkQsQ0FBQztJQUNELFlBQVk7SUFDTCwwQkFBWSxHQUFuQixVQUFvQixJQUFLLElBQUksQ0FBQztJQUN2QiwwQkFBWSxHQUFuQixVQUFvQixJQUFLLElBQUksQ0FBQztJQUN2Qiw2QkFBZSxHQUF0QixVQUF1QixJQUFLLElBQUksQ0FBQztJQUMxQiwrQkFBaUIsR0FBeEIsVUFBeUIsSUFBSyxJQUFJLENBQUM7SUFDNUIsK0JBQWlCLEdBQXhCLFVBQXlCLElBQUssSUFBSSxDQUFDO0lBQ3ZDLFVBQUM7QUFBRCxDQS9oQkEsQUEraEJDLElBQUE7O0FBRUQ7SUFnQkksa0JBQW1CLElBQUk7UUFDbkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7UUFDdkIsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7UUFDdkIsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNQLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1NBQ3hCO2FBQU07WUFDSCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDdEMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQ3RDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztZQUNwQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7U0FDdkM7SUFDTCxDQUFDO0lBRU0seUJBQU0sR0FBYjtRQUNJLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUNNLHlCQUFNLEdBQWI7UUFDSSxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN2QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFDRCwyQkFBMkI7SUFDcEIsbUNBQWdCLEdBQXZCO1FBQ0ksSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDdEMsT0FBTyxDQUFDLEdBQUcsS0FBSyxDQUFDO0lBQ3JCLENBQUM7SUFDRCwyQkFBMkI7SUFDcEIsbUNBQWdCLEdBQXZCO1FBQ0ksSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDdEMsT0FBTyxDQUFDLEdBQUcsS0FBSyxDQUFDO0lBQ3JCLENBQUM7SUFFTCxlQUFDO0FBQUQsQ0F4REEsQUF3REMsSUFBQTtBQUNELFlBQVk7QUFDWjtJQUtJLHlCQUFtQixJQUFJO1FBQ25CLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRTtZQUNSLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztTQUMzQzthQUFNO1lBQ0gsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7U0FDMUI7SUFDTCxDQUFDO0lBQ0QsVUFBVTtJQUNILGlDQUFPLEdBQWQ7UUFDSSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBQ0QsVUFBVTtJQUNILCtCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRUQsc0JBQVcsc0NBQVM7UUFEcEIsZUFBZTthQUNmO1lBQ0ksT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEtBQUssQ0FBQztRQUNuRCxDQUFDOzs7T0FBQTtJQUNELFVBQVU7SUFDSCxpQ0FBTyxHQUFkO1FBQ0ksSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBQ0wsc0JBQUM7QUFBRCxDQWpDQSxBQWlDQyxJQUFBO0FBRUQ7O0dBRUc7QUFDSCxJQUFZLFFBT1g7QUFQRCxXQUFZLFFBQVE7SUFDaEIsY0FBYztJQUNkLHFCQUFTLENBQUE7SUFDVCxRQUFRO0lBQ1IsdUJBQVcsQ0FBQTtJQUNYLFFBQVE7SUFDUiwrQkFBbUIsQ0FBQTtBQUN2QixDQUFDLEVBUFcsUUFBUSxHQUFSLGdCQUFRLEtBQVIsZ0JBQVEsUUFPbkIiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgRXZlbnRNYW5hZ2VyIGZyb20gXCIuLi8uLi9Db21tb24vRXZlbnRNYW5hZ2VyXCI7XHJcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi8uLi9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XHJcbmltcG9ydCBHYW1lUGxhdGZvcm0gZnJvbSBcIi4uL0dhbWVQbGF0Zm9ybVwiO1xyXG5pbXBvcnQgR2FtZUNvbmZpZyBmcm9tIFwiLi4vLi4vR2FtZVNwZWNpYWwvR2FtZUNvbmZpZ1wiO1xyXG5pbXBvcnQgeyBHbG9iYWxFbnVtIH0gZnJvbSBcIi4uLy4uL0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNESyB7XHJcbiAgICAvKipcclxuICAgICAqIOWIhuS6q+a4uOaIj+aXtueahOaPj+i/sFxyXG4gICAgICovXHJcbiAgICBwcm90ZWN0ZWQgc2hhcmVUaXRsZUFyciA9IFtcclxuICAgICAgICAnJyxcclxuICAgICAgICAnJ1xyXG4gICAgXVxyXG4gICAgLyoqXHJcbiAgICAgKiDliIbkuqvmuLjmiI/ml7bnmoTlm77niYdcclxuICAgICAqL1xyXG4gICAgcHJvdGVjdGVkIHNoYXJlSW1nQXJyID0gW1xyXG4gICAgICAgICcnLFxyXG4gICAgICAgICcnXHJcbiAgICBdXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDlvZPliY3lubPlj7BhcGlcclxuICAgICAqL1xyXG4gICAgcHJvdGVjdGVkIGFwaTogYW55O1xyXG5cclxuICAgIC8qKui/m+WFpea4uOaIj+eahOaXtumXtCAqL1xyXG4gICAgcHJvdGVjdGVkIGVudGVyVGltZTogbnVtYmVyO1xyXG5cclxuICAgIC8qKuezu+e7n+S/oeaBryAqL1xyXG4gICAgcHJvdGVjdGVkIHN5c3RlbUluZm86IGFueTtcclxuICAgIC8qKuaJi+acuuaTjeS9nOezu+e7n+exu+WeiyAqL1xyXG4gICAgcHJvdGVjdGVkIHBsYXRmb3JtOiBQbGF0Zm9ybSA9IG51bGw7XHJcbiAgICAvKirmiYvmnLrmk43kvZzns7vnu5/niYjmnKzlj7cgKi9cclxuICAgIHByb3RlY3RlZCBzeXN0ZW1WZXJzaW9uOiBzdHJpbmc7XHJcbiAgICAvKipTREvniYjmnKzlj7cgKi9cclxuICAgIHByb3RlY3RlZCBzZGtWZXJzaW9uOiBzdHJpbmc7XHJcbiAgICAvKipcclxuICAgICAqIOiusOW9lVNES+S4juezu+e7n+S/oeaBr1xyXG4gICAgICogXHJcbiAgICAgKiDlsIbkuI3lkIzlubPlj7DnmoTns7vnu5/kv6Hmga/kuK3pgJrnlKjnmoTlhoXlrrnnlKjnu5/kuIDnmoTlrZfmrrXlrZjlgqhcclxuICAgICAqIEBwYXJhbSBwbGF0Zm9ybSAgICAgIFNES+iOt+WPlueahOezu+e7n+S/oeaBr+S4reeahOaTjeS9nOezu+e7n1xyXG4gICAgICogQHBhcmFtIHZlcnNpb24gICAgICAgU0RL6I635Y+W55qE57O757uf5L+h5oGv5Lit55qE5pON5L2c57O757uf54mI5pys5Y+3XHJcbiAgICAgKiBAcGFyYW0gc2RrVmVyc2lvbiAgICBTREvojrflj5bnmoTns7vnu5/kv6Hmga/kuK3nmoRTREvniYjmnKzlj7dcclxuICAgICAqL1xyXG4gICAgcHJvdGVjdGVkIHNldFN5c3RlbUluZm8ocGxhdGZvcm06IHN0cmluZywgc3lzdGVtVmVyc2lvbjogc3RyaW5nLCBzZGtWZXJzaW9uOiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLnN5c3RlbVZlcnNpb24gPSBzeXN0ZW1WZXJzaW9uO1xyXG4gICAgICAgIHRoaXMuc2RrVmVyc2lvbiA9IHNka1ZlcnNpb247XHJcbiAgICAgICAgbGV0IHN0ciA9IHBsYXRmb3JtLnRvVXBwZXJDYXNlKCk7XHJcbiAgICAgICAgc3dpdGNoIChzdHIpIHtcclxuICAgICAgICAgICAgY2FzZSBQbGF0Zm9ybS5pb3M6IHtcclxuICAgICAgICAgICAgICAgIHRoaXMucGxhdGZvcm0gPSBQbGF0Zm9ybS5pb3M7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYXNlIFBsYXRmb3JtLmFuZHJvaWQ6IHtcclxuICAgICAgICAgICAgICAgIHRoaXMucGxhdGZvcm0gPSBQbGF0Zm9ybS5hbmRyb2lkO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZGVmYXVsdDoge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wbGF0Zm9ybSA9IFBsYXRmb3JtLnBjO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKirmiYvmnLrmk43kvZzns7vnu5/mmK/lkKbkvY7kuo7mjIflrprniYjmnKwgKi9cclxuICAgIHByb3RlY3RlZCBzeXN0ZW1MZXNzVGhhbih2OiBzdHJpbmcpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5sZXNzVGhhbih0aGlzLnN5c3RlbVZlcnNpb24sIHYpO1xyXG4gICAgfVxyXG4gICAgLyoq5bmz5Y+wc2Rr5piv5ZCm5L2O5LqO5oyH5a6a54mI5pysICovXHJcbiAgICBwcm90ZWN0ZWQgc2RrTGVzc1RoYW4odjogc3RyaW5nKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMubGVzc1RoYW4odGhpcy5zZGtWZXJzaW9uLCB2KTtcclxuICAgIH1cclxuICAgIC8qKuavlOi+g+eJiOacrOWPt3Yx5piv5ZCm5L2O5LqOdjIgKi9cclxuICAgIHByb3RlY3RlZCBsZXNzVGhhbih2MTogc3RyaW5nLCB2Mjogc3RyaW5nKSB7XHJcbiAgICAgICAgbGV0IGFycjEgPSB2MS5zcGxpdCgnLicpO1xyXG4gICAgICAgIGxldCBhcnIyID0gdjIuc3BsaXQoJy4nKTtcclxuICAgICAgICBjb25zdCBsZW4gPSBNYXRoLm1heChhcnIyLmxlbmd0aCwgYXJyMi5sZW5ndGgpO1xyXG4gICAgICAgIHdoaWxlIChhcnIxLmxlbmd0aCA8IGxlbikge1xyXG4gICAgICAgICAgICBhcnIxLnB1c2goJzAnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgd2hpbGUgKGFycjIubGVuZ3RoIDwgbGVuKSB7XHJcbiAgICAgICAgICAgIGFycjIucHVzaCgnMCcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IG51bTEgPSBwYXJzZUludChhcnIxW2ldKTtcclxuICAgICAgICAgICAgY29uc3QgbnVtMiA9IHBhcnNlSW50KGFycjJbaV0pO1xyXG4gICAgICAgICAgICBpZiAobnVtMSA8IG51bTIpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKG51bTEgPiBudW0yKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgLyoq5Yik5pat5Z+656GA5bqT54mI5pys5Y+3ICovXHJcbiAgICBwcm90ZWN0ZWQgY29tcGFyZVZlcnNpb24odjEsIHYyKSB7XHJcbiAgICAgICAgdjEgPSB2MS5zcGxpdCgnLicpO1xyXG4gICAgICAgIHYyID0gdjIuc3BsaXQoJy4nKTtcclxuICAgICAgICBjb25zdCBsZW4gPSBNYXRoLm1heCh2MS5sZW5ndGgsIHYyLmxlbmd0aCk7XHJcbiAgICAgICAgd2hpbGUgKHYxLmxlbmd0aCA8IGxlbikge1xyXG4gICAgICAgICAgICB2MS5wdXNoKCcwJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHdoaWxlICh2Mi5sZW5ndGggPCBsZW4pIHtcclxuICAgICAgICAgICAgdjIucHVzaCgnMCcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IG51bTEgPSBwYXJzZUludCh2MVtpXSk7XHJcbiAgICAgICAgICAgIGNvbnN0IG51bTIgPSBwYXJzZUludCh2MltpXSk7XHJcbiAgICAgICAgICAgIGlmIChudW0xID4gbnVtMikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIDE7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobnVtMSA8IG51bTIpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiAtMTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOWIneWni+WMllxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgaW5pdCgpIHsgfVxyXG5cclxuICAgIHB1YmxpYyBvbkV2ZW50cygpIHtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnNob3dCYW5uZXIsIHRoaXMuc2hvd0Jhbm5lciwgdGhpcyk7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLm9uKEV2ZW50VHlwZS5TREtFdmVudC5oaWRlQmFubmVyLCB0aGlzLnJlbW92ZUJhbm5lciwgdGhpcyk7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLm9uKEV2ZW50VHlwZS5TREtFdmVudC5zaG93VmlkZW8sIHRoaXMuc2hvd1ZpZGVvLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnN0YXJ0UmVjb3JkLCB0aGlzLnN0YXJ0UmVjb3JkLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnBhdXNlUmVjb3JkLCB0aGlzLnBhdXNlUmVjb3JkLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnJlc3VtZVJlY29yZCwgdGhpcy5yZXN1bWVSZWNvcmQsIHRoaXMpO1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuU0RLRXZlbnQuc3RvcFJlY29yZCwgdGhpcy5zdG9wUmVjb3JkLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnNoYXJlUmVjb3JkLCB0aGlzLnNoYXJlUmVjb3JkLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnNob3dNc2csIHRoaXMuc2hvd01lc3NhZ2UsIHRoaXMpO1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuU0RLRXZlbnQuc2hvd0luc2VydEFkLCB0aGlzLnNob3dJbnRlcnN0aXRpYWxBZCwgdGhpcyk7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLm9uKEV2ZW50VHlwZS5TREtFdmVudC5uYXZpZ2F0ZVRvTWluaVByb2dyYW0sIHRoaXMubmF2aWdhdGVUb01pbmlQcm9ncmFtLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnZpYnJhdGVMb25nLCB0aGlzLm9uVmlicmF0ZUxvbmcsIHRoaXMpO1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuU0RLRXZlbnQudmlicmF0ZVNob3J0LCB0aGlzLm9uVmlicmF0ZVNob3J0LCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnNob3csIHRoaXMub25TaG93LCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LmhpZGUsIHRoaXMub25IaWRlLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnNob3dJbnNlcnRCeVBhdXNlTGV2ZWwsIHRoaXMuc2hvd0luc2VydEFkQnlQYXVzZUxldmVsLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnRyaWdnZXJHQywgdGhpcy50cmlnZ2VyR0MsIHRoaXMpO1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuU0RLRXZlbnQuc2hvd05hdGl2ZUFkLCB0aGlzLnNob3dOYXRpdmVBZCwgdGhpcyk7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLm9uKEV2ZW50VHlwZS5TREtFdmVudC5oaWRlTmF0aXZlQWQsIHRoaXMuaGlkZU5hdGl2ZUFkLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LmhpZGVBbGxOYXRpdmVBZCwgdGhpcy5oaWRlQWxsTmF0aXZlQWQsIHRoaXMpO1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuU0RLRXZlbnQucXVpY2tTaG93TmF0aXZlQWQsIHRoaXMucXVpY2tTaG93TmF0aXZlQWQsIHRoaXMpO1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuU0RLRXZlbnQucXVpY2tIaWRlTmF0aXZlQWQsIHRoaXMucXVpY2tIaWRlTmF0aXZlQWQsIHRoaXMpO1xyXG5cclxuXHJcbiAgICAgICAgLy9xceW5s+WPsOWKn+iDve+8mlxyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuU0RLRXZlbnQuc2hvd0FwcEJveCwgdGhpcy5zaG93QXBwQm94LCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LnNob3dCbG9ja0FkLCB0aGlzLnNob3dCbG9ja0FkLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlNES0V2ZW50LmFkZENvbG9yU2lnbiwgdGhpcy5hZGRDb2xvclNpZ24sIHRoaXMpO1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuU0RLRXZlbnQuc3Vic2NyaWJlTXNnLCB0aGlzLnN1YnNjcmliZU1zZywgdGhpcyk7XHJcblxyXG4gICAgfVxyXG4gICAgcHVibGljIHRyaWdnZXJHQygpIHsgfVxyXG5cclxuICAgIC8qKuaaguWBnOa4uOaIj+aXtuaYvuekuuaPkuWxj++8jOaPkuWxj+aYvuekuuWksei0peaXtuS4jeaYvuekumJhbm5lciAqL1xyXG4gICAgcHJvdGVjdGVkIHNob3dJbnNlcnRBZEJ5UGF1c2VMZXZlbCgpIHtcclxuICAgICAgICB0aGlzLnNob3dJbnRlcnN0aXRpYWxBZChmYWxzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy/lub/lkYrorrDlvZVcclxuICAgIHB1YmxpYyBsb2FkUmVjb3JkKCkge1xyXG4gICAgICAgIGxldCBkYXRhID0ge1xyXG4gICAgICAgICAgICB2aWRlbzogbnVsbCxcclxuICAgICAgICAgICAgYmFubmVyOiBudWxsLFxyXG4gICAgICAgICAgICBpbnNlcnQ6IG51bGwsXHJcbiAgICAgICAgICAgIHJlY29yZFZpZGVvRGF0YTogbnVsbCxcclxuICAgICAgICAgICAgdGltZTogMCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCByZWNvcmQgPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJBZFJlY29yZFwiKTtcclxuICAgICAgICBpZiAoISFyZWNvcmQpIHtcclxuICAgICAgICAgICAgbGV0IGQgPSBKU09OLnBhcnNlKHJlY29yZCk7XHJcbiAgICAgICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgICAgICBsZXQgb2xkID0gbmV3IERhdGUoZC50aW1lKTtcclxuICAgICAgICAgICAgaWYgKG5vdy5nZXRNb250aCgpID09IG9sZC5nZXRNb250aCgpICYmIG5vdy5nZXREYXRlKCkgPT0gb2xkLmdldERhdGUoKSkge1xyXG4gICAgICAgICAgICAgICAgZGF0YSA9IGQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5iYW5uZXJSZWNvcmQgPSBuZXcgQWRSZWNvcmQoZGF0YS5iYW5uZXIpO1xyXG4gICAgICAgIHRoaXMudmlkZW9SZWNvcmQgPSBuZXcgQWRSZWNvcmQoZGF0YS52aWRlbyk7XHJcbiAgICAgICAgdGhpcy5pbnNlcnRBZFJlY29yZCA9IG5ldyBBZFJlY29yZChkYXRhLmluc2VydCk7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRWaWRlb0RhdGEgPSBuZXcgUmVjb3JkVmlkZW9EYXRhKGRhdGEucmVjb3JkVmlkZW9EYXRhKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzYXZlUmVjb3JkKCkge1xyXG4gICAgICAgIGxldCBkYXRhID0ge1xyXG4gICAgICAgICAgICB2aWRlbzogdGhpcy52aWRlb1JlY29yZCxcclxuICAgICAgICAgICAgYmFubmVyOiB0aGlzLmJhbm5lclJlY29yZCxcclxuICAgICAgICAgICAgaW5zZXJ0OiB0aGlzLmluc2VydEFkUmVjb3JkLFxyXG4gICAgICAgICAgICByZWNvcmRWaWRlb0RhdGE6IHRoaXMucmVjb3JkVmlkZW9EYXRhLFxyXG4gICAgICAgICAgICB0aW1lOiBEYXRlLm5vdygpLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiQWRSZWNvcmRcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5b2V5bGPKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8v5byA5aeL5b2V5bGP77yI5aS05p2h77yJXHJcbiAgICBwcm90ZWN0ZWQgc3RhcnRSZWNvcmQoKSB7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRWaWRlbyhcInN0YXJ0XCIpO1xyXG4gICAgICAgIHRoaXMucmVjb3JkVmlkZW9EYXRhLm9uU3RhcnQoKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBwYXVzZVJlY29yZCgpIHtcclxuICAgICAgICB0aGlzLnJlY29yZFZpZGVvKFwicGF1c2VcIik7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgcmVzdW1lUmVjb3JkKCkge1xyXG4gICAgICAgIHRoaXMucmVjb3JkVmlkZW8oXCJyZXN1bWVcIik7XHJcbiAgICB9XHJcbiAgICAvL+WBnOatouW9leWxj++8iOWktOadoe+8iVxyXG4gICAgcHJvdGVjdGVkIHN0b3BSZWNvcmQoKSB7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRWaWRlb0RhdGEub25FbmQoKTtcclxuICAgICAgICB0aGlzLnJlY29yZFZpZGVvKFwic3RvcFwiKTtcclxuICAgIH1cclxuICAgIC8v5YiG5Lqr5b2V5bGP77yI5aS05p2h77yJXHJcbiAgICBwcm90ZWN0ZWQgc2hhcmVSZWNvcmQoc3VjY2VzczogRnVuY3Rpb24sIGZhaWw6IEZ1bmN0aW9uID0gbnVsbCkge1xyXG4gICAgICAgIHRoaXMuc2hhcmVSZWNvcmRWaWRlbyhzdWNjZXNzLCBmYWlsKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKuinhumikeW5v+WRiioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwcm90ZWN0ZWQgdmlkZW9BZDogYW55O1xyXG4gICAgcHJvdGVjdGVkIHZpZGVvUmVjb3JkOiBBZFJlY29yZCA9IG51bGw7XHJcbiAgICAvKipcclxuICAgICAqIOinhumikeW5v+WRilxyXG4gICAgICogQHBhcmFtIHN1Y2Nlc3MgICDlub/lkYrop4LnnIvlrozmr5XnmoTlm57osINcclxuICAgICAqIEBwYXJhbSBxdWl0ICAgICAg5Lit6YCU6YCA5Ye65bm/5ZGK6KeC55yL55qE5Zue6LCDXHJcbiAgICAgKiBAcGFyYW0gZmFpbCAgICAgIOW5v+WRiuWKoOi9veWksei0peeahOWbnuiwg1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2hvd1ZpZGVvKHN1Y2Nlc3M6IEZ1bmN0aW9uIHwge1xyXG4gICAgICAgIHN1Y2Nlc3M6IEZ1bmN0aW9uLFxyXG4gICAgICAgIHF1aXQ/OiBGdW5jdGlvbixcclxuICAgICAgICBmYWlsPzogRnVuY3Rpb24sXHJcbiAgICAgICAgcGFnZT86IG51bWJlcixcclxuICAgICAgICBiYXR0bGU/OiBudW1iZXIsXHJcbiAgICAgICAgdmlkZW9OYW1lPzogdHlwZW9mIEdsb2JhbEVudW0uVmlkZW9OYW1lLFxyXG4gICAgfSwgcXVpdD86IEZ1bmN0aW9uLCBmYWlsPzogRnVuY3Rpb24sIHZpZGVvTmFtZT86IHR5cGVvZiBHbG9iYWxFbnVtLlZpZGVvTmFtZSkge1xyXG4gICAgICAgIHRoaXMudmlkZW9Ub25nSmkgPSBudWxsO1xyXG4gICAgICAgIGlmICghdGhpcy5jYW5BcGlVc2VWaWRlbygpKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygc3VjY2VzcyA9PT0gXCJvYmplY3RcIikge1xyXG4gICAgICAgICAgICAgICAgaWYgKCEhc3VjY2Vzcy5wYWdlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlRvbmdKaS52aWRlbywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBzdWNjZXNzLnBhZ2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1YlR5cGU6IEdsb2JhbEVudW0uVmlkZW9TdWJUeXBlLnZpZGVvRmFpbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmF0dGxlOiBzdWNjZXNzLmJhdHRsZVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKCEhc3VjY2Vzcy5mYWlsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3VjY2Vzcy5mYWlsKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoISFmYWlsKSB7XHJcbiAgICAgICAgICAgICAgICBmYWlsKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnJlc2V0VmlkZW9DYigpO1xyXG4gICAgICAgIGlmICh0eXBlb2Ygc3VjY2VzcyA9PT0gXCJvYmplY3RcIikge1xyXG4gICAgICAgICAgICB0aGlzLnZpZGVvU3VjY2VzcyA9IHN1Y2Nlc3Muc3VjY2VzcztcclxuICAgICAgICAgICAgdGhpcy52aWRlb1F1aXQgPSBzdWNjZXNzLnF1aXQ7XHJcbiAgICAgICAgICAgIHRoaXMudmlkZW9GYWlsID0gc3VjY2Vzcy5mYWlsO1xyXG4gICAgICAgICAgICBpZiAodW5kZWZpbmVkICE9PSBzdWNjZXNzLnBhZ2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudmlkZW9Ub25nSmkgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogc3VjY2Vzcy5wYWdlLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhdHRsZTogc3VjY2Vzcy5iYXR0bGUsXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdmlkZW9OYW1lID0gc3VjY2Vzcy52aWRlb05hbWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy52aWRlb1N1Y2Nlc3MgPSBzdWNjZXNzO1xyXG4gICAgICAgICAgICB0aGlzLnZpZGVvUXVpdCA9IHF1aXQ7XHJcbiAgICAgICAgICAgIHRoaXMudmlkZW9GYWlsID0gZmFpbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCF0aGlzLnZpZGVvRmFpbCkge1xyXG4gICAgICAgICAgICB0aGlzLnZpZGVvRmFpbCA9IHRoaXMudGlwVmlkZW9GYWlsLmJpbmQodGhpcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuc2VuZFZpZGVvVG9uZ0ppKEdsb2JhbEVudW0uVmlkZW9TdWJUeXBlLmNsaWNrQnRuVmlkZW8pO1xyXG4gICAgICAgIHRoaXMub25WaWRlb1N0YXJ0KCk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmdldFZpZGVvQWRVbml0SWQoKSkge1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KHRoaXMub25WaWRlb1N1Y2Nlc3MuYmluZCh0aGlzKSwgMCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93VmlkZW9BZCh2aWRlb05hbWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKuinhumikeW5v+WRiuW8gOWni+aSreaUvuaXtu+8jOWkhOeQhuS4jua4uOaIj+mAu+i+keebuOWFs+eahOS6i+S7tiAqL1xyXG4gICAgcHJvdGVjdGVkIG9uVmlkZW9TdGFydCgpIHtcclxuICAgICAgICBFdmVudE1hbmFnZXIuZW1pdChFdmVudFR5cGUuQXVkaW9FdmVudC5wYXVzZSk7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQucGF1c2VMZXZlbCk7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuc2hvd1RvdWNoTWFzayk7XHJcbiAgICB9XHJcbiAgICAvKirop4bpopHlub/lkYrmkq3mlL7nu5PmnZ/miJbliqDovb3lpLHotKXlkI7vvIzlpITnkIbkuI7muLjmiI/pgLvovpHnm7jlhbPnmoTkuovku7YgKi9cclxuICAgIHByb3RlY3RlZCBvblZpZGVvRW5kKCkge1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnJlc3VtZSk7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQucmVzdW1lTGV2ZWwpO1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmhpZGVUb3VjaE1hc2spO1xyXG4gICAgfVxyXG4gICAgLyoq6IO95ZCm5L2/55SoYXBp77yadmlkZW8g77yM5a2Q57G75a6e546wICovXHJcbiAgICBwcm90ZWN0ZWQgY2FuQXBpVXNlVmlkZW8oKSB7IHJldHVybiB0cnVlOyB9XHJcbiAgICBwcm90ZWN0ZWQgdGlwVmlkZW9GYWlsKCkge1xyXG4gICAgICAgIHRoaXMuc2hvd01lc3NhZ2UoXCLop4bpopHliqDovb3lpLHotKXvvIzor7fnqI3lkI7lho3or5V+XCIpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHNob3dWaWRlb0FkKHZpZGVvTmFtZT86IHR5cGVvZiBHbG9iYWxFbnVtLlZpZGVvTmFtZSkge1xyXG4gICAgICAgIHRoaXMub25WaWRlb1N1Y2Nlc3MoKTtcclxuICAgIH1cclxuICAgIC8qKuiOt+WPluinhumikeW5v+WRimlkICovXHJcbiAgICBwcm90ZWN0ZWQgZ2V0VmlkZW9BZFVuaXRJZCh2aWRlb05hbWU/OiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICghR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy52aWRlbykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuW5v+WRiuW8gOWFs+acquaJk+W8gFwiKTtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy52aWRlb0FkVW5pdElkIHx8ICFHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLnZpZGVvQWRVbml0SWRbMF0pIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLlub/lkYrlj4LmlbDmnKrloavlhplcIik7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSB2aWRlb05hbWUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlkZW9BZFVuaXRJZFswXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHZpZGVvTmFtZSA+PSBHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLnZpZGVvQWRVbml0SWQubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLnZpZGVvQWRVbml0SWRbMF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLnZpZGVvQWRVbml0SWRbdmlkZW9OYW1lXTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBvblZpZGVvU2hvdygpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuinhumikeW5v+WRiuWxleekuuaIkOWKn1wiKTtcclxuICAgICAgICB0aGlzLnZpZGVvUmVjb3JkLm9uU2hvdygpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uVmlkZW9IaWRlKCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi6KeG6aKR5bm/5ZGK5pyq5pKt5pS+5a6M5Y2z6KKr5YWz6ZetXCIpO1xyXG4gICAgICAgIHRoaXMudmlkZW9SZWNvcmQub25IaWRlKCk7XHJcbiAgICB9XHJcbiAgICAvKirop4bpopHlub/lkYrop4LnnIvlrozmr5Xlm57osIMgKi9cclxuICAgIHByb3RlY3RlZCB2aWRlb1N1Y2Nlc3M6IEZ1bmN0aW9uO1xyXG4gICAgLyoq6KeG6aKR5bm/5ZGK5Yqg6L295aSx6LSl5Zue6LCDICovXHJcbiAgICBwcm90ZWN0ZWQgdmlkZW9GYWlsOiBGdW5jdGlvbjtcclxuICAgIC8qKuinhumikeW5v+WRiuS4remAlOmAgOWHuuWbnuiwgyAqL1xyXG4gICAgcHJvdGVjdGVkIHZpZGVvUXVpdDogRnVuY3Rpb247XHJcbiAgICAvKirmlbDmja7liIbmnpDlt6Xlhbfkvb/nlKjnmoTmlbDmja4gKi9cclxuICAgIHByb3RlY3RlZCB2aWRlb1RvbmdKaTogeyB0eXBlOiBudW1iZXIsIGJhdHRsZT86IG51bWJlciB9ID0gbnVsbDtcclxuICAgIHByb3RlY3RlZCBvblZpZGVvU3VjY2VzcygpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuinhumikeW5v+WRiuingueci+aIkOWKn++8gVwiKTtcclxuICAgICAgICB0aGlzLnNlbmRWaWRlb1RvbmdKaShHbG9iYWxFbnVtLlZpZGVvU3ViVHlwZS52aWRlb1N1Yyk7XHJcbiAgICAgICAgdGhpcy5vblZpZGVvRW5kKCk7XHJcbiAgICAgICAgbGV0IGNiID0gdGhpcy52aWRlb1N1Y2Nlc3M7XHJcbiAgICAgICAgdGhpcy5yZXNldFZpZGVvQ2IoKTtcclxuICAgICAgICBpZiAoISFjYikge1xyXG4gICAgICAgICAgICBjYigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBvblZpZGVvRmFpbChlcnI/OiBhbnkpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuinhumikeW5v+WRiuWKoOi9veWHuumUmSAgXCIsIGVycik7XHJcbiAgICAgICAgdGhpcy5zZW5kVmlkZW9Ub25nSmkoR2xvYmFsRW51bS5WaWRlb1N1YlR5cGUudmlkZW9GYWlsKTtcclxuICAgICAgICB0aGlzLm9uVmlkZW9FbmQoKTtcclxuICAgICAgICBsZXQgY2IgPSB0aGlzLnZpZGVvRmFpbDtcclxuICAgICAgICB0aGlzLnJlc2V0VmlkZW9DYigpO1xyXG4gICAgICAgIGlmICghIWNiKSB7XHJcbiAgICAgICAgICAgIGNiKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uVmlkZW9RdWl0KCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi6KeG6aKR5bm/5ZGK6KeC55yL5pyq5a6M5oiQXCIpO1xyXG4gICAgICAgIHRoaXMuc2VuZFZpZGVvVG9uZ0ppKEdsb2JhbEVudW0uVmlkZW9TdWJUeXBlLnZpZGVvUXVpdCk7XHJcbiAgICAgICAgdGhpcy5vblZpZGVvRW5kKCk7XHJcbiAgICAgICAgbGV0IGNiID0gdGhpcy52aWRlb1F1aXQ7XHJcbiAgICAgICAgdGhpcy5yZXNldFZpZGVvQ2IoKTtcclxuICAgICAgICBpZiAoISFjYikge1xyXG4gICAgICAgICAgICBjYigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKuWPkemAgeinhumikeaVsOaNrui/m+ihjOe7n+iuoSAqL1xyXG4gICAgcHJvdGVjdGVkIHNlbmRWaWRlb1RvbmdKaShzdWJUeXBlOiBudW1iZXIpIHtcclxuICAgICAgICBpZiAoISF0aGlzLnZpZGVvVG9uZ0ppKSB7XHJcbiAgICAgICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5Ub25nSmkudmlkZW8sIHtcclxuICAgICAgICAgICAgICAgIHR5cGU6IHRoaXMudmlkZW9Ub25nSmkudHlwZSxcclxuICAgICAgICAgICAgICAgIHN1YlR5cGU6IHN1YlR5cGUsXHJcbiAgICAgICAgICAgICAgICBiYXR0bGU6IHRoaXMudmlkZW9Ub25nSmkuYmF0dGxlLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgcmVzZXRWaWRlb0NiKCkge1xyXG4gICAgICAgIHRoaXMudmlkZW9TdWNjZXNzID0gbnVsbDtcclxuICAgICAgICB0aGlzLnZpZGVvUXVpdCA9IG51bGw7XHJcbiAgICAgICAgdGhpcy52aWRlb0ZhaWwgPSBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqYmFubmVyKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByb3RlY3RlZCBiYW5uZXJSZWNvcmQ6IEFkUmVjb3JkID0gbnVsbDtcclxuICAgIC8qKuW9k+WJjeaYr+WQpuaYvuekuuS6hmJhbm5lcijpg6jliIblubPlj7DlhbPpl61iYW5uZXLml6Dlm57osIMpICovXHJcbiAgICBwcm90ZWN0ZWQgYmFubmVyU2hvd2luZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHNob3dCYW5uZXIoKSB7IH1cclxuICAgIC8qKuiDveWQpuS9v+eUqGFwae+8mmJhbm5lciDvvIzlrZDnsbvlrp7njrAgKi9cclxuICAgIHByb3RlY3RlZCBjYW5BcGlVc2VCYW5uZXIoKSB7IHJldHVybiB0cnVlOyB9XHJcbiAgICBwdWJsaWMgcmVtb3ZlQmFubmVyKCkgeyB9XHJcbiAgICBwcm90ZWN0ZWQgZ2V0QmFubmVySWQoKSB7XHJcbiAgICAgICAgaWYgKCFHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLmJhbm5lcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImJhbm5lcuW8gOWFs+acquaJk+W8gFwiKTtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5CYW5uZXJBZFVuaXRJZCB8fCAhR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5CYW5uZXJBZFVuaXRJZFswXSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImJhbm5lciBJRCDmnKrloavlhplcIik7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5CYW5uZXJBZFVuaXRJZFswXTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBvbkJhbm5lclNob3coKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJiYW5uZXIg5pi+56S65oiQ5YqfXCIpO1xyXG4gICAgICAgIHRoaXMuYmFubmVyUmVjb3JkLm9uU2hvdygpO1xyXG4gICAgICAgIHRoaXMuYmFubmVyU2hvd2luZyA9IHRydWU7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlNES0V2ZW50LnNob3dCYW5uZXJGaW5pc2gpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uQmFubmVySGlkZSgpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImJhbm5lciDlub/lkYrpmpDol49cIik7XHJcbiAgICAgICAgdGhpcy5iYW5uZXJSZWNvcmQub25IaWRlKCk7XHJcbiAgICAgICAgdGhpcy5iYW5uZXJTaG93aW5nID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgb25CYW5uZXJFcnIoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2Jhbm5lciDmmL7npLrlpLHotKU6JywgSlNPTi5zdHJpbmdpZnkoZXJyKSk7XHJcbiAgICAgICAgdGhpcy5iYW5uZXJSZWNvcmQuaXNTaG93aW5nID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKirmj5LlsY8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHJvdGVjdGVkIGluc2VydEFkUmVjb3JkOiBBZFJlY29yZCA9IG51bGw7XHJcbiAgICAvKipcclxuICAgICAqIOaPkuWxj+W5v+WRilxyXG4gICAgICogQHBhcmFtIGJhbm5lciAgICDmj5LlsY/mmL7npLrlpLHotKXml7bmmK/lkKbmmL7npLpiYW5uZXJcclxuICAgICAqL1xyXG4gICAgcHVibGljIHNob3dJbnRlcnN0aXRpYWxBZChiYW5uZXI/OiBib29sZWFuKSB7IH1cclxuICAgIC8qKuiDveWQpuS9v+eUqGFwae+8mmluc2VydCDvvIzlrZDnsbvlrp7njrAgKi9cclxuICAgIHByb3RlY3RlZCBjYW5BcGlVc2VJbnNlcnQoKSB7IHJldHVybiB0cnVlOyB9XHJcbiAgICAvKirojrflj5bmj5LlsY/lub/lkYppZCAqL1xyXG4gICAgcHJvdGVjdGVkIGdldEluc2VydEFkVW5pdElkKCk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKCFHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLmludGVyc3RpdGlhbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaPkuWxj+W5v+WRiuW8gOWFs+acquaJk+W8gFwiKTtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5JbnRlcnN0aXRpYWxBZFVuaXRJZCB8fCAhR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5JbnRlcnN0aXRpYWxBZFVuaXRJZFswXSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaPkuWxj+W5v+WRiuWPguaVsOacquWhq+WGmVwiKTtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLkludGVyc3RpdGlhbEFkVW5pdElkWzBdO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uSW5zZXJ0U2hvdygpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuaPkuWxj+aYvuekuuaIkOWKn1wiKTtcclxuICAgICAgICB0aGlzLmluc2VydEFkUmVjb3JkLm9uU2hvdygpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uSW5zZXJ0SGlkZSgpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuWFs+mXreaPkuWxj1wiKTtcclxuICAgICAgICB0aGlzLmluc2VydEFkUmVjb3JkLm9uSGlkZSgpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIG9uSW5zZXJ0RXJyKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi5o+S5bGP5bm/5ZGK5Yqg6L295aSx6LSl77yaXCIgKyBKU09OLnN0cmluZ2lmeShlcnIpKTtcclxuICAgICAgICB0aGlzLmluc2VydEFkUmVjb3JkLmlzU2hvd2luZyA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgLyoq5o+S5bGP5pi+56S65aSx6LSl5pe277yM5piv5ZCm5L2/55SoYmFubmVy5Luj5pu/ICovXHJcbiAgICBwcm90ZWN0ZWQgdXNlQmFubmVySW5zdGVhZEluc2VydDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJvdGVjdGVkIHNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCkge1xyXG4gICAgICAgIGlmICh0aGlzLnVzZUJhbm5lckluc3RlYWRJbnNlcnQpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLmmL7npLpiYW5uZXLku6Pmm7/mj5LlsY9cIik7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd0Jhbm5lcigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnVzZUJhbm5lckluc3RlYWRJbnNlcnQgPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKumch+WKqCoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKirnn63pnIfliqggKi9cclxuICAgIHB1YmxpYyBvblZpYnJhdGVTaG9ydCgpIHtcclxuICAgICAgICBpZiAoIUdhbWVDb25maWcuZHJpdmVDb25maWcudmlicmF0ZSkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMudmlicmF0ZVNob3J0KCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgdmlicmF0ZVNob3J0KCkgeyB9XHJcbiAgICAvKirplb/pnIfliqggKi9cclxuICAgIHB1YmxpYyBvblZpYnJhdGVMb25nKCkge1xyXG4gICAgICAgIGlmICghR2FtZUNvbmZpZy5kcml2ZUNvbmZpZy52aWJyYXRlKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy52aWJyYXRlTG9uZygpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHZpYnJhdGVMb25nKCkgeyB9XHJcblxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5YiG5LqrKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8qKuaXoOa/gOWKseWIhuS6qyYm5bim5Y+C5YiG5LqrICovXHJcbiAgICBwdWJsaWMgc2hhcmVBcHBNZXNzYWdlKHF1ZXJ5OiBzdHJpbmcgPSAnJykgeyB9XHJcbiAgICAvKirmv4DlirHliIbkuqsmJuW4puWPguWIhuS6qyAqL1xyXG4gICAgcHVibGljIHNoYXJlVG9BbnlPbmUoc3VjY2VzczogRnVuY3Rpb24sIGZhaWw/OiBGdW5jdGlvbiwgcXVlcnk6IHN0cmluZyA9ICcnKSB7IHN1Y2Nlc3MoKSB9XHJcblxyXG4gICAgLyoq5by55Ye65raI5oGvICovXHJcbiAgICBwdWJsaWMgc2hvd01lc3NhZ2UobXNnOiBzdHJpbmcsIGljb246IHN0cmluZyA9ICdub25lJykge1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LnNob3dUaXAsIG1zZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHJlY29yZFZpZGVvRGF0YTogUmVjb3JkVmlkZW9EYXRhID0gbnVsbDtcclxuICAgIC8qKuW9leWxj+WKn+iDvSAqL1xyXG4gICAgcHVibGljIHJlY29yZFZpZGVvKHR5cGU6IHN0cmluZyA9ICdzdGFydCcpIHsgfVxyXG4gICAgLyoq5b2V5bGP5YiG5LqrICovXHJcbiAgICBwdWJsaWMgc2hhcmVSZWNvcmRWaWRlbyhzdWNjZXNzOiBGdW5jdGlvbiwgZmFpbD86IEZ1bmN0aW9uKSB7IH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKui3s+i9rCoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKirot7PovazliLDlhbbku5blsI/muLjmiI8gKi9cclxuICAgIHB1YmxpYyBuYXZpZ2F0ZVRvTWluaVByb2dyYW0oZGF0YTogYW55KSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCLot7PovazlsI/muLjmiI/vvIzlrZDnsbvlrp7njrDvvIxkYXRhOlwiLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICAvKirmuLjmiI/liIfliLDlkI7lj7AgKi9cclxuICAgIHB1YmxpYyBvbkhpZGUoKSB7IH1cclxuICAgIC8qKuS7juWQjuWPsOWbnuWIsOa4uOaIjyAqL1xyXG4gICAgcHVibGljIG9uU2hvdygpIHsgfVxyXG5cclxuICAgIC8vUVHlubPlj7Dlip/og73vvJpcclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKuebkuWtkOW5v+WRiioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgc2hvd0FwcEJveCgpIHsgfVxyXG4gICAgcHJvdGVjdGVkIGdldEFwcEJveElkKCkge1xyXG4gICAgICAgIGlmICghR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5hcHBCb3hVbml0SWQgfHwgIUdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcuYXBwQm94VW5pdElkWzBdKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi55uS5a2Q5bm/5ZGK5Y+C5pWw5pyq5aGr5YaZXCIpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcuYXBwQm94VW5pdElkWzBdO1xyXG4gICAgfVxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKirnp6/mnKjlub/lkYoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHVibGljIHNob3dCbG9ja0FkKCkgeyB9XHJcbiAgICBwcm90ZWN0ZWQgZ2V0QmxvY2tBZElkKCkge1xyXG4gICAgICAgIGlmICghR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5ibG9ja0FkVW5pdElkIHx8ICFHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLmJsb2NrQWRVbml0SWRbMF0pIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLnp6/mnKjlub/lkYrlj4LmlbDmnKrloavlhplcIik7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5ibG9ja0FkVW5pdElkWzBdO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5b2p562+KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHB1YmxpYyBhZGRDb2xvclNpZ24oZGF0YT86IGFueSkgeyB9XHJcbiAgICBwdWJsaWMgc3Vic2NyaWJlTXNnKGRhdGE/OiBhbnkpIHsgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5Y6f55Sf5bm/5ZGKKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8qKuWOn+eUn+W5v+WRimlkICovXHJcbiAgICBwdWJsaWMgZ2V0TmF0aXZlQWRJZCgpIHtcclxuICAgICAgICBpZiAoIUdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcubmF0aXZlQWRVbml0SWRbMF0pIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLljp/nlJ/lub/lkYrlj4LmlbDmnKrloavlhplcIik7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy5uYXRpdmVBZFVuaXRJZFswXTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXRBbGxOYXRpdmVBZElkcygpIHtcclxuICAgICAgICBpZiAoIUdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcubmF0aXZlQWRVbml0SWRbMF0pIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLljp/nlJ/lub/lkYrlj4LmlbDmnKrloavlhplcIik7XHJcbiAgICAgICAgICAgIHJldHVybiBbXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcubmF0aXZlQWRVbml0SWQ7XHJcbiAgICB9XHJcbiAgICAvKirmmL7npLrljp/nlJ/lub/lkYogKi9cclxuICAgIHB1YmxpYyBzaG93TmF0aXZlQWQoZGF0YT8pIHsgfVxyXG4gICAgcHVibGljIGhpZGVOYXRpdmVBZChkYXRhPykgeyB9XHJcbiAgICBwdWJsaWMgaGlkZUFsbE5hdGl2ZUFkKGRhdGE/KSB7IH1cclxuICAgIHB1YmxpYyBxdWlja1Nob3dOYXRpdmVBZChkYXRhPykgeyB9XHJcbiAgICBwdWJsaWMgcXVpY2tIaWRlTmF0aXZlQWQoZGF0YT8pIHsgfVxyXG59XHJcblxyXG5jbGFzcyBBZFJlY29yZCB7XHJcbiAgICAvKirmnKzmuLjmiI/lvZPlpKnmmL7npLrnmoTmgLvmrKHmlbAgKi9cclxuICAgIHB1YmxpYyBkYXlTaG93Q291bnQ6IG51bWJlcjtcclxuICAgIC8qKuW9k+WkqeeUqOaIt+eCueWHu+WFs+mXreeahOaAu+asoeaVsCAqL1xyXG4gICAgcHVibGljIGRheUhpZGVDb3VudDogbnVtYmVyO1xyXG4gICAgLyoq5LuO6L+b5YWl5ri45oiP5byA5aeL5bGV56S655qE5oC75qyh5pWwICovXHJcbiAgICBwdWJsaWMgZ2FtZVNob3dDb3VudDogbnVtYmVyO1xyXG4gICAgLyoq6L+b5YWl5ri45oiP5byA5aeL55So5oi354K55Ye75YWz6Zet55qE5oC75qyh5pWwICovXHJcbiAgICBwdWJsaWMgZ2FtZUhpZGVDb3VudDogbnVtYmVyO1xyXG4gICAgLyoq5LiK5LiA5qyh5bGV56S655qE5pe26Ze05oizICovXHJcbiAgICBwdWJsaWMgcHJlU2hvd1RpbWU6IG51bWJlcjtcclxuICAgIC8qKuS4iuS4gOasoeWFs+mXreeahOaXtumXtOaIsyAqL1xyXG4gICAgcHVibGljIHByZUhpZGVUaW1lOiBudW1iZXI7XHJcbiAgICAvKirmmK/lkKbmraPlnKjlsZXnpLogKi9cclxuICAgIHB1YmxpYyBpc1Nob3dpbmc6IGJvb2xlYW47XHJcblxyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKGRhdGEpIHtcclxuICAgICAgICB0aGlzLmlzU2hvd2luZyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuZ2FtZVNob3dDb3VudCA9IDA7XHJcbiAgICAgICAgdGhpcy5nYW1lSGlkZUNvdW50ID0gMDtcclxuICAgICAgICBpZiAoIWRhdGEpIHtcclxuICAgICAgICAgICAgdGhpcy5kYXlTaG93Q291bnQgPSAwO1xyXG4gICAgICAgICAgICB0aGlzLmRheUhpZGVDb3VudCA9IDA7XHJcbiAgICAgICAgICAgIHRoaXMucHJlU2hvd1RpbWUgPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnByZUhpZGVUaW1lID0gMDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmRheVNob3dDb3VudCA9IGRhdGEuZGF5U2hvd0NvdW50O1xyXG4gICAgICAgICAgICB0aGlzLmRheUhpZGVDb3VudCA9IGRhdGEuZGF5SGlkZUNvdW50O1xyXG4gICAgICAgICAgICB0aGlzLnByZVNob3dUaW1lID0gZGF0YS5wcmVTaG93VGltZTtcclxuICAgICAgICAgICAgdGhpcy5wcmVIaWRlVGltZSA9IGRhdGEucHJlSGlkZVRpbWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvblNob3coKSB7XHJcbiAgICAgICAgdGhpcy5pc1Nob3dpbmcgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuZGF5U2hvd0NvdW50Kys7XHJcbiAgICAgICAgdGhpcy5nYW1lU2hvd0NvdW50Kys7XHJcbiAgICAgICAgdGhpcy5wcmVTaG93VGltZSA9IERhdGUubm93KCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgb25IaWRlKCkge1xyXG4gICAgICAgIHRoaXMuaXNTaG93aW5nID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5kYXlIaWRlQ291bnQrKztcclxuICAgICAgICB0aGlzLmdhbWVIaWRlQ291bnQrKztcclxuICAgICAgICB0aGlzLnByZUhpZGVUaW1lID0gRGF0ZS5ub3coKTtcclxuICAgIH1cclxuICAgIC8qKuW9k+WJjeaXtumXtOi3neemu+S4iuS4gOasoeWxleekuueahOaXtumXtOmXtOmalO+8jOWNleS9je+8muenkiAqL1xyXG4gICAgcHVibGljIGdldFNob3dTcGFjZVRpbWUoKSB7XHJcbiAgICAgICAgbGV0IGQgPSBEYXRlLm5vdygpIC0gdGhpcy5wcmVTaG93VGltZTtcclxuICAgICAgICByZXR1cm4gZCAqIDAuMDAxO1xyXG4gICAgfVxyXG4gICAgLyoq5b2T5YmN5pe26Ze06Led56a75LiK5LiA5qyh5YWz6Zet55qE5pe26Ze06Ze06ZqU77yM5Y2V5L2N77ya56eSICovXHJcbiAgICBwdWJsaWMgZ2V0SGlkZVNwYWNlVGltZSgpIHtcclxuICAgICAgICBsZXQgZCA9IERhdGUubm93KCkgLSB0aGlzLnByZUhpZGVUaW1lO1xyXG4gICAgICAgIHJldHVybiBkICogMC4wMDE7XHJcbiAgICB9XHJcblxyXG59XHJcbi8qKuW9leWxj+aVsOaNruiusOW9lSAqL1xyXG5jbGFzcyBSZWNvcmRWaWRlb0RhdGEge1xyXG4gICAgcHVibGljIHN0YXJ0VGltZTogbnVtYmVyO1xyXG4gICAgcHVibGljIGVuZFRpbWU6IG51bWJlcjtcclxuICAgIHB1YmxpYyBnYW1lU2hhcmVDb3VudDogbnVtYmVyO1xyXG4gICAgcHVibGljIGRheVNoYXJlQ291bnQ6IG51bWJlcjtcclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihkYXRhKSB7XHJcbiAgICAgICAgdGhpcy5zdGFydFRpbWUgPSAwO1xyXG4gICAgICAgIHRoaXMuZW5kVGltZSA9IDA7XHJcbiAgICAgICAgdGhpcy5nYW1lU2hhcmVDb3VudCA9IDA7XHJcbiAgICAgICAgaWYgKCEhZGF0YSkge1xyXG4gICAgICAgICAgICB0aGlzLmRheVNoYXJlQ291bnQgPSBkYXRhLmRheVNoYXJlQ291bnQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5kYXlTaGFyZUNvdW50ID0gMDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKirlvZXlsY/lvIDlp4sgKi9cclxuICAgIHB1YmxpYyBvblN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMuc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcclxuICAgICAgICB0aGlzLmVuZFRpbWUgPSBEYXRlLm5vdygpO1xyXG4gICAgfVxyXG4gICAgLyoq5b2V5bGP57uT5p2fICovXHJcbiAgICBwdWJsaWMgb25FbmQoKSB7XHJcbiAgICAgICAgdGhpcy5lbmRUaW1lID0gRGF0ZS5ub3coKTtcclxuICAgIH1cclxuICAgIC8qKuW9leWxj+aXtumVv++8jOWNleS9je+8muenkiAqL1xyXG4gICAgcHVibGljIGdldCB0b3RhbFRpbWUoKSB7XHJcbiAgICAgICAgcmV0dXJuICh0aGlzLmVuZFRpbWUgLSB0aGlzLnN0YXJ0VGltZSkgKiAwLjAwMTtcclxuICAgIH1cclxuICAgIC8qKuWIhuS6q+aIkOWKnyAqL1xyXG4gICAgcHVibGljIG9uU2hhcmUoKSB7XHJcbiAgICAgICAgdGhpcy5nYW1lU2hhcmVDb3VudCsrO1xyXG4gICAgICAgIHRoaXMuZGF5U2hhcmVDb3VudCsrO1xyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICog5omL5py65bmz5Y+w57G75Z6LXHJcbiAqL1xyXG5leHBvcnQgZW51bSBQbGF0Zm9ybSB7XHJcbiAgICAvKirnlLXohJHkuIrosIPor5Xml7bkvb/nlKggKi9cclxuICAgIHBjID0gXCJQQ1wiLFxyXG4gICAgLyoq6Iu55p6cICovXHJcbiAgICBpb3MgPSBcIklPU1wiLFxyXG4gICAgLyoq5a6J5Y2TICovXHJcbiAgICBhbmRyb2lkID0gXCJBTkRST0lEXCIsXHJcbn0iXX0=