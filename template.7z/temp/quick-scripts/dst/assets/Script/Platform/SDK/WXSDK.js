
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/SDK/WXSDK.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c40cdLxs1FA0ZE1thrryygV', 'WXSDK');
// Script/Platform/SDK/WXSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var EventManager_1 = require("../../Common/EventManager");
var WXSDK = /** @class */ (function (_super) {
    __extends(WXSDK, _super);
    function WXSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'wx';
        /**创建新的banner的时间 */
        _this.createBannerTime = 0;
        /**banner加载成功后是否需要立即显示 */
        _this.needShowBanner = false;
        /**banner是否已加载完毕 */
        _this.bannerLoaded = false;
        return _this;
    }
    WXSDK.prototype.init = function () {
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        console.log("系统信息：");
        console.log(JSON.stringify(this.systemInfo));
        // this.api.onShareAppMessage(() => ({}));
        this.api.showShareMenu({ withShareTicket: false });
        this.preCreateBanner();
    };
    WXSDK.prototype.triggerGC = function () {
        this.api.triggerGC();
    };
    //video
    WXSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("视频id获取失败");
            return;
        }
        if (!this.videoAd) {
            this.videoAd = this.api.createRewardedVideoAd({ adUnitId: id });
            this.videoAd.onLoad(function () {
                console.log("视频广告加载完毕");
            });
            this.videoAd.onError(function (err) {
                console.log("视频广告错误：", JSON.stringify(err));
            });
            this.videoAd.onClose(function (res) {
                // 小于 2.1.0 的基础库版本，res 是一个 undefined
                if (res && res.isEnded || res === undefined) {
                    _this.onVideoSuccess();
                }
                else {
                    _this.onVideoQuit();
                    _this.onVideoHide();
                }
            });
        }
        this.videoAd.show().then(this.onVideoShow.bind(this))
            .catch(function (err) {
            _this.videoAd.load()
                .then(function () {
                _this.videoAd.show().then(_this.onVideoShow.bind(_this));
            })
                .catch(_this.onVideoFail.bind(_this));
        });
    };
    /**
     * 打开banner
     */
    WXSDK.prototype.showBanner = function (cb) {
        var _this = this;
        // if (this.insertAdRecord.isShowing) {
        //     console.log("插屏广告正在显示，无法同时显示banner");
        //     this.removeBanner();
        //     return;
        // }
        if (this.bannerShowing)
            return;
        //已经创建了banner：
        if (!!this._bannerAd) {
            //创建的banner已经加载成功，直接显示：
            if (this.bannerLoaded) {
                this._bannerAd.show().then(function () {
                    _this.onBannerShow();
                    _this.bannerShowing = true;
                    if (!!cb) {
                        cb();
                    }
                });
            }
            else {
                //创建的banner还没加载完成时，设置标记，使其在加载完成后显示
                this.needShowBanner = true;
            }
        }
        else {
            //尚未创建banner，则设置标记，创建banner，并使其在加载完成后显示
            this.needShowBanner = true;
            this.preCreateBanner();
        }
    };
    /**预先创建banner，创建的banner在加载完成时，会根据 needShowBanner 确定是否需要立即显示 */
    WXSDK.prototype.preCreateBanner = function () {
        var _this = this;
        var id = this.getBannerId();
        if (!id)
            return null;
        this._bannerAd = this.api.createBannerAd({
            adUnitId: id,
            style: {
                left: 0,
                top: this.systemInfo.screenHeight - 130,
                width: this.systemInfo.screenWidth + 50,
            }
        });
        this._bannerAd.onError(function (err) {
            _this.onBannerErr(err);
            _this.destroyBanner();
        });
        this._bannerAd.onResize(function (res) {
            if (_this.systemInfo.platform == "ios" && !!_this.systemInfo.statusBarHeight && _this.systemInfo.statusBarHeight > 20) {
                _this._bannerAd.style.top = _this.systemInfo.screenHeight - res.height - 20;
            }
            else {
                _this._bannerAd.style.top = _this.systemInfo.screenHeight - res.height;
            }
        });
        this._bannerAd.onLoad(function () {
            _this.bannerLoaded = true;
            if (_this.needShowBanner) {
                _this.showBanner();
                _this.needShowBanner = false;
            }
        });
        this.createBannerTime = Date.now();
        return this._bannerAd;
    };
    /**
     * 关闭广告
     */
    WXSDK.prototype.removeBanner = function () {
        if (this._bannerAd) {
            var t = Date.now();
            if (t - this.createBannerTime > 60000) {
                console.log("距上次显示banner已超过60秒，创建新的banner");
                this.destroyBanner();
                this.preCreateBanner();
            }
            else {
                this._bannerAd.hide();
            }
        }
        this.bannerShowing = false;
        this.needShowBanner = false;
    };
    /**销毁已经创建的banner */
    WXSDK.prototype.destroyBanner = function () {
        if (!!this._bannerAd) {
            this._bannerAd.offLoad();
            this._bannerAd.offError();
            this._bannerAd.offResize();
            this._bannerAd.destroy(); //要先把旧的广告给销毁，不然会导致其监听的事件无法释放，影响性能
            this._bannerAd = null;
        }
        this.bannerLoaded = false;
    };
    //插屏广告
    WXSDK.prototype.showInterstitialAd = function (banner) {
        var _this = this;
        if (banner === void 0) { banner = false; }
        this.useBannerInsteadInsert = banner;
        this.showBannerInsteadInsert();
        var id = this.getInsertAdUnitId();
        if (!id) {
            // this.showBannerInsteadInsert();
            return;
        }
        var version = this.systemInfo.SDKVersion;
        if (this.compareVersion(version, '2.6.0') < 0) {
            console.log('基础库版本过低');
            // this.showBannerInsteadInsert();
            //   // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
            //   wx.showModal({
            //     title: '提示',
            //     content: '当前微信版本过低，无法使用插屏广告，请升级到最新微信版本后重试。'
            //   })
            return;
        }
        var ad = this.api.createInterstitialAd({ adUnitId: id });
        ad.show().then(this.onInsertShow.bind(this));
        ad.onClose(this.onInsertHide.bind(this));
        ad.onError(function (err) {
            _this.onInsertErr(err);
            // this.showBannerInsteadInsert();
        });
    };
    /**
     * 短震动
     */
    WXSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    WXSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    WXSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ""; }
        var index = Math.floor((Math.random() * this.shareTitleArr.length));
        var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
        this.api.shareAppMessage({
            title: "" + this.shareTitleArr[index],
            imageUrl: "" + this.shareImgArr[indeximg],
            query: "" + query,
        });
    };
    /**
     * 激励分享&&带参分享
     */
    WXSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
        if (!GamePlatform_1.default.instance.Config.share) {
            success();
            return;
        }
        this.shareAppMessage(query);
        success();
    };
    /**
     * 消息提示
     */
    WXSDK.prototype.showMessage = function (msg, icon) {
        if (icon === void 0) { icon = 'none'; }
        // this.api.showToast({
        //     title: msg,
        //     duration: 2000,
        //     icon: icon,
        //     success: (res) => { }
        // });
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTip, msg);
    };
    WXSDK.prototype.navigateToMiniProgram = function (data) {
        this.api.navigateToMiniProgram({
            appId: data.gameId,
        });
    };
    return WXSDK;
}(SDK_1.default));
exports.default = WXSDK;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcU0RLXFxXWFNESy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw2QkFBd0I7QUFDeEIsZ0RBQTJDO0FBQzNDLGlFQUE0RDtBQUM1RCwwREFBcUQ7QUFFckQ7SUFBbUMseUJBQUc7SUFBdEM7UUFBQSxxRUF5UEM7UUF4UGEsYUFBTyxHQUFXLElBQUksQ0FBQztRQXdGakMsbUJBQW1CO1FBQ1Qsc0JBQWdCLEdBQVcsQ0FBQyxDQUFDO1FBQ3ZDLHlCQUF5QjtRQUNmLG9CQUFjLEdBQVksS0FBSyxDQUFDO1FBQzFDLG1CQUFtQjtRQUNULGtCQUFZLEdBQVksS0FBSyxDQUFDOztJQTJKNUMsQ0FBQztJQXRQVSxvQkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRWhDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBRTdDLDBDQUEwQztRQUMxQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxFQUFFLGVBQWUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBRW5ELElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU0seUJBQVMsR0FBaEI7UUFDSSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRCxPQUFPO0lBQ0EsMkJBQVcsR0FBbEIsVUFBbUIsU0FBZTtRQUFsQyxpQkFnQ0M7UUEvQkcsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDTCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzdCLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2YsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQ2hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDNUIsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUc7Z0JBQ3JCLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNoRCxDQUFDLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQUMsR0FBRztnQkFDckIsb0NBQW9DO2dCQUNwQyxJQUFJLEdBQUcsSUFBSSxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUU7b0JBQ3pDLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztpQkFDekI7cUJBQU07b0JBQ0gsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUNuQixLQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7aUJBQ3RCO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FDTjtRQUNELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ2hELEtBQUssQ0FBQyxVQUFDLEdBQUc7WUFDUCxLQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRTtpQkFDZCxJQUFJLENBQUM7Z0JBQ0YsS0FBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLENBQUMsQ0FBQztZQUMxRCxDQUFDLENBQUM7aUJBQ0QsS0FBSyxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxDQUFDLENBQUM7UUFDNUMsQ0FBQyxDQUFDLENBQUM7SUFDWCxDQUFDO0lBSUQ7O09BRUc7SUFDSSwwQkFBVSxHQUFqQixVQUFrQixFQUFhO1FBQS9CLGlCQTJCQztRQTFCRyx1Q0FBdUM7UUFDdkMsNENBQTRDO1FBQzVDLDJCQUEyQjtRQUMzQixjQUFjO1FBQ2QsSUFBSTtRQUNKLElBQUksSUFBSSxDQUFDLGFBQWE7WUFBRSxPQUFPO1FBQy9CLGNBQWM7UUFDZCxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2xCLHVCQUF1QjtZQUN2QixJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ25CLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO29CQUN2QixLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7b0JBQ3BCLEtBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO29CQUMxQixJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7d0JBQ04sRUFBRSxFQUFFLENBQUM7cUJBQ1I7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7YUFDTjtpQkFBTTtnQkFDSCxrQ0FBa0M7Z0JBQ2xDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2FBQzlCO1NBQ0o7YUFBTTtZQUNILHVDQUF1QztZQUN2QyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7U0FDMUI7SUFDTCxDQUFDO0lBUUQsOERBQThEO0lBQ3ZELCtCQUFlLEdBQXRCO1FBQUEsaUJBK0JDO1FBOUJHLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsRUFBRTtZQUFFLE9BQU8sSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7WUFDckMsUUFBUSxFQUFFLEVBQUU7WUFDWixLQUFLLEVBQUU7Z0JBQ0gsSUFBSSxFQUFFLENBQUM7Z0JBQ1AsR0FBRyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLEdBQUc7Z0JBQ3ZDLEtBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsR0FBRyxFQUFFO2FBQzFDO1NBQ0osQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBQyxHQUFHO1lBQ3ZCLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsS0FBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsVUFBQSxHQUFHO1lBQ3ZCLElBQUksS0FBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsSUFBSSxLQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxFQUFFLEVBQUU7Z0JBQ2hILEtBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQzthQUM3RTtpQkFBTTtnQkFDSCxLQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQzthQUN4RTtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7WUFDbEIsS0FBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDekIsSUFBSSxLQUFJLENBQUMsY0FBYyxFQUFFO2dCQUNyQixLQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2xCLEtBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO2FBQy9CO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ25DLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUMxQixDQUFDO0lBRUQ7O09BRUc7SUFDSSw0QkFBWSxHQUFuQjtRQUNJLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDbkIsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssRUFBRTtnQkFDbkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO2dCQUM1QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzthQUMxQjtpQkFBTTtnQkFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ3pCO1NBQ0o7UUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUNoQyxDQUFDO0lBQ0QsbUJBQW1CO0lBQ1QsNkJBQWEsR0FBdkI7UUFDSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUMxQixJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQzNCLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxpQ0FBaUM7WUFDM0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7U0FDekI7UUFDRCxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztJQUM5QixDQUFDO0lBRUQsTUFBTTtJQUNDLGtDQUFrQixHQUF6QixVQUEwQixNQUF1QjtRQUFqRCxpQkEwQkM7UUExQnlCLHVCQUFBLEVBQUEsY0FBdUI7UUFDN0MsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQztRQUNyQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUMvQixJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUNsQyxJQUFJLENBQUMsRUFBRSxFQUFFO1lBQ0wsa0NBQWtDO1lBQ2xDLE9BQU87U0FDVjtRQUNELElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO1FBQzNDLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDdkIsa0NBQWtDO1lBQ2xDLHVDQUF1QztZQUN2QyxtQkFBbUI7WUFDbkIsbUJBQW1CO1lBQ25CLGtEQUFrRDtZQUNsRCxPQUFPO1lBQ1AsT0FBTztTQUNWO1FBQ0QsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUM3QyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDekMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUc7WUFDWCxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3RCLGtDQUFrQztRQUN0QyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFHRDs7T0FFRztJQUNJLDRCQUFZLEdBQW5CO1FBQ0ksSUFBSSxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksMkJBQVcsR0FBbEI7UUFDSSxJQUFJLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7WUFDdEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCwrQkFBZSxHQUFmLFVBQWdCLEtBQWtCO1FBQWxCLHNCQUFBLEVBQUEsVUFBa0I7UUFDOUIsSUFBSSxLQUFLLEdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDNUUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDN0UsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7WUFDckIsS0FBSyxFQUFFLEtBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUc7WUFDckMsUUFBUSxFQUFFLEtBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUc7WUFDekMsS0FBSyxFQUFFLEtBQUcsS0FBTztTQUNwQixDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7O09BRUc7SUFDSCw2QkFBYSxHQUFiLFVBQWMsT0FBaUIsRUFBRSxJQUFlLEVBQUUsS0FBa0I7UUFBbEIsc0JBQUEsRUFBQSxVQUFrQjtRQUNoRSxJQUFJLENBQUMsc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNyQyxPQUFPLEVBQUUsQ0FBQztZQUNWLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUIsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQ7O09BRUc7SUFDSSwyQkFBVyxHQUFsQixVQUFtQixHQUFXLEVBQUUsSUFBcUI7UUFBckIscUJBQUEsRUFBQSxhQUFxQjtRQUNqRCx1QkFBdUI7UUFDdkIsa0JBQWtCO1FBQ2xCLHNCQUFzQjtRQUN0QixrQkFBa0I7UUFDbEIsNEJBQTRCO1FBQzVCLE1BQU07UUFDTixzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVNLHFDQUFxQixHQUE1QixVQUE2QixJQUFTO1FBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUM7WUFDM0IsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNO1NBQ3JCLENBQUMsQ0FBQTtJQUNOLENBQUM7SUFDTCxZQUFDO0FBQUQsQ0F6UEEsQUF5UEMsQ0F6UGtDLGFBQUcsR0F5UHJDIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFNESyBmcm9tIFwiLi9TREtcIjtcbmltcG9ydCBHYW1lUGxhdGZvcm0gZnJvbSBcIi4uL0dhbWVQbGF0Zm9ybVwiO1xuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcbmltcG9ydCBFdmVudE1hbmFnZXIgZnJvbSBcIi4uLy4uL0NvbW1vbi9FdmVudE1hbmFnZXJcIjtcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgV1hTREsgZXh0ZW5kcyBTREsge1xuICAgIHByb3RlY3RlZCBhcGlOYW1lOiBzdHJpbmcgPSAnd3gnO1xuXG4gICAgcHVibGljIGluaXQoKSB7XG4gICAgICAgIHRoaXMuYXBpID0gd2luZG93W3RoaXMuYXBpTmFtZV07XG5cbiAgICAgICAgdGhpcy5zeXN0ZW1JbmZvID0gdGhpcy5hcGkuZ2V0U3lzdGVtSW5mb1N5bmMoKTtcbiAgICAgICAgY29uc29sZS5sb2coXCLns7vnu5/kv6Hmga/vvJpcIik7XG4gICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHRoaXMuc3lzdGVtSW5mbykpO1xuXG4gICAgICAgIC8vIHRoaXMuYXBpLm9uU2hhcmVBcHBNZXNzYWdlKCgpID0+ICh7fSkpO1xuICAgICAgICB0aGlzLmFwaS5zaG93U2hhcmVNZW51KHsgd2l0aFNoYXJlVGlja2V0OiBmYWxzZSB9KTtcblxuICAgICAgICB0aGlzLnByZUNyZWF0ZUJhbm5lcigpO1xuICAgIH1cblxuICAgIHB1YmxpYyB0cmlnZ2VyR0MoKSB7XG4gICAgICAgIHRoaXMuYXBpLnRyaWdnZXJHQygpO1xuICAgIH1cblxuICAgIC8vdmlkZW9cbiAgICBwdWJsaWMgc2hvd1ZpZGVvQWQodmlkZW9OYW1lPzogYW55KSB7XG4gICAgICAgIGxldCBpZCA9IHRoaXMuZ2V0VmlkZW9BZFVuaXRJZCh2aWRlb05hbWUpO1xuICAgICAgICBpZiAoIWlkKSB7XG4gICAgICAgICAgICB0aGlzLm9uVmlkZW9GYWlsKFwi6KeG6aKRaWTojrflj5blpLHotKVcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLnZpZGVvQWQpIHtcbiAgICAgICAgICAgIHRoaXMudmlkZW9BZCA9IHRoaXMuYXBpLmNyZWF0ZVJld2FyZGVkVmlkZW9BZCh7IGFkVW5pdElkOiBpZCB9KTtcbiAgICAgICAgICAgIHRoaXMudmlkZW9BZC5vbkxvYWQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6KeG6aKR5bm/5ZGK5Yqg6L295a6M5q+VXCIpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLnZpZGVvQWQub25FcnJvcigoZXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLop4bpopHlub/lkYrplJnor6/vvJpcIiwgSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMudmlkZW9BZC5vbkNsb3NlKChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICAvLyDlsI/kuo4gMi4xLjAg55qE5Z+656GA5bqT54mI5pys77yMcmVzIOaYr+S4gOS4qiB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICBpZiAocmVzICYmIHJlcy5pc0VuZGVkIHx8IHJlcyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb1N1Y2Nlc3MoKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uVmlkZW9RdWl0KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25WaWRlb0hpZGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnZpZGVvQWQuc2hvdygpLnRoZW4odGhpcy5vblZpZGVvU2hvdy5iaW5kKHRoaXMpKVxuICAgICAgICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnZpZGVvQWQubG9hZCgpXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudmlkZW9BZC5zaG93KCkudGhlbih0aGlzLm9uVmlkZW9TaG93LmJpbmQodGhpcykpO1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAuY2F0Y2godGhpcy5vblZpZGVvRmFpbC5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8v5b2T5YmN5bm/5ZGK44CCXG4gICAgcHJvdGVjdGVkIF9iYW5uZXJBZDogYW55O1xuICAgIC8qKlxuICAgICAqIOaJk+W8gGJhbm5lclxuICAgICAqL1xuICAgIHB1YmxpYyBzaG93QmFubmVyKGNiPzogRnVuY3Rpb24pIHtcbiAgICAgICAgLy8gaWYgKHRoaXMuaW5zZXJ0QWRSZWNvcmQuaXNTaG93aW5nKSB7XG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhcIuaPkuWxj+W5v+WRiuato+WcqOaYvuekuu+8jOaXoOazleWQjOaXtuaYvuekumJhbm5lclwiKTtcbiAgICAgICAgLy8gICAgIHRoaXMucmVtb3ZlQmFubmVyKCk7XG4gICAgICAgIC8vICAgICByZXR1cm47XG4gICAgICAgIC8vIH1cbiAgICAgICAgaWYgKHRoaXMuYmFubmVyU2hvd2luZykgcmV0dXJuO1xuICAgICAgICAvL+W3sue7j+WIm+W7uuS6hmJhbm5lcu+8mlxuICAgICAgICBpZiAoISF0aGlzLl9iYW5uZXJBZCkge1xuICAgICAgICAgICAgLy/liJvlu7rnmoRiYW5uZXLlt7Lnu4/liqDovb3miJDlip/vvIznm7TmjqXmmL7npLrvvJpcbiAgICAgICAgICAgIGlmICh0aGlzLmJhbm5lckxvYWRlZCkge1xuICAgICAgICAgICAgICAgIHRoaXMuX2Jhbm5lckFkLnNob3coKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vbkJhbm5lclNob3coKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iYW5uZXJTaG93aW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEhY2IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNiKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy/liJvlu7rnmoRiYW5uZXLov5jmsqHliqDovb3lrozmiJDml7bvvIzorr7nva7moIforrDvvIzkvb/lhbblnKjliqDovb3lrozmiJDlkI7mmL7npLpcbiAgICAgICAgICAgICAgICB0aGlzLm5lZWRTaG93QmFubmVyID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8v5bCa5pyq5Yib5bu6YmFubmVy77yM5YiZ6K6+572u5qCH6K6w77yM5Yib5bu6YmFubmVy77yM5bm25L2/5YW25Zyo5Yqg6L295a6M5oiQ5ZCO5pi+56S6XG4gICAgICAgICAgICB0aGlzLm5lZWRTaG93QmFubmVyID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMucHJlQ3JlYXRlQmFubmVyKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKirliJvlu7rmlrDnmoRiYW5uZXLnmoTml7bpl7QgKi9cbiAgICBwcm90ZWN0ZWQgY3JlYXRlQmFubmVyVGltZTogbnVtYmVyID0gMDtcbiAgICAvKipiYW5uZXLliqDovb3miJDlip/lkI7mmK/lkKbpnIDopoHnq4vljbPmmL7npLogKi9cbiAgICBwcm90ZWN0ZWQgbmVlZFNob3dCYW5uZXI6IGJvb2xlYW4gPSBmYWxzZTtcbiAgICAvKipiYW5uZXLmmK/lkKblt7LliqDovb3lrozmr5UgKi9cbiAgICBwcm90ZWN0ZWQgYmFubmVyTG9hZGVkOiBib29sZWFuID0gZmFsc2U7XG4gICAgLyoq6aKE5YWI5Yib5bu6YmFubmVy77yM5Yib5bu655qEYmFubmVy5Zyo5Yqg6L295a6M5oiQ5pe277yM5Lya5qC55o2uIG5lZWRTaG93QmFubmVyIOehruWumuaYr+WQpumcgOimgeeri+WNs+aYvuekuiAqL1xuICAgIHB1YmxpYyBwcmVDcmVhdGVCYW5uZXIoKSB7XG4gICAgICAgIGxldCBpZCA9IHRoaXMuZ2V0QmFubmVySWQoKTtcbiAgICAgICAgaWYgKCFpZCkgcmV0dXJuIG51bGw7XG4gICAgICAgIHRoaXMuX2Jhbm5lckFkID0gdGhpcy5hcGkuY3JlYXRlQmFubmVyQWQoe1xuICAgICAgICAgICAgYWRVbml0SWQ6IGlkLFxuICAgICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgICAgICBsZWZ0OiAwLFxuICAgICAgICAgICAgICAgIHRvcDogdGhpcy5zeXN0ZW1JbmZvLnNjcmVlbkhlaWdodCAtIDEzMCxcbiAgICAgICAgICAgICAgICB3aWR0aDogdGhpcy5zeXN0ZW1JbmZvLnNjcmVlbldpZHRoICsgNTAsXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLl9iYW5uZXJBZC5vbkVycm9yKChlcnIpID0+IHtcbiAgICAgICAgICAgIHRoaXMub25CYW5uZXJFcnIoZXJyKTtcbiAgICAgICAgICAgIHRoaXMuZGVzdHJveUJhbm5lcigpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fYmFubmVyQWQub25SZXNpemUocmVzID0+IHtcbiAgICAgICAgICAgIGlmICh0aGlzLnN5c3RlbUluZm8ucGxhdGZvcm0gPT0gXCJpb3NcIiAmJiAhIXRoaXMuc3lzdGVtSW5mby5zdGF0dXNCYXJIZWlnaHQgJiYgdGhpcy5zeXN0ZW1JbmZvLnN0YXR1c0JhckhlaWdodCA+IDIwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQuc3R5bGUudG9wID0gdGhpcy5zeXN0ZW1JbmZvLnNjcmVlbkhlaWdodCAtIHJlcy5oZWlnaHQgLSAyMDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQuc3R5bGUudG9wID0gdGhpcy5zeXN0ZW1JbmZvLnNjcmVlbkhlaWdodCAtIHJlcy5oZWlnaHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLl9iYW5uZXJBZC5vbkxvYWQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5iYW5uZXJMb2FkZWQgPSB0cnVlO1xuICAgICAgICAgICAgaWYgKHRoaXMubmVlZFNob3dCYW5uZXIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dCYW5uZXIoKTtcbiAgICAgICAgICAgICAgICB0aGlzLm5lZWRTaG93QmFubmVyID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNyZWF0ZUJhbm5lclRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICByZXR1cm4gdGhpcy5fYmFubmVyQWQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5YWz6Zet5bm/5ZGKXG4gICAgICovXG4gICAgcHVibGljIHJlbW92ZUJhbm5lcigpIHtcbiAgICAgICAgaWYgKHRoaXMuX2Jhbm5lckFkKSB7XG4gICAgICAgICAgICBsZXQgdCA9IERhdGUubm93KCk7XG4gICAgICAgICAgICBpZiAodCAtIHRoaXMuY3JlYXRlQmFubmVyVGltZSA+IDYwMDAwKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLot53kuIrmrKHmmL7npLpiYW5uZXLlt7LotoXov4c2MOenku+8jOWIm+W7uuaWsOeahGJhbm5lclwiKTtcbiAgICAgICAgICAgICAgICB0aGlzLmRlc3Ryb3lCYW5uZXIoKTtcbiAgICAgICAgICAgICAgICB0aGlzLnByZUNyZWF0ZUJhbm5lcigpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5oaWRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5iYW5uZXJTaG93aW5nID0gZmFsc2U7XG4gICAgICAgIHRoaXMubmVlZFNob3dCYW5uZXIgPSBmYWxzZTtcbiAgICB9XG4gICAgLyoq6ZSA5q+B5bey57uP5Yib5bu655qEYmFubmVyICovXG4gICAgcHJvdGVjdGVkIGRlc3Ryb3lCYW5uZXIoKSB7XG4gICAgICAgIGlmICghIXRoaXMuX2Jhbm5lckFkKSB7XG4gICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5vZmZMb2FkKCk7XG4gICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5vZmZFcnJvcigpO1xuICAgICAgICAgICAgdGhpcy5fYmFubmVyQWQub2ZmUmVzaXplKCk7XG4gICAgICAgICAgICB0aGlzLl9iYW5uZXJBZC5kZXN0cm95KCk7IC8v6KaB5YWI5oqK5pen55qE5bm/5ZGK57uZ6ZSA5q+B77yM5LiN54S25Lya5a+86Ie05YW255uR5ZCs55qE5LqL5Lu25peg5rOV6YeK5pS+77yM5b2x5ZON5oCn6IO9XG4gICAgICAgICAgICB0aGlzLl9iYW5uZXJBZCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5iYW5uZXJMb2FkZWQgPSBmYWxzZTtcbiAgICB9XG5cbiAgICAvL+aPkuWxj+W5v+WRilxuICAgIHB1YmxpYyBzaG93SW50ZXJzdGl0aWFsQWQoYmFubmVyOiBib29sZWFuID0gZmFsc2UpIHtcbiAgICAgICAgdGhpcy51c2VCYW5uZXJJbnN0ZWFkSW5zZXJ0ID0gYmFubmVyO1xuICAgICAgICB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgIGxldCBpZCA9IHRoaXMuZ2V0SW5zZXJ0QWRVbml0SWQoKTtcbiAgICAgICAgaWYgKCFpZCkge1xuICAgICAgICAgICAgLy8gdGhpcy5zaG93QmFubmVySW5zdGVhZEluc2VydCgpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHZlcnNpb24gPSB0aGlzLnN5c3RlbUluZm8uU0RLVmVyc2lvbjtcbiAgICAgICAgaWYgKHRoaXMuY29tcGFyZVZlcnNpb24odmVyc2lvbiwgJzIuNi4wJykgPCAwKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygn5Z+656GA5bqT54mI5pys6L+H5L2OJyk7XG4gICAgICAgICAgICAvLyB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgICAgICAvLyAgIC8vIOWmguaenOW4jOacm+eUqOaIt+WcqOacgOaWsOeJiOacrOeahOWuouaIt+err+S4iuS9k+mqjOaCqOeahOWwj+eoi+W6j++8jOWPr+S7pei/meagt+WtkOaPkOekulxuICAgICAgICAgICAgLy8gICB3eC5zaG93TW9kYWwoe1xuICAgICAgICAgICAgLy8gICAgIHRpdGxlOiAn5o+Q56S6JyxcbiAgICAgICAgICAgIC8vICAgICBjb250ZW50OiAn5b2T5YmN5b6u5L+h54mI5pys6L+H5L2O77yM5peg5rOV5L2/55So5o+S5bGP5bm/5ZGK77yM6K+35Y2H57qn5Yiw5pyA5paw5b6u5L+h54mI5pys5ZCO6YeN6K+V44CCJ1xuICAgICAgICAgICAgLy8gICB9KVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGxldCBhZCA9IHRoaXMuYXBpLmNyZWF0ZUludGVyc3RpdGlhbEFkKHsgYWRVbml0SWQ6IGlkIH0pO1xuICAgICAgICBhZC5zaG93KCkudGhlbih0aGlzLm9uSW5zZXJ0U2hvdy5iaW5kKHRoaXMpKTtcbiAgICAgICAgYWQub25DbG9zZSh0aGlzLm9uSW5zZXJ0SGlkZS5iaW5kKHRoaXMpKTtcbiAgICAgICAgYWQub25FcnJvcigoZXJyKSA9PiB7XG4gICAgICAgICAgICB0aGlzLm9uSW5zZXJ0RXJyKGVycik7XG4gICAgICAgICAgICAvLyB0aGlzLnNob3dCYW5uZXJJbnN0ZWFkSW5zZXJ0KCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICog55+t6ZyH5YqoXG4gICAgICovXG4gICAgcHVibGljIHZpYnJhdGVTaG9ydCgpIHtcbiAgICAgICAgaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlicmF0ZSkge1xuICAgICAgICAgICAgdGhpcy5hcGkudmlicmF0ZVNob3J0KHt9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOmVv+mch+WKqFxuICAgICAqL1xuICAgIHB1YmxpYyB2aWJyYXRlTG9uZygpIHtcbiAgICAgICAgaWYgKEdhbWVQbGF0Zm9ybS5pbnN0YW5jZS5Db25maWcudmlicmF0ZSkge1xuICAgICAgICAgICAgdGhpcy5hcGkudmlicmF0ZUxvbmcoe30pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5peg5r+A5Yqx5YiG5LqrJibluKblj4LliIbkuqtcbiAgICAgKi9cbiAgICBzaGFyZUFwcE1lc3NhZ2UocXVlcnk6IHN0cmluZyA9IFwiXCIpIHtcbiAgICAgICAgbGV0IGluZGV4OiBudW1iZXIgPSBNYXRoLmZsb29yKChNYXRoLnJhbmRvbSgpICogdGhpcy5zaGFyZVRpdGxlQXJyLmxlbmd0aCkpO1xuICAgICAgICBsZXQgaW5kZXhpbWc6IG51bWJlciA9IE1hdGguZmxvb3IoKE1hdGgucmFuZG9tKCkgKiB0aGlzLnNoYXJlSW1nQXJyLmxlbmd0aCkpO1xuICAgICAgICB0aGlzLmFwaS5zaGFyZUFwcE1lc3NhZ2Uoe1xuICAgICAgICAgICAgdGl0bGU6IGAke3RoaXMuc2hhcmVUaXRsZUFycltpbmRleF19YCxcbiAgICAgICAgICAgIGltYWdlVXJsOiBgJHt0aGlzLnNoYXJlSW1nQXJyW2luZGV4aW1nXX1gLFxuICAgICAgICAgICAgcXVlcnk6IGAke3F1ZXJ5fWAsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOa/gOWKseWIhuS6qyYm5bim5Y+C5YiG5LqrXG4gICAgICovXG4gICAgc2hhcmVUb0FueU9uZShzdWNjZXNzOiBGdW5jdGlvbiwgZmFpbD86IEZ1bmN0aW9uLCBxdWVyeTogc3RyaW5nID0gJycpIHtcbiAgICAgICAgaWYgKCFHYW1lUGxhdGZvcm0uaW5zdGFuY2UuQ29uZmlnLnNoYXJlKSB7XG4gICAgICAgICAgICBzdWNjZXNzKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zaGFyZUFwcE1lc3NhZ2UocXVlcnkpO1xuICAgICAgICBzdWNjZXNzKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5raI5oGv5o+Q56S6XG4gICAgICovXG4gICAgcHVibGljIHNob3dNZXNzYWdlKG1zZzogc3RyaW5nLCBpY29uOiBzdHJpbmcgPSAnbm9uZScpIHtcbiAgICAgICAgLy8gdGhpcy5hcGkuc2hvd1RvYXN0KHtcbiAgICAgICAgLy8gICAgIHRpdGxlOiBtc2csXG4gICAgICAgIC8vICAgICBkdXJhdGlvbjogMjAwMCxcbiAgICAgICAgLy8gICAgIGljb246IGljb24sXG4gICAgICAgIC8vICAgICBzdWNjZXNzOiAocmVzKSA9PiB7IH1cbiAgICAgICAgLy8gfSk7XG4gICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LnNob3dUaXAsIG1zZyk7XG4gICAgfVxuXG4gICAgcHVibGljIG5hdmlnYXRlVG9NaW5pUHJvZ3JhbShkYXRhOiBhbnkpIHtcbiAgICAgICAgdGhpcy5hcGkubmF2aWdhdGVUb01pbmlQcm9ncmFtKHtcbiAgICAgICAgICAgIGFwcElkOiBkYXRhLmdhbWVJZCxcbiAgICAgICAgfSlcbiAgICB9XG59XG4iXX0=