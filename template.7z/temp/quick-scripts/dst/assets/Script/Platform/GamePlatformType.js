
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/GamePlatformType.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a0a33dEZ9RBsqUmmWr+YJ9q', 'GamePlatformType');
// Script/Platform/GamePlatformType.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GamePlatformType = void 0;
var GamePlatformType;
(function (GamePlatformType) {
    GamePlatformType[GamePlatformType["PC"] = 0] = "PC";
    GamePlatformType[GamePlatformType["WX"] = 1] = "WX";
    GamePlatformType[GamePlatformType["TT"] = 2] = "TT";
    GamePlatformType[GamePlatformType["QQ"] = 3] = "QQ";
    GamePlatformType[GamePlatformType["OPPO"] = 4] = "OPPO";
    GamePlatformType[GamePlatformType["VIVO"] = 5] = "VIVO";
    GamePlatformType[GamePlatformType["XiaoMi"] = 6] = "XiaoMi";
    GamePlatformType[GamePlatformType["LeYou"] = 7] = "LeYou";
    GamePlatformType[GamePlatformType["DYB_QQ"] = 8] = "DYB_QQ";
    GamePlatformType[GamePlatformType["Blue_Android"] = 9] = "Blue_Android";
    GamePlatformType[GamePlatformType["Blue_IOS"] = 10] = "Blue_IOS";
})(GamePlatformType = exports.GamePlatformType || (exports.GamePlatformType = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcR2FtZVBsYXRmb3JtVHlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFZLGdCQVlYO0FBWkQsV0FBWSxnQkFBZ0I7SUFDeEIsbURBQUUsQ0FBQTtJQUNGLG1EQUFFLENBQUE7SUFDRixtREFBRSxDQUFBO0lBQ0YsbURBQUUsQ0FBQTtJQUNGLHVEQUFJLENBQUE7SUFDSix1REFBSSxDQUFBO0lBQ0osMkRBQU0sQ0FBQTtJQUNOLHlEQUFLLENBQUE7SUFDTCwyREFBTSxDQUFBO0lBQ04sdUVBQVksQ0FBQTtJQUNaLGdFQUFRLENBQUE7QUFDWixDQUFDLEVBWlcsZ0JBQWdCLEdBQWhCLHdCQUFnQixLQUFoQix3QkFBZ0IsUUFZM0IiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCBlbnVtIEdhbWVQbGF0Zm9ybVR5cGUge1xuICAgIFBDLFxuICAgIFdYLFxuICAgIFRULCAgICAgICAgICAgICAvL+Wtl+iKgui3s+WKqO+8iOWktOadoe+8jOaKlumfs++8jOilv+eTnOinhumikeetie+8iVxuICAgIFFRLCAgICAgICAgICAgICAvL+aJi1FcbiAgICBPUFBPLFxuICAgIFZJVk8sXG4gICAgWGlhb01pLCAgICAgICAgIC8v5bCP57GzXG4gICAgTGVZb3UsICAgICAgICAgIC8v5LmQ5ri4XG4gICAgRFlCX1FRLCAgICAgICAgIC8vUVHlsI/muLjmiI/lubPlj7DvvIznrKzkuInmlrlTREtcbiAgICBCbHVlX0FuZHJvaWQsICAgLy/lronljZPlubPlj7DlpKfok51TREtcbiAgICBCbHVlX0lPUywgICAgICAgLy9JT1PlubPlj7DlpKfok51TREtcbn1cbiJdfQ==