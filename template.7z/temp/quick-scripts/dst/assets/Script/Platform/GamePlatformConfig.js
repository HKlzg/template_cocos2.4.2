
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Platform/GamePlatformConfig.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'dcc1fC1BMVGYoDaYaaesjp4', 'GamePlatformConfig');
// Script/Platform/GamePlatformConfig.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GamePlatformType_1 = require("./GamePlatformType");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GamePlatformConfig = /** @class */ (function (_super) {
    __extends(GamePlatformConfig, _super);
    function GamePlatformConfig() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //平台。
        _this.type = GamePlatformType_1.GamePlatformType.PC;
        _this.version = "";
        _this.appId = "";
        _this.secret = "";
        _this.ServiceAdress = "";
        _this.videoAdUnitId = [];
        _this.BannerAdUnitId = [];
        _this.InterstitialAdUnitId = [];
        _this.appBoxUnitId = [];
        _this.blockAdUnitId = [];
        _this.nativeAdUnitId = [];
        _this.share = true;
        _this.video = true;
        _this.banner = true;
        _this.interstitial = true;
        _this.vibrate = true;
        return _this;
    }
    __decorate([
        property({ type: cc.Enum(GamePlatformType_1.GamePlatformType) })
    ], GamePlatformConfig.prototype, "type", void 0);
    __decorate([
        property
    ], GamePlatformConfig.prototype, "version", void 0);
    __decorate([
        property({
            displayName: "项目appId",
        })
    ], GamePlatformConfig.prototype, "appId", void 0);
    __decorate([
        property({
            displayName: "项目secret",
        })
    ], GamePlatformConfig.prototype, "secret", void 0);
    __decorate([
        property({
            displayName: "项目远程服务器地址",
        })
    ], GamePlatformConfig.prototype, "ServiceAdress", void 0);
    __decorate([
        property({
            displayName: "视频广告Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "videoAdUnitId", void 0);
    __decorate([
        property({
            displayName: "BannerId",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "BannerAdUnitId", void 0);
    __decorate([
        property({
            displayName: "插屏Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "InterstitialAdUnitId", void 0);
    __decorate([
        property({
            displayName: "盒子广告Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "appBoxUnitId", void 0);
    __decorate([
        property({
            displayName: "积木广告Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "blockAdUnitId", void 0);
    __decorate([
        property({
            displayName: "原生广告Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "nativeAdUnitId", void 0);
    __decorate([
        property({
            displayName: "开启激励分享",
            tooltip: "是否关闭激励分享，图标也会隐藏"
        })
    ], GamePlatformConfig.prototype, "share", void 0);
    __decorate([
        property({
            displayName: "开启视频广告",
            tooltip: "是否关闭视频广告，图标也会隐藏"
        })
    ], GamePlatformConfig.prototype, "video", void 0);
    __decorate([
        property({
            displayName: "开启Banner",
            tooltip: "是否关闭Banner"
        })
    ], GamePlatformConfig.prototype, "banner", void 0);
    __decorate([
        property({
            displayName: "开启插屏",
            tooltip: "是否关闭插屏"
        })
    ], GamePlatformConfig.prototype, "interstitial", void 0);
    __decorate([
        property({
            displayName: "开启震动",
            tooltip: "是否开启震动"
        })
    ], GamePlatformConfig.prototype, "vibrate", void 0);
    GamePlatformConfig = __decorate([
        ccclass
    ], GamePlatformConfig);
    return GamePlatformConfig;
}(cc.Component));
exports.default = GamePlatformConfig;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF0Zm9ybVxcR2FtZVBsYXRmb3JtQ29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHVEQUFzRDtBQUVoRCxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFnRCxzQ0FBWTtJQUE1RDtRQUFBLHFFQXlGQztRQXhGRyxLQUFLO1FBRUUsVUFBSSxHQUFxQixtQ0FBZ0IsQ0FBQyxFQUFFLENBQUM7UUFHN0MsYUFBTyxHQUFHLEVBQUUsQ0FBQztRQUtiLFdBQUssR0FBVyxFQUFFLENBQUM7UUFLbkIsWUFBTSxHQUFXLEVBQUUsQ0FBQztRQUtwQixtQkFBYSxHQUFXLEVBQUUsQ0FBQztRQU0zQixtQkFBYSxHQUFhLEVBQUUsQ0FBQztRQU03QixvQkFBYyxHQUFhLEVBQUUsQ0FBQztRQU05QiwwQkFBb0IsR0FBYSxFQUFFLENBQUM7UUFNcEMsa0JBQVksR0FBYSxFQUFFLENBQUM7UUFNNUIsbUJBQWEsR0FBYSxFQUFFLENBQUM7UUFNN0Isb0JBQWMsR0FBYSxFQUFFLENBQUM7UUFPOUIsV0FBSyxHQUFZLElBQUksQ0FBQztRQU10QixXQUFLLEdBQVksSUFBSSxDQUFDO1FBTXRCLFlBQU0sR0FBWSxJQUFJLENBQUM7UUFNdkIsa0JBQVksR0FBWSxJQUFJLENBQUM7UUFNN0IsYUFBTyxHQUFZLElBQUksQ0FBQzs7SUFDbkMsQ0FBQztJQXRGRztRQURDLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1DQUFnQixDQUFDLEVBQUUsQ0FBQztvREFDTTtJQUdwRDtRQURDLFFBQVE7dURBQ1c7SUFLcEI7UUFIQyxRQUFRLENBQUM7WUFDTixXQUFXLEVBQUUsU0FBUztTQUN6QixDQUFDO3FEQUN3QjtJQUsxQjtRQUhDLFFBQVEsQ0FBQztZQUNOLFdBQVcsRUFBRSxVQUFVO1NBQzFCLENBQUM7c0RBQ3lCO0lBSzNCO1FBSEMsUUFBUSxDQUFDO1lBQ04sV0FBVyxFQUFFLFdBQVc7U0FDM0IsQ0FBQzs2REFDZ0M7SUFNbEM7UUFKQyxRQUFRLENBQUM7WUFDTixXQUFXLEVBQUUsUUFBUTtZQUNyQixJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO1NBQ3BCLENBQUM7NkRBQ2tDO0lBTXBDO1FBSkMsUUFBUSxDQUFDO1lBQ04sV0FBVyxFQUFFLFVBQVU7WUFDdkIsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztTQUNwQixDQUFDOzhEQUNtQztJQU1yQztRQUpDLFFBQVEsQ0FBQztZQUNOLFdBQVcsRUFBRSxNQUFNO1lBQ25CLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7U0FDcEIsQ0FBQztvRUFDeUM7SUFNM0M7UUFKQyxRQUFRLENBQUM7WUFDTixXQUFXLEVBQUUsUUFBUTtZQUNyQixJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO1NBQ3BCLENBQUM7NERBQ2lDO0lBTW5DO1FBSkMsUUFBUSxDQUFDO1lBQ04sV0FBVyxFQUFFLFFBQVE7WUFDckIsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztTQUNwQixDQUFDOzZEQUNrQztJQU1wQztRQUpDLFFBQVEsQ0FBQztZQUNOLFdBQVcsRUFBRSxRQUFRO1lBQ3JCLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7U0FDcEIsQ0FBQzs4REFDbUM7SUFPckM7UUFKQyxRQUFRLENBQUM7WUFDTixXQUFXLEVBQUUsUUFBUTtZQUNyQixPQUFPLEVBQUUsaUJBQWlCO1NBQzdCLENBQUM7cURBQzJCO0lBTTdCO1FBSkMsUUFBUSxDQUFDO1lBQ04sV0FBVyxFQUFFLFFBQVE7WUFDckIsT0FBTyxFQUFFLGlCQUFpQjtTQUM3QixDQUFDO3FEQUMyQjtJQU03QjtRQUpDLFFBQVEsQ0FBQztZQUNOLFdBQVcsRUFBRSxVQUFVO1lBQ3ZCLE9BQU8sRUFBRSxZQUFZO1NBQ3hCLENBQUM7c0RBQzRCO0lBTTlCO1FBSkMsUUFBUSxDQUFDO1lBQ04sV0FBVyxFQUFFLE1BQU07WUFDbkIsT0FBTyxFQUFFLFFBQVE7U0FDcEIsQ0FBQzs0REFDa0M7SUFNcEM7UUFKQyxRQUFRLENBQUM7WUFDTixXQUFXLEVBQUUsTUFBTTtZQUNuQixPQUFPLEVBQUUsUUFBUTtTQUNwQixDQUFDO3VEQUM2QjtJQXhGZCxrQkFBa0I7UUFEdEMsT0FBTztPQUNhLGtCQUFrQixDQXlGdEM7SUFBRCx5QkFBQztDQXpGRCxBQXlGQyxDQXpGK0MsRUFBRSxDQUFDLFNBQVMsR0F5RjNEO2tCQXpGb0Isa0JBQWtCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgR2FtZVBsYXRmb3JtVHlwZSB9IGZyb20gXCIuL0dhbWVQbGF0Zm9ybVR5cGVcIjtcblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdhbWVQbGF0Zm9ybUNvbmZpZyBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG4gICAgLy/lubPlj7DjgIJcbiAgICBAcHJvcGVydHkoeyB0eXBlOiBjYy5FbnVtKEdhbWVQbGF0Zm9ybVR5cGUpIH0pXG4gICAgcHVibGljIHR5cGU6IEdhbWVQbGF0Zm9ybVR5cGUgPSBHYW1lUGxhdGZvcm1UeXBlLlBDO1xuXG4gICAgQHByb3BlcnR5XG4gICAgcHVibGljIHZlcnNpb24gPSBcIlwiO1xuXG4gICAgQHByb3BlcnR5KHtcbiAgICAgICAgZGlzcGxheU5hbWU6IFwi6aG555uuYXBwSWRcIixcbiAgICB9KVxuICAgIHB1YmxpYyBhcHBJZDogc3RyaW5nID0gXCJcIjtcblxuICAgIEBwcm9wZXJ0eSh7XG4gICAgICAgIGRpc3BsYXlOYW1lOiBcIumhueebrnNlY3JldFwiLFxuICAgIH0pXG4gICAgcHVibGljIHNlY3JldDogc3RyaW5nID0gXCJcIjtcblxuICAgIEBwcm9wZXJ0eSh7XG4gICAgICAgIGRpc3BsYXlOYW1lOiBcIumhueebrui/nOeoi+acjeWKoeWZqOWcsOWdgFwiLFxuICAgIH0pXG4gICAgcHVibGljIFNlcnZpY2VBZHJlc3M6IHN0cmluZyA9IFwiXCI7XG5cbiAgICBAcHJvcGVydHkoe1xuICAgICAgICBkaXNwbGF5TmFtZTogXCLop4bpopHlub/lkYpJZFwiLFxuICAgICAgICB0eXBlOiBbY2MuU3RyaW5nXSxcbiAgICB9KVxuICAgIHB1YmxpYyB2aWRlb0FkVW5pdElkOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgQHByb3BlcnR5KHtcbiAgICAgICAgZGlzcGxheU5hbWU6IFwiQmFubmVySWRcIixcbiAgICAgICAgdHlwZTogW2NjLlN0cmluZ10sXG4gICAgfSlcbiAgICBwdWJsaWMgQmFubmVyQWRVbml0SWQ6IHN0cmluZ1tdID0gW107XG5cbiAgICBAcHJvcGVydHkoe1xuICAgICAgICBkaXNwbGF5TmFtZTogXCLmj5LlsY9JZFwiLFxuICAgICAgICB0eXBlOiBbY2MuU3RyaW5nXSxcbiAgICB9KVxuICAgIHB1YmxpYyBJbnRlcnN0aXRpYWxBZFVuaXRJZDogc3RyaW5nW10gPSBbXTtcblxuICAgIEBwcm9wZXJ0eSh7XG4gICAgICAgIGRpc3BsYXlOYW1lOiBcIuebkuWtkOW5v+WRiklkXCIsXG4gICAgICAgIHR5cGU6IFtjYy5TdHJpbmddLFxuICAgIH0pXG4gICAgcHVibGljIGFwcEJveFVuaXRJZDogc3RyaW5nW10gPSBbXTtcblxuICAgIEBwcm9wZXJ0eSh7XG4gICAgICAgIGRpc3BsYXlOYW1lOiBcIuenr+acqOW5v+WRiklkXCIsXG4gICAgICAgIHR5cGU6IFtjYy5TdHJpbmddLFxuICAgIH0pXG4gICAgcHVibGljIGJsb2NrQWRVbml0SWQ6IHN0cmluZ1tdID0gW107XG5cbiAgICBAcHJvcGVydHkoe1xuICAgICAgICBkaXNwbGF5TmFtZTogXCLljp/nlJ/lub/lkYpJZFwiLFxuICAgICAgICB0eXBlOiBbY2MuU3RyaW5nXSxcbiAgICB9KVxuICAgIHB1YmxpYyBuYXRpdmVBZFVuaXRJZDogc3RyaW5nW10gPSBbXTtcblxuXG4gICAgQHByb3BlcnR5KHtcbiAgICAgICAgZGlzcGxheU5hbWU6IFwi5byA5ZCv5r+A5Yqx5YiG5LqrXCIsXG4gICAgICAgIHRvb2x0aXA6IFwi5piv5ZCm5YWz6Zet5r+A5Yqx5YiG5Lqr77yM5Zu+5qCH5Lmf5Lya6ZqQ6JePXCJcbiAgICB9KVxuICAgIHB1YmxpYyBzaGFyZTogYm9vbGVhbiA9IHRydWU7XG5cbiAgICBAcHJvcGVydHkoe1xuICAgICAgICBkaXNwbGF5TmFtZTogXCLlvIDlkK/op4bpopHlub/lkYpcIixcbiAgICAgICAgdG9vbHRpcDogXCLmmK/lkKblhbPpl63op4bpopHlub/lkYrvvIzlm77moIfkuZ/kvJrpmpDol49cIlxuICAgIH0pXG4gICAgcHVibGljIHZpZGVvOiBib29sZWFuID0gdHJ1ZTtcblxuICAgIEBwcm9wZXJ0eSh7XG4gICAgICAgIGRpc3BsYXlOYW1lOiBcIuW8gOWQr0Jhbm5lclwiLFxuICAgICAgICB0b29sdGlwOiBcIuaYr+WQpuWFs+mXrUJhbm5lclwiXG4gICAgfSlcbiAgICBwdWJsaWMgYmFubmVyOiBib29sZWFuID0gdHJ1ZTtcblxuICAgIEBwcm9wZXJ0eSh7XG4gICAgICAgIGRpc3BsYXlOYW1lOiBcIuW8gOWQr+aPkuWxj1wiLFxuICAgICAgICB0b29sdGlwOiBcIuaYr+WQpuWFs+mXreaPkuWxj1wiXG4gICAgfSlcbiAgICBwdWJsaWMgaW50ZXJzdGl0aWFsOiBib29sZWFuID0gdHJ1ZTtcblxuICAgIEBwcm9wZXJ0eSh7XG4gICAgICAgIGRpc3BsYXlOYW1lOiBcIuW8gOWQr+mch+WKqFwiLFxuICAgICAgICB0b29sdGlwOiBcIuaYr+WQpuW8gOWQr+mch+WKqFwiXG4gICAgfSlcbiAgICBwdWJsaWMgdmlicmF0ZTogYm9vbGVhbiA9IHRydWU7XG59XG4iXX0=