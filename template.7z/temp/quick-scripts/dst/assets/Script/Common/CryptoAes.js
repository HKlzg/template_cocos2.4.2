
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/CryptoAes.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1b75e2LoNBL/qFnvI/JpByU', 'CryptoAes');
// Script/Common/CryptoAes.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var CryptoJS = require("../3rd/CryptoJS");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var key = CryptoJS.enc.Utf8.parse('d2ba0a0acd99b1a8d1ded721d86d128d');
var iv = CryptoJS.enc.Utf8.parse('632323c6ee97597f');
var CryptoAes = /** @class */ (function (_super) {
    __extends(CryptoAes, _super);
    function CryptoAes() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CryptoAes.aesEncrypt = function (data) {
        var encrypted = CryptoJS.AES.encrypt(data, key, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
        return encrypted.toString();
    };
    CryptoAes.aesDecrypt = function (data) {
        return CryptoJS.AES.decrypt(data, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.ZeroPadding
            // padding:CryptoJS.pad.Pkcs7
        }).toString(CryptoJS.enc.Utf8);
    };
    CryptoAes = __decorate([
        ccclass
    ], CryptoAes);
    return CryptoAes;
}(cc.Component));
exports.default = CryptoAes;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXENyeXB0b0Flcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwwQ0FBNkM7QUFDdkMsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFFMUMsSUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7QUFDeEUsSUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFHdkQ7SUFBdUMsNkJBQVk7SUFBbkQ7O0lBa0JBLENBQUM7SUFmaUIsb0JBQVUsR0FBeEIsVUFBeUIsSUFBSTtRQUN6QixJQUFJLFNBQVMsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUNsSCxPQUFPLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRWEsb0JBQVUsR0FBeEIsVUFBeUIsSUFBSTtRQUN6QixPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUU7WUFDbkMsRUFBRSxFQUFFLEVBQUU7WUFDTixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHO1lBQ3ZCLE9BQU8sRUFBRSxRQUFRLENBQUMsR0FBRyxDQUFDLFdBQVc7WUFDakMsNkJBQTZCO1NBQ2hDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUNsQyxDQUFDO0lBZmdCLFNBQVM7UUFEN0IsT0FBTztPQUNhLFNBQVMsQ0FrQjdCO0lBQUQsZ0JBQUM7Q0FsQkQsQUFrQkMsQ0FsQnNDLEVBQUUsQ0FBQyxTQUFTLEdBa0JsRDtrQkFsQm9CLFNBQVMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ3J5cHRvSlMgPSByZXF1aXJlKFwiLi4vM3JkL0NyeXB0b0pTXCIpO1xyXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbmNvbnN0IGtleSA9IENyeXB0b0pTLmVuYy5VdGY4LnBhcnNlKCdkMmJhMGEwYWNkOTliMWE4ZDFkZWQ3MjFkODZkMTI4ZCcpO1xyXG5jb25zdCBpdiA9IENyeXB0b0pTLmVuYy5VdGY4LnBhcnNlKCc2MzIzMjNjNmVlOTc1OTdmJyk7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDcnlwdG9BZXMgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG4gICAgXHJcblxyXG4gICAgcHVibGljIHN0YXRpYyBhZXNFbmNyeXB0KGRhdGEpe1xyXG4gICAgICAgIGxldCBlbmNyeXB0ZWQgPSBDcnlwdG9KUy5BRVMuZW5jcnlwdChkYXRhLCBrZXksIHsgaXY6IGl2LCBtb2RlOiBDcnlwdG9KUy5tb2RlLkNCQywgcGFkZGluZzogQ3J5cHRvSlMucGFkLlBrY3M3IH0pO1xyXG4gICAgICAgIHJldHVybiBlbmNyeXB0ZWQudG9TdHJpbmcoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIGFlc0RlY3J5cHQoZGF0YSl7XHJcbiAgICAgICAgcmV0dXJuIENyeXB0b0pTLkFFUy5kZWNyeXB0KGRhdGEsIGtleSwge1xyXG4gICAgICAgICAgICBpdjogaXYsXHJcbiAgICAgICAgICAgIG1vZGU6IENyeXB0b0pTLm1vZGUuQ0JDLFxyXG4gICAgICAgICAgICBwYWRkaW5nOiBDcnlwdG9KUy5wYWQuWmVyb1BhZGRpbmdcclxuICAgICAgICAgICAgLy8gcGFkZGluZzpDcnlwdG9KUy5wYWQuUGtjczdcclxuICAgICAgICB9KS50b1N0cmluZyhDcnlwdG9KUy5lbmMuVXRmOClcclxuICAgIH1cclxuXHJcblxyXG59XHJcbiJdfQ==