
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/UIManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5b708/73FlAXbGUAoQ4RyT8', 'UIManager');
// Script/Common/UIManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameEventType_1 = require("../GameSpecial/GameEventType");
var Loader_1 = require("./Loader");
var EventManager_1 = require("./EventManager");
/**UI管理器 */
var UIManager = /** @class */ (function () {
    function UIManager() {
    }
    UIManager.init = function (node) {
        this.node = node;
        this.UIs = {};
        this.onEvents();
    };
    UIManager.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.UIEvent.enter, this.enterUI, this);
        EventManager_1.default.on(GameEventType_1.EventType.UIEvent.exit, this.exitUI, this);
    };
    /**获取指定UI脚本 */
    UIManager.getUI = function (type) {
        if (!this.UIs[type]) {
            console.warn("UI尚未加载，无法获取：", type);
            return null;
        }
        return this.UIs[type];
    };
    UIManager.enterUI = function (ui, data) {
        var iui = this.UIs[ui];
        if (null === iui)
            return;
        if (!!iui) {
            this.showUI(ui, data);
        }
        else {
            this.loadUI(ui, data);
        }
    };
    UIManager.showUI = function (ui, data) {
        var js = this.UIs[ui];
        if (!!js) {
            js.show(data);
            EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.entered, ui);
        }
    };
    UIManager.loadUI = function (ui, data) {
        var _this = this;
        var js = cc.find("Canvas").getComponentInChildren(ui);
        if (!!js) {
            this.UIs[ui] = js;
            this.showUI(ui, data);
        }
        else {
            Loader_1.default.loadBundle("LobbyUI", function () {
                Loader_1.default.loadBundleRes("LobbyUI", ui + "/" + ui, function (res) {
                    if (!res) {
                        // this.UIs[ui] = null;
                        // console.error("要显示的界面预制不存在：", ui);
                        _this.loadLevelUI(ui, data);
                        return;
                    }
                    var node = cc.instantiate(res);
                    _this.node.getChildByName(ui).addChild(node);
                    var wg = node.getComponent(cc.Widget);
                    if (!!wg) {
                        wg.updateAlignment();
                    }
                    var ly = node.getComponent(cc.Layout);
                    if (!!ly) {
                        ly.updateLayout();
                    }
                    var js = node.getComponent(ui);
                    js.init();
                    _this.UIs[ui] = js;
                    _this.showUI(ui, data);
                }, cc.Prefab, true);
            }, true);
        }
    };
    UIManager.loadLevelUI = function (ui, data) {
        var _this = this;
        Loader_1.default.loadBundle("LevelUI", function () {
            Loader_1.default.loadBundleRes("LevelUI", ui + "/" + ui, function (res) {
                if (!res) {
                    _this.UIs[ui] = null;
                    console.error("要显示的界面预制不存在：", ui);
                    return;
                }
                var node = cc.instantiate(res);
                _this.node.getChildByName(ui).addChild(node);
                var wg = node.getComponent(cc.Widget);
                if (!!wg) {
                    wg.updateAlignment();
                }
                var ly = node.getComponent(cc.Layout);
                if (!!ly) {
                    ly.updateLayout();
                }
                var js = node.getComponent(ui);
                js.init();
                _this.UIs[ui] = js;
                _this.showUI(ui, data);
            }, cc.Prefab, true);
        }, true);
    };
    UIManager.exitUI = function (ui) {
        var js = this.UIs[ui];
        if (!!js) {
            js.hide();
            EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.exited, ui);
        }
    };
    return UIManager;
}());
exports.default = UIManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXFVJTWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLDhEQUF5RDtBQUN6RCxtQ0FBOEI7QUFDOUIsK0NBQTBDO0FBRTFDLFdBQVc7QUFDWDtJQUFBO0lBdUdBLENBQUM7SUFwR2lCLGNBQUksR0FBbEIsVUFBbUIsSUFBYTtRQUM1QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQztRQUNkLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBQ2dCLGtCQUFRLEdBQXpCO1FBQ0ksc0JBQVksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDN0Qsc0JBQVksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDL0QsQ0FBQztJQUVELGNBQWM7SUFDQSxlQUFLLEdBQW5CLFVBQW9CLElBQUk7UUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDakIsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbkMsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUNELE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRWdCLGlCQUFPLEdBQXhCLFVBQXlCLEVBQUUsRUFBRSxJQUFVO1FBQ25DLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdkIsSUFBSSxJQUFJLEtBQUssR0FBRztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO1lBQ1AsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDekI7YUFBTTtZQUNILElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3pCO0lBQ0wsQ0FBQztJQUNnQixnQkFBTSxHQUF2QixVQUF3QixFQUFFLEVBQUUsSUFBVTtRQUNsQyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNOLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDZCxzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDcEQ7SUFDTCxDQUFDO0lBQ2dCLGdCQUFNLEdBQXZCLFVBQXdCLEVBQUUsRUFBRSxJQUFVO1FBQXRDLGlCQStCQztRQTlCRyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3RELElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNOLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3pCO2FBQU07WUFDSCxnQkFBTSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUU7Z0JBQ3pCLGdCQUFNLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsRUFBRSxVQUFDLEdBQUc7b0JBQy9DLElBQUksQ0FBQyxHQUFHLEVBQUU7d0JBQ04sdUJBQXVCO3dCQUN2QixxQ0FBcUM7d0JBQ3JDLEtBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO3dCQUMzQixPQUFPO3FCQUNWO29CQUNELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQy9CLEtBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDNUMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTt3QkFDTixFQUFFLENBQUMsZUFBZSxFQUFFLENBQUM7cUJBQ3hCO29CQUNELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN0QyxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7d0JBQ04sRUFBRSxDQUFDLFlBQVksRUFBRSxDQUFDO3FCQUNyQjtvQkFDRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUMvQixFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ1YsS0FBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQ2xCLEtBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxQixDQUFDLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN4QixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDWjtJQUNMLENBQUM7SUFDZ0IscUJBQVcsR0FBNUIsVUFBNkIsRUFBRSxFQUFFLElBQVU7UUFBM0MsaUJBd0JDO1FBdkJHLGdCQUFNLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRTtZQUN6QixnQkFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsRUFBRSxHQUFHLEdBQUcsR0FBRyxFQUFFLEVBQUUsVUFBQyxHQUFHO2dCQUMvQyxJQUFJLENBQUMsR0FBRyxFQUFFO29CQUNOLEtBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDO29CQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDbEMsT0FBTztpQkFDVjtnQkFDRCxJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMvQixLQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzVDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7b0JBQ04sRUFBRSxDQUFDLGVBQWUsRUFBRSxDQUFDO2lCQUN4QjtnQkFDRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFFO29CQUNOLEVBQUUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztpQkFDckI7Z0JBQ0QsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDL0IsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNWLEtBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNsQixLQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUMxQixDQUFDLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN4QixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDYixDQUFDO0lBRWdCLGdCQUFNLEdBQXZCLFVBQXdCLEVBQUU7UUFDdEIsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN0QixJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDTixFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDVixzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDbkQ7SUFDTCxDQUFDO0lBQ0wsZ0JBQUM7QUFBRCxDQXZHQSxBQXVHQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgR2xvYmFsRW51bSB9IGZyb20gXCIuLi9HYW1lU3BlY2lhbC9HbG9iYWxFbnVtXCI7XHJcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XHJcbmltcG9ydCBMb2FkZXIgZnJvbSBcIi4vTG9hZGVyXCI7XHJcbmltcG9ydCBFdmVudE1hbmFnZXIgZnJvbSBcIi4vRXZlbnRNYW5hZ2VyXCI7XHJcblxyXG4vKipVSeeuoeeQhuWZqCAqL1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBVSU1hbmFnZXIge1xyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBub2RlOiBjYy5Ob2RlO1xyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBVSXM7XHJcbiAgICBwdWJsaWMgc3RhdGljIGluaXQobm9kZTogY2MuTm9kZSkge1xyXG4gICAgICAgIHRoaXMubm9kZSA9IG5vZGU7XHJcbiAgICAgICAgdGhpcy5VSXMgPSB7fTtcclxuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIG9uRXZlbnRzKCkge1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuVUlFdmVudC5lbnRlciwgdGhpcy5lbnRlclVJLCB0aGlzKTtcclxuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLlVJRXZlbnQuZXhpdCwgdGhpcy5leGl0VUksIHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKuiOt+WPluaMh+WumlVJ6ISa5pysICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGdldFVJKHR5cGUpIHtcclxuICAgICAgICBpZiAoIXRoaXMuVUlzW3R5cGVdKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcIlVJ5bCa5pyq5Yqg6L2977yM5peg5rOV6I635Y+W77yaXCIsIHR5cGUpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuVUlzW3R5cGVdO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBzdGF0aWMgZW50ZXJVSSh1aSwgZGF0YT86IGFueSkge1xyXG4gICAgICAgIGxldCBpdWkgPSB0aGlzLlVJc1t1aV07XHJcbiAgICAgICAgaWYgKG51bGwgPT09IGl1aSkgcmV0dXJuO1xyXG4gICAgICAgIGlmICghIWl1aSkge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dVSSh1aSwgZGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5sb2FkVUkodWksIGRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBzdGF0aWMgc2hvd1VJKHVpLCBkYXRhPzogYW55KSB7XHJcbiAgICAgICAgbGV0IGpzID0gdGhpcy5VSXNbdWldO1xyXG4gICAgICAgIGlmICghIWpzKSB7XHJcbiAgICAgICAgICAgIGpzLnNob3coZGF0YSk7XHJcbiAgICAgICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmVudGVyZWQsIHVpKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIGxvYWRVSSh1aSwgZGF0YT86IGFueSkge1xyXG4gICAgICAgIGxldCBqcyA9IGNjLmZpbmQoXCJDYW52YXNcIikuZ2V0Q29tcG9uZW50SW5DaGlsZHJlbih1aSk7XHJcbiAgICAgICAgaWYgKCEhanMpIHtcclxuICAgICAgICAgICAgdGhpcy5VSXNbdWldID0ganM7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1VJKHVpLCBkYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZShcIkxvYmJ5VUlcIiwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgTG9hZGVyLmxvYWRCdW5kbGVSZXMoXCJMb2JieVVJXCIsIHVpICsgXCIvXCIgKyB1aSwgKHJlcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghcmVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuVUlzW3VpXSA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUuZXJyb3IoXCLopoHmmL7npLrnmoTnlYzpnaLpooTliLbkuI3lrZjlnKjvvJpcIiwgdWkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRMZXZlbFVJKHVpLCBkYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBsZXQgbm9kZSA9IGNjLmluc3RhbnRpYXRlKHJlcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKHVpKS5hZGRDaGlsZChub2RlKTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgd2cgPSBub2RlLmdldENvbXBvbmVudChjYy5XaWRnZXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghIXdnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdnLnVwZGF0ZUFsaWdubWVudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBsZXQgbHkgPSBub2RlLmdldENvbXBvbmVudChjYy5MYXlvdXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghIWx5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGx5LnVwZGF0ZUxheW91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBsZXQganMgPSBub2RlLmdldENvbXBvbmVudCh1aSk7XHJcbiAgICAgICAgICAgICAgICAgICAganMuaW5pdCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuVUlzW3VpXSA9IGpzO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvd1VJKHVpLCBkYXRhKTtcclxuICAgICAgICAgICAgICAgIH0sIGNjLlByZWZhYiwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIH0sIHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBzdGF0aWMgbG9hZExldmVsVUkodWksIGRhdGE/OiBhbnkpIHtcclxuICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZShcIkxldmVsVUlcIiwgKCkgPT4ge1xyXG4gICAgICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZVJlcyhcIkxldmVsVUlcIiwgdWkgKyBcIi9cIiArIHVpLCAocmVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuVUlzW3VpXSA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIuimgeaYvuekuueahOeVjOmdoumihOWItuS4jeWtmOWcqO+8mlwiLCB1aSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IG5vZGUgPSBjYy5pbnN0YW50aWF0ZShyZXMpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKHVpKS5hZGRDaGlsZChub2RlKTtcclxuICAgICAgICAgICAgICAgIGxldCB3ZyA9IG5vZGUuZ2V0Q29tcG9uZW50KGNjLldpZGdldCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoISF3Zykge1xyXG4gICAgICAgICAgICAgICAgICAgIHdnLnVwZGF0ZUFsaWdubWVudCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IGx5ID0gbm9kZS5nZXRDb21wb25lbnQoY2MuTGF5b3V0KTtcclxuICAgICAgICAgICAgICAgIGlmICghIWx5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbHkudXBkYXRlTGF5b3V0KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBsZXQganMgPSBub2RlLmdldENvbXBvbmVudCh1aSk7XHJcbiAgICAgICAgICAgICAgICBqcy5pbml0KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlVJc1t1aV0gPSBqcztcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd1VJKHVpLCBkYXRhKTtcclxuICAgICAgICAgICAgfSwgY2MuUHJlZmFiLCB0cnVlKTtcclxuICAgICAgICB9LCB0cnVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIGV4aXRVSSh1aSkge1xyXG4gICAgICAgIGxldCBqcyA9IHRoaXMuVUlzW3VpXTtcclxuICAgICAgICBpZiAoISFqcykge1xyXG4gICAgICAgICAgICBqcy5oaWRlKCk7XHJcbiAgICAgICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmV4aXRlZCwgdWkpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=