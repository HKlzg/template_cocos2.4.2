
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/http_request.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2c29csX5rhKb490tgYRKTP0', 'http_request');
// Script/Common/http_request.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Button_manager_1 = require("../mananer/Button_manager");
var http_request = /** @class */ (function () {
    function http_request() {
        this.objFunc = {};
    }
    http_request.getInstance = function () {
        if (!http_request._instance) {
            http_request._instance = new http_request();
        }
        return http_request._instance;
    };
    http_request.prototype.postRequest = function (url, _data, _callback) {
        Button_manager_1.default.getInstance().setIsClick(false);
        console.log('postRequest --->', url);
        var http = new XMLHttpRequest();
        http.addEventListener("error", this.onRequestError);
        http.open("POST", url, true); //初始化请求
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        // httpRequest.setRequestHeader("Content-type","application/json");
        var str = '';
        for (var a in _data) {
            str += a + "=" + encodeURIComponent(_data[a]) + '&';
        }
        str = str.substr(0, str.length - 1);
        http.send(str); //JSON.stringify(_data)
        http.onreadystatechange = function () {
            var state = http.readyState; //返回服务器的状态
            var status = http.status;
            if (state == 4 && status == 200) {
                var response = http.responseText; //返回的信息是一个字符串
                var data = JSON.parse(response); //解析字符串
                Button_manager_1.default.getInstance().setIsClick(true);
                _callback && _callback(data);
            }
        };
    };
    http_request.prototype.get = function (url, _data, _callback) {
        Button_manager_1.default.getInstance().setIsClick(false);
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.timeout = 10 * 1000;
        xhr.open("GET", url, true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (this.readyState === 4 && (this.status >= 200 && this.status < 300)) {
                var respone = xhr.responseText;
                if (!respone)
                    console.log("httperror", respone);
                var resp = JSON.parse(respone);
                _callback(resp);
                Button_manager_1.default.getInstance().setIsClick(true);
            }
        };
        var str = '';
        for (var a in _data) {
            str += a + "=" + _data[a] + '&';
        }
        str = str.substr(0, str.length - 1);
        xhr.send(str);
    };
    http_request.prototype.setRequestErrorFunc = function (cb, target) {
        this.objFunc['error'] = { 'cb': cb, 'target': target };
    };
    http_request.prototype.onRequestError = function () {
        //请求失败
        if (this.objFunc['error']) {
            var obj = this.objFunc['error'];
            obj['cb'].call(obj['target'], "游戏维护中");
        }
    };
    http_request.url_ad = 'https://ad.geyian.ink/';
    http_request.url_login = 'https://tjqh.youdongxi.cn/';
    http_request.url_gamelevel = 'https://img.youdongxi.cn/';
    http_request.url_buy = "https://tj.geyian.ink/";
    http_request._instance = null;
    return http_request;
}());
exports.default = http_request;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXGh0dHBfcmVxdWVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDREQUF1RDtBQUN2RDtJQWNJO1FBbURRLFlBQU8sR0FBVSxFQUFFLENBQUM7SUFuRE4sQ0FBQztJQU5ULHdCQUFXLEdBQXpCO1FBQ0ksSUFBRyxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUM7WUFDdkIsWUFBWSxDQUFDLFNBQVMsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO1NBQy9DO1FBQ0QsT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDO0lBQ2xDLENBQUM7SUFHTSxrQ0FBVyxHQUFsQixVQUFtQixHQUFVLEVBQUUsS0FBUyxFQUFFLFNBQWdDO1FBQ3RFLHdCQUFjLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEMsSUFBSSxJQUFJLEdBQUcsSUFBSSxjQUFjLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPO1FBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLEVBQUMsbUNBQW1DLENBQUMsQ0FBQztRQUMxRSxtRUFBbUU7UUFDbkUsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBQ2IsS0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLEVBQUU7WUFDakIsR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1NBQ3ZEO1FBQ0QsR0FBRyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtRQUN2QyxJQUFJLENBQUMsa0JBQWtCLEdBQUc7WUFDdEIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFVBQVU7WUFDdkMsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUN6QixJQUFHLEtBQUssSUFBSSxDQUFDLElBQUksTUFBTSxJQUFJLEdBQUcsRUFBQztnQkFDM0IsSUFBSSxRQUFRLEdBQVUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWE7Z0JBQ3RELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPO2dCQUN4Qyx3QkFBYyxDQUFDLFdBQVcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDOUMsU0FBUyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNoQztRQUNMLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFTSwwQkFBRyxHQUFWLFVBQVcsR0FBRyxFQUFFLEtBQUssRUFBRSxTQUFTO1FBQzVCLHdCQUFjLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQy9DLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN4QyxHQUFHLENBQUMsT0FBTyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDeEIsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNCLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLEVBQUMsbUNBQW1DLENBQUMsQ0FBQztRQUN6RSxHQUFHLENBQUMsa0JBQWtCLEdBQUc7WUFDckIsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLEVBQUU7Z0JBQ3BFLElBQUksT0FBTyxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxPQUFPO29CQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNoRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMvQixTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2hCLHdCQUFjLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ2pEO1FBQ0wsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBQ2IsS0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLEVBQUU7WUFDakIsR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUNuQztRQUNELEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2xDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbEIsQ0FBQztJQUdNLDBDQUFtQixHQUExQixVQUEyQixFQUFXLEVBQUMsTUFBTTtRQUN6QyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUMsSUFBSSxFQUFDLEVBQUUsRUFBQyxRQUFRLEVBQUMsTUFBTSxFQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVPLHFDQUFjLEdBQXRCO1FBQ0ksTUFBTTtRQUNOLElBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBQztZQUNyQixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ3pDO0lBQ0wsQ0FBQztJQTFFYSxtQkFBTSxHQUFHLHdCQUF3QixDQUFDO0lBQ2xDLHNCQUFTLEdBQUcsNEJBQTRCLENBQUM7SUFDekMsMEJBQWEsR0FBRywyQkFBMkIsQ0FBQztJQUM1QyxvQkFBTyxHQUFHLHdCQUF3QixDQUFDO0lBRWxDLHNCQUFTLEdBQWdCLElBQUksQ0FBQztJQXNFakQsbUJBQUM7Q0E3RUQsQUE2RUMsSUFBQTtrQkE3RW9CLFlBQVkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQnV0dG9uX21hbmFnZXIgZnJvbSBcIi4uL21hbmFuZXIvQnV0dG9uX21hbmFnZXJcIjtcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgaHR0cF9yZXF1ZXN0IHtcclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIHVybF9hZCA9ICdodHRwczovL2FkLmdleWlhbi5pbmsvJztcclxuICAgIHB1YmxpYyBzdGF0aWMgdXJsX2xvZ2luID0gJ2h0dHBzOi8vdGpxaC55b3Vkb25neGkuY24vJztcclxuICAgIHB1YmxpYyBzdGF0aWMgdXJsX2dhbWVsZXZlbCA9ICdodHRwczovL2ltZy55b3Vkb25neGkuY24vJztcclxuICAgIHB1YmxpYyBzdGF0aWMgdXJsX2J1eSA9IFwiaHR0cHM6Ly90ai5nZXlpYW4uaW5rL1wiO1xyXG5cclxuICAgIHByaXZhdGUgc3RhdGljIF9pbnN0YW5jZTpodHRwX3JlcXVlc3QgPSBudWxsO1xyXG4gICAgcHVibGljIHN0YXRpYyBnZXRJbnN0YW5jZSgpOmh0dHBfcmVxdWVzdHtcclxuICAgICAgICBpZighaHR0cF9yZXF1ZXN0Ll9pbnN0YW5jZSl7XHJcbiAgICAgICAgICAgIGh0dHBfcmVxdWVzdC5faW5zdGFuY2UgPSBuZXcgaHR0cF9yZXF1ZXN0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBodHRwX3JlcXVlc3QuX2luc3RhbmNlO1xyXG4gICAgfVxyXG4gICAgcHJpdmF0ZSBjb25zdHJ1Y3Rvcigpe31cclxuXHJcbiAgICBwdWJsaWMgcG9zdFJlcXVlc3QodXJsOnN0cmluZywgX2RhdGE6YW55LCBfY2FsbGJhY2s/OiAocGFyYW1zOmFueSkgPT4gdm9pZCl7XHJcbiAgICAgICAgQnV0dG9uX21hbmFnZXIuZ2V0SW5zdGFuY2UoKS5zZXRJc0NsaWNrKGZhbHNlKTtcclxuICAgICAgICBjb25zb2xlLmxvZygncG9zdFJlcXVlc3QgLS0tPicsdXJsKTtcclxuICAgICAgICBsZXQgaHR0cCA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xyXG4gICAgICAgIGh0dHAuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIHRoaXMub25SZXF1ZXN0RXJyb3IpO1xyXG4gICAgICAgIGh0dHAub3BlbihcIlBPU1RcIiwgdXJsLCB0cnVlKTsgLy/liJ3lp4vljJbor7fmsYJcclxuICAgICAgICBodHRwLnNldFJlcXVlc3RIZWFkZXIoXCJDb250ZW50LXR5cGVcIixcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiKTtcclxuICAgICAgICAvLyBodHRwUmVxdWVzdC5zZXRSZXF1ZXN0SGVhZGVyKFwiQ29udGVudC10eXBlXCIsXCJhcHBsaWNhdGlvbi9qc29uXCIpO1xyXG4gICAgICAgIGxldCBzdHIgPSAnJztcclxuICAgICAgICBmb3IgKGxldCBhIGluIF9kYXRhKSB7XHJcbiAgICAgICAgICAgIHN0ciArPSBhICsgXCI9XCIgKyBlbmNvZGVVUklDb21wb25lbnQoX2RhdGFbYV0pICsgJyYnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzdHIgPSBzdHIuc3Vic3RyKDAsIHN0ci5sZW5ndGgtMSk7XHJcbiAgICAgICAgaHR0cC5zZW5kKHN0cik7IC8vSlNPTi5zdHJpbmdpZnkoX2RhdGEpXHJcbiAgICAgICAgaHR0cC5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoKT0+e1xyXG4gICAgICAgICAgICBsZXQgc3RhdGUgPSBodHRwLnJlYWR5U3RhdGU7IC8v6L+U5Zue5pyN5Yqh5Zmo55qE54q25oCBXHJcbiAgICAgICAgICAgIGxldCBzdGF0dXMgPSBodHRwLnN0YXR1cztcclxuICAgICAgICAgICAgaWYoc3RhdGUgPT0gNCAmJiBzdGF0dXMgPT0gMjAwKXtcclxuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZTpzdHJpbmcgPSBodHRwLnJlc3BvbnNlVGV4dDsgLy/ov5Tlm57nmoTkv6Hmga/mmK/kuIDkuKrlrZfnrKbkuLJcclxuICAgICAgICAgICAgICAgIGxldCBkYXRhID0gSlNPTi5wYXJzZShyZXNwb25zZSk7IC8v6Kej5p6Q5a2X56ym5LiyXHJcbiAgICAgICAgICAgICAgICBCdXR0b25fbWFuYWdlci5nZXRJbnN0YW5jZSgpLnNldElzQ2xpY2sodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICBfY2FsbGJhY2sgJiYgX2NhbGxiYWNrKGRhdGEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0KHVybCwgX2RhdGEsIF9jYWxsYmFjaykge1xyXG4gICAgICAgIEJ1dHRvbl9tYW5hZ2VyLmdldEluc3RhbmNlKCkuc2V0SXNDbGljayhmYWxzZSk7XHJcbiAgICAgICAgbGV0IHhociA9IGNjLmxvYWRlci5nZXRYTUxIdHRwUmVxdWVzdCgpO1xyXG4gICAgICAgIHhoci50aW1lb3V0ID0gMTAgKiAxMDAwO1xyXG4gICAgICAgIHhoci5vcGVuKFwiR0VUXCIsIHVybCwgdHJ1ZSk7XHJcbiAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIoXCJDb250ZW50LXR5cGVcIixcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiKTtcclxuICAgICAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5yZWFkeVN0YXRlID09PSA0ICYmICh0aGlzLnN0YXR1cyA+PSAyMDAgJiYgdGhpcy5zdGF0dXMgPCAzMDApKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcmVzcG9uZSA9IHhoci5yZXNwb25zZVRleHQ7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXJlc3BvbmUpIGNvbnNvbGUubG9nKFwiaHR0cGVycm9yXCIsIHJlc3BvbmUpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHJlc3AgPSBKU09OLnBhcnNlKHJlc3BvbmUpO1xyXG4gICAgICAgICAgICAgICAgX2NhbGxiYWNrKHJlc3ApO1xyXG4gICAgICAgICAgICAgICAgQnV0dG9uX21hbmFnZXIuZ2V0SW5zdGFuY2UoKS5zZXRJc0NsaWNrKHRydWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgc3RyID0gJyc7XHJcbiAgICAgICAgZm9yIChsZXQgYSBpbiBfZGF0YSkge1xyXG4gICAgICAgICAgICBzdHIgKz0gYSArIFwiPVwiICsgX2RhdGFbYV0gKyAnJic7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN0ciA9IHN0ci5zdWJzdHIoMCwgc3RyLmxlbmd0aC0xKTtcclxuICAgICAgICB4aHIuc2VuZChzdHIpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgb2JqRnVuYzpvYmplY3QgPSB7fTtcclxuICAgIHB1YmxpYyBzZXRSZXF1ZXN0RXJyb3JGdW5jKGNiOkZ1bmN0aW9uLHRhcmdldCl7XHJcbiAgICAgICAgdGhpcy5vYmpGdW5jWydlcnJvciddID0geydjYic6Y2IsJ3RhcmdldCc6dGFyZ2V0fTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIG9uUmVxdWVzdEVycm9yKCl7XHJcbiAgICAgICAgLy/or7fmsYLlpLHotKVcclxuICAgICAgICBpZih0aGlzLm9iakZ1bmNbJ2Vycm9yJ10pe1xyXG4gICAgICAgICAgICBsZXQgb2JqID0gdGhpcy5vYmpGdW5jWydlcnJvciddO1xyXG4gICAgICAgICAgICBvYmpbJ2NiJ10uY2FsbChvYmpbJ3RhcmdldCddLFwi5ri45oiP57u05oqk5LitXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcblxyXG5cclxuIl19