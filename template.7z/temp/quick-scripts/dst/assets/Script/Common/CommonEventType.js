
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/CommonEventType.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f58a07RCU5EcZ3PXgKStiAX', 'CommonEventType');
// Script/Common/CommonEventType.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**游戏流程相关的事件,从 1000 开始 */
var DirectorEvent;
(function (DirectorEvent) {
    DirectorEvent[DirectorEvent["startIndex"] = 1000] = "startIndex";
    DirectorEvent[DirectorEvent["enterLobby"] = 1001] = "enterLobby";
    DirectorEvent[DirectorEvent["hideGameLobby"] = 1002] = "hideGameLobby";
    DirectorEvent[DirectorEvent["startGame"] = 1003] = "startGame";
    DirectorEvent[DirectorEvent["startLevel"] = 1004] = "startLevel";
    DirectorEvent[DirectorEvent["enterChosedLevel"] = 1005] = "enterChosedLevel";
    DirectorEvent[DirectorEvent["exitLevel"] = 1006] = "exitLevel";
    DirectorEvent[DirectorEvent["playNextLevel"] = 1007] = "playNextLevel";
    DirectorEvent[DirectorEvent["replayCurLevel"] = 1008] = "replayCurLevel";
    DirectorEvent[DirectorEvent["playerWin"] = 1009] = "playerWin";
    DirectorEvent[DirectorEvent["playerLose"] = 1010] = "playerLose";
    DirectorEvent[DirectorEvent["pauseLevel"] = 1011] = "pauseLevel";
    DirectorEvent[DirectorEvent["resumeLevel"] = 1012] = "resumeLevel";
    DirectorEvent[DirectorEvent["matchPlayerFinish"] = 1013] = "matchPlayerFinish";
    DirectorEvent[DirectorEvent["chooseTrySkinFinish"] = 1014] = "chooseTrySkinFinish";
})(DirectorEvent || (DirectorEvent = {}));
/**资源加载相关事件，从 2000 开始 */
var LoadAssetEvent;
(function (LoadAssetEvent) {
    LoadAssetEvent[LoadAssetEvent["startIndex"] = 2000] = "startIndex";
    LoadAssetEvent[LoadAssetEvent["showProgress"] = 2001] = "showProgress";
    LoadAssetEvent[LoadAssetEvent["hideProgress"] = 2002] = "hideProgress";
    LoadAssetEvent[LoadAssetEvent["updateProgress"] = 2003] = "updateProgress";
})(LoadAssetEvent || (LoadAssetEvent = {}));
/**游戏数据相关事件，从 3000 开始 */
var PlayerDataEvent;
(function (PlayerDataEvent) {
    PlayerDataEvent[PlayerDataEvent["startIndex"] = 3000] = "startIndex";
    PlayerDataEvent[PlayerDataEvent["updatePlayerData"] = 3001] = "updatePlayerData";
    PlayerDataEvent[PlayerDataEvent["playerDataChanged"] = 3002] = "playerDataChanged";
    PlayerDataEvent[PlayerDataEvent["trySkinEnd"] = 3003] = "trySkinEnd";
})(PlayerDataEvent || (PlayerDataEvent = {}));
/**SDK相关事件 */
var SDKEvent;
(function (SDKEvent) {
    SDKEvent[SDKEvent["startIndex"] = 4000] = "startIndex";
    SDKEvent[SDKEvent["showMsg"] = 4001] = "showMsg";
    SDKEvent[SDKEvent["showVideo"] = 4002] = "showVideo";
    SDKEvent[SDKEvent["showBanner"] = 4003] = "showBanner";
    SDKEvent[SDKEvent["hideBanner"] = 4004] = "hideBanner";
    SDKEvent[SDKEvent["showBannerFinish"] = 4005] = "showBannerFinish";
    SDKEvent[SDKEvent["showInsertAd"] = 4006] = "showInsertAd";
    SDKEvent[SDKEvent["startRecord"] = 4007] = "startRecord";
    SDKEvent[SDKEvent["pauseRecord"] = 4008] = "pauseRecord";
    SDKEvent[SDKEvent["resumeRecord"] = 4009] = "resumeRecord";
    SDKEvent[SDKEvent["stopRecord"] = 4010] = "stopRecord";
    SDKEvent[SDKEvent["recordSaved"] = 4011] = "recordSaved";
    SDKEvent[SDKEvent["recordError"] = 4012] = "recordError";
    SDKEvent[SDKEvent["shareRecord"] = 4013] = "shareRecord";
    SDKEvent[SDKEvent["bannerResize"] = 4014] = "bannerResize";
    SDKEvent[SDKEvent["navigateToMiniProgram"] = 4015] = "navigateToMiniProgram";
    SDKEvent[SDKEvent["vibrateShort"] = 4016] = "vibrateShort";
    SDKEvent[SDKEvent["vibrateLong"] = 4017] = "vibrateLong";
    SDKEvent[SDKEvent["hide"] = 4018] = "hide";
    SDKEvent[SDKEvent["show"] = 4019] = "show";
    SDKEvent[SDKEvent["showInsertByPauseLevel"] = 4020] = "showInsertByPauseLevel";
    SDKEvent[SDKEvent["triggerGC"] = 4021] = "triggerGC";
    SDKEvent[SDKEvent["showNativeAd"] = 4022] = "showNativeAd";
    SDKEvent[SDKEvent["hideNativeAd"] = 4023] = "hideNativeAd";
    SDKEvent[SDKEvent["hideAllNativeAd"] = 4024] = "hideAllNativeAd";
    SDKEvent[SDKEvent["quickShowNativeAd"] = 4025] = "quickShowNativeAd";
    SDKEvent[SDKEvent["quickHideNativeAd"] = 4026] = "quickHideNativeAd";
    //安卓/苹果端原生包SDK事件：
    SDKEvent[SDKEvent["callJSVideoSuccess"] = 4027] = "callJSVideoSuccess";
    SDKEvent[SDKEvent["callJSVideoFail"] = 4028] = "callJSVideoFail";
    SDKEvent[SDKEvent["callJSVideoError"] = 4029] = "callJSVideoError";
    SDKEvent[SDKEvent["callJSFullVideoSuccess"] = 4030] = "callJSFullVideoSuccess";
    SDKEvent[SDKEvent["callJSFullVideoFail"] = 4031] = "callJSFullVideoFail";
    SDKEvent[SDKEvent["callJSFullVideoError"] = 4032] = "callJSFullVideoError";
    //QQ平台：
    SDKEvent[SDKEvent["showAppBox"] = 4033] = "showAppBox";
    SDKEvent[SDKEvent["showBlockAd"] = 4034] = "showBlockAd";
    SDKEvent[SDKEvent["subscribeMsg"] = 4035] = "subscribeMsg";
    SDKEvent[SDKEvent["addColorSign"] = 4036] = "addColorSign";
})(SDKEvent || (SDKEvent = {}));
/**UI相关事件 */
var UIEvent;
(function (UIEvent) {
    UIEvent[UIEvent["startIndex"] = 5000] = "startIndex";
    UIEvent[UIEvent["playGoldAnim"] = 5001] = "playGoldAnim";
    UIEvent[UIEvent["goldAnimPlayFinish"] = 5002] = "goldAnimPlayFinish";
    UIEvent[UIEvent["showTip"] = 5003] = "showTip";
    UIEvent[UIEvent["showTouchMask"] = 5004] = "showTouchMask";
    UIEvent[UIEvent["hideTouchMask"] = 5005] = "hideTouchMask";
    UIEvent[UIEvent["enter"] = 5006] = "enter";
    UIEvent[UIEvent["entered"] = 5007] = "entered";
    UIEvent[UIEvent["exit"] = 5008] = "exit";
    UIEvent[UIEvent["exited"] = 5009] = "exited";
})(UIEvent || (UIEvent = {}));
/**音效事件 */
var AudioEvent;
(function (AudioEvent) {
    AudioEvent[AudioEvent["startIndex"] = 6000] = "startIndex";
    AudioEvent[AudioEvent["playBGM"] = 6001] = "playBGM";
    AudioEvent[AudioEvent["playEffect"] = 6002] = "playEffect";
    AudioEvent[AudioEvent["playClickBtn"] = 6003] = "playClickBtn";
    AudioEvent[AudioEvent["stopBGM"] = 6004] = "stopBGM";
    AudioEvent[AudioEvent["changeConfig"] = 6005] = "changeConfig";
    AudioEvent[AudioEvent["pause"] = 6006] = "pause";
    AudioEvent[AudioEvent["resume"] = 6007] = "resume";
})(AudioEvent || (AudioEvent = {}));
/**阿拉丁数据统计事件 */
var ALDEvent;
(function (ALDEvent) {
    ALDEvent[ALDEvent["startIndex"] = 7000] = "startIndex";
    ALDEvent[ALDEvent["levelStart"] = 7001] = "levelStart";
    ALDEvent[ALDEvent["levelWin"] = 7002] = "levelWin";
    ALDEvent[ALDEvent["levelLose"] = 7003] = "levelLose";
    ALDEvent[ALDEvent["levelExit"] = 7004] = "levelExit";
})(ALDEvent || (ALDEvent = {}));
/**互推相关事件 */
var RecommendEvent;
(function (RecommendEvent) {
    RecommendEvent[RecommendEvent["startIndex"] = 8000] = "startIndex";
    RecommendEvent[RecommendEvent["assetLoadFinish"] = 8001] = "assetLoadFinish";
    RecommendEvent[RecommendEvent["clickRecommendItem"] = 8002] = "clickRecommendItem";
    RecommendEvent[RecommendEvent["clickBtnRecommend_TT"] = 8003] = "clickBtnRecommend_TT";
    RecommendEvent[RecommendEvent["hideRecommend"] = 8004] = "hideRecommend";
    RecommendEvent[RecommendEvent["openDrawer"] = 8005] = "openDrawer";
    RecommendEvent[RecommendEvent["drawerStartOpen"] = 8006] = "drawerStartOpen";
    RecommendEvent[RecommendEvent["drawerOpened"] = 8007] = "drawerOpened";
    RecommendEvent[RecommendEvent["closeDrawer"] = 8008] = "closeDrawer";
    RecommendEvent[RecommendEvent["drawerStartClose"] = 8009] = "drawerStartClose";
    RecommendEvent[RecommendEvent["drawerClosed"] = 8010] = "drawerClosed";
})(RecommendEvent || (RecommendEvent = {}));
/**玩家资产事件 */
var AssetEvent;
(function (AssetEvent) {
    AssetEvent[AssetEvent["startIndex"] = 9000] = "startIndex";
    AssetEvent[AssetEvent["powerChanged"] = 9001] = "powerChanged";
    AssetEvent[AssetEvent["powerUnEnough"] = 9002] = "powerUnEnough";
    AssetEvent[AssetEvent["consumePower"] = 9003] = "consumePower";
    AssetEvent[AssetEvent["getPower"] = 9004] = "getPower";
})(AssetEvent || (AssetEvent = {}));
/**后台开关事件，从10000开始 */
var AdvertSwitchEvent;
(function (AdvertSwitchEvent) {
    AdvertSwitchEvent[AdvertSwitchEvent["startIndex"] = 10000] = "startIndex";
    AdvertSwitchEvent[AdvertSwitchEvent["loadConfigSuccess"] = 10001] = "loadConfigSuccess";
    AdvertSwitchEvent[AdvertSwitchEvent["changeScene"] = 10002] = "changeScene";
    AdvertSwitchEvent[AdvertSwitchEvent["closeFullRecommend"] = 10003] = "closeFullRecommend";
    AdvertSwitchEvent[AdvertSwitchEvent["onBtnFadeExit"] = 10004] = "onBtnFadeExit";
})(AdvertSwitchEvent || (AdvertSwitchEvent = {}));
/**触摸控制器事件，适用于只有一个节点接收触摸操作的场景，从11000开始 */
var CtrlEvent;
(function (CtrlEvent) {
    CtrlEvent[CtrlEvent["startIndex"] = 11000] = "startIndex";
    CtrlEvent[CtrlEvent["ctrlStart"] = 11001] = "ctrlStart";
    CtrlEvent[CtrlEvent["ctrlEnd"] = 11002] = "ctrlEnd";
    CtrlEvent[CtrlEvent["touchStart"] = 11003] = "touchStart";
    CtrlEvent[CtrlEvent["touchMove"] = 11004] = "touchMove";
    CtrlEvent[CtrlEvent["touchEnd"] = 11005] = "touchEnd";
    CtrlEvent[CtrlEvent["touchStay"] = 11006] = "touchStay";
})(CtrlEvent || (CtrlEvent = {}));
/**商城相关事件，从12000开始 */
var ShopEvent;
(function (ShopEvent) {
    ShopEvent[ShopEvent["startIndex"] = 12000] = "startIndex";
    ShopEvent[ShopEvent["chooseItem"] = 12001] = "chooseItem";
    ShopEvent[ShopEvent["changeDisplayItem"] = 12002] = "changeDisplayItem";
})(ShopEvent || (ShopEvent = {}));
/**乐游SDK专属事件，从13000开始 */
var LeYouRecommend;
(function (LeYouRecommend) {
    LeYouRecommend[LeYouRecommend["startIndex"] = 13000] = "startIndex";
    /**底部猜你喜欢互推 */
    LeYouRecommend[LeYouRecommend["showMoreGameByBanner"] = 13001] = "showMoreGameByBanner";
    /**单个图标的互推 */
    LeYouRecommend[LeYouRecommend["showMoreGameByIcon"] = 13002] = "showMoreGameByIcon";
    /**更多游戏互推 */
    LeYouRecommend[LeYouRecommend["showMoreGame"] = 13003] = "showMoreGame";
    /**侧边栏互推 */
    LeYouRecommend[LeYouRecommend["showMoreGameSide"] = 13004] = "showMoreGameSide";
    /**中间水平滚动的互推 */
    LeYouRecommend[LeYouRecommend["showMoreGameMiddle"] = 13005] = "showMoreGameMiddle";
})(LeYouRecommend || (LeYouRecommend = {}));
/**数据统计事件，从14000开始 */
var TongJi;
(function (TongJi) {
    TongJi[TongJi["startIndex"] = 14000] = "startIndex";
    /**用户事件漏斗（进区服事件） */
    TongJi[TongJi["appOnce"] = 14001] = "appOnce";
    /**分享出日志 */
    TongJi[TongJi["sharedOut"] = 14002] = "sharedOut";
    /**通过分享进入 */
    TongJi[TongJi["sharedIn"] = 14003] = "sharedIn";
    /**视频广告事件 */
    TongJi[TongJi["video"] = 14004] = "video";
    /**升级 */
    TongJi[TongJi["levelUp"] = 14005] = "levelUp";
    /**完成任务 */
    TongJi[TongJi["task"] = 14006] = "task";
    /**自定义行为 */
    TongJi[TongJi["action"] = 14007] = "action";
    /**充值 */
    TongJi[TongJi["pay"] = 14008] = "pay";
    /**money日志 */
    TongJi[TongJi["money"] = 14009] = "money";
    /**道具 */
    TongJi[TongJi["item"] = 14010] = "item";
    /**闯关 */
    TongJi[TongJi["battle"] = 14011] = "battle";
    /**装备日志 */
    TongJi[TongJi["equip"] = 14012] = "equip";
    /**装备升级 */
    TongJi[TongJi["equipLevel"] = 14013] = "equipLevel";
    /**装备升阶 */
    TongJi[TongJi["equipDegree"] = 14014] = "equipDegree";
    /**装备玩法 */
    TongJi[TongJi["equipPlayWay"] = 14015] = "equipPlayWay";
    /**自定义事件 */
    TongJi[TongJi["event"] = 14016] = "event";
    /**清除云存储数据 */
    TongJi[TongJi["clear"] = 14017] = "clear";
    /**广告错误日志 */
    TongJi[TongJi["error"] = 14018] = "error";
    /**解锁皮肤事件 */
    TongJi[TongJi["unlockSkin"] = 14019] = "unlockSkin";
})(TongJi || (TongJi = {}));
/**柚子互推专属事件，从15000开始 */
var YouZiRecommend;
(function (YouZiRecommend) {
    YouZiRecommend[YouZiRecommend["startIndex"] = 15000] = "startIndex";
    /**显示全屏落地推广页 */
    YouZiRecommend[YouZiRecommend["showFullScreenIcon"] = 15001] = "showFullScreenIcon";
    /**显示游戏合集 */
    YouZiRecommend[YouZiRecommend["showYouziGameCollectionPage"] = 15002] = "showYouziGameCollectionPage";
})(YouZiRecommend || (YouZiRecommend = {}));
/**
 * 适用于框架的通用事件类型
 *
 * 在子类中添加游戏专属的事件时， startIndex 从 100000 开始
 */
var CommonEventType = /** @class */ (function () {
    function CommonEventType() {
    }
    CommonEventType.DirectorEvent = DirectorEvent;
    CommonEventType.LoadAssetEvent = LoadAssetEvent;
    CommonEventType.PlayerDataEvent = PlayerDataEvent;
    CommonEventType.SDKEvent = SDKEvent;
    CommonEventType.UIEvent = UIEvent;
    CommonEventType.AudioEvent = AudioEvent;
    CommonEventType.ALDEvent = ALDEvent;
    CommonEventType.RecommendEvent = RecommendEvent;
    CommonEventType.AssetEvent = AssetEvent;
    CommonEventType.AdvertSwitchEvent = AdvertSwitchEvent;
    CommonEventType.CtrlEvent = CtrlEvent;
    CommonEventType.ShopEvent = ShopEvent;
    CommonEventType.LeYouRecommend = LeYouRecommend;
    CommonEventType.TongJi = TongJi;
    CommonEventType.YouZiRecommend = YouZiRecommend;
    return CommonEventType;
}());
exports.default = CommonEventType;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXENvbW1vbkV2ZW50VHlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLHlCQUF5QjtBQUN6QixJQUFLLGFBZ0JKO0FBaEJELFdBQUssYUFBYTtJQUNkLGdFQUFpQixDQUFBO0lBQ2pCLGdFQUFVLENBQUE7SUFDVixzRUFBYSxDQUFBO0lBQ2IsOERBQVMsQ0FBQTtJQUNULGdFQUFVLENBQUE7SUFDViw0RUFBZ0IsQ0FBQTtJQUNoQiw4REFBUyxDQUFBO0lBQ1Qsc0VBQWEsQ0FBQTtJQUNiLHdFQUFjLENBQUE7SUFDZCw4REFBUyxDQUFBO0lBQ1QsZ0VBQVUsQ0FBQTtJQUNWLGdFQUFVLENBQUE7SUFDVixrRUFBVyxDQUFBO0lBQ1gsOEVBQWlCLENBQUE7SUFDakIsa0ZBQW1CLENBQUE7QUFDdkIsQ0FBQyxFQWhCSSxhQUFhLEtBQWIsYUFBYSxRQWdCakI7QUFDRCx3QkFBd0I7QUFDeEIsSUFBSyxjQUtKO0FBTEQsV0FBSyxjQUFjO0lBQ2Ysa0VBQWlCLENBQUE7SUFDakIsc0VBQVksQ0FBQTtJQUNaLHNFQUFZLENBQUE7SUFDWiwwRUFBYyxDQUFBO0FBQ2xCLENBQUMsRUFMSSxjQUFjLEtBQWQsY0FBYyxRQUtsQjtBQUNELHdCQUF3QjtBQUN4QixJQUFLLGVBS0o7QUFMRCxXQUFLLGVBQWU7SUFDaEIsb0VBQWlCLENBQUE7SUFDakIsZ0ZBQWdCLENBQUE7SUFDaEIsa0ZBQWlCLENBQUE7SUFDakIsb0VBQVUsQ0FBQTtBQUNkLENBQUMsRUFMSSxlQUFlLEtBQWYsZUFBZSxRQUtuQjtBQUNELGFBQWE7QUFDYixJQUFLLFFBMENKO0FBMUNELFdBQUssUUFBUTtJQUNULHNEQUFpQixDQUFBO0lBQ2pCLGdEQUFPLENBQUE7SUFDUCxvREFBUyxDQUFBO0lBQ1Qsc0RBQVUsQ0FBQTtJQUNWLHNEQUFVLENBQUE7SUFDVixrRUFBZ0IsQ0FBQTtJQUNoQiwwREFBWSxDQUFBO0lBQ1osd0RBQVcsQ0FBQTtJQUNYLHdEQUFXLENBQUE7SUFDWCwwREFBWSxDQUFBO0lBQ1osc0RBQVUsQ0FBQTtJQUNWLHdEQUFXLENBQUE7SUFDWCx3REFBVyxDQUFBO0lBQ1gsd0RBQVcsQ0FBQTtJQUNYLDBEQUFZLENBQUE7SUFDWiw0RUFBcUIsQ0FBQTtJQUNyQiwwREFBWSxDQUFBO0lBQ1osd0RBQVcsQ0FBQTtJQUNYLDBDQUFJLENBQUE7SUFDSiwwQ0FBSSxDQUFBO0lBQ0osOEVBQXNCLENBQUE7SUFDdEIsb0RBQVMsQ0FBQTtJQUNULDBEQUFZLENBQUE7SUFDWiwwREFBWSxDQUFBO0lBQ1osZ0VBQWUsQ0FBQTtJQUNmLG9FQUFpQixDQUFBO0lBQ2pCLG9FQUFpQixDQUFBO0lBRWpCLGlCQUFpQjtJQUNqQixzRUFBa0IsQ0FBQTtJQUNsQixnRUFBZSxDQUFBO0lBQ2Ysa0VBQWdCLENBQUE7SUFDaEIsOEVBQXNCLENBQUE7SUFDdEIsd0VBQW1CLENBQUE7SUFDbkIsMEVBQW9CLENBQUE7SUFFcEIsT0FBTztJQUNQLHNEQUFVLENBQUE7SUFDVix3REFBVyxDQUFBO0lBQ1gsMERBQVksQ0FBQTtJQUNaLDBEQUFZLENBQUE7QUFDaEIsQ0FBQyxFQTFDSSxRQUFRLEtBQVIsUUFBUSxRQTBDWjtBQUNELFlBQVk7QUFDWixJQUFLLE9BWUo7QUFaRCxXQUFLLE9BQU87SUFDUixvREFBaUIsQ0FBQTtJQUNqQix3REFBWSxDQUFBO0lBQ1osb0VBQWtCLENBQUE7SUFDbEIsOENBQU8sQ0FBQTtJQUNQLDBEQUFhLENBQUE7SUFDYiwwREFBYSxDQUFBO0lBRWIsMENBQUssQ0FBQTtJQUNMLDhDQUFPLENBQUE7SUFDUCx3Q0FBSSxDQUFBO0lBQ0osNENBQU0sQ0FBQTtBQUNWLENBQUMsRUFaSSxPQUFPLEtBQVAsT0FBTyxRQVlYO0FBQ0QsVUFBVTtBQUNWLElBQUssVUFTSjtBQVRELFdBQUssVUFBVTtJQUNYLDBEQUFpQixDQUFBO0lBQ2pCLG9EQUFPLENBQUE7SUFDUCwwREFBVSxDQUFBO0lBQ1YsOERBQVksQ0FBQTtJQUNaLG9EQUFPLENBQUE7SUFDUCw4REFBWSxDQUFBO0lBQ1osZ0RBQUssQ0FBQTtJQUNMLGtEQUFNLENBQUE7QUFDVixDQUFDLEVBVEksVUFBVSxLQUFWLFVBQVUsUUFTZDtBQUNELGVBQWU7QUFDZixJQUFLLFFBTUo7QUFORCxXQUFLLFFBQVE7SUFDVCxzREFBaUIsQ0FBQTtJQUNqQixzREFBVSxDQUFBO0lBQ1Ysa0RBQVEsQ0FBQTtJQUNSLG9EQUFTLENBQUE7SUFDVCxvREFBUyxDQUFBO0FBQ2IsQ0FBQyxFQU5JLFFBQVEsS0FBUixRQUFRLFFBTVo7QUFDRCxZQUFZO0FBQ1osSUFBSyxjQWNKO0FBZEQsV0FBSyxjQUFjO0lBQ2Ysa0VBQWlCLENBQUE7SUFDakIsNEVBQWUsQ0FBQTtJQUNmLGtGQUFrQixDQUFBO0lBQ2xCLHNGQUFvQixDQUFBO0lBQ3BCLHdFQUFhLENBQUE7SUFFYixrRUFBVSxDQUFBO0lBQ1YsNEVBQWUsQ0FBQTtJQUNmLHNFQUFZLENBQUE7SUFFWixvRUFBVyxDQUFBO0lBQ1gsOEVBQWdCLENBQUE7SUFDaEIsc0VBQVksQ0FBQTtBQUNoQixDQUFDLEVBZEksY0FBYyxLQUFkLGNBQWMsUUFjbEI7QUFDRCxZQUFZO0FBQ1osSUFBSyxVQU1KO0FBTkQsV0FBSyxVQUFVO0lBQ1gsMERBQWlCLENBQUE7SUFDakIsOERBQVksQ0FBQTtJQUNaLGdFQUFhLENBQUE7SUFDYiw4REFBWSxDQUFBO0lBQ1osc0RBQVEsQ0FBQTtBQUNaLENBQUMsRUFOSSxVQUFVLEtBQVYsVUFBVSxRQU1kO0FBQ0QscUJBQXFCO0FBQ3JCLElBQUssaUJBT0o7QUFQRCxXQUFLLGlCQUFpQjtJQUNsQix5RUFBa0IsQ0FBQTtJQUVsQix1RkFBaUIsQ0FBQTtJQUNqQiwyRUFBVyxDQUFBO0lBQ1gseUZBQWtCLENBQUE7SUFDbEIsK0VBQWEsQ0FBQTtBQUNqQixDQUFDLEVBUEksaUJBQWlCLEtBQWpCLGlCQUFpQixRQU9yQjtBQUNELHlDQUF5QztBQUN6QyxJQUFLLFNBU0o7QUFURCxXQUFLLFNBQVM7SUFDVix5REFBa0IsQ0FBQTtJQUNsQix1REFBUyxDQUFBO0lBQ1QsbURBQU8sQ0FBQTtJQUVQLHlEQUFVLENBQUE7SUFDVix1REFBUyxDQUFBO0lBQ1QscURBQVEsQ0FBQTtJQUNSLHVEQUFTLENBQUE7QUFDYixDQUFDLEVBVEksU0FBUyxLQUFULFNBQVMsUUFTYjtBQUNELHFCQUFxQjtBQUNyQixJQUFLLFNBTUo7QUFORCxXQUFLLFNBQVM7SUFDVix5REFBa0IsQ0FBQTtJQUVsQix5REFBVSxDQUFBO0lBRVYsdUVBQWlCLENBQUE7QUFDckIsQ0FBQyxFQU5JLFNBQVMsS0FBVCxTQUFTLFFBTWI7QUFDRCx3QkFBd0I7QUFDeEIsSUFBSyxjQVlKO0FBWkQsV0FBSyxjQUFjO0lBQ2YsbUVBQWtCLENBQUE7SUFDbEIsY0FBYztJQUNkLHVGQUFvQixDQUFBO0lBQ3BCLGFBQWE7SUFDYixtRkFBa0IsQ0FBQTtJQUNsQixZQUFZO0lBQ1osdUVBQVksQ0FBQTtJQUNaLFdBQVc7SUFDWCwrRUFBZ0IsQ0FBQTtJQUNoQixlQUFlO0lBQ2YsbUZBQWtCLENBQUE7QUFDdEIsQ0FBQyxFQVpJLGNBQWMsS0FBZCxjQUFjLFFBWWxCO0FBQ0QscUJBQXFCO0FBQ3JCLElBQUssTUF3Q0o7QUF4Q0QsV0FBSyxNQUFNO0lBQ1AsbURBQWtCLENBQUE7SUFDbEIsbUJBQW1CO0lBQ25CLDZDQUFPLENBQUE7SUFDUCxXQUFXO0lBQ1gsaURBQVMsQ0FBQTtJQUNULFlBQVk7SUFDWiwrQ0FBUSxDQUFBO0lBQ1IsWUFBWTtJQUNaLHlDQUFLLENBQUE7SUFDTCxRQUFRO0lBQ1IsNkNBQU8sQ0FBQTtJQUNQLFVBQVU7SUFDVix1Q0FBSSxDQUFBO0lBQ0osV0FBVztJQUNYLDJDQUFNLENBQUE7SUFDTixRQUFRO0lBQ1IscUNBQUcsQ0FBQTtJQUNILGFBQWE7SUFDYix5Q0FBSyxDQUFBO0lBQ0wsUUFBUTtJQUNSLHVDQUFJLENBQUE7SUFDSixRQUFRO0lBQ1IsMkNBQU0sQ0FBQTtJQUNOLFVBQVU7SUFDVix5Q0FBSyxDQUFBO0lBQ0wsVUFBVTtJQUNWLG1EQUFVLENBQUE7SUFDVixVQUFVO0lBQ1YscURBQVcsQ0FBQTtJQUNYLFVBQVU7SUFDVix1REFBWSxDQUFBO0lBQ1osV0FBVztJQUNYLHlDQUFLLENBQUE7SUFDTCxhQUFhO0lBQ2IseUNBQUssQ0FBQTtJQUNMLFlBQVk7SUFDWix5Q0FBSyxDQUFBO0lBQ0wsWUFBWTtJQUNaLG1EQUFVLENBQUE7QUFDZCxDQUFDLEVBeENJLE1BQU0sS0FBTixNQUFNLFFBd0NWO0FBRUQsdUJBQXVCO0FBQ3ZCLElBQUssY0FNSjtBQU5ELFdBQUssY0FBYztJQUNmLG1FQUFrQixDQUFBO0lBQ2xCLGVBQWU7SUFDZixtRkFBa0IsQ0FBQTtJQUNsQixZQUFZO0lBQ1oscUdBQTJCLENBQUE7QUFDL0IsQ0FBQyxFQU5JLGNBQWMsS0FBZCxjQUFjLFFBTWxCO0FBQ0Q7Ozs7R0FJRztBQUNIO0lBQUE7SUFnQkEsQ0FBQztJQWZVLDZCQUFhLEdBQUcsYUFBYSxDQUFDO0lBQzlCLDhCQUFjLEdBQUcsY0FBYyxDQUFDO0lBQ2hDLCtCQUFlLEdBQUcsZUFBZSxDQUFDO0lBQ2xDLHdCQUFRLEdBQUcsUUFBUSxDQUFDO0lBQ3BCLHVCQUFPLEdBQUcsT0FBTyxDQUFDO0lBQ2xCLDBCQUFVLEdBQUcsVUFBVSxDQUFDO0lBQ3hCLHdCQUFRLEdBQUcsUUFBUSxDQUFDO0lBQ3BCLDhCQUFjLEdBQUcsY0FBYyxDQUFDO0lBQ2hDLDBCQUFVLEdBQUcsVUFBVSxDQUFDO0lBQ3hCLGlDQUFpQixHQUFHLGlCQUFpQixDQUFDO0lBQ3RDLHlCQUFTLEdBQUcsU0FBUyxDQUFDO0lBQ3RCLHlCQUFTLEdBQUcsU0FBUyxDQUFDO0lBQ3RCLDhCQUFjLEdBQUcsY0FBYyxDQUFDO0lBQ2hDLHNCQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ2hCLDhCQUFjLEdBQUcsY0FBYyxDQUFDO0lBQzNDLHNCQUFDO0NBaEJELEFBZ0JDLElBQUE7a0JBaEJvQixlQUFlIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi8qKua4uOaIj+a1geeoi+ebuOWFs+eahOS6i+S7tizku44gMTAwMCDlvIDlp4sgKi9cclxuZW51bSBEaXJlY3RvckV2ZW50IHtcclxuICAgIHN0YXJ0SW5kZXggPSAxMDAwLFxyXG4gICAgZW50ZXJMb2JieSwgICAgICAgICAgICAgLy/ov5vlhaXmuLjmiI/lpKfljoUo6aaW6aG1KVxyXG4gICAgaGlkZUdhbWVMb2JieSwgICAgICAgICAgLy/pmpDol4/pppbpobVcclxuICAgIHN0YXJ0R2FtZSwgICAgICAgICAgICAgIC8v5byA5aeL5ri45oiP77yI54K55Ye76aaW6aG15oyJ6ZKu4oCc5byA5aeL5ri45oiP4oCd77yJXHJcbiAgICBzdGFydExldmVsLCAgICAgICAgICAgICAvL+W8gOWni+WFs+WNoVxyXG4gICAgZW50ZXJDaG9zZWRMZXZlbCwgICAgICAgLy/ov5vlhaXpgInmi6nnmoTlhbPljaFcclxuICAgIGV4aXRMZXZlbCwgICAgICAgICAgICAgIC8v6YCA5Ye65YWz5Y2hXHJcbiAgICBwbGF5TmV4dExldmVsLCAgICAgICAgICAvL+e7p+e7reS4i+S4gOWFs1xyXG4gICAgcmVwbGF5Q3VyTGV2ZWwsICAgICAgICAgLy/ph43njqnlvZPliY3lhbNcclxuICAgIHBsYXllcldpbiwgICAgICAgICAgICAgIC8v5YWz5Y2h6IOc5YipXHJcbiAgICBwbGF5ZXJMb3NlLCAgICAgICAgICAgICAvL+WFs+WNoeWksei0pVxyXG4gICAgcGF1c2VMZXZlbCwgICAgICAgICAgICAgLy/mmoLlgZzmuLjmiI9cclxuICAgIHJlc3VtZUxldmVsLCAgICAgICAgICAgIC8v5oGi5aSN5ri45oiPXHJcbiAgICBtYXRjaFBsYXllckZpbmlzaCwgICAgICAvL+eOqeWutuWMuemFjeWujOaIkFxyXG4gICAgY2hvb3NlVHJ5U2tpbkZpbmlzaCwgICAgLy/pgInmi6nor5XnlKjnmq7ogqTnu5PmnZ9cclxufVxyXG4vKirotYTmupDliqDovb3nm7jlhbPkuovku7bvvIzku44gMjAwMCDlvIDlp4sgKi9cclxuZW51bSBMb2FkQXNzZXRFdmVudCB7XHJcbiAgICBzdGFydEluZGV4ID0gMjAwMCxcclxuICAgIHNob3dQcm9ncmVzcywgICAgICAgICAgIC8v5pi+56S66LWE5rqQ5Yqg6L296L+b5bqmXHJcbiAgICBoaWRlUHJvZ3Jlc3MsICAgICAgICAgICAvL+makOiXj+i1hOa6kOWKoOi9vei/m+W6plxyXG4gICAgdXBkYXRlUHJvZ3Jlc3MsICAgICAgICAgLy/mm7TmlrDotYTmupDliqDovb3ov5vluqZcclxufVxyXG4vKirmuLjmiI/mlbDmja7nm7jlhbPkuovku7bvvIzku44gMzAwMCDlvIDlp4sgKi9cclxuZW51bSBQbGF5ZXJEYXRhRXZlbnQge1xyXG4gICAgc3RhcnRJbmRleCA9IDMwMDAsXHJcbiAgICB1cGRhdGVQbGF5ZXJEYXRhLCAgICAgICAvL+S/ruaUueeOqeWutuaVsOaNrlxyXG4gICAgcGxheWVyRGF0YUNoYW5nZWQsICAgICAgLy/njqnlrrbmlbDmja7mnInlj5jliqhcclxuICAgIHRyeVNraW5FbmQsICAgICAgICAgICAgIC8v55qu6IKk6K+V55So57uT5p2fXHJcbn1cclxuLyoqU0RL55u45YWz5LqL5Lu2ICovXHJcbmVudW0gU0RLRXZlbnQge1xyXG4gICAgc3RhcnRJbmRleCA9IDQwMDAsXHJcbiAgICBzaG93TXNnLFxyXG4gICAgc2hvd1ZpZGVvLCAgICAgICAgICAvL+a/gOWKseinhumikVxyXG4gICAgc2hvd0Jhbm5lcixcclxuICAgIGhpZGVCYW5uZXIsXHJcbiAgICBzaG93QmFubmVyRmluaXNoLCAgICAgICAvL2Jhbm5lcuaYvuekuuaIkOWKn1xyXG4gICAgc2hvd0luc2VydEFkLCAgICAgICAgICAgLy/mj5LlsY/lub/lkYpcclxuICAgIHN0YXJ0UmVjb3JkLCAgICAgICAgICAgIC8v5aS05p2h77ya5byA5aeL5b2V5bGPXHJcbiAgICBwYXVzZVJlY29yZCwgICAgICAgICAgICAvL+WktOadoe+8muaaguWBnOW9leWxj1xyXG4gICAgcmVzdW1lUmVjb3JkLCAgICAgICAgICAgLy/lpLTmnaHvvJrnu6fnu63lvZXlsY9cclxuICAgIHN0b3BSZWNvcmQsICAgICAgICAgICAgIC8v5aS05p2h77ya57uT5p2f5b2V5bGPXHJcbiAgICByZWNvcmRTYXZlZCwgICAgICAgICAgICAvL+WktOadoe+8muW9leWItuinhumikeS/neWtmOaIkOWKn1xyXG4gICAgcmVjb3JkRXJyb3IsICAgICAgICAgICAgLy/lpLTmnaHvvJrlvZXlsY/plJnor69cclxuICAgIHNoYXJlUmVjb3JkLCAgICAgICAgICAgIC8v5aS05p2h77ya5YiG5Lqr5b2V5bGPXHJcbiAgICBiYW5uZXJSZXNpemUsICAgICAgICAgICAvL+W6lemDqOW5v+WRiuagj+WwuuWvuOabtOaWsO+8jOS8oOmAkuWPguaVsO+8muW5v+WRiuagj+mhtumDqOS4juWxj+W5leW6lemDqOeahOi3neemu1xyXG4gICAgbmF2aWdhdGVUb01pbmlQcm9ncmFtLCAgLy/ot7PovazliLDlhbbku5blsI/muLjmiI9cclxuICAgIHZpYnJhdGVTaG9ydCwgICAgICAgICAgIC8v55+t6ZyH5YqoXHJcbiAgICB2aWJyYXRlTG9uZywgICAgICAgICAgICAvL+mVv+mch+WKqFxyXG4gICAgaGlkZSwgICAgICAgICAgICAgICAgICAgLy/muLjmiI/ov5vlhaXlkI7lj7BcclxuICAgIHNob3csICAgICAgICAgICAgICAgICAgIC8v5ZCO5Y+w5Zue5Yiw5ri45oiPXHJcbiAgICBzaG93SW5zZXJ0QnlQYXVzZUxldmVsLCAvL+aaguWBnOa4uOaIj++8jOaYvuekuuaPkuWxjyjkuZDmuLhTREvlsIblr7nlhbbljZXni6zlpITnkIYpXHJcbiAgICB0cmlnZ2VyR0MsICAgICAgICAgICAgICAvL+Weg+WcvuWbnuaUtlxyXG4gICAgc2hvd05hdGl2ZUFkLCAgICAgICAgICAgLy/mmL7npLrljp/nlJ/lub/lkYrvvIzpnIDopoHkvKDlhaXniLboioLngrnlj4rlhbbku5blj4LmlbBcclxuICAgIGhpZGVOYXRpdmVBZCxcclxuICAgIGhpZGVBbGxOYXRpdmVBZCxcclxuICAgIHF1aWNrU2hvd05hdGl2ZUFkLFxyXG4gICAgcXVpY2tIaWRlTmF0aXZlQWQsXHJcblxyXG4gICAgLy/lronljZMv6Iu55p6c56uv5Y6f55Sf5YyFU0RL5LqL5Lu277yaXHJcbiAgICBjYWxsSlNWaWRlb1N1Y2Nlc3MsICAgICAvL+WOn+eUn+Wbnuiwg++8muinhumikeingueci+aIkOWKn1xyXG4gICAgY2FsbEpTVmlkZW9GYWlsLCAgICAgICAgLy/ljp/nlJ/lm57osIPvvJrop4bpopHop4LnnIvmnKrlrozmiJBcclxuICAgIGNhbGxKU1ZpZGVvRXJyb3IsICAgICAgIC8v5Y6f55Sf5Zue6LCD77ya6KeG6aKR5Yqg6L296ZSZ6K+vXHJcbiAgICBjYWxsSlNGdWxsVmlkZW9TdWNjZXNzLCAvL+WOn+eUn+Wbnuiwg++8muWFqOWxj+inhumikeingueci+aIkOWKn1xyXG4gICAgY2FsbEpTRnVsbFZpZGVvRmFpbCwgICAgLy/ljp/nlJ/lm57osIPvvJrlhajlsY/op4bpopHop4LnnIvmnKrlrozmiJBcclxuICAgIGNhbGxKU0Z1bGxWaWRlb0Vycm9yLCAgIC8v5Y6f55Sf5Zue6LCD77ya5YWo5bGP6KeG6aKR5Yqg6L296ZSZ6K+vXHJcblxyXG4gICAgLy9RUeW5s+WPsO+8mlxyXG4gICAgc2hvd0FwcEJveCwgICAgICAgICAgICAgLy/nm5LlrZDlub/lkYpcclxuICAgIHNob3dCbG9ja0FkLCAgICAgICAgICAgIC8v56ev5pyo5bm/5ZGKXHJcbiAgICBzdWJzY3JpYmVNc2csICAgICAgICAgICAvL+iuoumYhVxyXG4gICAgYWRkQ29sb3JTaWduLCAgICAgICAgICAgLy/mt7vliqDlvannrb5cclxufVxyXG4vKipVSeebuOWFs+S6i+S7tiAqL1xyXG5lbnVtIFVJRXZlbnQge1xyXG4gICAgc3RhcnRJbmRleCA9IDUwMDAsXHJcbiAgICBwbGF5R29sZEFuaW0sICAgICAgICAgICAvL+W+l+WIsOmHkeW4geWKqOeUu1xyXG4gICAgZ29sZEFuaW1QbGF5RmluaXNoLCAgICAgLy/ph5HluIHliqjnlLvmkq3mlL7lrozmr5VcclxuICAgIHNob3dUaXAsICAgICAgICAgICAgICAgIC8v5pi+56S65o+Q56S65L+h5oGvXHJcbiAgICBzaG93VG91Y2hNYXNrLCAgICAgICAgICAvL+aYvuekuuinpuaRuOmBrue9qe+8jOWxj+iUveeOqeWutuinpuaRuOaTjeS9nFxyXG4gICAgaGlkZVRvdWNoTWFzaywgICAgICAgICAgLy/pmpDol4/op6bmkbjpga7nvalcclxuXHJcbiAgICBlbnRlciwgICAgICAgICAgICAgICAgICAvL+ivt+axgui/m+WFpVVJ77yM5Lyg6YCS5Y+C5pWwVUnnsbvlnotcclxuICAgIGVudGVyZWQsICAgICAgICAgICAgICAgIC8v5bey6L+b5YWlVUlcclxuICAgIGV4aXQsICAgICAgICAgICAgICAgICAgIC8v6K+35rGC6YCA5Ye6VUlcclxuICAgIGV4aXRlZCwgICAgICAgICAgICAgICAgIC8v5bey6YCA5Ye6VUlcclxufVxyXG4vKirpn7PmlYjkuovku7YgKi9cclxuZW51bSBBdWRpb0V2ZW50IHtcclxuICAgIHN0YXJ0SW5kZXggPSA2MDAwLFxyXG4gICAgcGxheUJHTSxcclxuICAgIHBsYXlFZmZlY3QsXHJcbiAgICBwbGF5Q2xpY2tCdG4sXHJcbiAgICBzdG9wQkdNLFxyXG4gICAgY2hhbmdlQ29uZmlnLFxyXG4gICAgcGF1c2UsXHJcbiAgICByZXN1bWUsXHJcbn1cclxuLyoq6Zi/5ouJ5LiB5pWw5o2u57uf6K6h5LqL5Lu2ICovXHJcbmVudW0gQUxERXZlbnQge1xyXG4gICAgc3RhcnRJbmRleCA9IDcwMDAsXHJcbiAgICBsZXZlbFN0YXJ0LCAgICAgICAgIC8v5YWz5Y2h5byA5aeLXHJcbiAgICBsZXZlbFdpbiwgICAgICAgICAgIC8v5YWz5Y2h5oiQ5YqfXHJcbiAgICBsZXZlbExvc2UsICAgICAgICAgIC8v5YWz5Y2h5aSx6LSlXHJcbiAgICBsZXZlbEV4aXQsICAgICAgICAgIC8v5Lit6YCU6YCA5Ye6XHJcbn1cclxuLyoq5LqS5o6o55u45YWz5LqL5Lu2ICovXHJcbmVudW0gUmVjb21tZW5kRXZlbnQge1xyXG4gICAgc3RhcnRJbmRleCA9IDgwMDAsXHJcbiAgICBhc3NldExvYWRGaW5pc2gsICAgICAgIC8v5LqS5o6o6YWN572u6KGo5Yqg6L295a6M5oiQXHJcbiAgICBjbGlja1JlY29tbWVuZEl0ZW0sICAgICAvL+eCueWHu+S6huWFtuS7lua4uOaIj2ljb25cclxuICAgIGNsaWNrQnRuUmVjb21tZW5kX1RULCAgIC8v54K55Ye75aS05p2h5bmz5Y+w55qE5pu05aSa5ri45oiP5oyJ6ZKuXHJcbiAgICBoaWRlUmVjb21tZW5kLCAgICAgICAgICAvL+makOiXj+S6kuaOqOWGheWuuVxyXG5cclxuICAgIG9wZW5EcmF3ZXIsICAgICAgICAgICAgIC8v5omT5byA5oq95bGJXHJcbiAgICBkcmF3ZXJTdGFydE9wZW4sICAgICAgICAvL+aKveWxieW8gOWni+aJk+W8gOWKqOeUu1xyXG4gICAgZHJhd2VyT3BlbmVkLCAgICAgICAgICAgLy/mir3lsYnlt7LmiZPlvIBcclxuXHJcbiAgICBjbG9zZURyYXdlciwgICAgICAgICAgICAvL+WFs+mXreaKveWxiVxyXG4gICAgZHJhd2VyU3RhcnRDbG9zZSwgICAgICAgLy/mir3lsYnlvIDlp4vlhbPpl63liqjnlLtcclxuICAgIGRyYXdlckNsb3NlZCwgICAgICAgICAgIC8v5oq95bGJ5bey5YWz6ZetXHJcbn1cclxuLyoq546p5a626LWE5Lqn5LqL5Lu2ICovXHJcbmVudW0gQXNzZXRFdmVudCB7XHJcbiAgICBzdGFydEluZGV4ID0gOTAwMCxcclxuICAgIHBvd2VyQ2hhbmdlZCwgICAgICAgLy/kvZPlipvlgLzlj5jljJZcclxuICAgIHBvd2VyVW5Fbm91Z2gsICAgICAgLy/kvZPlipvkuI3otrPmj5DnpLpcclxuICAgIGNvbnN1bWVQb3dlciwgICAgICAgLy/or7fmsYLmtojogJfkvZPlipvmiafooYzmn5DkuotcclxuICAgIGdldFBvd2VyLCAgICAgICAgICAgLy/lvpfliLDkvZPlipvlpZblirFcclxufVxyXG4vKirlkI7lj7DlvIDlhbPkuovku7bvvIzku44xMDAwMOW8gOWniyAqL1xyXG5lbnVtIEFkdmVydFN3aXRjaEV2ZW50IHtcclxuICAgIHN0YXJ0SW5kZXggPSAxMDAwMCxcclxuXHJcbiAgICBsb2FkQ29uZmlnU3VjY2VzcywgIC8v5ZCO5Y+w6YWN572u5ouJ5Y+W5oiQ5YqfXHJcbiAgICBjaGFuZ2VTY2VuZSwgICAgICAgIC8v5Zy65pmv5YiH5o2i77yI5pi+56S65YWo5bGP5LqS5o6o6IqC54K55bm25pqC5YGc5YWz5Y2h77yJXHJcbiAgICBjbG9zZUZ1bGxSZWNvbW1lbmQsIC8v5YWz6Zet5YWo5bGP5LqS5o6o6IqC54K577yM57un57ut5YWz5Y2h6L+Q6KGMXHJcbiAgICBvbkJ0bkZhZGVFeGl0LCAgICAgIC8v54K55Ye75YGH55qE6YCA5Ye65oyJ6ZKu77yM5pi+56S65YWo5bGP5LqS5o6o6IqC54K55bm25pqC5YGc5YWz5Y2hXHJcbn1cclxuLyoq6Kem5pG45o6n5Yi25Zmo5LqL5Lu277yM6YCC55So5LqO5Y+q5pyJ5LiA5Liq6IqC54K55o6l5pS26Kem5pG45pON5L2c55qE5Zy65pmv77yM5LuOMTEwMDDlvIDlp4sgKi9cclxuZW51bSBDdHJsRXZlbnQge1xyXG4gICAgc3RhcnRJbmRleCA9IDExMDAwLFxyXG4gICAgY3RybFN0YXJ0LCAgICAgICAvL+WFs+WNoeW8gOWni++8jOW8gOWni+WFs+WNoeaTjeS9nFxyXG4gICAgY3RybEVuZCwgICAgICAgICAvL+WFs+WNoee7k+adn++8jOWBnOatouWFs+WNoeaTjeS9nFxyXG5cclxuICAgIHRvdWNoU3RhcnQsICAgICAgICAgLy/mjInkuItcclxuICAgIHRvdWNoTW92ZSwgICAgICAgICAgLy/np7vliqhcclxuICAgIHRvdWNoRW5kLCAgICAgICAgICAgLy/mnb7lvIBcclxuICAgIHRvdWNoU3RheSwgICAgICAgICAgLy/mjIHnu63mjInkvY9cclxufVxyXG4vKirllYbln47nm7jlhbPkuovku7bvvIzku44xMjAwMOW8gOWniyAqL1xyXG5lbnVtIFNob3BFdmVudCB7XHJcbiAgICBzdGFydEluZGV4ID0gMTIwMDAsXHJcblxyXG4gICAgY2hvb3NlSXRlbSwgICAgICAgICAvL+mAieS4reS6huWVhuWTgemhuVxyXG5cclxuICAgIGNoYW5nZURpc3BsYXlJdGVtLCAgLy9cclxufVxyXG4vKirkuZDmuLhTREvkuJPlsZ7kuovku7bvvIzku44xMzAwMOW8gOWniyAqL1xyXG5lbnVtIExlWW91UmVjb21tZW5kIHtcclxuICAgIHN0YXJ0SW5kZXggPSAxMzAwMCxcclxuICAgIC8qKuW6lemDqOeMnOS9oOWWnOasouS6kuaOqCAqL1xyXG4gICAgc2hvd01vcmVHYW1lQnlCYW5uZXIsXHJcbiAgICAvKirljZXkuKrlm77moIfnmoTkupLmjqggKi9cclxuICAgIHNob3dNb3JlR2FtZUJ5SWNvbixcclxuICAgIC8qKuabtOWkmua4uOaIj+S6kuaOqCAqL1xyXG4gICAgc2hvd01vcmVHYW1lLFxyXG4gICAgLyoq5L6n6L655qCP5LqS5o6oICovXHJcbiAgICBzaG93TW9yZUdhbWVTaWRlLFxyXG4gICAgLyoq5Lit6Ze05rC05bmz5rua5Yqo55qE5LqS5o6oICovXHJcbiAgICBzaG93TW9yZUdhbWVNaWRkbGUsXHJcbn1cclxuLyoq5pWw5o2u57uf6K6h5LqL5Lu277yM5LuOMTQwMDDlvIDlp4sgKi9cclxuZW51bSBUb25nSmkge1xyXG4gICAgc3RhcnRJbmRleCA9IDE0MDAwLFxyXG4gICAgLyoq55So5oi35LqL5Lu25ryP5paX77yI6L+b5Yy65pyN5LqL5Lu277yJICovXHJcbiAgICBhcHBPbmNlLFxyXG4gICAgLyoq5YiG5Lqr5Ye65pel5b+XICovXHJcbiAgICBzaGFyZWRPdXQsXHJcbiAgICAvKirpgJrov4fliIbkuqvov5vlhaUgKi9cclxuICAgIHNoYXJlZEluLFxyXG4gICAgLyoq6KeG6aKR5bm/5ZGK5LqL5Lu2ICovXHJcbiAgICB2aWRlbyxcclxuICAgIC8qKuWNh+e6pyAqL1xyXG4gICAgbGV2ZWxVcCxcclxuICAgIC8qKuWujOaIkOS7u+WKoSAqL1xyXG4gICAgdGFzayxcclxuICAgIC8qKuiHquWumuS5ieihjOS4uiAqL1xyXG4gICAgYWN0aW9uLFxyXG4gICAgLyoq5YWF5YC8ICovXHJcbiAgICBwYXksXHJcbiAgICAvKiptb25leeaXpeW/lyAqL1xyXG4gICAgbW9uZXksXHJcbiAgICAvKirpgZPlhbcgKi9cclxuICAgIGl0ZW0sXHJcbiAgICAvKirpl6/lhbMgKi9cclxuICAgIGJhdHRsZSxcclxuICAgIC8qKuijheWkh+aXpeW/lyAqL1xyXG4gICAgZXF1aXAsXHJcbiAgICAvKiroo4XlpIfljYfnuqcgKi9cclxuICAgIGVxdWlwTGV2ZWwsXHJcbiAgICAvKiroo4XlpIfljYfpmLYgKi9cclxuICAgIGVxdWlwRGVncmVlLFxyXG4gICAgLyoq6KOF5aSH546p5rOVICovXHJcbiAgICBlcXVpcFBsYXlXYXksXHJcbiAgICAvKiroh6rlrprkuYnkuovku7YgKi9cclxuICAgIGV2ZW50LFxyXG4gICAgLyoq5riF6Zmk5LqR5a2Y5YKo5pWw5o2uICovXHJcbiAgICBjbGVhcixcclxuICAgIC8qKuW5v+WRiumUmeivr+aXpeW/lyAqL1xyXG4gICAgZXJyb3IsXHJcbiAgICAvKirop6PplIHnmq7ogqTkuovku7YgKi9cclxuICAgIHVubG9ja1NraW4sXHJcbn1cclxuXHJcbi8qKuafmuWtkOS6kuaOqOS4k+WxnuS6i+S7tu+8jOS7jjE1MDAw5byA5aeLwqAqL1xyXG5lbnVtIFlvdVppUmVjb21tZW5kIHtcclxuICAgIHN0YXJ0SW5kZXggPSAxNTAwMCxcclxuICAgIC8qKuaYvuekuuWFqOWxj+iQveWcsOaOqOW5v+mhtcKgKi9cclxuICAgIHNob3dGdWxsU2NyZWVuSWNvbixcclxuICAgIC8qKuaYvuekuua4uOaIj+WQiOmbhsKgKi9cclxuICAgIHNob3dZb3V6aUdhbWVDb2xsZWN0aW9uUGFnZSxcclxufVxyXG4vKipcclxuICog6YCC55So5LqO5qGG5p6255qE6YCa55So5LqL5Lu257G75Z6LXHJcbiAqIFxyXG4gKiDlnKjlrZDnsbvkuK3mt7vliqDmuLjmiI/kuJPlsZ7nmoTkuovku7bml7bvvIwgc3RhcnRJbmRleCDku44gMTAwMDAwIOW8gOWni1xyXG4gKi9cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ29tbW9uRXZlbnRUeXBlIHtcclxuICAgIHN0YXRpYyBEaXJlY3RvckV2ZW50ID0gRGlyZWN0b3JFdmVudDtcclxuICAgIHN0YXRpYyBMb2FkQXNzZXRFdmVudCA9IExvYWRBc3NldEV2ZW50O1xyXG4gICAgc3RhdGljIFBsYXllckRhdGFFdmVudCA9IFBsYXllckRhdGFFdmVudDtcclxuICAgIHN0YXRpYyBTREtFdmVudCA9IFNES0V2ZW50O1xyXG4gICAgc3RhdGljIFVJRXZlbnQgPSBVSUV2ZW50O1xyXG4gICAgc3RhdGljIEF1ZGlvRXZlbnQgPSBBdWRpb0V2ZW50O1xyXG4gICAgc3RhdGljIEFMREV2ZW50ID0gQUxERXZlbnQ7XHJcbiAgICBzdGF0aWMgUmVjb21tZW5kRXZlbnQgPSBSZWNvbW1lbmRFdmVudDtcclxuICAgIHN0YXRpYyBBc3NldEV2ZW50ID0gQXNzZXRFdmVudDtcclxuICAgIHN0YXRpYyBBZHZlcnRTd2l0Y2hFdmVudCA9IEFkdmVydFN3aXRjaEV2ZW50O1xyXG4gICAgc3RhdGljIEN0cmxFdmVudCA9IEN0cmxFdmVudDtcclxuICAgIHN0YXRpYyBTaG9wRXZlbnQgPSBTaG9wRXZlbnQ7XHJcbiAgICBzdGF0aWMgTGVZb3VSZWNvbW1lbmQgPSBMZVlvdVJlY29tbWVuZDtcclxuICAgIHN0YXRpYyBUb25nSmkgPSBUb25nSmk7XHJcbiAgICBzdGF0aWMgWW91WmlSZWNvbW1lbmQgPSBZb3VaaVJlY29tbWVuZDtcclxufVxyXG4iXX0=