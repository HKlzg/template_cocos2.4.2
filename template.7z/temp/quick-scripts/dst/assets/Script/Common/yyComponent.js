
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/yyComponent.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd2f58JcttJPP6hHjBNvP5V8', 'yyComponent');
// Script/Common/yyComponent.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var EventManager_1 = require("./EventManager");
//抽象类，自定义脚本基类，包含通用功能
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var yyComponent = /** @class */ (function (_super) {
    __extends(yyComponent, _super);
    function yyComponent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._customId = null;
        //#endregion
        /************************************************************事件管理器************************************************************/
        //#region 事件注册
        /**
         * 记录所有事件类型与对应回调函数的字典，销毁脚本时，根据此字典注销其事件
         * key:事件类型枚举值
         * value:事件类型对应的回调函数数组
         */
        _this.events = {};
        /**
         * 记录所有只触发一次的事件类型与对应回调函数的字典
         * key:事件类型枚举值
         * value:事件类型对应的回调函数数组
         */
        _this.onceEvents = {};
        return _this;
        //#endregion
    }
    yyComponent_1 = yyComponent;
    Object.defineProperty(yyComponent.prototype, "Id", {
        get: function () {
            if (null === this._customId) {
                this._customId = yyComponent_1._autoId++;
            }
            return this._customId;
        },
        enumerable: false,
        configurable: true
    });
    //#endregion
    //#region 数组功能
    /**从数组中移除元素，只限于yyComponent的子类，返回结果是否移除成功 */
    yyComponent.prototype.removeElementInArray = function (ele, arr) {
        var id = ele.Id;
        for (var i = 0, count = arr.length; i < count; ++i) {
            if (arr[i].Id == id) {
                arr.splice(i, 1);
                return true;
            }
        }
        return false;
    };
    //#endregion
    /************************************************************通用流程************************************************************/
    //#region 初始化
    //适用于自动对象池的接口函数，需在子类重写
    /**初始化数据，取代原有的onLoad方法，子类实现 */
    yyComponent.prototype.init = function (data) {
        this.initComponents();
        this.registAllCustomUpdate();
        this.onEvents();
        if (!!data)
            this.setData(data);
    };
    /**初始化脚本以外的其他组件 */
    yyComponent.prototype.initComponents = function () {
        if (!!this.node.parent) {
            var wg = this.node.getComponent(cc.Widget);
            if (!!wg) {
                wg.updateAlignment();
            }
            var ly = this.node.getComponent(cc.Layout);
            if (!!ly) {
                ly.updateLayout();
            }
        }
    };
    /**注册通过自定义事件管理器管理的事件，子类实现 */
    yyComponent.prototype.onEvents = function () { };
    /**注册所有自定义运行状态与函数，子类实现 */
    yyComponent.prototype.registAllCustomUpdate = function () { };
    /**设置状态、数据等，子类实现 */
    yyComponent.prototype.setData = function (data) { };
    //#endregion
    //#region 重置
    /**重置状态、数据等，子类实现 */
    yyComponent.prototype.reset = function () { };
    //#endregion
    //#region 对象池复用
    /**从对象池中取回实例重新使用时将执行的方法，可重置状态、数据，设置新的状态、数据 */
    yyComponent.prototype.reuse = function (data) {
        this.reset();
        this.onEvents();
        if (!!data)
            this.setData(data);
    };
    /**放回对象池时将执行的方法，应当注销事件、计时器等 */
    yyComponent.prototype.unuse = function () {
        this.reset();
        this.offEvents();
    };
    Object.defineProperty(yyComponent.prototype, "customUpdateState", {
        get: function () { return this._customUpdateState; },
        enumerable: false,
        configurable: true
    });
    yyComponent.prototype.stepEmpty = function (dt) { };
    /**初始化运行状态 */
    yyComponent.prototype.initCustomUpdateState = function () {
        this._customUpdateState = null;
        this.customStep = this.stepEmpty;
        this.customUpdateMap = {};
    };
    /**重置运行状态 */
    yyComponent.prototype.resetCustomUpdateState = function () {
        this._customUpdateState = null;
        this.customStep = this.stepEmpty;
    };
    /**注册运行状态与函数，注册后，脚本切换到该状态时，自定义更新函数中将执行该方法 */
    yyComponent.prototype.registCustomUpdate = function (state, step) {
        if (!this.customUpdateMap) {
            this.customUpdateMap = {};
        }
        this.customUpdateMap[state] = step;
    };
    /**切换到指定的运行状态 */
    yyComponent.prototype.enterCustomUpdateState = function (state) {
        if (this._customUpdateState != state) {
            this._customUpdateState = state;
            if (!!this.customUpdateMap[state]) {
                this.customStep = this.customUpdateMap[state];
            }
            else {
                this.customStep = this.stepEmpty;
            }
        }
    };
    /**自定义的每帧更新函数 */
    yyComponent.prototype.customUpdate = function (dt) {
        if (!!this.customStep) {
            this.customStep(dt);
        }
    };
    /**遍历数组执行其自定义的更新函数 */
    yyComponent.prototype.runCustomUpdate = function (cps, dt) {
        for (var i = cps.length - 1; i >= 0; --i) {
            cps[i].customUpdate(dt);
        }
    };
    //#endregion
    /************************************************************节点通用功能************************************************************/
    //#region 基础属性
    /**设置节点的基础属性，包括坐标、角度、缩放 */
    yyComponent.prototype.setTransform = function (data) {
        if (undefined !== data.p) {
            this.setPosition(data.p);
        }
        if (undefined !== data.e) {
            if (typeof data.e === "number") {
                this.setEulerAngles(cc.v3(0, 0, data.e));
            }
            else {
                this.setEulerAngles(data.e);
            }
        }
        if (undefined !== data.s) {
            if (typeof data.s === "number") {
                this.setScale(cc.v3(data.s, data.s, data.s));
            }
            else {
                this.setScale(data.s);
            }
        }
    };
    Object.defineProperty(yyComponent.prototype, "x", {
        //#endregion
        //#region 坐标
        //节点相关属性
        get: function () { return this.node.x; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(yyComponent.prototype, "y", {
        get: function () { return this.node.y; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(yyComponent.prototype, "z", {
        get: function () { return this.node.z; },
        enumerable: false,
        configurable: true
    });
    yyComponent.prototype.setPosition = function (pos) {
        this.node.setPosition(pos);
    };
    yyComponent.prototype.getPosition = function () {
        if (this.node.is3DNode) {
            return cc.v3(this.x, this.y, this.z);
        }
        else {
            return cc.v2(this.x, this.y);
        }
    };
    Object.defineProperty(yyComponent.prototype, "angleX", {
        //#endregion
        //#region 角度
        get: function () { return this.node.eulerAngles.x; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(yyComponent.prototype, "angleY", {
        get: function () { return this.node.eulerAngles.y; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(yyComponent.prototype, "angleZ", {
        get: function () { return this.node.eulerAngles.z; },
        enumerable: false,
        configurable: true
    });
    yyComponent.prototype.setEulerAngles = function (eulerAngles) {
        this.node.eulerAngles = eulerAngles;
    };
    //#endregion
    //#region 缩放
    /**设置节点缩放 */
    yyComponent.prototype.setScale = function (scale) {
        this.node.setScale(scale);
    };
    //#endregion
    /************************************************************UI通用功能************************************************************/
    //#region UI显示/隐藏
    /**适用于UI节点，显示UI并设置UI内容 */
    yyComponent.prototype.show = function (data) {
        this.node.active = true;
        if (undefined !== data)
            this.setData(data);
    };
    /**适用于UI节点，隐藏UI */
    yyComponent.prototype.hide = function () {
        this.node.active = false;
    };
    //#endregion
    //#region 数据
    /**获取数据 */
    yyComponent.prototype.getData = function (data) {
        return null;
    };
    /**
     * 注册事件
     * @param {number} type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     */
    yyComponent.prototype.on = function (type, cb, target) {
        var h = EventManager_1.default.on(type, cb, target);
        if (!!h) {
            if (!this.events.hasOwnProperty(type)) {
                this.events[type] = [];
            }
            this.events[type].push(h);
        }
    };
    /**
     * 注册只触发一次的事件
     * @param {number} type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     */
    yyComponent.prototype.once = function (type, cb, target) {
        var h = EventManager_1.default.once(type, cb, target);
        if (!!h) {
            if (!this.onceEvents.hasOwnProperty(type)) {
                this.onceEvents[type] = [];
            }
            this.onceEvents[type].push(h);
        }
    };
    //#endregion
    //#region 事件发射
    /**
     * 发送事件
     * @param {number} type 事件类型枚举值
     * @param {any} data 传给回调函数的参数
     */
    yyComponent.prototype.emit = function (type, d1, d2, d3, d4, d5) {
        if (undefined === d1) {
            EventManager_1.default.emit(type);
        }
        else if (undefined === d2) {
            EventManager_1.default.emit(type, d1);
        }
        else if (undefined === d3) {
            EventManager_1.default.emit(type, d1, d2);
        }
        else if (undefined === d4) {
            EventManager_1.default.emit(type, d1, d2, d3);
        }
        else if (undefined === d5) {
            EventManager_1.default.emit(type, d1, d2, d3, d4);
        }
        else {
            EventManager_1.default.emit(type, d1, d2, d3, d4, d5);
        }
        if (this.onceEvents.hasOwnProperty(type))
            delete this.onceEvents[type];
    };
    //#endregion
    //#region 事件注销
    yyComponent.prototype.off = function (type, cb, target) {
        var events = this.events[type];
        if (!!events) {
            for (var i = events.length - 1; i >= 0; --i) {
                if (events[i].cb === cb && events[i].target === target) {
                    EventManager_1.default.off(type, events[i]);
                    events.splice(i, 1);
                }
            }
        }
        events = this.onceEvents[type];
        if (!!events) {
            for (var i = events.length - 1; i >= 0; --i) {
                if (events[i].cb === cb && events[i].target === target) {
                    EventManager_1.default.off(type, events[i]);
                    events.splice(i, 1);
                }
            }
        }
    };
    /**
     * 注销脚本中注册的所有事件
     */
    yyComponent.prototype.offEvents = function () {
        for (var key in this.events) {
            EventManager_1.default.offGroup(key, this.events[key]);
        }
        this.events = {};
        for (var key in this.onceEvents) {
            EventManager_1.default.offGroup(key, this.onceEvents[key]);
        }
        this.onceEvents = {};
    };
    /**对象销毁时自动注销所有事件 */
    yyComponent.prototype.onDestroy = function () {
        this.offEvents();
    };
    var yyComponent_1;
    /************************************************************自定义ID************************************************************/
    //#region 自定义ID
    //自动id
    yyComponent._autoId = 1;
    yyComponent = yyComponent_1 = __decorate([
        ccclass
    ], yyComponent);
    return yyComponent;
}(cc.Component));
exports.default = yyComponent;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXHl5Q29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLCtDQUF1RDtBQUV2RCxvQkFBb0I7QUFDZCxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUF5QywrQkFBWTtJQUFyRDtRQUFBLHFFQXFVQztRQS9UVyxlQUFTLEdBQVcsSUFBSSxDQUFDO1FBNk1qQyxZQUFZO1FBR1osK0hBQStIO1FBQy9ILGNBQWM7UUFDZDs7OztXQUlHO1FBQ0ssWUFBTSxHQUFrQyxFQUFFLENBQUM7UUFDbkQ7Ozs7V0FJRztRQUNLLGdCQUFVLEdBQWtDLEVBQUUsQ0FBQzs7UUErRnZELFlBQVk7SUFHaEIsQ0FBQztvQkFyVW9CLFdBQVc7SUFPNUIsc0JBQVcsMkJBQUU7YUFBYjtZQUNJLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ3pCLElBQUksQ0FBQyxTQUFTLEdBQUcsYUFBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQzFDO1lBQ0QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQzFCLENBQUM7OztPQUFBO0lBQ0QsWUFBWTtJQUVaLGNBQWM7SUFDZCwyQ0FBMkM7SUFDcEMsMENBQW9CLEdBQTNCLFVBQTRCLEdBQWdCLEVBQUUsR0FBa0I7UUFDNUQsSUFBSSxFQUFFLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUNoQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2hELElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUU7Z0JBQ2pCLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixPQUFPLElBQUksQ0FBQzthQUNmO1NBQ0o7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBQ0QsWUFBWTtJQUdaLDhIQUE4SDtJQUM5SCxhQUFhO0lBQ2Isc0JBQXNCO0lBQ3RCLDhCQUE4QjtJQUN2QiwwQkFBSSxHQUFYLFVBQVksSUFBVTtRQUNsQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxDQUFDLElBQUk7WUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFDRCxrQkFBa0I7SUFDUixvQ0FBYyxHQUF4QjtRQUNJLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ3BCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ04sRUFBRSxDQUFDLGVBQWUsRUFBRSxDQUFDO2FBQ3hCO1lBQ0QsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzNDLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQkFDTixFQUFFLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDckI7U0FDSjtJQUNMLENBQUM7SUFDRCw0QkFBNEI7SUFDbEIsOEJBQVEsR0FBbEIsY0FBdUIsQ0FBQztJQUN4Qix5QkFBeUI7SUFDZiwyQ0FBcUIsR0FBL0IsY0FBb0MsQ0FBQztJQUNyQyxtQkFBbUI7SUFDVCw2QkFBTyxHQUFqQixVQUFrQixJQUFVLElBQUksQ0FBQztJQUNqQyxZQUFZO0lBRVosWUFBWTtJQUNaLG1CQUFtQjtJQUNaLDJCQUFLLEdBQVosY0FBaUIsQ0FBQztJQUNsQixZQUFZO0lBRVosZUFBZTtJQUNmLDZDQUE2QztJQUN0QywyQkFBSyxHQUFaLFVBQWEsSUFBVTtRQUNuQixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLENBQUMsSUFBSTtZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELDhCQUE4QjtJQUN2QiwyQkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFRRCxzQkFBVywwQ0FBaUI7YUFBNUIsY0FBaUMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUt4RCwrQkFBUyxHQUFuQixVQUFvQixFQUFVLElBQUksQ0FBQztJQUNuQyxhQUFhO0lBQ0gsMkNBQXFCLEdBQS9CO1FBQ0ksSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztRQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDakMsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUNELFlBQVk7SUFDRiw0Q0FBc0IsR0FBaEM7UUFDSSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1FBQy9CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsNENBQTRDO0lBQ2xDLHdDQUFrQixHQUE1QixVQUE2QixLQUFVLEVBQUUsSUFBYztRQUNuRCxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUN2QixJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztTQUM3QjtRQUNELElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxnQkFBZ0I7SUFDTiw0Q0FBc0IsR0FBaEMsVUFBaUMsS0FBVTtRQUN2QyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxLQUFLLEVBQUU7WUFDbEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztZQUNoQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDakQ7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2FBQ3BDO1NBQ0o7SUFDTCxDQUFDO0lBQ0QsZ0JBQWdCO0lBQ1Qsa0NBQVksR0FBbkIsVUFBb0IsRUFBVTtRQUMxQixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDdkI7SUFDTCxDQUFDO0lBQ0QscUJBQXFCO0lBQ2QscUNBQWUsR0FBdEIsVUFBdUIsR0FBa0IsRUFBRSxFQUFVO1FBQ2pELEtBQUssSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN0QyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzNCO0lBQ0wsQ0FBQztJQUNELFlBQVk7SUFHWixnSUFBZ0k7SUFDaEksY0FBYztJQUNkLDBCQUEwQjtJQUNuQixrQ0FBWSxHQUFuQixVQUFvQixJQUFJO1FBQ3BCLElBQUksU0FBUyxLQUFLLElBQUksQ0FBQyxDQUFDLEVBQUU7WUFDdEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDNUI7UUFDRCxJQUFJLFNBQVMsS0FBSyxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQ3RCLElBQUksT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDNUM7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDL0I7U0FDSjtRQUNELElBQUksU0FBUyxLQUFLLElBQUksQ0FBQyxDQUFDLEVBQUU7WUFDdEIsSUFBSSxPQUFPLElBQUksQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO2dCQUM1QixJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2hEO2lCQUFNO2dCQUNILElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3pCO1NBQ0o7SUFDTCxDQUFDO0lBS0Qsc0JBQVcsMEJBQUM7UUFKWixZQUFZO1FBRVosWUFBWTtRQUNaLFFBQVE7YUFDUixjQUFpQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFDdEMsc0JBQVcsMEJBQUM7YUFBWixjQUFpQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFDdEMsc0JBQVcsMEJBQUM7YUFBWixjQUFpQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFDL0IsaUNBQVcsR0FBbEIsVUFBbUIsR0FBc0I7UUFDckMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUNNLGlDQUFXLEdBQWxCO1FBQ0ksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNwQixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4QzthQUFNO1lBQ0gsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUlELHNCQUFXLCtCQUFNO1FBSGpCLFlBQVk7UUFFWixZQUFZO2FBQ1osY0FBc0IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUN2RCxzQkFBVywrQkFBTTthQUFqQixjQUFzQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBQ3ZELHNCQUFXLCtCQUFNO2FBQWpCLGNBQXNCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFDaEQsb0NBQWMsR0FBckIsVUFBc0IsV0FBb0I7UUFDdEMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxZQUFZO0lBRVosWUFBWTtJQUNaLFlBQVk7SUFDTCw4QkFBUSxHQUFmLFVBQWdCLEtBQWM7UUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUNELFlBQVk7SUFFWixnSUFBZ0k7SUFDaEksaUJBQWlCO0lBRWpCLHlCQUF5QjtJQUNsQiwwQkFBSSxHQUFYLFVBQVksSUFBVTtRQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDeEIsSUFBSSxTQUFTLEtBQUssSUFBSTtZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELGtCQUFrQjtJQUNYLDBCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUNELFlBQVk7SUFFWixZQUFZO0lBQ1osVUFBVTtJQUNILDZCQUFPLEdBQWQsVUFBZSxJQUFVO1FBQ3JCLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFrQkQ7Ozs7O09BS0c7SUFDSSx3QkFBRSxHQUFULFVBQVUsSUFBWSxFQUFFLEVBQVksRUFBRSxNQUFjO1FBQ2hELElBQUksQ0FBQyxHQUFZLHNCQUFZLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNuQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUMxQjtZQUNELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzdCO0lBQ0wsQ0FBQztJQUNEOzs7OztPQUtHO0lBQ0ksMEJBQUksR0FBWCxVQUFZLElBQVksRUFBRSxFQUFZLEVBQUUsTUFBYztRQUNsRCxJQUFJLENBQUMsR0FBWSxzQkFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDOUI7WUFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNqQztJQUNMLENBQUM7SUFDRCxZQUFZO0lBRVosY0FBYztJQUNkOzs7O09BSUc7SUFDSSwwQkFBSSxHQUFYLFVBQVksSUFBWSxFQUFFLEVBQVEsRUFBRSxFQUFRLEVBQUUsRUFBUSxFQUFFLEVBQVEsRUFBRSxFQUFRO1FBQ3RFLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtZQUNsQixzQkFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMzQjthQUFNLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtZQUN6QixzQkFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDL0I7YUFBTSxJQUFJLFNBQVMsS0FBSyxFQUFFLEVBQUU7WUFDekIsc0JBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNuQzthQUFNLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtZQUN6QixzQkFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN2QzthQUFNLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtZQUN6QixzQkFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDM0M7YUFBTTtZQUNILHNCQUFZLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDL0M7UUFDRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQztZQUFFLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMzRSxDQUFDO0lBQ0QsWUFBWTtJQUVaLGNBQWM7SUFDUCx5QkFBRyxHQUFWLFVBQVcsSUFBWSxFQUFFLEVBQVksRUFBRSxNQUFjO1FBQ2pELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFO1lBQ1YsS0FBSyxJQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN6QyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUssTUFBTSxFQUFFO29CQUNwRCxzQkFBWSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2xDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2lCQUN2QjthQUNKO1NBQ0o7UUFDRCxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUU7WUFDVixLQUFLLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ3pDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxNQUFNLEVBQUU7b0JBQ3BELHNCQUFZLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDbEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ3ZCO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFDRDs7T0FFRztJQUNJLCtCQUFTLEdBQWhCO1FBQ0ksS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ3pCLHNCQUFZLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEQ7UUFDRCxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNqQixLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDN0Isc0JBQVksQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNwRDtRQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFDRCxtQkFBbUI7SUFDbkIsK0JBQVMsR0FBVDtRQUNJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQUNyQixDQUFDOztJQS9URCwrSEFBK0g7SUFDL0gsZUFBZTtJQUNmLE1BQU07SUFDUyxtQkFBTyxHQUFXLENBQUMsQ0FBQztJQUxsQixXQUFXO1FBRC9CLE9BQU87T0FDYSxXQUFXLENBcVUvQjtJQUFELGtCQUFDO0NBclVELEFBcVVDLENBclV3QyxFQUFFLENBQUMsU0FBUyxHQXFVcEQ7a0JBclVvQixXQUFXIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEV2ZW50TWFuYWdlciwgeyBIYW5kbGVyIH0gZnJvbSBcIi4vRXZlbnRNYW5hZ2VyXCI7XHJcblxyXG4vL+aKveixoeexu++8jOiHquWumuS5ieiEmuacrOWfuuexu++8jOWMheWQq+mAmueUqOWKn+iDvVxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgeXlDb21wb25lbnQgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiroh6rlrprkuYlJRCoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vI3JlZ2lvbiDoh6rlrprkuYlJRFxyXG4gICAgLy/oh6rliqhpZFxyXG4gICAgcHJpdmF0ZSBzdGF0aWMgX2F1dG9JZDogbnVtYmVyID0gMTtcclxuICAgIHByaXZhdGUgX2N1c3RvbUlkOiBudW1iZXIgPSBudWxsO1xyXG4gICAgcHVibGljIGdldCBJZCgpIHtcclxuICAgICAgICBpZiAobnVsbCA9PT0gdGhpcy5fY3VzdG9tSWQpIHtcclxuICAgICAgICAgICAgdGhpcy5fY3VzdG9tSWQgPSB5eUNvbXBvbmVudC5fYXV0b0lkKys7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLl9jdXN0b21JZDtcclxuICAgIH1cclxuICAgIC8vI2VuZHJlZ2lvblxyXG5cclxuICAgIC8vI3JlZ2lvbiDmlbDnu4Tlip/og71cclxuICAgIC8qKuS7juaVsOe7hOS4reenu+mZpOWFg+e0oO+8jOWPqumZkOS6jnl5Q29tcG9uZW5055qE5a2Q57G777yM6L+U5Zue57uT5p6c5piv5ZCm56e76Zmk5oiQ5YqfICovXHJcbiAgICBwdWJsaWMgcmVtb3ZlRWxlbWVudEluQXJyYXkoZWxlOiB5eUNvbXBvbmVudCwgYXJyOiB5eUNvbXBvbmVudFtdKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGlkID0gZWxlLklkO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBjb3VudCA9IGFyci5sZW5ndGg7IGkgPCBjb3VudDsgKytpKSB7XHJcbiAgICAgICAgICAgIGlmIChhcnJbaV0uSWQgPT0gaWQpIHtcclxuICAgICAgICAgICAgICAgIGFyci5zcGxpY2UoaSwgMSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKumAmueUqOa1geeoiyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vI3JlZ2lvbiDliJ3lp4vljJZcclxuICAgIC8v6YCC55So5LqO6Ieq5Yqo5a+56LGh5rGg55qE5o6l5Y+j5Ye95pWw77yM6ZyA5Zyo5a2Q57G76YeN5YaZXHJcbiAgICAvKirliJ3lp4vljJbmlbDmja7vvIzlj5bku6Pljp/mnInnmoRvbkxvYWTmlrnms5XvvIzlrZDnsbvlrp7njrAgKi9cclxuICAgIHB1YmxpYyBpbml0KGRhdGE/OiBhbnkpIHtcclxuICAgICAgICB0aGlzLmluaXRDb21wb25lbnRzKCk7XHJcbiAgICAgICAgdGhpcy5yZWdpc3RBbGxDdXN0b21VcGRhdGUoKTtcclxuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XHJcbiAgICAgICAgaWYgKCEhZGF0YSkgdGhpcy5zZXREYXRhKGRhdGEpO1xyXG4gICAgfVxyXG4gICAgLyoq5Yid5aeL5YyW6ISa5pys5Lul5aSW55qE5YW25LuW57uE5Lu2ICovXHJcbiAgICBwcm90ZWN0ZWQgaW5pdENvbXBvbmVudHMoKSB7XHJcbiAgICAgICAgaWYgKCEhdGhpcy5ub2RlLnBhcmVudCkge1xyXG4gICAgICAgICAgICBsZXQgd2cgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLldpZGdldCk7XHJcbiAgICAgICAgICAgIGlmICghIXdnKSB7XHJcbiAgICAgICAgICAgICAgICB3Zy51cGRhdGVBbGlnbm1lbnQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZXQgbHkgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxheW91dCk7XHJcbiAgICAgICAgICAgIGlmICghIWx5KSB7XHJcbiAgICAgICAgICAgICAgICBseS51cGRhdGVMYXlvdXQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKuazqOWGjOmAmui/h+iHquWumuS5ieS6i+S7tueuoeeQhuWZqOeuoeeQhueahOS6i+S7tu+8jOWtkOexu+WunueOsCAqL1xyXG4gICAgcHJvdGVjdGVkIG9uRXZlbnRzKCkgeyB9XHJcbiAgICAvKirms6jlhozmiYDmnInoh6rlrprkuYnov5DooYznirbmgIHkuI7lh73mlbDvvIzlrZDnsbvlrp7njrAgKi9cclxuICAgIHByb3RlY3RlZCByZWdpc3RBbGxDdXN0b21VcGRhdGUoKSB7IH1cclxuICAgIC8qKuiuvue9rueKtuaAgeOAgeaVsOaNruetie+8jOWtkOexu+WunueOsCAqL1xyXG4gICAgcHJvdGVjdGVkIHNldERhdGEoZGF0YT86IGFueSkgeyB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g6YeN572uXHJcbiAgICAvKirph43nva7nirbmgIHjgIHmlbDmja7nrYnvvIzlrZDnsbvlrp7njrAgKi9cclxuICAgIHB1YmxpYyByZXNldCgpIHsgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLy8jcmVnaW9uIOWvueixoeaxoOWkjeeUqFxyXG4gICAgLyoq5LuO5a+56LGh5rGg5Lit5Y+W5Zue5a6e5L6L6YeN5paw5L2/55So5pe25bCG5omn6KGM55qE5pa55rOV77yM5Y+v6YeN572u54q25oCB44CB5pWw5o2u77yM6K6+572u5paw55qE54q25oCB44CB5pWw5o2uICovXHJcbiAgICBwdWJsaWMgcmV1c2UoZGF0YT86IGFueSkge1xyXG4gICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XHJcbiAgICAgICAgaWYgKCEhZGF0YSkgdGhpcy5zZXREYXRhKGRhdGEpO1xyXG4gICAgfVxyXG4gICAgLyoq5pS+5Zue5a+56LGh5rGg5pe25bCG5omn6KGM55qE5pa55rOV77yM5bqU5b2T5rOo6ZSA5LqL5Lu244CB6K6h5pe25Zmo562JICovXHJcbiAgICBwdWJsaWMgdW51c2UoKSB7XHJcbiAgICAgICAgdGhpcy5yZXNldCgpO1xyXG4gICAgICAgIHRoaXMub2ZmRXZlbnRzKCk7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKuiHquWumuS5ieS4u+W+queOr+WKn+iDvSoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vI3JlZ2lvbiDoh6rlrprkuYnnmoTkuLvlvqrnjq/lip/og71cclxuICAgIC8qKuiHquWumuS5ieeahOi/kOihjOeKtuaAgSAqL1xyXG4gICAgcHJvdGVjdGVkIF9jdXN0b21VcGRhdGVTdGF0ZTogYW55O1xyXG4gICAgcHVibGljIGdldCBjdXN0b21VcGRhdGVTdGF0ZSgpIHsgcmV0dXJuIHRoaXMuX2N1c3RvbVVwZGF0ZVN0YXRlOyB9XHJcbiAgICAvKirov5DooYznirbmgIHkuI7ov5DooYzlh73mlbDnmoTmmKDlsITooajvvIxrZXnvvJrov5DooYznirbmgIHmnprkuL7lgLzvvIx2YWx1Ze+8mui/kOihjOWHveaVsCAqL1xyXG4gICAgcHJvdGVjdGVkIGN1c3RvbVVwZGF0ZU1hcDtcclxuICAgIC8qKuW9k+WJjeeKtuaAgeWvueW6lOeahOavj+W4p+abtOaWsOWHveaVsCAqL1xyXG4gICAgcHJvdGVjdGVkIGN1c3RvbVN0ZXA6IChkdDogbnVtYmVyKSA9PiB2b2lkO1xyXG4gICAgcHJvdGVjdGVkIHN0ZXBFbXB0eShkdDogbnVtYmVyKSB7IH1cclxuICAgIC8qKuWIneWni+WMlui/kOihjOeKtuaAgSAqL1xyXG4gICAgcHJvdGVjdGVkIGluaXRDdXN0b21VcGRhdGVTdGF0ZSgpIHtcclxuICAgICAgICB0aGlzLl9jdXN0b21VcGRhdGVTdGF0ZSA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5jdXN0b21TdGVwID0gdGhpcy5zdGVwRW1wdHk7XHJcbiAgICAgICAgdGhpcy5jdXN0b21VcGRhdGVNYXAgPSB7fTtcclxuICAgIH1cclxuICAgIC8qKumHjee9rui/kOihjOeKtuaAgSAqL1xyXG4gICAgcHJvdGVjdGVkIHJlc2V0Q3VzdG9tVXBkYXRlU3RhdGUoKSB7XHJcbiAgICAgICAgdGhpcy5fY3VzdG9tVXBkYXRlU3RhdGUgPSBudWxsO1xyXG4gICAgICAgIHRoaXMuY3VzdG9tU3RlcCA9IHRoaXMuc3RlcEVtcHR5O1xyXG4gICAgfVxyXG4gICAgLyoq5rOo5YaM6L+Q6KGM54q25oCB5LiO5Ye95pWw77yM5rOo5YaM5ZCO77yM6ISa5pys5YiH5o2i5Yiw6K+l54q25oCB5pe277yM6Ieq5a6a5LmJ5pu05paw5Ye95pWw5Lit5bCG5omn6KGM6K+l5pa55rOVICovXHJcbiAgICBwcm90ZWN0ZWQgcmVnaXN0Q3VzdG9tVXBkYXRlKHN0YXRlOiBhbnksIHN0ZXA6IEZ1bmN0aW9uKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmN1c3RvbVVwZGF0ZU1hcCkge1xyXG4gICAgICAgICAgICB0aGlzLmN1c3RvbVVwZGF0ZU1hcCA9IHt9O1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmN1c3RvbVVwZGF0ZU1hcFtzdGF0ZV0gPSBzdGVwO1xyXG4gICAgfVxyXG4gICAgLyoq5YiH5o2i5Yiw5oyH5a6a55qE6L+Q6KGM54q25oCBICovXHJcbiAgICBwcm90ZWN0ZWQgZW50ZXJDdXN0b21VcGRhdGVTdGF0ZShzdGF0ZTogYW55KSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2N1c3RvbVVwZGF0ZVN0YXRlICE9IHN0YXRlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1c3RvbVVwZGF0ZVN0YXRlID0gc3RhdGU7XHJcbiAgICAgICAgICAgIGlmICghIXRoaXMuY3VzdG9tVXBkYXRlTWFwW3N0YXRlXSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jdXN0b21TdGVwID0gdGhpcy5jdXN0b21VcGRhdGVNYXBbc3RhdGVdO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jdXN0b21TdGVwID0gdGhpcy5zdGVwRW1wdHk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKiroh6rlrprkuYnnmoTmr4/luKfmm7TmlrDlh73mlbAgKi9cclxuICAgIHB1YmxpYyBjdXN0b21VcGRhdGUoZHQ6IG51bWJlcikge1xyXG4gICAgICAgIGlmICghIXRoaXMuY3VzdG9tU3RlcCkge1xyXG4gICAgICAgICAgICB0aGlzLmN1c3RvbVN0ZXAoZHQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKumBjeWOhuaVsOe7hOaJp+ihjOWFtuiHquWumuS5ieeahOabtOaWsOWHveaVsCAqL1xyXG4gICAgcHVibGljIHJ1bkN1c3RvbVVwZGF0ZShjcHM6IHl5Q29tcG9uZW50W10sIGR0OiBudW1iZXIpIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gY3BzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICAgIGNwc1tpXS5jdXN0b21VcGRhdGUoZHQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8vI2VuZHJlZ2lvblxyXG5cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq6IqC54K56YCa55So5Yqf6IO9KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8jcmVnaW9uIOWfuuehgOWxnuaAp1xyXG4gICAgLyoq6K6+572u6IqC54K555qE5Z+656GA5bGe5oCn77yM5YyF5ous5Z2Q5qCH44CB6KeS5bqm44CB57yp5pS+ICovXHJcbiAgICBwdWJsaWMgc2V0VHJhbnNmb3JtKGRhdGEpIHtcclxuICAgICAgICBpZiAodW5kZWZpbmVkICE9PSBkYXRhLnApIHtcclxuICAgICAgICAgICAgdGhpcy5zZXRQb3NpdGlvbihkYXRhLnApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodW5kZWZpbmVkICE9PSBkYXRhLmUpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBkYXRhLmUgPT09IFwibnVtYmVyXCIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0RXVsZXJBbmdsZXMoY2MudjMoMCwgMCwgZGF0YS5lKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNldEV1bGVyQW5nbGVzKGRhdGEuZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCAhPT0gZGF0YS5zKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgZGF0YS5zID09PSBcIm51bWJlclwiKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNldFNjYWxlKGNjLnYzKGRhdGEucywgZGF0YS5zLCBkYXRhLnMpKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0U2NhbGUoZGF0YS5zKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8vI2VuZHJlZ2lvblxyXG5cclxuICAgIC8vI3JlZ2lvbiDlnZDmoIdcclxuICAgIC8v6IqC54K555u45YWz5bGe5oCnXHJcbiAgICBwdWJsaWMgZ2V0IHgoKSB7IHJldHVybiB0aGlzLm5vZGUueDsgfVxyXG4gICAgcHVibGljIGdldCB5KCkgeyByZXR1cm4gdGhpcy5ub2RlLnk7IH1cclxuICAgIHB1YmxpYyBnZXQgeigpIHsgcmV0dXJuIHRoaXMubm9kZS56OyB9XHJcbiAgICBwdWJsaWMgc2V0UG9zaXRpb24ocG9zOiBjYy5WZWMzIHwgY2MuVmVjMikge1xyXG4gICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbihwb3MpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGdldFBvc2l0aW9uKCkge1xyXG4gICAgICAgIGlmICh0aGlzLm5vZGUuaXMzRE5vZGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGNjLnYzKHRoaXMueCwgdGhpcy55LCB0aGlzLnopO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBjYy52Mih0aGlzLngsIHRoaXMueSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLy8jcmVnaW9uIOinkuW6plxyXG4gICAgcHVibGljIGdldCBhbmdsZVgoKSB7IHJldHVybiB0aGlzLm5vZGUuZXVsZXJBbmdsZXMueDsgfVxyXG4gICAgcHVibGljIGdldCBhbmdsZVkoKSB7IHJldHVybiB0aGlzLm5vZGUuZXVsZXJBbmdsZXMueTsgfVxyXG4gICAgcHVibGljIGdldCBhbmdsZVooKSB7IHJldHVybiB0aGlzLm5vZGUuZXVsZXJBbmdsZXMuejsgfVxyXG4gICAgcHVibGljIHNldEV1bGVyQW5nbGVzKGV1bGVyQW5nbGVzOiBjYy5WZWMzKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmV1bGVyQW5nbGVzID0gZXVsZXJBbmdsZXM7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g57yp5pS+XHJcbiAgICAvKirorr7nva7oioLngrnnvKnmlL4gKi9cclxuICAgIHB1YmxpYyBzZXRTY2FsZShzY2FsZTogY2MuVmVjMykge1xyXG4gICAgICAgIHRoaXMubm9kZS5zZXRTY2FsZShzY2FsZSk7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqVUnpgJrnlKjlip/og70qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLyNyZWdpb24gVUnmmL7npLov6ZqQ6JePXHJcblxyXG4gICAgLyoq6YCC55So5LqOVUnoioLngrnvvIzmmL7npLpVSeW5tuiuvue9rlVJ5YaF5a65ICovXHJcbiAgICBwdWJsaWMgc2hvdyhkYXRhPzogYW55KSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCAhPT0gZGF0YSkgdGhpcy5zZXREYXRhKGRhdGEpO1xyXG4gICAgfVxyXG4gICAgLyoq6YCC55So5LqOVUnoioLngrnvvIzpmpDol49VSSAqL1xyXG4gICAgcHVibGljIGhpZGUoKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLy8jcmVnaW9uIOaVsOaNrlxyXG4gICAgLyoq6I635Y+W5pWw5o2uICovXHJcbiAgICBwdWJsaWMgZ2V0RGF0YShkYXRhPzogYW55KSB7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKuS6i+S7tueuoeeQhuWZqCoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vI3JlZ2lvbiDkuovku7bms6jlhoxcclxuICAgIC8qKlxyXG4gICAgICog6K6w5b2V5omA5pyJ5LqL5Lu257G75Z6L5LiO5a+55bqU5Zue6LCD5Ye95pWw55qE5a2X5YW477yM6ZSA5q+B6ISa5pys5pe277yM5qC55o2u5q2k5a2X5YW45rOo6ZSA5YW25LqL5Lu2XHJcbiAgICAgKiBrZXk65LqL5Lu257G75Z6L5p6a5Li+5YC8XHJcbiAgICAgKiB2YWx1ZTrkuovku7bnsbvlnovlr7nlupTnmoTlm57osIPlh73mlbDmlbDnu4RcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBldmVudHM6IHsgW3R5cGU6IG51bWJlcl06IEhhbmRsZXJbXSB9ID0ge307XHJcbiAgICAvKipcclxuICAgICAqIOiusOW9leaJgOacieWPquinpuWPkeS4gOasoeeahOS6i+S7tuexu+Wei+S4juWvueW6lOWbnuiwg+WHveaVsOeahOWtl+WFuFxyXG4gICAgICoga2V5OuS6i+S7tuexu+Wei+aemuS4vuWAvFxyXG4gICAgICogdmFsdWU65LqL5Lu257G75Z6L5a+55bqU55qE5Zue6LCD5Ye95pWw5pWw57uEXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgb25jZUV2ZW50czogeyBbdHlwZTogbnVtYmVyXTogSGFuZGxlcltdIH0gPSB7fTtcclxuICAgIC8qKlxyXG4gICAgICog5rOo5YaM5LqL5Lu2XHJcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gdHlwZSDkuovku7bnsbvlnovmnprkuL7lgLxcclxuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGNiIOWbnuiwg+WHveaVsFxyXG4gICAgICogQHBhcmFtIHtPYmplY3R9IHRhcmdldCDlh73mlbDmiYDlsZ7lr7nosaFcclxuICAgICAqL1xyXG4gICAgcHVibGljIG9uKHR5cGU6IG51bWJlciwgY2I6IEZ1bmN0aW9uLCB0YXJnZXQ6IE9iamVjdCkge1xyXG4gICAgICAgIGxldCBoOiBIYW5kbGVyID0gRXZlbnRNYW5hZ2VyLm9uKHR5cGUsIGNiLCB0YXJnZXQpO1xyXG4gICAgICAgIGlmICghIWgpIHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLmV2ZW50cy5oYXNPd25Qcm9wZXJ0eSh0eXBlKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ldmVudHNbdHlwZV0gPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmV2ZW50c1t0eXBlXS5wdXNoKGgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog5rOo5YaM5Y+q6Kem5Y+R5LiA5qyh55qE5LqL5Lu2XHJcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gdHlwZSDkuovku7bnsbvlnovmnprkuL7lgLxcclxuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGNiIOWbnuiwg+WHveaVsFxyXG4gICAgICogQHBhcmFtIHtPYmplY3R9IHRhcmdldCDlh73mlbDmiYDlsZ7lr7nosaFcclxuICAgICAqL1xyXG4gICAgcHVibGljIG9uY2UodHlwZTogbnVtYmVyLCBjYjogRnVuY3Rpb24sIHRhcmdldDogT2JqZWN0KSB7XHJcbiAgICAgICAgbGV0IGg6IEhhbmRsZXIgPSBFdmVudE1hbmFnZXIub25jZSh0eXBlLCBjYiwgdGFyZ2V0KTtcclxuICAgICAgICBpZiAoISFoKSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5vbmNlRXZlbnRzLmhhc093blByb3BlcnR5KHR5cGUpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9uY2VFdmVudHNbdHlwZV0gPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLm9uY2VFdmVudHNbdHlwZV0ucHVzaChoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g5LqL5Lu25Y+R5bCEXHJcbiAgICAvKipcclxuICAgICAqIOWPkemAgeS6i+S7tlxyXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHR5cGUg5LqL5Lu257G75Z6L5p6a5Li+5YC8XHJcbiAgICAgKiBAcGFyYW0ge2FueX0gZGF0YSDkvKDnu5nlm57osIPlh73mlbDnmoTlj4LmlbBcclxuICAgICAqL1xyXG4gICAgcHVibGljIGVtaXQodHlwZTogbnVtYmVyLCBkMT86IGFueSwgZDI/OiBhbnksIGQzPzogYW55LCBkND86IGFueSwgZDU/OiBhbnkpIHtcclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBkMSkge1xyXG4gICAgICAgICAgICBFdmVudE1hbmFnZXIuZW1pdCh0eXBlKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHVuZGVmaW5lZCA9PT0gZDIpIHtcclxuICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQodHlwZSwgZDEpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodW5kZWZpbmVkID09PSBkMykge1xyXG4gICAgICAgICAgICBFdmVudE1hbmFnZXIuZW1pdCh0eXBlLCBkMSwgZDIpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodW5kZWZpbmVkID09PSBkNCkge1xyXG4gICAgICAgICAgICBFdmVudE1hbmFnZXIuZW1pdCh0eXBlLCBkMSwgZDIsIGQzKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHVuZGVmaW5lZCA9PT0gZDUpIHtcclxuICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQodHlwZSwgZDEsIGQyLCBkMywgZDQpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KHR5cGUsIGQxLCBkMiwgZDMsIGQ0LCBkNSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLm9uY2VFdmVudHMuaGFzT3duUHJvcGVydHkodHlwZSkpIGRlbGV0ZSB0aGlzLm9uY2VFdmVudHNbdHlwZV07XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g5LqL5Lu25rOo6ZSAXHJcbiAgICBwdWJsaWMgb2ZmKHR5cGU6IG51bWJlciwgY2I6IEZ1bmN0aW9uLCB0YXJnZXQ6IE9iamVjdCkge1xyXG4gICAgICAgIGxldCBldmVudHMgPSB0aGlzLmV2ZW50c1t0eXBlXTtcclxuICAgICAgICBpZiAoISFldmVudHMpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IGV2ZW50cy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50c1tpXS5jYiA9PT0gY2IgJiYgZXZlbnRzW2ldLnRhcmdldCA9PT0gdGFyZ2V0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLm9mZih0eXBlLCBldmVudHNbaV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50cy5zcGxpY2UoaSwgMSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZXZlbnRzID0gdGhpcy5vbmNlRXZlbnRzW3R5cGVdO1xyXG4gICAgICAgIGlmICghIWV2ZW50cykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gZXZlbnRzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZXZlbnRzW2ldLmNiID09PSBjYiAmJiBldmVudHNbaV0udGFyZ2V0ID09PSB0YXJnZXQpIHtcclxuICAgICAgICAgICAgICAgICAgICBFdmVudE1hbmFnZXIub2ZmKHR5cGUsIGV2ZW50c1tpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRzLnNwbGljZShpLCAxKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog5rOo6ZSA6ISa5pys5Lit5rOo5YaM55qE5omA5pyJ5LqL5Lu2XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBvZmZFdmVudHMoKSB7XHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuZXZlbnRzKSB7XHJcbiAgICAgICAgICAgIEV2ZW50TWFuYWdlci5vZmZHcm91cChrZXksIHRoaXMuZXZlbnRzW2tleV0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmV2ZW50cyA9IHt9O1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiB0aGlzLm9uY2VFdmVudHMpIHtcclxuICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLm9mZkdyb3VwKGtleSwgdGhpcy5vbmNlRXZlbnRzW2tleV0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm9uY2VFdmVudHMgPSB7fTtcclxuICAgIH1cclxuICAgIC8qKuWvueixoemUgOavgeaXtuiHquWKqOazqOmUgOaJgOacieS6i+S7tiAqL1xyXG4gICAgb25EZXN0cm95KCkge1xyXG4gICAgICAgIHRoaXMub2ZmRXZlbnRzKCk7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICBcclxufSJdfQ==