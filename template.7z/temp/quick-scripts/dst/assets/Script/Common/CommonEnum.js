
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/CommonEnum.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'cf28fdbEPpGfbpydjMQvpU4', 'CommonEnum');
// Script/Common/CommonEnum.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommonEnum = void 0;
/******************************框架通用枚举，不需要改动******************************/
//互推预制件
var RecommendPrefab;
(function (RecommendPrefab) {
    RecommendPrefab["item"] = "RecommendItem";
    RecommendPrefab["drawer"] = "RecommendDrawer";
    RecommendPrefab["banner"] = "RecommendBanner";
    RecommendPrefab["matrix"] = "RecommendMatrix";
    RecommendPrefab["primary"] = "RecommendPrimary";
    RecommendPrefab["primary_tt"] = "RecommendPrimary_TT";
    RecommendPrefab["btnCenter_tt"] = "RecommendBtnCenter_TT";
    RecommendPrefab["btnSide_tt"] = "RecommendBtnSide_TT";
})(RecommendPrefab || (RecommendPrefab = {}));
//互推游戏节点类型
var RecommendItemType;
(function (RecommendItemType) {
    RecommendItemType["normal"] = "RecommendItem";
})(RecommendItemType || (RecommendItemType = {}));
//互推矩阵抽屉类型
var RecommendDrawerType;
(function (RecommendDrawerType) {
    RecommendDrawerType[RecommendDrawerType["left"] = 1] = "left";
    RecommendDrawerType[RecommendDrawerType["right"] = 2] = "right";
})(RecommendDrawerType || (RecommendDrawerType = {}));
//互推banner类型
var RecommendBannerType;
(function (RecommendBannerType) {
    RecommendBannerType[RecommendBannerType["pingpong"] = 1] = "pingpong";
    RecommendBannerType[RecommendBannerType["left"] = 2] = "left";
    RecommendBannerType[RecommendBannerType["right"] = 3] = "right";
})(RecommendBannerType || (RecommendBannerType = {}));
/**触摸控制器状态 */
var CtrlState;
(function (CtrlState) {
    CtrlState[CtrlState["none"] = 1] = "none";
    CtrlState[CtrlState["touched"] = 2] = "touched";
})(CtrlState || (CtrlState = {}));
/**用于数据统计的视频事件 */
var VideoSubType;
(function (VideoSubType) {
    VideoSubType[VideoSubType["showVideoBtn"] = 7] = "showVideoBtn";
    VideoSubType[VideoSubType["openVideoWindow"] = 0] = "openVideoWindow";
    VideoSubType[VideoSubType["closeVideoWindow"] = 1] = "closeVideoWindow";
    VideoSubType[VideoSubType["clickBtnVideo"] = 2] = "clickBtnVideo";
    VideoSubType[VideoSubType["videoQuit"] = 3] = "videoQuit";
    VideoSubType[VideoSubType["videoSuc"] = 4] = "videoSuc";
    VideoSubType[VideoSubType["getAward"] = 5] = "getAward";
    VideoSubType[VideoSubType["videoFail"] = 6] = "videoFail";
})(VideoSubType || (VideoSubType = {}));
/*****************框架通用枚举，可能需要根据实际游戏添加枚举值，添加后放到其他游戏中照样能正常运行*****************/
/**资源路径，可为本地路径或远程路径 */
var UrlPath;
(function (UrlPath) {
    //皮肤资源：
    /**皮肤资源根路径 */
    UrlPath["skinRootUrl"] = "myGame/Img/Skin/";
    /**皮肤贴图文件夹名 */
    UrlPath["skinTextureDir"] = "Textures";
    /**皮肤在商城的商品项显示图片的文件夹名 */
    UrlPath["skinItemDir"] = "Item";
    /**皮肤商品选中时在展示台显示的图片的文件夹名 */
    UrlPath["skinDisplayDir"] = "Display";
})(UrlPath || (UrlPath = {}));
/**UI类型，枚举值与对应UI预制件、脚本名称相同 */
var UI;
(function (UI) {
    UI["lobby"] = "GameLobby";
    UI["configSetting"] = "ConfigSettingUI";
    UI["playerAssetBar"] = "PlayerAssetBar";
    UI["getPower"] = "GetPowerUI";
    UI["tipPower"] = "TipPowerUI";
    UI["shop"] = "ShopUI";
    UI["chooseLevel"] = "ChooseLevelUI";
    UI["levelInfo"] = "LevelInfoUI";
    UI["pauseLevel"] = "PauseLevelUI";
    UI["trySkin"] = "TrySkinUI";
    UI["levelTeach"] = "TeachAnim";
    UI["winUI"] = "WinUI";
    UI["loseUI"] = "LoseUI";
    UI["resurgence"] = "ResurgenceUI";
})(UI || (UI = {}));
/**游戏数据类型 */
var GameDataType;
(function (GameDataType) {
    /**关卡数据 */
    GameDataType["levelData"] = "LevelData";
    //皮肤
    GameDataType["playerSkin"] = "PlayerSkin";
})(GameDataType || (GameDataType = {}));
/**商店中商品项的类型 */
var GoodsType;
(function (GoodsType) {
    /**主角皮肤 */
    GoodsType["playerSkin"] = "PlayerSkin";
})(GoodsType || (GoodsType = {}));
//音效文件
var AudioClip;
(function (AudioClip) {
    AudioClip["clickBtn"] = "Common/Audio/clickBtn";
    AudioClip["win"] = "Common/Audio/win";
    AudioClip["lose"] = "Common/Audio/lose";
    AudioClip["BGM"] = "myGame/Audio/BGM1";
})(AudioClip || (AudioClip = {}));
/**关卡状态 */
var LevelState;
(function (LevelState) {
    LevelState[LevelState["inited"] = 1] = "inited";
    LevelState[LevelState["playing"] = 2] = "playing";
    LevelState[LevelState["win"] = 3] = "win";
    LevelState[LevelState["lose"] = 4] = "lose";
    LevelState[LevelState["lobby"] = 5] = "lobby";
})(LevelState || (LevelState = {}));
/**********************根据实际游戏设置的枚举值，由子类定义，这里仅作示例，不会包含到导出的类中**********************/
/**通过全局对象池管理的预制件名称与对应的脚本名称，这里仅作示例，不会包含到导出的类中，需在子类中定义 */
var LevelPrefab;
(function (LevelPrefab) {
    LevelPrefab["goldIcon"] = "GoldIcon";
})(LevelPrefab || (LevelPrefab = {}));
/**
 * 定义全部通用的枚举值
 *
 * 注：LevelPrefab 枚举类型必须在子类中定义
 */
var CommonEnum = /** @class */ (function () {
    function CommonEnum() {
    }
    CommonEnum.RecommendPrefab = RecommendPrefab;
    CommonEnum.RecommendItemType = RecommendItemType;
    CommonEnum.RecommendDrawerType = RecommendDrawerType;
    CommonEnum.RecommendBannerType = RecommendBannerType;
    CommonEnum.CtrlState = CtrlState;
    CommonEnum.VideoSubType = VideoSubType;
    CommonEnum.UrlPath = UrlPath;
    CommonEnum.UI = UI;
    CommonEnum.GameDataType = GameDataType;
    CommonEnum.GoodsType = GoodsType;
    CommonEnum.AudioClip = AudioClip;
    CommonEnum.LevelState = LevelState;
    return CommonEnum;
}());
exports.CommonEnum = CommonEnum;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXENvbW1vbkVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsMEVBQTBFO0FBQzFFLE9BQU87QUFDUCxJQUFLLGVBU0o7QUFURCxXQUFLLGVBQWU7SUFDaEIseUNBQXNCLENBQUE7SUFDdEIsNkNBQTBCLENBQUE7SUFDMUIsNkNBQTBCLENBQUE7SUFDMUIsNkNBQTBCLENBQUE7SUFDMUIsK0NBQTRCLENBQUE7SUFDNUIscURBQWtDLENBQUE7SUFDbEMseURBQXNDLENBQUE7SUFDdEMscURBQWtDLENBQUE7QUFDdEMsQ0FBQyxFQVRJLGVBQWUsS0FBZixlQUFlLFFBU25CO0FBQ0QsVUFBVTtBQUNWLElBQUssaUJBR0o7QUFIRCxXQUFLLGlCQUFpQjtJQUNsQiw2Q0FBd0IsQ0FBQTtBQUU1QixDQUFDLEVBSEksaUJBQWlCLEtBQWpCLGlCQUFpQixRQUdyQjtBQUNELFVBQVU7QUFDVixJQUFLLG1CQUdKO0FBSEQsV0FBSyxtQkFBbUI7SUFDcEIsNkRBQVEsQ0FBQTtJQUNSLCtEQUFLLENBQUE7QUFDVCxDQUFDLEVBSEksbUJBQW1CLEtBQW5CLG1CQUFtQixRQUd2QjtBQUNELFlBQVk7QUFDWixJQUFLLG1CQUlKO0FBSkQsV0FBSyxtQkFBbUI7SUFDcEIscUVBQVksQ0FBQTtJQUNaLDZEQUFJLENBQUE7SUFDSiwrREFBSyxDQUFBO0FBQ1QsQ0FBQyxFQUpJLG1CQUFtQixLQUFuQixtQkFBbUIsUUFJdkI7QUFDRCxhQUFhO0FBQ2IsSUFBSyxTQUdKO0FBSEQsV0FBSyxTQUFTO0lBQ1YseUNBQVEsQ0FBQTtJQUNSLCtDQUFPLENBQUE7QUFDWCxDQUFDLEVBSEksU0FBUyxLQUFULFNBQVMsUUFHYjtBQUVELGlCQUFpQjtBQUNqQixJQUFLLFlBU0o7QUFURCxXQUFLLFlBQVk7SUFDYiwrREFBZ0IsQ0FBQTtJQUNoQixxRUFBbUIsQ0FBQTtJQUNuQix1RUFBb0IsQ0FBQTtJQUNwQixpRUFBaUIsQ0FBQTtJQUNqQix5REFBYSxDQUFBO0lBQ2IsdURBQVksQ0FBQTtJQUNaLHVEQUFZLENBQUE7SUFDWix5REFBYSxDQUFBO0FBQ2pCLENBQUMsRUFUSSxZQUFZLEtBQVosWUFBWSxRQVNoQjtBQUVELDRFQUE0RTtBQUM1RSxzQkFBc0I7QUFDdEIsSUFBSyxPQVVKO0FBVkQsV0FBSyxPQUFPO0lBQ1IsT0FBTztJQUNQLGFBQWE7SUFDYiwyQ0FBZ0MsQ0FBQTtJQUNoQyxjQUFjO0lBQ2Qsc0NBQTJCLENBQUE7SUFDM0Isd0JBQXdCO0lBQ3hCLCtCQUFvQixDQUFBO0lBQ3BCLDJCQUEyQjtJQUMzQixxQ0FBMEIsQ0FBQTtBQUM5QixDQUFDLEVBVkksT0FBTyxLQUFQLE9BQU8sUUFVWDtBQUNELDZCQUE2QjtBQUM3QixJQUFLLEVBbUJKO0FBbkJELFdBQUssRUFBRTtJQUNILHlCQUFtQixDQUFBO0lBRW5CLHVDQUFpQyxDQUFBO0lBRWpDLHVDQUFpQyxDQUFBO0lBQ2pDLDZCQUF1QixDQUFBO0lBQ3ZCLDZCQUF1QixDQUFBO0lBRXZCLHFCQUFlLENBQUE7SUFDZixtQ0FBNkIsQ0FBQTtJQUU3QiwrQkFBeUIsQ0FBQTtJQUN6QixpQ0FBMkIsQ0FBQTtJQUMzQiwyQkFBcUIsQ0FBQTtJQUNyQiw4QkFBd0IsQ0FBQTtJQUN4QixxQkFBZSxDQUFBO0lBQ2YsdUJBQWlCLENBQUE7SUFDakIsaUNBQTJCLENBQUE7QUFDL0IsQ0FBQyxFQW5CSSxFQUFFLEtBQUYsRUFBRSxRQW1CTjtBQUNELFlBQVk7QUFDWixJQUFLLFlBS0o7QUFMRCxXQUFLLFlBQVk7SUFDYixVQUFVO0lBQ1YsdUNBQXVCLENBQUE7SUFDdkIsSUFBSTtJQUNKLHlDQUF5QixDQUFBO0FBQzdCLENBQUMsRUFMSSxZQUFZLEtBQVosWUFBWSxRQUtoQjtBQUNELGVBQWU7QUFDZixJQUFLLFNBR0o7QUFIRCxXQUFLLFNBQVM7SUFDVixVQUFVO0lBQ1Ysc0NBQXlCLENBQUE7QUFDN0IsQ0FBQyxFQUhJLFNBQVMsS0FBVCxTQUFTLFFBR2I7QUFDRCxNQUFNO0FBQ04sSUFBSyxTQUtKO0FBTEQsV0FBSyxTQUFTO0lBQ1YsK0NBQWtDLENBQUE7SUFDbEMscUNBQXdCLENBQUE7SUFDeEIsdUNBQTBCLENBQUE7SUFDMUIsc0NBQXlCLENBQUE7QUFDN0IsQ0FBQyxFQUxJLFNBQVMsS0FBVCxTQUFTLFFBS2I7QUFDRCxVQUFVO0FBQ1YsSUFBSyxVQU9KO0FBUEQsV0FBSyxVQUFVO0lBQ1gsK0NBQVUsQ0FBQTtJQUNWLGlEQUFPLENBQUE7SUFDUCx5Q0FBRyxDQUFBO0lBQ0gsMkNBQUksQ0FBQTtJQUNKLDZDQUFLLENBQUE7QUFFVCxDQUFDLEVBUEksVUFBVSxLQUFWLFVBQVUsUUFPZDtBQUVELGtGQUFrRjtBQUNsRix1REFBdUQ7QUFDdkQsSUFBSyxXQUVKO0FBRkQsV0FBSyxXQUFXO0lBQ1osb0NBQXFCLENBQUE7QUFDekIsQ0FBQyxFQUZJLFdBQVcsS0FBWCxXQUFXLFFBRWY7QUFFRDs7OztHQUlHO0FBQ0g7SUFBQTtJQWFBLENBQUM7SUFaVSwwQkFBZSxHQUFHLGVBQWUsQ0FBQztJQUNsQyw0QkFBaUIsR0FBRyxpQkFBaUIsQ0FBQztJQUN0Qyw4QkFBbUIsR0FBRyxtQkFBbUIsQ0FBQztJQUMxQyw4QkFBbUIsR0FBRyxtQkFBbUIsQ0FBQztJQUMxQyxvQkFBUyxHQUFHLFNBQVMsQ0FBQztJQUN0Qix1QkFBWSxHQUFHLFlBQVksQ0FBQztJQUM1QixrQkFBTyxHQUFHLE9BQU8sQ0FBQztJQUNsQixhQUFFLEdBQUcsRUFBRSxDQUFDO0lBQ1IsdUJBQVksR0FBRyxZQUFZLENBQUM7SUFDNUIsb0JBQVMsR0FBRyxTQUFTLENBQUM7SUFDdEIsb0JBQVMsR0FBRyxTQUFTLENBQUM7SUFDdEIscUJBQVUsR0FBRyxVQUFVLENBQUM7SUFDbkMsaUJBQUM7Q0FiRCxBQWFDLElBQUE7QUFiWSxnQ0FBVSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKirmoYbmnrbpgJrnlKjmnprkuL7vvIzkuI3pnIDopoHmlLnliqgqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbi8v5LqS5o6o6aKE5Yi25Lu2XHJcbmVudW0gUmVjb21tZW5kUHJlZmFiIHtcclxuICAgIGl0ZW0gPSBcIlJlY29tbWVuZEl0ZW1cIiwgICAgICAgICAgICAgICAgIC8v5Z+656GA57G75Z6L55qE5LqS5o6o5ri45oiP6IqC54K5XHJcbiAgICBkcmF3ZXIgPSBcIlJlY29tbWVuZERyYXdlclwiLCAgICAgICAgICAgICAvL+efqemYteaKveWxiVxyXG4gICAgYmFubmVyID0gXCJSZWNvbW1lbmRCYW5uZXJcIixcclxuICAgIG1hdHJpeCA9IFwiUmVjb21tZW5kTWF0cml4XCIsXHJcbiAgICBwcmltYXJ5ID0gXCJSZWNvbW1lbmRQcmltYXJ5XCIsXHJcbiAgICBwcmltYXJ5X3R0ID0gXCJSZWNvbW1lbmRQcmltYXJ5X1RUXCIsXHJcbiAgICBidG5DZW50ZXJfdHQgPSBcIlJlY29tbWVuZEJ0bkNlbnRlcl9UVFwiLCAvL+WktOadoeW5s+WPsOato+S4remXtOeahOS6kuaOqOaMiemSrlxyXG4gICAgYnRuU2lkZV90dCA9IFwiUmVjb21tZW5kQnRuU2lkZV9UVFwiLCAgICAgLy/lpLTmnaHlubPlj7DpnaDovrnnmoTkupLmjqjmjInpkq5cclxufVxyXG4vL+S6kuaOqOa4uOaIj+iKgueCueexu+Wei1xyXG5lbnVtIFJlY29tbWVuZEl0ZW1UeXBlIHtcclxuICAgIG5vcm1hbCA9IFwiUmVjb21tZW5kSXRlbVwiLCAgICAgICAvL+WfuuehgOexu+Wei++8jOaXoOS7u+S9leWKqOeUu+OAgeeJueaViOetieaViOaenO+8jOWbuuWumuWcqOWxj+W5leS4ilxyXG5cclxufVxyXG4vL+S6kuaOqOefqemYteaKveWxieexu+Wei1xyXG5lbnVtIFJlY29tbWVuZERyYXdlclR5cGUge1xyXG4gICAgbGVmdCA9IDEsICAgICAgIC8v5LuO5bem5L6n6L+b5YWl55qE5oq95bGJXHJcbiAgICByaWdodCwgICAgICAgICAgLy/ku47lj7Pkvqfov5vlhaXnmoTmir3lsYlcclxufVxyXG4vL+S6kuaOqGJhbm5lcuexu+Wei1xyXG5lbnVtIFJlY29tbWVuZEJhbm5lclR5cGUge1xyXG4gICAgcGluZ3BvbmcgPSAxLCAgIC8v5p2l5Zue5rua5YqoXHJcbiAgICBsZWZ0LCAgICAgICAgICAgLy/msLjov5zlkJHlt6bmu5rliqhcclxuICAgIHJpZ2h0LCAgICAgICAgICAvL+awuOi/nOWQkeWPs+a7muWKqFxyXG59XHJcbi8qKuinpuaRuOaOp+WItuWZqOeKtuaAgSAqL1xyXG5lbnVtIEN0cmxTdGF0ZSB7XHJcbiAgICBub25lID0gMSxcclxuICAgIHRvdWNoZWQsICAgIC8v5oyJ5L2P54q25oCBXHJcbn1cclxuXHJcbi8qKueUqOS6juaVsOaNrue7n+iuoeeahOinhumikeS6i+S7tiAqL1xyXG5lbnVtIFZpZGVvU3ViVHlwZSB7XHJcbiAgICBzaG93VmlkZW9CdG4gPSA3LCAgICAgICAvL+abneWFie+8jOavlOWmguWkjea0u+aXtueci+WIsOingueci+inhumikeaMiemSrlxyXG4gICAgb3BlblZpZGVvV2luZG93ID0gMCwgICAgLy/kuLvliqjop6blj5HmiZPlvIDop4bpopHnqpflj6NcclxuICAgIGNsb3NlVmlkZW9XaW5kb3cgPSAxLCAgIC8v55yL5Yiw6KeG6aKR56qX5Y+j5ZCO5Li75Yqo5YWz6ZetXHJcbiAgICBjbGlja0J0blZpZGVvID0gMiwgICAgICAvL+eCueWHu+aSreaUvuinhumikVxyXG4gICAgdmlkZW9RdWl0ID0gMywgICAgICAgICAgLy/op4bpopHkuK3pgJTlhbPpl63op4bpopFcclxuICAgIHZpZGVvU3VjID0gNCwgICAgICAgICAgIC8v6KeC55yL57uT5p2fXHJcbiAgICBnZXRBd2FyZCA9IDUsICAgICAgICAgICAvL+iOt+W+l+WlluWKsVxyXG4gICAgdmlkZW9GYWlsID0gNiwgICAgICAgICAgLy/msqHmnInlj6/op4LnnIvnmoTlub/lkYpcclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioq5qGG5p626YCa55So5p6a5Li+77yM5Y+v6IO96ZyA6KaB5qC55o2u5a6e6ZmF5ri45oiP5re75Yqg5p6a5Li+5YC877yM5re75Yqg5ZCO5pS+5Yiw5YW25LuW5ri45oiP5Lit54Wn5qC36IO95q2j5bi46L+Q6KGMKioqKioqKioqKioqKioqKiovXHJcbi8qKui1hOa6kOi3r+W+hO+8jOWPr+S4uuacrOWcsOi3r+W+hOaIlui/nOeoi+i3r+W+hCAqL1xyXG5lbnVtIFVybFBhdGgge1xyXG4gICAgLy/nmq7ogqTotYTmupDvvJpcclxuICAgIC8qKuearuiCpOi1hOa6kOaguei3r+W+hCAqL1xyXG4gICAgc2tpblJvb3RVcmwgPSBcIm15R2FtZS9JbWcvU2tpbi9cIixcclxuICAgIC8qKuearuiCpOi0tOWbvuaWh+S7tuWkueWQjSAqL1xyXG4gICAgc2tpblRleHR1cmVEaXIgPSBcIlRleHR1cmVzXCIsXHJcbiAgICAvKirnmq7ogqTlnKjllYbln47nmoTllYblk4HpobnmmL7npLrlm77niYfnmoTmlofku7blpLnlkI0gKi9cclxuICAgIHNraW5JdGVtRGlyID0gXCJJdGVtXCIsXHJcbiAgICAvKirnmq7ogqTllYblk4HpgInkuK3ml7blnKjlsZXnpLrlj7DmmL7npLrnmoTlm77niYfnmoTmlofku7blpLnlkI0gKi9cclxuICAgIHNraW5EaXNwbGF5RGlyID0gXCJEaXNwbGF5XCIsXHJcbn1cclxuLyoqVUnnsbvlnovvvIzmnprkuL7lgLzkuI7lr7nlupRVSemihOWItuS7tuOAgeiEmuacrOWQjeensOebuOWQjCAqL1xyXG5lbnVtIFVJIHtcclxuICAgIGxvYmJ5ID0gXCJHYW1lTG9iYnlcIiwgICAgICAgICAgICAgICAgLy/pppbpobVcclxuXHJcbiAgICBjb25maWdTZXR0aW5nID0gXCJDb25maWdTZXR0aW5nVUlcIiwgIC8v6K6+572u6Z2i5p2/XHJcblxyXG4gICAgcGxheWVyQXNzZXRCYXIgPSBcIlBsYXllckFzc2V0QmFyXCIsICAvL+eOqeWutui1hOS6p+S/oeaBr+adoVxyXG4gICAgZ2V0UG93ZXIgPSBcIkdldFBvd2VyVUlcIiwgICAgICAgICAgICAvL+iOt+WPluS9k+WKm+eVjOmdolxyXG4gICAgdGlwUG93ZXIgPSBcIlRpcFBvd2VyVUlcIiwgICAgICAgICAgICAvL+S9k+WKm+S4jei2s+aPkOekuueVjOmdolxyXG5cclxuICAgIHNob3AgPSBcIlNob3BVSVwiLCAgICAgICAgICAgICAgICAgICAgLy/llYbln47nlYzpnaJcclxuICAgIGNob29zZUxldmVsID0gXCJDaG9vc2VMZXZlbFVJXCIsICAgICAgLy/lhbPljaHpgInmi6npobXpnaIgXHJcblxyXG4gICAgbGV2ZWxJbmZvID0gXCJMZXZlbEluZm9VSVwiLCAgICAgICAgICAvL+WFs+WNoeS/oeaBr1xyXG4gICAgcGF1c2VMZXZlbCA9IFwiUGF1c2VMZXZlbFVJXCIsICAgICAgICAvL+WFs+WNoeaaguWBnOmdouadv1xyXG4gICAgdHJ5U2tpbiA9IFwiVHJ5U2tpblVJXCIsICAgICAgICAgICAgICAvL+earuiCpOivleeUqOeVjOmdolxyXG4gICAgbGV2ZWxUZWFjaCA9IFwiVGVhY2hBbmltXCIsICAgICAgICAgICAvL+WFs+WNoeaVmeWtpueVjOmdolxyXG4gICAgd2luVUkgPSBcIldpblVJXCIsICAgICAgICAgICAgICAgICAgICAvL+iDnOWIqeeVjOmdolxyXG4gICAgbG9zZVVJID0gXCJMb3NlVUlcIiwgICAgICAgICAgICAgICAgICAvL+Wksei0peeVjOmdolxyXG4gICAgcmVzdXJnZW5jZSA9IFwiUmVzdXJnZW5jZVVJXCIsICAgICAgICAvL+Wkjea0u+eVjOmdolxyXG59XHJcbi8qKua4uOaIj+aVsOaNruexu+WeiyAqL1xyXG5lbnVtIEdhbWVEYXRhVHlwZSB7XHJcbiAgICAvKirlhbPljaHmlbDmja4gKi9cclxuICAgIGxldmVsRGF0YSA9IFwiTGV2ZWxEYXRhXCIsXHJcbiAgICAvL+earuiCpFxyXG4gICAgcGxheWVyU2tpbiA9IFwiUGxheWVyU2tpblwiLFxyXG59XHJcbi8qKuWVhuW6l+S4reWVhuWTgemhueeahOexu+WeiyAqL1xyXG5lbnVtIEdvb2RzVHlwZSB7XHJcbiAgICAvKirkuLvop5Lnmq7ogqQgKi9cclxuICAgIHBsYXllclNraW4gPSBcIlBsYXllclNraW5cIixcclxufVxyXG4vL+mfs+aViOaWh+S7tlxyXG5lbnVtIEF1ZGlvQ2xpcCB7XHJcbiAgICBjbGlja0J0biA9IFwiQ29tbW9uL0F1ZGlvL2NsaWNrQnRuXCIsXHJcbiAgICB3aW4gPSBcIkNvbW1vbi9BdWRpby93aW5cIixcclxuICAgIGxvc2UgPSBcIkNvbW1vbi9BdWRpby9sb3NlXCIsXHJcbiAgICBCR00gPSBcIm15R2FtZS9BdWRpby9CR00xXCIsXHJcbn1cclxuLyoq5YWz5Y2h54q25oCBICovXHJcbmVudW0gTGV2ZWxTdGF0ZSB7XHJcbiAgICBpbml0ZWQgPSAxLCAgICAgLy/lhbPljaHlt7LliJ3lp4vljJblrozmiJDvvIzkvYbov5jmnKrlvIDlp4vmuLjmiI9cclxuICAgIHBsYXlpbmcsICAgICAgICAvL+WFs+WNoei/m+ihjOS4rVxyXG4gICAgd2luLCAgICAgICAgICAgIC8v546p5a625bey6IOc5YipXHJcbiAgICBsb3NlLCAgICAgICAgICAgLy/njqnlrrblt7LlpLHotKVcclxuICAgIGxvYmJ5LCAgICAgICAgICAvL+aYvuekuummlumhteS4rVxyXG5cclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKirmoLnmja7lrp7pmYXmuLjmiI/orr7nva7nmoTmnprkuL7lgLzvvIznlLHlrZDnsbvlrprkuYnvvIzov5nph4zku4XkvZznpLrkvovvvIzkuI3kvJrljIXlkKvliLDlr7zlh7rnmoTnsbvkuK0qKioqKioqKioqKioqKioqKioqKioqL1xyXG4vKirpgJrov4flhajlsYDlr7nosaHmsaDnrqHnkIbnmoTpooTliLbku7blkI3np7DkuI7lr7nlupTnmoTohJrmnKzlkI3np7DvvIzov5nph4zku4XkvZznpLrkvovvvIzkuI3kvJrljIXlkKvliLDlr7zlh7rnmoTnsbvkuK3vvIzpnIDlnKjlrZDnsbvkuK3lrprkuYkgKi9cclxuZW51bSBMZXZlbFByZWZhYiB7XHJcbiAgICBnb2xkSWNvbiA9IFwiR29sZEljb25cIixcclxufVxyXG5cclxuLyoqXHJcbiAqIOWumuS5ieWFqOmDqOmAmueUqOeahOaemuS4vuWAvFxyXG4gKiBcclxuICog5rOo77yaTGV2ZWxQcmVmYWIg5p6a5Li+57G75Z6L5b+F6aG75Zyo5a2Q57G75Lit5a6a5LmJXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgQ29tbW9uRW51bSB7XHJcbiAgICBzdGF0aWMgUmVjb21tZW5kUHJlZmFiID0gUmVjb21tZW5kUHJlZmFiO1xyXG4gICAgc3RhdGljIFJlY29tbWVuZEl0ZW1UeXBlID0gUmVjb21tZW5kSXRlbVR5cGU7XHJcbiAgICBzdGF0aWMgUmVjb21tZW5kRHJhd2VyVHlwZSA9IFJlY29tbWVuZERyYXdlclR5cGU7XHJcbiAgICBzdGF0aWMgUmVjb21tZW5kQmFubmVyVHlwZSA9IFJlY29tbWVuZEJhbm5lclR5cGU7XHJcbiAgICBzdGF0aWMgQ3RybFN0YXRlID0gQ3RybFN0YXRlO1xyXG4gICAgc3RhdGljIFZpZGVvU3ViVHlwZSA9IFZpZGVvU3ViVHlwZTtcclxuICAgIHN0YXRpYyBVcmxQYXRoID0gVXJsUGF0aDtcclxuICAgIHN0YXRpYyBVSSA9IFVJO1xyXG4gICAgc3RhdGljIEdhbWVEYXRhVHlwZSA9IEdhbWVEYXRhVHlwZTtcclxuICAgIHN0YXRpYyBHb29kc1R5cGUgPSBHb29kc1R5cGU7XHJcbiAgICBzdGF0aWMgQXVkaW9DbGlwID0gQXVkaW9DbGlwO1xyXG4gICAgc3RhdGljIExldmVsU3RhdGUgPSBMZXZlbFN0YXRlO1xyXG59XHJcbiJdfQ==