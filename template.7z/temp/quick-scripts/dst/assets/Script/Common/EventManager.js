
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/EventManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '923b3ZTA9BPFb6bNUNyeF3N', 'EventManager');
// CommonScript/EventManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Handler = void 0;
/**
 * 自定义的事件管理器
 */
var EventManager = /** @class */ (function () {
    function EventManager() {
    }
    /**
     * 注册事件
     * @param {number} type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     * @returns {Handler} 若注册成功，返回回调对象
     */
    EventManager.on = function (type, cb, target) {
        if (!this.events.hasOwnProperty(type)) {
            this.events[type] = [];
        }
        for (var i = this.events[type].length - 1; i >= 0; --i) {
            if (this.events[type][i].equal(cb, target)) {
                return null;
            }
        }
        var h = new Handler(cb, target);
        this.events[type].push(h);
        return h;
    };
    /**
     * 注册只触发一次的事件
     * @param {number} type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     * @returns {Handler} 若注册成功，返回回调对象
     */
    EventManager.once = function (type, cb, target) {
        if (!this.onceEvents.hasOwnProperty(type)) {
            this.onceEvents[type] = [];
        }
        for (var i = this.onceEvents[type].length - 1; i >= 0; --i) {
            if (this.onceEvents[type][i].equal(cb, target)) {
                return null;
            }
        }
        var h = new Handler(cb, target);
        this.onceEvents[type].push(h);
        return h;
    };
    /**
     * 注销事件，只传入事件类型枚举值时，将删除该枚举值对应的所有回调函数
     * @param type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     */
    EventManager.off = function (type, h, target) {
        if (!h) {
            this.events[type] = [];
            this.onceEvents[type] = [];
            return;
        }
        if (h instanceof Handler) {
            if (this.events.hasOwnProperty(type)) {
                for (var i = this.events[type].length - 1; i >= 0; --i) {
                    if (this.events[type][i].id == h.id) {
                        this.events[type].splice(i, 1);
                        break;
                    }
                }
            }
            if (this.onceEvents.hasOwnProperty(type)) {
                for (var i = this.onceEvents[type].length - 1; i >= 0; --i) {
                    if (this.onceEvents[type][i].id == h.id) {
                        this.onceEvents[type].splice(i, 1);
                        break;
                    }
                }
            }
        }
        else {
            if (this.events.hasOwnProperty(type)) {
                for (var i = this.events[type].length - 1; i >= 0; --i) {
                    if (this.events[type][i].equal(h, target)) {
                        this.events[type].splice(i, 1);
                        break;
                    }
                }
            }
            if (this.onceEvents.hasOwnProperty(type)) {
                for (var i = this.onceEvents[type].length - 1; i >= 0; --i) {
                    if (this.onceEvents[type][i].equal(h, target)) {
                        this.onceEvents[type].splice(i, 1);
                        break;
                    }
                }
            }
        }
    };
    /**
     * 批量注销事件
     * @param type 事件类型
     * @param h 事件回调数组
     */
    EventManager.offGroup = function (type, h) {
        if (this.events.hasOwnProperty(type)) {
            for (var i = h.length - 1; i >= 0; --i) {
                for (var j = this.events[type].length - 1; j >= 0; --j) {
                    if (this.events[type][j].id == h[i].id) {
                        this.events[type].splice(j, 1);
                        break;
                    }
                }
            }
        }
        if (this.onceEvents.hasOwnProperty(type)) {
            for (var i = h.length - 1; i >= 0; --i) {
                for (var j = this.onceEvents[type].length - 1; j >= 0; --j) {
                    if (this.onceEvents[type][j].id == h[i].id) {
                        this.onceEvents[type].splice(j, 1);
                        break;
                    }
                }
            }
        }
    };
    /**
     * 发送事件
     * @param {number} type 事件类型枚举值
     * @param {any} data 传给回调函数的参数
     */
    EventManager.emit = function (type, d1, d2, d3, d4, d5) {
        if (this.events.hasOwnProperty(type)) {
            var handlers = this.events[type];
            for (var i = 0, count = handlers.length; i < count; ++i) {
                if (undefined === d1) {
                    handlers[i].cb.call(handlers[i].target);
                }
                else if (undefined === d2) {
                    handlers[i].cb.call(handlers[i].target, d1);
                }
                else if (undefined === d3) {
                    handlers[i].cb.call(handlers[i].target, d1, d2);
                }
                else if (undefined === d4) {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3);
                }
                else if (undefined === d5) {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3, d4);
                }
                else {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3, d4, d5);
                }
            }
        }
        if (this.onceEvents.hasOwnProperty(type)) {
            var handlers = this.onceEvents[type];
            for (var i = 0, count = handlers.length; i < count; ++i) {
                if (undefined === d1) {
                    handlers[i].cb.call(handlers[i].target);
                }
                else if (undefined === d2) {
                    handlers[i].cb.call(handlers[i].target, d1);
                }
                else if (undefined === d3) {
                    handlers[i].cb.call(handlers[i].target, d1, d2);
                }
                else if (undefined === d4) {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3);
                }
                else if (undefined === d5) {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3, d4);
                }
                else {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3, d4, d5);
                }
            }
            delete this.onceEvents[type];
        }
    };
    /**
     * 记录所有事件类型与对应回调函数的字典
     * key:事件类型枚举值
     * value:事件类型对应的回调函数数组
     */
    EventManager.events = {};
    /**
     * 记录所有只触发一次的事件类型与对应回调函数的字典
     * key:事件类型枚举值
     * value:事件类型对应的回调函数数组
     */
    EventManager.onceEvents = {};
    return EventManager;
}());
exports.default = EventManager;
/**
 * 回调函数，包含函数和函数所属的对象
 */
var Handler = /** @class */ (function () {
    /**
     * @param {Function} cb 回调函数
     * @param {Object} target 回调函数所属的对象
     */
    function Handler(cb, target) {
        this._id = Handler.idCount++;
        this.target = target;
        this.cb = cb;
    }
    Object.defineProperty(Handler.prototype, "id", {
        get: function () {
            return this._id;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 比较两个回调是否一样
     * @param {Function} cb
     * @param {Object} target
     */
    Handler.prototype.equal = function (cb, target) {
        return this.target === target && this.cb == cb;
    };
    Handler.idCount = 0; //自增id
    return Handler;
}());
exports.Handler = Handler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcQ29tbW9uU2NyaXB0XFxFdmVudE1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7O0dBRUc7QUFDSDtJQUFBO0lBZ0xBLENBQUM7SUFqS0c7Ozs7OztPQU1HO0lBQ1csZUFBRSxHQUFoQixVQUFpQixJQUFZLEVBQUUsRUFBWSxFQUFFLE1BQWM7UUFDdkQsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ25DLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQzFCO1FBQ0QsS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNwRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDeEMsT0FBTyxJQUFJLENBQUM7YUFDZjtTQUNKO1FBQ0QsSUFBSSxDQUFDLEdBQUcsSUFBSSxPQUFPLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFCLE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUNEOzs7Ozs7T0FNRztJQUNXLGlCQUFJLEdBQWxCLFVBQW1CLElBQVksRUFBRSxFQUFZLEVBQUUsTUFBYztRQUN6RCxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7U0FDOUI7UUFDRCxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3hELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUM1QyxPQUFPLElBQUksQ0FBQzthQUNmO1NBQ0o7UUFDRCxJQUFJLENBQUMsR0FBRyxJQUFJLE9BQU8sQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUIsT0FBTyxDQUFDLENBQUM7SUFDYixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDVyxnQkFBRyxHQUFqQixVQUFrQixJQUFxQixFQUFFLENBQXNCLEVBQUUsTUFBZTtRQUM1RSxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQ0osSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDM0IsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLFlBQVksT0FBTyxFQUFFO1lBQ3RCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ2xDLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3BELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTt3QkFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUMvQixNQUFNO3FCQUNUO2lCQUNKO2FBQ0o7WUFDRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUN0QyxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN4RCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7d0JBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDbkMsTUFBTTtxQkFDVDtpQkFDSjthQUNKO1NBQ0o7YUFBTTtZQUNILElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ2xDLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3BELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFO3dCQUN2QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQy9CLE1BQU07cUJBQ1Q7aUJBQ0o7YUFDSjtZQUNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3RDLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3hELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFO3dCQUMzQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ25DLE1BQU07cUJBQ1Q7aUJBQ0o7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDVyxxQkFBUSxHQUF0QixVQUF1QixJQUFxQixFQUFFLENBQVk7UUFDdEQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNsQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ3BDLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3BELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTt3QkFDcEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUMvQixNQUFNO3FCQUNUO2lCQUNKO2FBQ0o7U0FDSjtRQUNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNwQyxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN4RCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7d0JBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDbkMsTUFBTTtxQkFDVDtpQkFDSjthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBQ0Q7Ozs7T0FJRztJQUNXLGlCQUFJLEdBQWxCLFVBQW1CLElBQVksRUFBRSxFQUFRLEVBQUUsRUFBUSxFQUFFLEVBQVEsRUFBRSxFQUFRLEVBQUUsRUFBUTtRQUM3RSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2xDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDakMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDckQsSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO29CQUNsQixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQzNDO3FCQUFNLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtvQkFDekIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDL0M7cUJBQU0sSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO29CQUN6QixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDbkQ7cUJBQU0sSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO29CQUN6QixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7aUJBQ3ZEO3FCQUFNLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtvQkFDekIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDM0Q7cUJBQU07b0JBQ0gsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7aUJBQy9EO2FBQ0o7U0FDSjtRQUNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdEMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNyRCxJQUFJLFNBQVMsS0FBSyxFQUFFLEVBQUU7b0JBQ2xCLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDM0M7cUJBQU0sSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO29CQUN6QixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2lCQUMvQztxQkFBTSxJQUFJLFNBQVMsS0FBSyxFQUFFLEVBQUU7b0JBQ3pCLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2lCQUNuRDtxQkFBTSxJQUFJLFNBQVMsS0FBSyxFQUFFLEVBQUU7b0JBQ3pCLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDdkQ7cUJBQU0sSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO29CQUN6QixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2lCQUMzRDtxQkFBTTtvQkFDSCxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDL0Q7YUFDSjtZQUNELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNoQztJQUNMLENBQUM7SUE3S0Q7Ozs7T0FJRztJQUNZLG1CQUFNLEdBQWtDLEVBQUUsQ0FBQztJQUMxRDs7OztPQUlHO0lBQ1ksdUJBQVUsR0FBa0MsRUFBRSxDQUFDO0lBbUtsRSxtQkFBQztDQWhMRCxBQWdMQyxJQUFBO2tCQWhMb0IsWUFBWTtBQWtMakM7O0dBRUc7QUFDSDtJQVNJOzs7T0FHRztJQUNILGlCQUFZLEVBQVksRUFBRSxNQUFjO1FBQ3BDLElBQUksQ0FBQyxHQUFHLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO0lBQ2pCLENBQUM7SUFkRCxzQkFBVyx1QkFBRTthQUFiO1lBQ0ksT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ3BCLENBQUM7OztPQUFBO0lBY0Q7Ozs7T0FJRztJQUNILHVCQUFLLEdBQUwsVUFBTSxFQUFZLEVBQUUsTUFBYztRQUM5QixPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDO0lBQ25ELENBQUM7SUF6QmMsZUFBTyxHQUFHLENBQUMsQ0FBQyxDQUFBLE1BQU07SUEwQnJDLGNBQUM7Q0EzQkQsQUEyQkMsSUFBQTtBQTNCWSwwQkFBTyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICog6Ieq5a6a5LmJ55qE5LqL5Lu2566h55CG5ZmoXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEV2ZW50TWFuYWdlciB7XG5cbiAgICAvKipcbiAgICAgKiDorrDlvZXmiYDmnInkuovku7bnsbvlnovkuI7lr7nlupTlm57osIPlh73mlbDnmoTlrZflhbhcbiAgICAgKiBrZXk65LqL5Lu257G75Z6L5p6a5Li+5YC8XG4gICAgICogdmFsdWU65LqL5Lu257G75Z6L5a+55bqU55qE5Zue6LCD5Ye95pWw5pWw57uEXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdGF0aWMgZXZlbnRzOiB7IFt0eXBlOiBudW1iZXJdOiBIYW5kbGVyW10gfSA9IHt9O1xuICAgIC8qKlxuICAgICAqIOiusOW9leaJgOacieWPquinpuWPkeS4gOasoeeahOS6i+S7tuexu+Wei+S4juWvueW6lOWbnuiwg+WHveaVsOeahOWtl+WFuFxuICAgICAqIGtleTrkuovku7bnsbvlnovmnprkuL7lgLxcbiAgICAgKiB2YWx1ZTrkuovku7bnsbvlnovlr7nlupTnmoTlm57osIPlh73mlbDmlbDnu4RcbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBvbmNlRXZlbnRzOiB7IFt0eXBlOiBudW1iZXJdOiBIYW5kbGVyW10gfSA9IHt9O1xuXG4gICAgLyoqXG4gICAgICog5rOo5YaM5LqL5Lu2XG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHR5cGUg5LqL5Lu257G75Z6L5p6a5Li+5YC8XG4gICAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2Ig5Zue6LCD5Ye95pWwXG4gICAgICogQHBhcmFtIHtPYmplY3R9IHRhcmdldCDlh73mlbDmiYDlsZ7lr7nosaFcbiAgICAgKiBAcmV0dXJucyB7SGFuZGxlcn0g6Iul5rOo5YaM5oiQ5Yqf77yM6L+U5Zue5Zue6LCD5a+56LGhXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBvbih0eXBlOiBudW1iZXIsIGNiOiBGdW5jdGlvbiwgdGFyZ2V0OiBPYmplY3QpOiBIYW5kbGVyIHtcbiAgICAgICAgaWYgKCF0aGlzLmV2ZW50cy5oYXNPd25Qcm9wZXJ0eSh0eXBlKSkge1xuICAgICAgICAgICAgdGhpcy5ldmVudHNbdHlwZV0gPSBbXTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5ldmVudHNbdHlwZV0ubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmV2ZW50c1t0eXBlXVtpXS5lcXVhbChjYiwgdGFyZ2V0KSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGxldCBoID0gbmV3IEhhbmRsZXIoY2IsIHRhcmdldCk7XG4gICAgICAgIHRoaXMuZXZlbnRzW3R5cGVdLnB1c2goaCk7XG4gICAgICAgIHJldHVybiBoO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiDms6jlhozlj6rop6blj5HkuIDmrKHnmoTkuovku7ZcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gdHlwZSDkuovku7bnsbvlnovmnprkuL7lgLxcbiAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYiDlm57osIPlh73mlbBcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gdGFyZ2V0IOWHveaVsOaJgOWxnuWvueixoVxuICAgICAqIEByZXR1cm5zIHtIYW5kbGVyfSDoi6Xms6jlhozmiJDlip/vvIzov5Tlm57lm57osIPlr7nosaFcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIG9uY2UodHlwZTogbnVtYmVyLCBjYjogRnVuY3Rpb24sIHRhcmdldDogT2JqZWN0KTogSGFuZGxlciB7XG4gICAgICAgIGlmICghdGhpcy5vbmNlRXZlbnRzLmhhc093blByb3BlcnR5KHR5cGUpKSB7XG4gICAgICAgICAgICB0aGlzLm9uY2VFdmVudHNbdHlwZV0gPSBbXTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5vbmNlRXZlbnRzW3R5cGVdLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5vbmNlRXZlbnRzW3R5cGVdW2ldLmVxdWFsKGNiLCB0YXJnZXQpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGggPSBuZXcgSGFuZGxlcihjYiwgdGFyZ2V0KTtcbiAgICAgICAgdGhpcy5vbmNlRXZlbnRzW3R5cGVdLnB1c2goaCk7XG4gICAgICAgIHJldHVybiBoO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOazqOmUgOS6i+S7tu+8jOWPquS8oOWFpeS6i+S7tuexu+Wei+aemuS4vuWAvOaXtu+8jOWwhuWIoOmZpOivpeaemuS4vuWAvOWvueW6lOeahOaJgOacieWbnuiwg+WHveaVsFxuICAgICAqIEBwYXJhbSB0eXBlIOS6i+S7tuexu+Wei+aemuS4vuWAvFxuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGNiIOWbnuiwg+WHveaVsFxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSB0YXJnZXQg5Ye95pWw5omA5bGe5a+56LGhXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBvZmYodHlwZTogbnVtYmVyIHwgc3RyaW5nLCBoPzogSGFuZGxlciB8IEZ1bmN0aW9uLCB0YXJnZXQ/OiBPYmplY3QpIHtcbiAgICAgICAgaWYgKCFoKSB7XG4gICAgICAgICAgICB0aGlzLmV2ZW50c1t0eXBlXSA9IFtdO1xuICAgICAgICAgICAgdGhpcy5vbmNlRXZlbnRzW3R5cGVdID0gW107XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGggaW5zdGFuY2VvZiBIYW5kbGVyKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5ldmVudHMuaGFzT3duUHJvcGVydHkodHlwZSkpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5ldmVudHNbdHlwZV0ubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuZXZlbnRzW3R5cGVdW2ldLmlkID09IGguaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZXZlbnRzW3R5cGVdLnNwbGljZShpLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMub25jZUV2ZW50cy5oYXNPd25Qcm9wZXJ0eSh0eXBlKSkge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSB0aGlzLm9uY2VFdmVudHNbdHlwZV0ubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMub25jZUV2ZW50c1t0eXBlXVtpXS5pZCA9PSBoLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9uY2VFdmVudHNbdHlwZV0uc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAodGhpcy5ldmVudHMuaGFzT3duUHJvcGVydHkodHlwZSkpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5ldmVudHNbdHlwZV0ubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuZXZlbnRzW3R5cGVdW2ldLmVxdWFsKGgsIHRhcmdldCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZXZlbnRzW3R5cGVdLnNwbGljZShpLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMub25jZUV2ZW50cy5oYXNPd25Qcm9wZXJ0eSh0eXBlKSkge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSB0aGlzLm9uY2VFdmVudHNbdHlwZV0ubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMub25jZUV2ZW50c1t0eXBlXVtpXS5lcXVhbChoLCB0YXJnZXQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9uY2VFdmVudHNbdHlwZV0uc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDmibnph4/ms6jplIDkuovku7ZcbiAgICAgKiBAcGFyYW0gdHlwZSDkuovku7bnsbvlnotcbiAgICAgKiBAcGFyYW0gaCDkuovku7blm57osIPmlbDnu4RcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIG9mZkdyb3VwKHR5cGU6IG51bWJlciB8IHN0cmluZywgaDogSGFuZGxlcltdKSB7XG4gICAgICAgIGlmICh0aGlzLmV2ZW50cy5oYXNPd25Qcm9wZXJ0eSh0eXBlKSkge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IGgubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBqID0gdGhpcy5ldmVudHNbdHlwZV0ubGVuZ3RoIC0gMTsgaiA+PSAwOyAtLWopIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuZXZlbnRzW3R5cGVdW2pdLmlkID09IGhbaV0uaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZXZlbnRzW3R5cGVdLnNwbGljZShqLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLm9uY2VFdmVudHMuaGFzT3duUHJvcGVydHkodHlwZSkpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSBoLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaiA9IHRoaXMub25jZUV2ZW50c1t0eXBlXS5sZW5ndGggLSAxOyBqID49IDA7IC0taikge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5vbmNlRXZlbnRzW3R5cGVdW2pdLmlkID09IGhbaV0uaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub25jZUV2ZW50c1t0eXBlXS5zcGxpY2UoaiwgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiDlj5HpgIHkuovku7ZcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gdHlwZSDkuovku7bnsbvlnovmnprkuL7lgLxcbiAgICAgKiBAcGFyYW0ge2FueX0gZGF0YSDkvKDnu5nlm57osIPlh73mlbDnmoTlj4LmlbBcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGVtaXQodHlwZTogbnVtYmVyLCBkMT86IGFueSwgZDI/OiBhbnksIGQzPzogYW55LCBkND86IGFueSwgZDU/OiBhbnkpIHtcbiAgICAgICAgaWYgKHRoaXMuZXZlbnRzLmhhc093blByb3BlcnR5KHR5cGUpKSB7XG4gICAgICAgICAgICBsZXQgaGFuZGxlcnMgPSB0aGlzLmV2ZW50c1t0eXBlXTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBjb3VudCA9IGhhbmRsZXJzLmxlbmd0aDsgaSA8IGNvdW50OyArK2kpIHtcbiAgICAgICAgICAgICAgICBpZiAodW5kZWZpbmVkID09PSBkMSkge1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVyc1tpXS5jYi5jYWxsKGhhbmRsZXJzW2ldLnRhcmdldCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh1bmRlZmluZWQgPT09IGQyKSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZXJzW2ldLmNiLmNhbGwoaGFuZGxlcnNbaV0udGFyZ2V0LCBkMSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh1bmRlZmluZWQgPT09IGQzKSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZXJzW2ldLmNiLmNhbGwoaGFuZGxlcnNbaV0udGFyZ2V0LCBkMSwgZDIpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodW5kZWZpbmVkID09PSBkNCkge1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVyc1tpXS5jYi5jYWxsKGhhbmRsZXJzW2ldLnRhcmdldCwgZDEsIGQyLCBkMyk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh1bmRlZmluZWQgPT09IGQ1KSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZXJzW2ldLmNiLmNhbGwoaGFuZGxlcnNbaV0udGFyZ2V0LCBkMSwgZDIsIGQzLCBkNCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlcnNbaV0uY2IuY2FsbChoYW5kbGVyc1tpXS50YXJnZXQsIGQxLCBkMiwgZDMsIGQ0LCBkNSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLm9uY2VFdmVudHMuaGFzT3duUHJvcGVydHkodHlwZSkpIHtcbiAgICAgICAgICAgIGxldCBoYW5kbGVycyA9IHRoaXMub25jZUV2ZW50c1t0eXBlXTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBjb3VudCA9IGhhbmRsZXJzLmxlbmd0aDsgaSA8IGNvdW50OyArK2kpIHtcbiAgICAgICAgICAgICAgICBpZiAodW5kZWZpbmVkID09PSBkMSkge1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVyc1tpXS5jYi5jYWxsKGhhbmRsZXJzW2ldLnRhcmdldCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh1bmRlZmluZWQgPT09IGQyKSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZXJzW2ldLmNiLmNhbGwoaGFuZGxlcnNbaV0udGFyZ2V0LCBkMSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh1bmRlZmluZWQgPT09IGQzKSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZXJzW2ldLmNiLmNhbGwoaGFuZGxlcnNbaV0udGFyZ2V0LCBkMSwgZDIpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodW5kZWZpbmVkID09PSBkNCkge1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVyc1tpXS5jYi5jYWxsKGhhbmRsZXJzW2ldLnRhcmdldCwgZDEsIGQyLCBkMyk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh1bmRlZmluZWQgPT09IGQ1KSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZXJzW2ldLmNiLmNhbGwoaGFuZGxlcnNbaV0udGFyZ2V0LCBkMSwgZDIsIGQzLCBkNCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlcnNbaV0uY2IuY2FsbChoYW5kbGVyc1tpXS50YXJnZXQsIGQxLCBkMiwgZDMsIGQ0LCBkNSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGVsZXRlIHRoaXMub25jZUV2ZW50c1t0eXBlXTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLyoqXG4gKiDlm57osIPlh73mlbDvvIzljIXlkKvlh73mlbDlkozlh73mlbDmiYDlsZ7nmoTlr7nosaFcbiAqL1xuZXhwb3J0IGNsYXNzIEhhbmRsZXIge1xuICAgIHByaXZhdGUgc3RhdGljIGlkQ291bnQgPSAwOy8v6Ieq5aKeaWRcbiAgICBwcml2YXRlIF9pZDogbnVtYmVyO1xuICAgIHB1YmxpYyBnZXQgaWQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9pZDtcbiAgICB9XG4gICAgcHVibGljIGNiOiBGdW5jdGlvbjsgICAgICAgLy/lm57osIPlh73mlbBcbiAgICBwdWJsaWMgdGFyZ2V0OiBPYmplY3Q7ICAgICAvL+Wbnuiwg+WHveaVsOaJgOWxnuWvueixoVxuXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2Ig5Zue6LCD5Ye95pWwXG4gICAgICogQHBhcmFtIHtPYmplY3R9IHRhcmdldCDlm57osIPlh73mlbDmiYDlsZ7nmoTlr7nosaFcbiAgICAgKi9cbiAgICBjb25zdHJ1Y3RvcihjYjogRnVuY3Rpb24sIHRhcmdldDogT2JqZWN0KSB7XG4gICAgICAgIHRoaXMuX2lkID0gSGFuZGxlci5pZENvdW50Kys7XG4gICAgICAgIHRoaXMudGFyZ2V0ID0gdGFyZ2V0O1xuICAgICAgICB0aGlzLmNiID0gY2I7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5q+U6L6D5Lik5Liq5Zue6LCD5piv5ZCm5LiA5qC3XG4gICAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2JcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gdGFyZ2V0XG4gICAgICovXG4gICAgZXF1YWwoY2I6IEZ1bmN0aW9uLCB0YXJnZXQ6IE9iamVjdCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy50YXJnZXQgPT09IHRhcmdldCAmJiB0aGlzLmNiID09IGNiO1xuICAgIH1cbn0iXX0=