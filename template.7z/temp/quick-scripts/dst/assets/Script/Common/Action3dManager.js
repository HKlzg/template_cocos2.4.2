
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/Action3dManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b26d3htEkFMfJARkhObfcES', 'Action3dManager');
// Script/Common/Action3dManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.RepeatForever = exports.Spawn3d = exports.Sequence3d = exports.CallFun3d = exports.FadeBy = exports.FadeTo = exports.RotateBy2d = exports.RotateTo2d = exports.RotateBy3d = exports.RotateTo3d = exports.ScaleTo3d = exports.MoveBy3d = exports.MoveTo3d = exports.DelayTime = exports.FiniteTimeAction3d = exports.Action3d = exports.ActionMngType = void 0;
/**动作管理器类型 */
var ActionMngType;
(function (ActionMngType) {
    /**UI动作管理器 */
    ActionMngType["UI"] = "UI";
    /**关卡动作管理器 */
    ActionMngType["Level"] = "Level";
})(ActionMngType = exports.ActionMngType || (exports.ActionMngType = {}));
/**3D动画管理器 */
var Action3dManager = /** @class */ (function () {
    function Action3dManager() {
        this.allActions = [];
        this.allActions = [];
    }
    /**
     * 获取指定类型的动作管理器，用于专门管理某一类对象的动作
     * @param type 管理器的类型，可以是枚举值，也可以自定义一个新的名称，获取新的管理器
     */
    Action3dManager.getMng = function (type) {
        if (!this.allMngs[type]) {
            this.allMngs[type] = new Action3dManager();
        }
        return this.allMngs[type];
    };
    Action3dManager.prototype.update = function (dt) {
        for (var i = this.allActions.length - 1; i >= 0; --i) {
            var act = this.allActions[i];
            if (!act) {
                continue;
            }
            act.update(dt);
            if (act.finished) {
                var index = i;
                if (index >= this.allActions.length) {
                    index = this.allActions.length - 1;
                }
                for (; index >= 0; --index) {
                    if (this.allActions[index].Id == act.Id) {
                        this.allActions.splice(index, 1);
                        break;
                    }
                }
            }
        }
    };
    Action3dManager.prototype.runAction = function (node, action) {
        this.stopAllActions(node);
        action.resetFinishState();
        action.setTarget(node);
        this.allActions.push(action);
    };
    Action3dManager.prototype.stopAllActions = function (node) {
        for (var i = this.allActions.length - 1; i >= 0; --i) {
            if (this.allActions[i].node == node) {
                this.allActions.splice(i, 1);
            }
        }
    };
    Action3dManager.delay = function (duration) {
        return new DelayTime(duration);
    };
    Action3dManager.moveTo = function (duration, x, y, z) {
        return new MoveTo3d(duration, x, y, z);
    };
    Action3dManager.moveBy = function (duration, x, y, z) {
        return new MoveBy3d(duration, x, y, z);
    };
    Action3dManager.scaleTo = function (duration, x, y, z) {
        return new ScaleTo3d(duration, x, y, z);
    };
    Action3dManager.rotateTo = function (duration, x, y, z) {
        return new RotateTo3d(duration, x, y, z);
    };
    Action3dManager.rotateBy = function (duration, x, y, z) {
        return new RotateBy3d(duration, x, y, z);
    };
    Action3dManager.rotateTo2d = function (duration, angle) {
        return new RotateTo2d(duration, angle);
    };
    Action3dManager.rotateBy2d = function (duration, angle) {
        return new RotateBy2d(duration, angle);
    };
    Action3dManager.fadeTo = function (duration, opacity) {
        return new FadeTo(duration, opacity);
    };
    Action3dManager.fadeBy = function (duration, opacity) {
        return new FadeBy(duration, opacity);
    };
    /**
     * 按目标值的方式修改对象的任意属性值
     * @param duration 动作持续的时间
     * @param attribute 变量名称
     * @param value 变化的相对值
     * @param newAttribute 值变化时是否需要新建属性再给目标对象赋值，例如要修改节点的position属性时应该为true
     */
    Action3dManager.tweenTo = function (duration, attribute, value, newAttribute) {
        if (newAttribute === void 0) { newAttribute = false; }
        return new TweenTo(duration, attribute, value, newAttribute);
    };
    /**
     * 按相对值的方式修改对象的任意属性值
     * @param duration 动作持续的时间
     * @param attribute 变量名称
     * @param value 变化的相对值
     * @param newAttribute 值变化时是否需要新建属性再给目标对象赋值，例如要修改节点的position属性时应该为true
     */
    Action3dManager.tweenBy = function (duration, attribute, value, newAttribute) {
        if (newAttribute === void 0) { newAttribute = false; }
        return new TweenBy(duration, attribute, value, newAttribute);
    };
    Action3dManager.callFun = function (cb, target, data) {
        return new CallFun3d(cb, target, data);
    };
    Action3dManager.sequence = function () {
        var actions = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            actions[_i] = arguments[_i];
        }
        return new Sequence3d(actions);
    };
    Action3dManager.spawn = function () {
        var actions = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            actions[_i] = arguments[_i];
        }
        return new Spawn3d(actions);
    };
    Action3dManager.repeatForever = function (action) {
        return new RepeatForever(action);
    };
    //缓动动作
    Action3dManager.easeIn = function (rate) {
        return new EaseIn(rate);
    };
    Action3dManager.easeOut = function (rate) {
        return new EaseOut(rate);
    };
    Action3dManager.easeInOut = function (rate) {
        return new EaseInOut(rate);
    };
    Action3dManager.easeOutIn = function (rate) {
        return new EaseOutIn(rate);
    };
    Action3dManager.easeExponentialIn = function () {
        return new EaseExponentialIn();
    };
    Action3dManager.easeExponentialOut = function () {
        return new EaseExponentialOut();
    };
    Action3dManager.easeExponentialInOut = function () {
        return new EaseExponentialInOut();
    };
    Action3dManager.easeSinIn = function () {
        return new EaseSinIn();
    };
    Action3dManager.easeSinOut = function () {
        return new EaseSinOut();
    };
    Action3dManager.easeSinInOut = function () {
        return new EaseSinInOut();
    };
    Action3dManager.easeSinOutIn = function () {
        return new EaseSinOutIn();
    };
    /**弹性变化进入，先回弹再变快 */
    Action3dManager.easeElasticIn = function (rate) {
        return new EaseElasticIn(rate);
    };
    /**弹性变化退出，先快速到达目标值再回弹 */
    Action3dManager.easeElasticOut = function (rate) {
        return new EaseElasticOut(rate);
    };
    /**弹性变化进入再退出，在时间轴的中间部分进行回弹 */
    Action3dManager.easeElasticInOut = function (rate) {
        return new EaseElasticInOut(rate);
    };
    /**按弹跳动作进入 */
    Action3dManager.easeBounceIn = function () {
        return new EaseBounceIn();
    };
    /**按弹跳动作退出 */
    Action3dManager.easeBounceOut = function () {
        return new EaseBounceOut();
    };
    Action3dManager.allMngs = {};
    return Action3dManager;
}());
exports.default = Action3dManager;
//动作基类
var Action3d = /** @class */ (function () {
    function Action3d() {
        this.myId = null;
    }
    Object.defineProperty(Action3d.prototype, "Id", {
        get: function () {
            if (null === this.myId) {
                this.myId = Action3d._id++;
            }
            return this.myId;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Action3d.prototype, "binded", {
        get: function () { return !!this.node; },
        enumerable: false,
        configurable: true
    });
    Action3d.prototype.setTarget = function (node) {
        this.node = node;
    };
    Action3d.prototype.easing = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        this._easeList = [];
        for (var i = 0, c = args.length; i < c; ++i) {
            this._easeList.push(args[i]);
        }
        return this;
    };
    /**缓动动作时间缩放 */
    Action3d.prototype.computeEaseTime = function (rate) {
        var locList = this._easeList;
        if ((!locList) || (locList.length === 0)) {
            return rate;
        }
        for (var i = 0, n = locList.length; i < n; i++) {
            rate = locList[i].easing(rate);
        }
        return rate;
    };
    Object.defineProperty(Action3d.prototype, "finished", {
        get: function () { return false; },
        enumerable: false,
        configurable: true
    });
    Action3d.prototype.resetFinishState = function () {
    };
    Action3d.prototype.update = function (dt) { };
    Action3d._id = 0;
    return Action3d;
}());
exports.Action3d = Action3d;
//有限时长的动作
var FiniteTimeAction3d = /** @class */ (function (_super) {
    __extends(FiniteTimeAction3d, _super);
    function FiniteTimeAction3d(duration) {
        var _this = _super.call(this) || this;
        _this._paused = false;
        _this.duration = duration;
        _this.elapse = 0;
        return _this;
    }
    Object.defineProperty(FiniteTimeAction3d.prototype, "finished", {
        get: function () { return this.elapse >= this.duration; },
        enumerable: false,
        configurable: true
    });
    FiniteTimeAction3d.prototype.resetFinishState = function () {
        this.elapse = 0;
    };
    Object.defineProperty(FiniteTimeAction3d.prototype, "paused", {
        get: function () { return this._paused; },
        enumerable: false,
        configurable: true
    });
    FiniteTimeAction3d.prototype.update = function (dt) {
        var rate = this.addElapseTime(dt);
        this.step(rate);
    };
    FiniteTimeAction3d.prototype.addElapseTime = function (dt) {
        this.elapse += dt;
        var rate = 1;
        if (this.duration > 0) {
            rate = this.elapse / this.duration;
            if (rate > 1)
                rate = 1;
        }
        rate = this.computeEaseTime(rate);
        return rate;
    };
    FiniteTimeAction3d.prototype.step = function (rate) {
    };
    FiniteTimeAction3d.prototype.interpolation = function (min, max, rate) {
        return min + (max - min) * rate;
    };
    return FiniteTimeAction3d;
}(Action3d));
exports.FiniteTimeAction3d = FiniteTimeAction3d;
//延迟
var DelayTime = /** @class */ (function (_super) {
    __extends(DelayTime, _super);
    function DelayTime() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return DelayTime;
}(FiniteTimeAction3d));
exports.DelayTime = DelayTime;
//移动
var MoveTo3d = /** @class */ (function (_super) {
    __extends(MoveTo3d, _super);
    function MoveTo3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        _this.curValue = {
            x: 0,
            y: 0,
            z: 0
        };
        return _this;
    }
    MoveTo3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.x,
            y: node.y,
            z: node.z
        };
    };
    MoveTo3d.prototype.step = function (rate) {
        this.curValue.x = this.interpolation(this.original.x, this.target.x, rate);
        this.curValue.y = this.interpolation(this.original.y, this.target.y, rate);
        this.curValue.z = this.interpolation(this.original.z, this.target.z, rate);
        this.node.setPosition(this.curValue.x, this.curValue.y, this.curValue.z);
    };
    return MoveTo3d;
}(FiniteTimeAction3d));
exports.MoveTo3d = MoveTo3d;
var MoveBy3d = /** @class */ (function (_super) {
    __extends(MoveBy3d, _super);
    function MoveBy3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        _this.curValue = {
            x: 0,
            y: 0,
            z: 0
        };
        return _this;
    }
    MoveBy3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.x,
            y: node.y,
            z: node.z
        };
    };
    MoveBy3d.prototype.step = function (rate) {
        this.curValue.x = this.original.x + this.target.x * rate;
        this.curValue.y = this.original.y + this.target.y * rate;
        this.curValue.z = this.original.z + this.target.z * rate;
        this.node.setPosition(this.curValue.x, this.curValue.y, this.curValue.z);
    };
    return MoveBy3d;
}(FiniteTimeAction3d));
exports.MoveBy3d = MoveBy3d;
//缩放
var ScaleTo3d = /** @class */ (function (_super) {
    __extends(ScaleTo3d, _super);
    function ScaleTo3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        return _this;
    }
    ScaleTo3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.scaleX,
            y: node.scaleY,
            z: node.scaleZ
        };
    };
    ScaleTo3d.prototype.step = function (rate) {
        var x = this.interpolation(this.original.x, this.target.x, rate);
        var y = this.interpolation(this.original.y, this.target.y, rate);
        var z = this.interpolation(this.original.z, this.target.z, rate);
        this.node.setScale(x, y, z);
    };
    return ScaleTo3d;
}(FiniteTimeAction3d));
exports.ScaleTo3d = ScaleTo3d;
//旋转
var RotateTo3d = /** @class */ (function (_super) {
    __extends(RotateTo3d, _super);
    function RotateTo3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        return _this;
    }
    RotateTo3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.eulerAngles.x,
            y: node.eulerAngles.y,
            z: node.eulerAngles.z
        };
    };
    RotateTo3d.prototype.step = function (rate) {
        var x = this.interpolation(this.original.x, this.target.x, rate);
        var y = this.interpolation(this.original.y, this.target.y, rate);
        var z = this.interpolation(this.original.z, this.target.z, rate);
        this.node.eulerAngles = cc.v3(x, y, z);
    };
    return RotateTo3d;
}(FiniteTimeAction3d));
exports.RotateTo3d = RotateTo3d;
var RotateBy3d = /** @class */ (function (_super) {
    __extends(RotateBy3d, _super);
    function RotateBy3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        return _this;
    }
    RotateBy3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.eulerAngles.x,
            y: node.eulerAngles.y,
            z: node.eulerAngles.z
        };
    };
    RotateBy3d.prototype.step = function (rate) {
        var x = this.original.x + this.target.x * rate;
        var y = this.original.y + this.target.y * rate;
        var z = this.original.z + this.target.z * rate;
        this.node.eulerAngles = cc.v3(x, y, z);
    };
    return RotateBy3d;
}(FiniteTimeAction3d));
exports.RotateBy3d = RotateBy3d;
//2D旋转
var RotateTo2d = /** @class */ (function (_super) {
    __extends(RotateTo2d, _super);
    function RotateTo2d(duration, angle) {
        var _this = _super.call(this, duration) || this;
        _this.target = angle;
        return _this;
    }
    RotateTo2d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = node.angle;
    };
    RotateTo2d.prototype.step = function (rate) {
        var angle = this.interpolation(this.original, this.target, rate);
        this.node.angle = angle;
    };
    return RotateTo2d;
}(FiniteTimeAction3d));
exports.RotateTo2d = RotateTo2d;
//2D旋转
var RotateBy2d = /** @class */ (function (_super) {
    __extends(RotateBy2d, _super);
    function RotateBy2d(duration, angle) {
        var _this = _super.call(this, duration) || this;
        _this.target = angle;
        return _this;
    }
    RotateBy2d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = node.angle;
    };
    RotateBy2d.prototype.step = function (rate) {
        var angle = this.original + this.target * rate;
        this.node.angle = angle;
    };
    return RotateBy2d;
}(FiniteTimeAction3d));
exports.RotateBy2d = RotateBy2d;
//2D节点：透明度变化
var FadeTo = /** @class */ (function (_super) {
    __extends(FadeTo, _super);
    function FadeTo(duration, x) {
        var _this = _super.call(this, duration) || this;
        _this.target = x;
        return _this;
    }
    FadeTo.prototype.setTarget = function (node) {
        this.node = node;
        this.original = node.opacity;
    };
    FadeTo.prototype.step = function (rate) {
        var o = this.interpolation(this.original, this.target, rate);
        this.node.opacity = o;
    };
    return FadeTo;
}(FiniteTimeAction3d));
exports.FadeTo = FadeTo;
var FadeBy = /** @class */ (function (_super) {
    __extends(FadeBy, _super);
    function FadeBy(duration, x) {
        var _this = _super.call(this, duration) || this;
        _this.target = x;
        return _this;
    }
    FadeBy.prototype.setTarget = function (node) {
        this.node = node;
        this.original = node.opacity;
    };
    FadeBy.prototype.step = function (rate) {
        this.node.opacity = this.original + this.target * rate;
    };
    return FadeBy;
}(FiniteTimeAction3d));
exports.FadeBy = FadeBy;
//任意属性变化
var TweenTo = /** @class */ (function (_super) {
    __extends(TweenTo, _super);
    /**
     *
     * @param duration 动作持续的时间
     * @param attribute 变量名称
     * @param value 变化的相对值
     * @param newAttribute 值变化时是否需要新建属性再给目标对象赋值，例如要修改节点的position属性时应该为true
     */
    function TweenTo(duration, attribute, value, newAttribute) {
        var _this = _super.call(this, duration) || this;
        _this.attribute = attribute;
        _this.targetValue = value;
        _this.isNumber = (typeof value === "number");
        _this.newAttribute = newAttribute;
        return _this;
    }
    TweenTo.prototype.setTarget = function (obj) {
        this.obj = obj;
        if (undefined === obj[this.attribute]) {
            console.error("对象不存在属性" + this.attribute + "，动作TweenTo将无法生效");
            return;
        }
        this.original = JSON.parse(JSON.stringify(obj[this.attribute]));
    };
    TweenTo.prototype.step = function (rate) {
        if (this.isNumber) {
            this.obj[this.attribute] = this.interpolation(this.original, this.targetValue, rate);
        }
        else if (this.newAttribute) {
            var data = {};
            for (var key in this.original) {
                data[key] = this.interpolation(this.original[key], this.targetValue[key], rate);
            }
            this.obj[this.attribute] = data;
        }
        else {
            for (var key in this.original) {
                this.obj[this.attribute][key] = this.interpolation(this.original[key], this.targetValue[key], rate);
            }
        }
    };
    return TweenTo;
}(FiniteTimeAction3d));
var TweenBy = /** @class */ (function (_super) {
    __extends(TweenBy, _super);
    /**
     *
     * @param duration 动作持续的时间
     * @param attribute 变量名称
     * @param value 变化的相对值
     * @param newAttribute 值变化时是否需要新建属性再给目标对象赋值，例如要修改节点的position属性时应该为true
     */
    function TweenBy(duration, attribute, value, newAttribute) {
        var _this = _super.call(this, duration) || this;
        _this.attribute = attribute;
        _this.targetValue = value;
        _this.isNumber = (typeof value === "number");
        _this.newAttribute = newAttribute;
        return _this;
    }
    TweenBy.prototype.setTarget = function (obj) {
        this.obj = obj;
        if (undefined === obj[this.attribute]) {
            console.error("对象不存在属性" + this.attribute + "，动作TweenTo将无法生效");
            return;
        }
        this.original = JSON.parse(JSON.stringify(obj[this.attribute]));
    };
    TweenBy.prototype.step = function (rate) {
        if (this.isNumber) {
            this.obj[this.attribute] = this.original + this.targetValue * rate;
        }
        else if (this.newAttribute) {
            var data = {};
            for (var key in this.original) {
                data[key] = this.original[key] + this.targetValue[key] * rate;
            }
            this.obj[this.attribute] = data;
        }
        else {
            for (var key in this.original) {
                this.obj[this.attribute][key] = this.original[key] + this.targetValue[key] * rate;
            }
        }
    };
    return TweenBy;
}(FiniteTimeAction3d));
//回调函数
var CallFun3d = /** @class */ (function (_super) {
    __extends(CallFun3d, _super);
    function CallFun3d(cb, target, data) {
        var _this = _super.call(this) || this;
        _this._finished = false;
        _this.cb = cb;
        _this.target = target;
        _this.data = data;
        return _this;
    }
    Object.defineProperty(CallFun3d.prototype, "finished", {
        get: function () { return this._finished; },
        enumerable: false,
        configurable: true
    });
    CallFun3d.prototype.resetFinishState = function () {
        this._finished = false;
    };
    CallFun3d.prototype.update = function (dt) {
        if (this.finished)
            return;
        if (!!this.target) {
            this.cb.call(this.target, this.data || null);
        }
        else {
            this.cb(this.data || null);
        }
        this._finished = true;
    };
    return CallFun3d;
}(Action3d));
exports.CallFun3d = CallFun3d;
//队列动作
var Sequence3d = /** @class */ (function (_super) {
    __extends(Sequence3d, _super);
    function Sequence3d(actions) {
        var _this = _super.call(this) || this;
        _this.curActionPtr = 0;
        _this.actions = [].concat(actions);
        return _this;
    }
    Object.defineProperty(Sequence3d.prototype, "finished", {
        get: function () { return this.curActionPtr >= this.actions.length; },
        enumerable: false,
        configurable: true
    });
    Sequence3d.prototype.resetFinishState = function () {
        for (var i = this.actions.length - 1; i >= 0; --i) {
            this.actions[i].resetFinishState();
        }
        this.curActionPtr = 0;
        this.setCurActionTarget();
    };
    Sequence3d.prototype.setTarget = function (node) {
        this.node = node;
        // for (let i = this.actions.length - 1; i >= 0; --i) {
        //     this.actions[i].setTarget(node);
        // }
        this.setCurActionTarget();
    };
    Sequence3d.prototype.update = function (dt) {
        if (this.finished)
            return;
        var action = this.actions[this.curActionPtr];
        action.update(dt);
        if (action.finished) {
            this.curActionPtr++;
            this.setCurActionTarget();
        }
    };
    /**设置当前正在执行的动作的目标节点 */
    Sequence3d.prototype.setCurActionTarget = function () {
        if (!this.finished)
            this.actions[this.curActionPtr].setTarget(this.node);
    };
    Sequence3d.prototype.pushAction = function (action) {
        this.actions.push(action);
    };
    return Sequence3d;
}(Action3d));
exports.Sequence3d = Sequence3d;
//同步动作
var Spawn3d = /** @class */ (function (_super) {
    __extends(Spawn3d, _super);
    function Spawn3d(actions) {
        var _this = _super.call(this) || this;
        _this.actions = [].concat(actions);
        _this.remainCount = _this.actions.length;
        return _this;
    }
    Object.defineProperty(Spawn3d.prototype, "finished", {
        get: function () {
            return this.remainCount <= 0;
        },
        enumerable: false,
        configurable: true
    });
    Spawn3d.prototype.resetFinishState = function () {
        for (var i = this.actions.length - 1; i >= 0; --i) {
            this.actions[i].resetFinishState();
        }
        this.remainCount = this.actions.length;
    };
    Spawn3d.prototype.setTarget = function (node) {
        this.node = node;
        for (var i = this.actions.length - 1; i >= 0; --i) {
            this.actions[i].setTarget(node);
        }
    };
    Spawn3d.prototype.update = function (dt) {
        if (this.finished)
            return;
        for (var i = this.actions.length - 1; i >= 0; --i) {
            if (!this.actions[i].finished) {
                this.actions[i].update(dt);
                if (this.actions[i].finished) {
                    this.remainCount--;
                }
            }
        }
    };
    //追加一个动作
    Spawn3d.prototype.pushAction = function (action) {
        this.actions.push(action);
        if (!!this.node)
            action.setTarget(this.node);
    };
    return Spawn3d;
}(Action3d));
exports.Spawn3d = Spawn3d;
//重复动作
var RepeatForever = /** @class */ (function (_super) {
    __extends(RepeatForever, _super);
    function RepeatForever(action) {
        var _this = _super.call(this) || this;
        _this.action = action;
        return _this;
    }
    RepeatForever.prototype.setTarget = function (node) {
        this.node = node;
        this.action.setTarget(node);
    };
    RepeatForever.prototype.update = function (dt) {
        this.action.update(dt);
        if (this.action.finished) {
            this.action.resetFinishState();
        }
    };
    return RepeatForever;
}(Action3d));
exports.RepeatForever = RepeatForever;
//缓动曲线
var Ease = /** @class */ (function () {
    function Ease() {
    }
    Ease.prototype.easing = function (rate) {
        return rate;
    };
    return Ease;
}());
var EaseIn = /** @class */ (function (_super) {
    __extends(EaseIn, _super);
    function EaseIn(rate) {
        var _this = _super.call(this) || this;
        _this._rate = rate;
        return _this;
    }
    EaseIn.prototype.easing = function (rate) {
        return Math.pow(rate, this._rate);
    };
    return EaseIn;
}(Ease));
var EaseOut = /** @class */ (function (_super) {
    __extends(EaseOut, _super);
    function EaseOut(rate) {
        var _this = _super.call(this) || this;
        _this._rate = rate;
        return _this;
    }
    EaseOut.prototype.easing = function (rate) {
        return Math.pow(rate, 1 / this._rate);
    };
    return EaseOut;
}(Ease));
var EaseInOut = /** @class */ (function (_super) {
    __extends(EaseInOut, _super);
    function EaseInOut(rate) {
        var _this = _super.call(this) || this;
        _this._rate = rate;
        return _this;
    }
    EaseInOut.prototype.easing = function (rate) {
        rate *= 2;
        if (rate < 1)
            return 0.5 * Math.pow(rate, this._rate);
        else
            return 1.0 - 0.5 * Math.pow(2 - rate, this._rate);
    };
    return EaseInOut;
}(Ease));
var EaseOutIn = /** @class */ (function (_super) {
    __extends(EaseOutIn, _super);
    function EaseOutIn(rate) {
        var _this = _super.call(this) || this;
        _this._rate = rate;
        return _this;
    }
    EaseOutIn.prototype.easing = function (rate) {
        rate *= 2;
        if (rate < 1)
            return 1.0 - 0.5 * Math.pow(2 - rate, this._rate);
        else
            return 0.5 * Math.pow(rate, this._rate);
    };
    return EaseOutIn;
}(Ease));
/**指数函数缓动进入 */
var EaseExponentialIn = /** @class */ (function (_super) {
    __extends(EaseExponentialIn, _super);
    function EaseExponentialIn() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseExponentialIn.prototype.easing = function (rate) {
        return rate === 0 ? 0 : Math.pow(2, 10 * (rate - 1));
    };
    return EaseExponentialIn;
}(Ease));
/**指数函数缓动退出 */
var EaseExponentialOut = /** @class */ (function (_super) {
    __extends(EaseExponentialOut, _super);
    function EaseExponentialOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseExponentialOut.prototype.easing = function (rate) {
        return rate === 1 ? 1 : (-(Math.pow(2, -10 * rate)) + 1);
    };
    return EaseExponentialOut;
}(Ease));
/**指数函数缓动进入——退出 */
var EaseExponentialInOut = /** @class */ (function (_super) {
    __extends(EaseExponentialInOut, _super);
    function EaseExponentialInOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseExponentialInOut.prototype.easing = function (rate) {
        if (rate !== 1 && rate !== 0) {
            rate *= 2;
            if (rate < 1)
                return 0.5 * Math.pow(2, 10 * (rate - 1));
            else
                return 0.5 * (-Math.pow(2, -10 * (rate - 1)) + 2);
        }
        return rate;
    };
    return EaseExponentialInOut;
}(Ease));
var EaseSinIn = /** @class */ (function (_super) {
    __extends(EaseSinIn, _super);
    function EaseSinIn() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseSinIn.prototype.easing = function (rate) {
        return 1 - Math.sin((1 - rate) * 1.57);
    };
    return EaseSinIn;
}(Ease));
var EaseSinOut = /** @class */ (function (_super) {
    __extends(EaseSinOut, _super);
    function EaseSinOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseSinOut.prototype.easing = function (rate) {
        return Math.sin(rate * 1.57);
    };
    return EaseSinOut;
}(Ease));
var EaseSinInOut = /** @class */ (function (_super) {
    __extends(EaseSinInOut, _super);
    function EaseSinInOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseSinInOut.prototype.easing = function (rate) {
        return Math.sin(rate * 3.14 + 4.71) * 0.5 + 0.5;
    };
    return EaseSinInOut;
}(Ease));
var EaseSinOutIn = /** @class */ (function (_super) {
    __extends(EaseSinOutIn, _super);
    function EaseSinOutIn() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseSinOutIn.prototype.easing = function (rate) {
        if (rate < 0.5) {
            return Math.sin(rate * 3.14) * 0.5;
        }
        else {
            return 1 - Math.sin((1 - rate) * 3.14) * 0.5;
        }
    };
    return EaseSinOutIn;
}(Ease));
//弹性变化
var EaseElasticIn = /** @class */ (function (_super) {
    __extends(EaseElasticIn, _super);
    function EaseElasticIn(rate) {
        var _this = _super.call(this) || this;
        _this._period = rate || 0.3;
        return _this;
    }
    EaseElasticIn.prototype.easing = function (rate) {
        if (rate === 0 || rate === 1)
            return rate;
        rate = rate - 1;
        return -Math.pow(2, 10 * rate) * Math.sin((rate - (this._period / 4)) * Math.PI * 2 / this._period);
    };
    return EaseElasticIn;
}(Ease));
var EaseElasticOut = /** @class */ (function (_super) {
    __extends(EaseElasticOut, _super);
    function EaseElasticOut(rate) {
        var _this = _super.call(this) || this;
        _this._period = rate || 0.3;
        return _this;
    }
    EaseElasticOut.prototype.easing = function (dt) {
        return (dt === 0 || dt === 1) ? dt : Math.pow(2, -10 * dt) * Math.sin((dt - (this._period / 4)) * Math.PI * 2 / this._period) + 1;
    };
    return EaseElasticOut;
}(Ease));
var EaseElasticInOut = /** @class */ (function (_super) {
    __extends(EaseElasticInOut, _super);
    function EaseElasticInOut(rate) {
        var _this = _super.call(this) || this;
        _this._period = rate || 0.3;
        return _this;
    }
    EaseElasticInOut.prototype.easing = function (dt) {
        var newT = 0;
        var locPeriod = this._period;
        if (dt === 0 || dt === 1) {
            newT = dt;
        }
        else {
            dt = dt * 2;
            if (!locPeriod)
                locPeriod = this._period = 0.3 * 1.5;
            var s = locPeriod / 4;
            dt = dt - 1;
            if (dt < 0)
                newT = -0.5 * Math.pow(2, 10 * dt) * Math.sin((dt - s) * Math.PI * 2 / locPeriod);
            else
                newT = Math.pow(2, -10 * dt) * Math.sin((dt - s) * Math.PI * 2 / locPeriod) * 0.5 + 1;
        }
        return newT;
    };
    return EaseElasticInOut;
}(Ease));
//按弹跳动作缓动进入的动作
var EaseBounceIn = /** @class */ (function (_super) {
    __extends(EaseBounceIn, _super);
    function EaseBounceIn() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseBounceIn.prototype.easing = function (dt) {
        return 1 - this._bounceTime(1 - dt);
    };
    EaseBounceIn.prototype._bounceTime = function (time1) {
        if (time1 < 1 / 2.75) {
            return 7.5625 * time1 * time1;
        }
        else if (time1 < 2 / 2.75) {
            time1 -= 1.5 / 2.75;
            return 7.5625 * time1 * time1 + 0.75;
        }
        else if (time1 < 2.5 / 2.75) {
            time1 -= 2.25 / 2.75;
            return 7.5625 * time1 * time1 + 0.9375;
        }
        time1 -= 2.625 / 2.75;
        return 7.5625 * time1 * time1 + 0.984375;
    };
    return EaseBounceIn;
}(Ease));
var EaseBounceOut = /** @class */ (function (_super) {
    __extends(EaseBounceOut, _super);
    function EaseBounceOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseBounceOut.prototype.easing = function (dt) {
        return this._bounceTime(dt);
    };
    EaseBounceOut.prototype._bounceTime = function (time1) {
        if (time1 < 1 / 2.75) {
            return 7.5625 * time1 * time1;
        }
        else if (time1 < 2 / 2.75) {
            time1 -= 1.5 / 2.75;
            return 7.5625 * time1 * time1 + 0.75;
        }
        else if (time1 < 2.5 / 2.75) {
            time1 -= 2.25 / 2.75;
            return 7.5625 * time1 * time1 + 0.9375;
        }
        time1 -= 2.625 / 2.75;
        return 7.5625 * time1 * time1 + 0.984375;
    };
    return EaseBounceOut;
}(Ease));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXEFjdGlvbjNkTWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBT0EsYUFBYTtBQUNiLElBQVksYUFNWDtBQU5ELFdBQVksYUFBYTtJQUNyQixhQUFhO0lBQ2IsMEJBQVMsQ0FBQTtJQUNULGFBQWE7SUFDYixnQ0FBZSxDQUFBO0FBRW5CLENBQUMsRUFOVyxhQUFhLEdBQWIscUJBQWEsS0FBYixxQkFBYSxRQU14QjtBQUVELGFBQWE7QUFDYjtJQWNJO1FBR1UsZUFBVSxHQUFlLEVBQUUsQ0FBQztRQUZsQyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBYkQ7OztPQUdHO0lBQ1csc0JBQU0sR0FBcEIsVUFBcUIsSUFBSTtRQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNyQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksZUFBZSxFQUFFLENBQUM7U0FDOUM7UUFDRCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQU9NLGdDQUFNLEdBQWIsVUFBYyxFQUFVO1FBQ3BCLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDbEQsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM3QixJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNOLFNBQVM7YUFDWjtZQUNELEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDZixJQUFJLEdBQUcsQ0FBQyxRQUFRLEVBQUU7Z0JBQ2QsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFO29CQUNqQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2lCQUN0QztnQkFDRCxPQUFPLEtBQUssSUFBSSxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUU7b0JBQ3hCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLElBQUksR0FBRyxDQUFDLEVBQUUsRUFBRTt3QkFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNqQyxNQUFNO3FCQUNUO2lCQUNKO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFDTSxtQ0FBUyxHQUFoQixVQUFpQixJQUFhLEVBQUUsTUFBZ0I7UUFDNUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMxQixNQUFNLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUMxQixNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFDTSx3Q0FBYyxHQUFyQixVQUFzQixJQUFhO1FBQy9CLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDbEQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUU7Z0JBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUNoQztTQUNKO0lBQ0wsQ0FBQztJQUVhLHFCQUFLLEdBQW5CLFVBQW9CLFFBQWdCO1FBQ2hDLE9BQU8sSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNhLHNCQUFNLEdBQXBCLFVBQXFCLFFBQWdCLEVBQUUsQ0FBZ0IsRUFBRSxDQUFVLEVBQUUsQ0FBVTtRQUMzRSxPQUFPLElBQUksUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDYSxzQkFBTSxHQUFwQixVQUFxQixRQUFnQixFQUFFLENBQWdCLEVBQUUsQ0FBVSxFQUFFLENBQVU7UUFDM0UsT0FBTyxJQUFJLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ2EsdUJBQU8sR0FBckIsVUFBc0IsUUFBZ0IsRUFBRSxDQUFnQixFQUFFLENBQVUsRUFBRSxDQUFVO1FBQzVFLE9BQU8sSUFBSSxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNhLHdCQUFRLEdBQXRCLFVBQXVCLFFBQWdCLEVBQUUsQ0FBZ0IsRUFBRSxDQUFVLEVBQUUsQ0FBVTtRQUM3RSxPQUFPLElBQUksVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDYSx3QkFBUSxHQUF0QixVQUF1QixRQUFnQixFQUFFLENBQWdCLEVBQUUsQ0FBVSxFQUFFLENBQVU7UUFDN0UsT0FBTyxJQUFJLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ2EsMEJBQVUsR0FBeEIsVUFBeUIsUUFBZ0IsRUFBRSxLQUFhO1FBQ3BELE9BQU8sSUFBSSxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDYSwwQkFBVSxHQUF4QixVQUF5QixRQUFnQixFQUFFLEtBQWE7UUFDcEQsT0FBTyxJQUFJLFVBQVUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNhLHNCQUFNLEdBQXBCLFVBQXFCLFFBQWdCLEVBQUUsT0FBZTtRQUNsRCxPQUFPLElBQUksTUFBTSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ2Esc0JBQU0sR0FBcEIsVUFBcUIsUUFBZ0IsRUFBRSxPQUFlO1FBQ2xELE9BQU8sSUFBSSxNQUFNLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDVyx1QkFBTyxHQUFyQixVQUFzQixRQUFnQixFQUFFLFNBQWlCLEVBQUUsS0FBVSxFQUFFLFlBQTZCO1FBQTdCLDZCQUFBLEVBQUEsb0JBQTZCO1FBQ2hHLE9BQU8sSUFBSSxPQUFPLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUNEOzs7Ozs7T0FNRztJQUNXLHVCQUFPLEdBQXJCLFVBQXNCLFFBQWdCLEVBQUUsU0FBaUIsRUFBRSxLQUFVLEVBQUUsWUFBNkI7UUFBN0IsNkJBQUEsRUFBQSxvQkFBNkI7UUFDaEcsT0FBTyxJQUFJLE9BQU8sQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRWEsdUJBQU8sR0FBckIsVUFBc0IsRUFBWSxFQUFFLE1BQVksRUFBRSxJQUFVO1FBQ3hELE9BQU8sSUFBSSxTQUFTLENBQUMsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRWEsd0JBQVEsR0FBdEI7UUFBdUIsaUJBQVU7YUFBVixVQUFVLEVBQVYscUJBQVUsRUFBVixJQUFVO1lBQVYsNEJBQVU7O1FBQzdCLE9BQU8sSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVhLHFCQUFLLEdBQW5CO1FBQW9CLGlCQUFVO2FBQVYsVUFBVSxFQUFWLHFCQUFVLEVBQVYsSUFBVTtZQUFWLDRCQUFVOztRQUMxQixPQUFPLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFYSw2QkFBYSxHQUEzQixVQUE0QixNQUFnQjtRQUN4QyxPQUFPLElBQUksYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxNQUFNO0lBQ1Esc0JBQU0sR0FBcEIsVUFBcUIsSUFBWTtRQUM3QixPQUFPLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFDYSx1QkFBTyxHQUFyQixVQUFzQixJQUFZO1FBQzlCLE9BQU8sSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUNhLHlCQUFTLEdBQXZCLFVBQXdCLElBQVk7UUFDaEMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBQ2EseUJBQVMsR0FBdkIsVUFBd0IsSUFBWTtRQUNoQyxPQUFPLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFYSxpQ0FBaUIsR0FBL0I7UUFDSSxPQUFPLElBQUksaUJBQWlCLEVBQUUsQ0FBQztJQUNuQyxDQUFDO0lBQ2Esa0NBQWtCLEdBQWhDO1FBQ0ksT0FBTyxJQUFJLGtCQUFrQixFQUFFLENBQUM7SUFDcEMsQ0FBQztJQUNhLG9DQUFvQixHQUFsQztRQUNJLE9BQU8sSUFBSSxvQkFBb0IsRUFBRSxDQUFDO0lBQ3RDLENBQUM7SUFFYSx5QkFBUyxHQUF2QjtRQUNJLE9BQU8sSUFBSSxTQUFTLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBQ2EsMEJBQVUsR0FBeEI7UUFDSSxPQUFPLElBQUksVUFBVSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUNhLDRCQUFZLEdBQTFCO1FBQ0ksT0FBTyxJQUFJLFlBQVksRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFDYSw0QkFBWSxHQUExQjtRQUNJLE9BQU8sSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRUQsbUJBQW1CO0lBQ0wsNkJBQWEsR0FBM0IsVUFBNEIsSUFBYTtRQUNyQyxPQUFPLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFDRCx3QkFBd0I7SUFDViw4QkFBYyxHQUE1QixVQUE2QixJQUFhO1FBQ3RDLE9BQU8sSUFBSSxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNELDZCQUE2QjtJQUNmLGdDQUFnQixHQUE5QixVQUErQixJQUFhO1FBQ3hDLE9BQU8sSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsYUFBYTtJQUNDLDRCQUFZLEdBQTFCO1FBQ0ksT0FBTyxJQUFJLFlBQVksRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFDRCxhQUFhO0lBQ0MsNkJBQWEsR0FBM0I7UUFDSSxPQUFPLElBQUksYUFBYSxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQWhMZ0IsdUJBQU8sR0FBd0MsRUFBRSxDQUFDO0lBaUx2RSxzQkFBQztDQW5MRCxBQW1MQyxJQUFBO2tCQW5Mb0IsZUFBZTtBQXFMcEMsTUFBTTtBQUNOO0lBQUE7UUFFYyxTQUFJLEdBQVcsSUFBSSxDQUFDO0lBcUNsQyxDQUFDO0lBcENHLHNCQUFXLHdCQUFFO2FBQWI7WUFDSSxJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNwQixJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUM5QjtZQUNELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQztRQUNyQixDQUFDOzs7T0FBQTtJQUVELHNCQUFXLDRCQUFNO2FBQWpCLGNBQStCLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUM3Qyw0QkFBUyxHQUFoQixVQUFpQixJQUFhO1FBQzFCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0lBQ3JCLENBQUM7SUFHTSx5QkFBTSxHQUFiO1FBQWMsY0FBZTthQUFmLFVBQWUsRUFBZixxQkFBZSxFQUFmLElBQWU7WUFBZix5QkFBZTs7UUFDekIsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFDcEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN6QyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNoQztRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDRCxjQUFjO0lBQ0osa0NBQWUsR0FBekIsVUFBMEIsSUFBWTtRQUNsQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQzdCLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUMsRUFBRTtZQUN0QyxPQUFPLElBQUksQ0FBQztTQUNmO1FBQ0QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM1QyxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNsQztRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDRCxzQkFBVyw4QkFBUTthQUFuQixjQUFpQyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBQ3pDLG1DQUFnQixHQUF2QjtJQUVBLENBQUM7SUFDTSx5QkFBTSxHQUFiLFVBQWMsRUFBVSxJQUFJLENBQUM7SUFyQ1osWUFBRyxHQUFXLENBQUMsQ0FBQztJQXNDckMsZUFBQztDQXZDRCxBQXVDQyxJQUFBO0FBdkNZLDRCQUFRO0FBMENyQixTQUFTO0FBQ1Q7SUFBd0Msc0NBQVE7SUFhNUMsNEJBQW1CLFFBQWdCO1FBQW5DLFlBQ0ksaUJBQU8sU0FHVjtRQVBTLGFBQU8sR0FBWSxLQUFLLENBQUM7UUFLL0IsS0FBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7UUFDekIsS0FBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7O0lBQ3BCLENBQUM7SUFYRCxzQkFBVyx3Q0FBUTthQUFuQixjQUFpQyxPQUFPLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBQ2hFLDZDQUFnQixHQUF2QjtRQUNJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUM7SUFFRCxzQkFBVyxzQ0FBTTthQUFqQixjQUErQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQU85QyxtQ0FBTSxHQUFiLFVBQWMsRUFBVTtRQUNwQixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUNTLDBDQUFhLEdBQXZCLFVBQXdCLEVBQVU7UUFDOUIsSUFBSSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUM7UUFDbEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsSUFBSSxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsRUFBRTtZQUNuQixJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ25DLElBQUksSUFBSSxHQUFHLENBQUM7Z0JBQUUsSUFBSSxHQUFHLENBQUMsQ0FBQztTQUMxQjtRQUNELElBQUksR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xDLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDUyxpQ0FBSSxHQUFkLFVBQWUsSUFBWTtJQUUzQixDQUFDO0lBRVMsMENBQWEsR0FBdkIsVUFBd0IsR0FBVyxFQUFFLEdBQVcsRUFBRSxJQUFZO1FBQzFELE9BQU8sR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztJQUNwQyxDQUFDO0lBQ0wseUJBQUM7QUFBRCxDQXZDQSxBQXVDQyxDQXZDdUMsUUFBUSxHQXVDL0M7QUF2Q1ksZ0RBQWtCO0FBd0MvQixJQUFJO0FBQ0o7SUFBK0IsNkJBQWtCO0lBQWpEOztJQUVBLENBQUM7SUFBRCxnQkFBQztBQUFELENBRkEsQUFFQyxDQUY4QixrQkFBa0IsR0FFaEQ7QUFGWSw4QkFBUztBQUd0QixJQUFJO0FBQ0o7SUFBOEIsNEJBQWtCO0lBTzVDLGtCQUFtQixRQUFnQixFQUFFLENBQWdCLEVBQUUsQ0FBVSxFQUFFLENBQVU7UUFBN0UsWUFDSSxrQkFBTSxRQUFRLENBQUMsU0FlbEI7UUFkRyxJQUFJLE9BQU8sQ0FBQyxLQUFLLFFBQVEsRUFBRTtZQUN2QixLQUFJLENBQUMsTUFBTSxHQUFHO2dCQUNWLENBQUMsRUFBRSxDQUFDO2dCQUNKLENBQUMsRUFBRSxDQUFDO2dCQUNKLENBQUMsRUFBRSxDQUFDO2FBQ1AsQ0FBQztTQUNMO2FBQU07WUFDSCxLQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztTQUNuQjtRQUNELEtBQUksQ0FBQyxRQUFRLEdBQUc7WUFDWixDQUFDLEVBQUUsQ0FBQztZQUNKLENBQUMsRUFBRSxDQUFDO1lBQ0osQ0FBQyxFQUFFLENBQUM7U0FDUCxDQUFDOztJQUNOLENBQUM7SUFFTSw0QkFBUyxHQUFoQixVQUFpQixJQUFhO1FBQzFCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUc7WUFDWixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDVCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDVCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDWixDQUFDO0lBRU4sQ0FBQztJQUVNLHVCQUFJLEdBQVgsVUFBWSxJQUFZO1FBQ3BCLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDM0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMzRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUNMLGVBQUM7QUFBRCxDQXpDQSxBQXlDQyxDQXpDNkIsa0JBQWtCLEdBeUMvQztBQXpDWSw0QkFBUTtBQTBDckI7SUFBOEIsNEJBQWtCO0lBTzVDLGtCQUFtQixRQUFnQixFQUFFLENBQWdCLEVBQUUsQ0FBVSxFQUFFLENBQVU7UUFBN0UsWUFDSSxrQkFBTSxRQUFRLENBQUMsU0FlbEI7UUFkRyxJQUFJLE9BQU8sQ0FBQyxLQUFLLFFBQVEsRUFBRTtZQUN2QixLQUFJLENBQUMsTUFBTSxHQUFHO2dCQUNWLENBQUMsRUFBRSxDQUFDO2dCQUNKLENBQUMsRUFBRSxDQUFDO2dCQUNKLENBQUMsRUFBRSxDQUFDO2FBQ1AsQ0FBQztTQUNMO2FBQU07WUFDSCxLQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztTQUNuQjtRQUNELEtBQUksQ0FBQyxRQUFRLEdBQUc7WUFDWixDQUFDLEVBQUUsQ0FBQztZQUNKLENBQUMsRUFBRSxDQUFDO1lBQ0osQ0FBQyxFQUFFLENBQUM7U0FDUCxDQUFDOztJQUNOLENBQUM7SUFFTSw0QkFBUyxHQUFoQixVQUFpQixJQUFhO1FBQzFCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUc7WUFDWixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDVCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDVCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDWixDQUFDO0lBQ04sQ0FBQztJQUVNLHVCQUFJLEdBQVgsVUFBWSxJQUFZO1FBQ3BCLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUN6RCxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDekQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ3pELElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUNMLGVBQUM7QUFBRCxDQXhDQSxBQXdDQyxDQXhDNkIsa0JBQWtCLEdBd0MvQztBQXhDWSw0QkFBUTtBQXlDckIsSUFBSTtBQUNKO0lBQStCLDZCQUFrQjtJQUs3QyxtQkFBbUIsUUFBZ0IsRUFBRSxDQUFnQixFQUFFLENBQVUsRUFBRSxDQUFVO1FBQTdFLFlBQ0ksa0JBQU0sUUFBUSxDQUFDLFNBVWxCO1FBVEcsSUFBSSxPQUFPLENBQUMsS0FBSyxRQUFRLEVBQUU7WUFDdkIsS0FBSSxDQUFDLE1BQU0sR0FBRztnQkFDVixDQUFDLEVBQUUsQ0FBQztnQkFDSixDQUFDLEVBQUUsQ0FBQztnQkFDSixDQUFDLEVBQUUsQ0FBQzthQUNQLENBQUM7U0FDTDthQUFNO1lBQ0gsS0FBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7U0FDbkI7O0lBQ0wsQ0FBQztJQUVNLDZCQUFTLEdBQWhCLFVBQWlCLElBQWE7UUFDMUIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRztZQUNaLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNkLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNkLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTTtTQUNqQixDQUFDO0lBQ04sQ0FBQztJQUVNLHdCQUFJLEdBQVgsVUFBWSxJQUFZO1FBQ3BCLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUNMLGdCQUFDO0FBQUQsQ0FqQ0EsQUFpQ0MsQ0FqQzhCLGtCQUFrQixHQWlDaEQ7QUFqQ1ksOEJBQVM7QUFrQ3RCLElBQUk7QUFDSjtJQUFnQyw4QkFBa0I7SUFLOUMsb0JBQW1CLFFBQWdCLEVBQUUsQ0FBZ0IsRUFBRSxDQUFVLEVBQUUsQ0FBVTtRQUE3RSxZQUNJLGtCQUFNLFFBQVEsQ0FBQyxTQVVsQjtRQVRHLElBQUksT0FBTyxDQUFDLEtBQUssUUFBUSxFQUFFO1lBQ3ZCLEtBQUksQ0FBQyxNQUFNLEdBQUc7Z0JBQ1YsQ0FBQyxFQUFFLENBQUM7Z0JBQ0osQ0FBQyxFQUFFLENBQUM7Z0JBQ0osQ0FBQyxFQUFFLENBQUM7YUFDUCxDQUFDO1NBQ0w7YUFBTTtZQUNILEtBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1NBQ25COztJQUNMLENBQUM7SUFDTSw4QkFBUyxHQUFoQixVQUFpQixJQUFhO1FBQzFCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUc7WUFDWixDQUFDLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3JCLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDckIsQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUN4QixDQUFDO0lBQ04sQ0FBQztJQUVNLHlCQUFJLEdBQVgsVUFBWSxJQUFZO1FBQ3BCLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0wsaUJBQUM7QUFBRCxDQWhDQSxBQWdDQyxDQWhDK0Isa0JBQWtCLEdBZ0NqRDtBQWhDWSxnQ0FBVTtBQWlDdkI7SUFBZ0MsOEJBQWtCO0lBSzlDLG9CQUFtQixRQUFnQixFQUFFLENBQWdCLEVBQUUsQ0FBVSxFQUFFLENBQVU7UUFBN0UsWUFDSSxrQkFBTSxRQUFRLENBQUMsU0FVbEI7UUFURyxJQUFJLE9BQU8sQ0FBQyxLQUFLLFFBQVEsRUFBRTtZQUN2QixLQUFJLENBQUMsTUFBTSxHQUFHO2dCQUNWLENBQUMsRUFBRSxDQUFDO2dCQUNKLENBQUMsRUFBRSxDQUFDO2dCQUNKLENBQUMsRUFBRSxDQUFDO2FBQ1AsQ0FBQztTQUNMO2FBQU07WUFDSCxLQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztTQUNuQjs7SUFDTCxDQUFDO0lBRU0sOEJBQVMsR0FBaEIsVUFBaUIsSUFBYTtRQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsUUFBUSxHQUFHO1lBQ1osQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUNyQixDQUFDLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3JCLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDeEIsQ0FBQztJQUNOLENBQUM7SUFFTSx5QkFBSSxHQUFYLFVBQVksSUFBWTtRQUNwQixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDL0MsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQy9DLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUMvQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNMLGlCQUFDO0FBQUQsQ0FqQ0EsQUFpQ0MsQ0FqQytCLGtCQUFrQixHQWlDakQ7QUFqQ1ksZ0NBQVU7QUFtQ3ZCLE1BQU07QUFDTjtJQUFnQyw4QkFBa0I7SUFLOUMsb0JBQW1CLFFBQWdCLEVBQUUsS0FBYTtRQUFsRCxZQUNJLGtCQUFNLFFBQVEsQ0FBQyxTQUVsQjtRQURHLEtBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDOztJQUN4QixDQUFDO0lBQ00sOEJBQVMsR0FBaEIsVUFBaUIsSUFBYTtRQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDL0IsQ0FBQztJQUVNLHlCQUFJLEdBQVgsVUFBWSxJQUFZO1FBQ3BCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBQ0wsaUJBQUM7QUFBRCxDQWxCQSxBQWtCQyxDQWxCK0Isa0JBQWtCLEdBa0JqRDtBQWxCWSxnQ0FBVTtBQW1CdkIsTUFBTTtBQUNOO0lBQWdDLDhCQUFrQjtJQUs5QyxvQkFBbUIsUUFBZ0IsRUFBRSxLQUFhO1FBQWxELFlBQ0ksa0JBQU0sUUFBUSxDQUFDLFNBRWxCO1FBREcsS0FBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7O0lBQ3hCLENBQUM7SUFDTSw4QkFBUyxHQUFoQixVQUFpQixJQUFhO1FBQzFCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUMvQixDQUFDO0lBRU0seUJBQUksR0FBWCxVQUFZLElBQVk7UUFDcEIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUMvQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7SUFDNUIsQ0FBQztJQUNMLGlCQUFDO0FBQUQsQ0FsQkEsQUFrQkMsQ0FsQitCLGtCQUFrQixHQWtCakQ7QUFsQlksZ0NBQVU7QUFtQnZCLFlBQVk7QUFDWjtJQUE0QiwwQkFBa0I7SUFLMUMsZ0JBQW1CLFFBQWdCLEVBQUUsQ0FBUztRQUE5QyxZQUNJLGtCQUFNLFFBQVEsQ0FBQyxTQUVsQjtRQURHLEtBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDOztJQUNwQixDQUFDO0lBQ00sMEJBQVMsR0FBaEIsVUFBaUIsSUFBYTtRQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDakMsQ0FBQztJQUVNLHFCQUFJLEdBQVgsVUFBWSxJQUFZO1FBQ3BCLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzdELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBQ0wsYUFBQztBQUFELENBbEJBLEFBa0JDLENBbEIyQixrQkFBa0IsR0FrQjdDO0FBbEJZLHdCQUFNO0FBbUJuQjtJQUE0QiwwQkFBa0I7SUFLMUMsZ0JBQW1CLFFBQWdCLEVBQUUsQ0FBUztRQUE5QyxZQUNJLGtCQUFNLFFBQVEsQ0FBQyxTQUVsQjtRQURHLEtBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDOztJQUNwQixDQUFDO0lBQ00sMEJBQVMsR0FBaEIsVUFBaUIsSUFBYTtRQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDakMsQ0FBQztJQUVNLHFCQUFJLEdBQVgsVUFBWSxJQUFZO1FBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7SUFDM0QsQ0FBQztJQUNMLGFBQUM7QUFBRCxDQWpCQSxBQWlCQyxDQWpCMkIsa0JBQWtCLEdBaUI3QztBQWpCWSx3QkFBTTtBQW9CbkIsUUFBUTtBQUNSO0lBQXNCLDJCQUFrQjtJQVFwQzs7Ozs7O09BTUc7SUFDSCxpQkFBbUIsUUFBZ0IsRUFBRSxTQUFpQixFQUFFLEtBQVUsRUFBRSxZQUFxQjtRQUF6RixZQUNJLGtCQUFNLFFBQVEsQ0FBQyxTQUtsQjtRQUpHLEtBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1FBQzNCLEtBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1FBQ3pCLEtBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxPQUFPLEtBQUssS0FBSyxRQUFRLENBQUMsQ0FBQztRQUM1QyxLQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQzs7SUFDckMsQ0FBQztJQUNNLDJCQUFTLEdBQWhCLFVBQWlCLEdBQVE7UUFDckIsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUM7UUFDZixJQUFJLFNBQVMsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ25DLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsaUJBQWlCLENBQUMsQ0FBQztZQUM5RCxPQUFPO1NBQ1Y7UUFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ00sc0JBQUksR0FBWCxVQUFZLElBQVk7UUFDcEIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDeEY7YUFBTSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDMUIsSUFBSSxJQUFJLEdBQVEsRUFBRSxDQUFDO1lBQ25CLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDM0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ25GO1lBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDO1NBQ25DO2FBQU07WUFDSCxLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQzNCLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3ZHO1NBQ0o7SUFDTCxDQUFDO0lBQ0wsY0FBQztBQUFELENBN0NBLEFBNkNDLENBN0NxQixrQkFBa0IsR0E2Q3ZDO0FBQ0Q7SUFBc0IsMkJBQWtCO0lBUXBDOzs7Ozs7T0FNRztJQUNILGlCQUFtQixRQUFnQixFQUFFLFNBQWlCLEVBQUUsS0FBVSxFQUFFLFlBQXFCO1FBQXpGLFlBQ0ksa0JBQU0sUUFBUSxDQUFDLFNBS2xCO1FBSkcsS0FBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDM0IsS0FBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFDekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLE9BQU8sS0FBSyxLQUFLLFFBQVEsQ0FBQyxDQUFDO1FBQzVDLEtBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDOztJQUNyQyxDQUFDO0lBQ00sMkJBQVMsR0FBaEIsVUFBaUIsR0FBUTtRQUNyQixJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNmLElBQUksU0FBUyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDbkMsT0FBTyxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDO1lBQzlELE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFDTSxzQkFBSSxHQUFYLFVBQVksSUFBWTtRQUNwQixJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDZixJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1NBQ3RFO2FBQU0sSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQzFCLElBQUksSUFBSSxHQUFRLEVBQUUsQ0FBQztZQUNuQixLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQzNCLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO2FBQ2pFO1lBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDO1NBQ25DO2FBQU07WUFDSCxLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQzNCLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7YUFDckY7U0FDSjtJQUNMLENBQUM7SUFDTCxjQUFDO0FBQUQsQ0E3Q0EsQUE2Q0MsQ0E3Q3FCLGtCQUFrQixHQTZDdkM7QUFHRCxNQUFNO0FBQ047SUFBK0IsNkJBQVE7SUFTbkMsbUJBQW1CLEVBQVksRUFBRSxNQUFZLEVBQUUsSUFBVTtRQUF6RCxZQUNJLGlCQUFPLFNBSVY7UUFWUyxlQUFTLEdBQVksS0FBSyxDQUFDO1FBT2pDLEtBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO1FBQ2IsS0FBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsS0FBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7O0lBQ3JCLENBQUM7SUFURCxzQkFBVywrQkFBUTthQUFuQixjQUFpQyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUNsRCxvQ0FBZ0IsR0FBdkI7UUFDSSxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUMzQixDQUFDO0lBT00sMEJBQU0sR0FBYixVQUFjLEVBQVU7UUFDcEIsSUFBSSxJQUFJLENBQUMsUUFBUTtZQUFFLE9BQU87UUFDMUIsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNmLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQztTQUNoRDthQUFNO1lBQ0gsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDO1NBQzlCO1FBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7SUFDMUIsQ0FBQztJQUNMLGdCQUFDO0FBQUQsQ0F4QkEsQUF3QkMsQ0F4QjhCLFFBQVEsR0F3QnRDO0FBeEJZLDhCQUFTO0FBMkJ0QixNQUFNO0FBQ047SUFBZ0MsOEJBQVE7SUFhcEMsb0JBQW1CLE9BQW1CO1FBQXRDLFlBQ0ksaUJBQU8sU0FHVjtRQUZHLEtBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1FBQ3RCLEtBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQzs7SUFDdEMsQ0FBQztJQVpELHNCQUFXLGdDQUFRO2FBQW5CLGNBQWlDLE9BQU8sSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBQzVFLHFDQUFnQixHQUF2QjtRQUNJLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDL0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1NBQ3RDO1FBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUM7UUFDdEIsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQU1NLDhCQUFTLEdBQWhCLFVBQWlCLElBQWE7UUFDMUIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFDakIsdURBQXVEO1FBQ3ZELHVDQUF1QztRQUN2QyxJQUFJO1FBQ0osSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUNNLDJCQUFNLEdBQWIsVUFBYyxFQUFVO1FBQ3BCLElBQUksSUFBSSxDQUFDLFFBQVE7WUFBRSxPQUFPO1FBQzFCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbEIsSUFBSSxNQUFNLENBQUMsUUFBUSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFDRCxzQkFBc0I7SUFDWix1Q0FBa0IsR0FBNUI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFFTSwrQkFBVSxHQUFqQixVQUFrQixNQUFnQjtRQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBQ0wsaUJBQUM7QUFBRCxDQTFDQSxBQTBDQyxDQTFDK0IsUUFBUSxHQTBDdkM7QUExQ1ksZ0NBQVU7QUEyQ3ZCLE1BQU07QUFDTjtJQUE2QiwyQkFBUTtJQWNqQyxpQkFBbUIsT0FBbUI7UUFBdEMsWUFDSSxpQkFBTyxTQUdWO1FBRkcsS0FBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2xDLEtBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7O0lBQzNDLENBQUM7SUFiRCxzQkFBVyw2QkFBUTthQUFuQjtZQUNJLE9BQU8sSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLENBQUM7UUFDakMsQ0FBQzs7O09BQUE7SUFDTSxrQ0FBZ0IsR0FBdkI7UUFDSSxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQy9DLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztTQUN0QztRQUNELElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7SUFDM0MsQ0FBQztJQU1NLDJCQUFTLEdBQWhCLFVBQWlCLElBQWE7UUFDMUIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFDakIsS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUMvQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNuQztJQUNMLENBQUM7SUFDTSx3QkFBTSxHQUFiLFVBQWMsRUFBVTtRQUNwQixJQUFJLElBQUksQ0FBQyxRQUFRO1lBQUUsT0FBTztRQUMxQixLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQy9DLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTtnQkFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQzNCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUU7b0JBQzFCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztpQkFDdEI7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUNELFFBQVE7SUFDRCw0QkFBVSxHQUFqQixVQUFrQixNQUFnQjtRQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSTtZQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDTCxjQUFDO0FBQUQsQ0F6Q0EsQUF5Q0MsQ0F6QzRCLFFBQVEsR0F5Q3BDO0FBekNZLDBCQUFPO0FBMENwQixNQUFNO0FBQ047SUFBbUMsaUNBQVE7SUFFdkMsdUJBQW1CLE1BQWdCO1FBQW5DLFlBQ0ksaUJBQU8sU0FFVjtRQURHLEtBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDOztJQUN6QixDQUFDO0lBQ00saUNBQVMsR0FBaEIsVUFBaUIsSUFBYTtRQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBQ00sOEJBQU0sR0FBYixVQUFjLEVBQVU7UUFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdkIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRTtZQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLENBQUM7U0FDbEM7SUFDTCxDQUFDO0lBQ0wsb0JBQUM7QUFBRCxDQWhCQSxBQWdCQyxDQWhCa0MsUUFBUSxHQWdCMUM7QUFoQlksc0NBQWE7QUFtQjFCLE1BQU07QUFDTjtJQUFBO0lBSUEsQ0FBQztJQUhVLHFCQUFNLEdBQWIsVUFBYyxJQUFZO1FBQ3RCLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDTCxXQUFDO0FBQUQsQ0FKQSxBQUlDLElBQUE7QUFDRDtJQUFxQiwwQkFBSTtJQUVyQixnQkFBbUIsSUFBWTtRQUEvQixZQUNJLGlCQUFPLFNBRVY7UUFERyxLQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQzs7SUFDdEIsQ0FBQztJQUNNLHVCQUFNLEdBQWIsVUFBYyxJQUFZO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDTCxhQUFDO0FBQUQsQ0FUQSxBQVNDLENBVG9CLElBQUksR0FTeEI7QUFDRDtJQUFzQiwyQkFBSTtJQUV0QixpQkFBbUIsSUFBWTtRQUEvQixZQUNJLGlCQUFPLFNBRVY7UUFERyxLQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQzs7SUFDdEIsQ0FBQztJQUNNLHdCQUFNLEdBQWIsVUFBYyxJQUFZO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0wsY0FBQztBQUFELENBVEEsQUFTQyxDQVRxQixJQUFJLEdBU3pCO0FBQ0Q7SUFBd0IsNkJBQUk7SUFFeEIsbUJBQW1CLElBQVk7UUFBL0IsWUFDSSxpQkFBTyxTQUVWO1FBREcsS0FBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7O0lBQ3RCLENBQUM7SUFDTSwwQkFBTSxHQUFiLFVBQWMsSUFBWTtRQUN0QixJQUFJLElBQUksQ0FBQyxDQUFDO1FBQ1YsSUFBSSxJQUFJLEdBQUcsQ0FBQztZQUNSLE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzs7WUFFeEMsT0FBTyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUNMLGdCQUFDO0FBQUQsQ0FiQSxBQWFDLENBYnVCLElBQUksR0FhM0I7QUFFRDtJQUF3Qiw2QkFBSTtJQUV4QixtQkFBbUIsSUFBWTtRQUEvQixZQUNJLGlCQUFPLFNBRVY7UUFERyxLQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQzs7SUFDdEIsQ0FBQztJQUNNLDBCQUFNLEdBQWIsVUFBYyxJQUFZO1FBQ3RCLElBQUksSUFBSSxDQUFDLENBQUM7UUFDVixJQUFJLElBQUksR0FBRyxDQUFDO1lBQ1IsT0FBTyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7O1lBRWxELE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0wsZ0JBQUM7QUFBRCxDQWJBLEFBYUMsQ0FidUIsSUFBSSxHQWEzQjtBQUNELGNBQWM7QUFDZDtJQUFnQyxxQ0FBSTtJQUFwQzs7SUFJQSxDQUFDO0lBSFUsa0NBQU0sR0FBYixVQUFjLElBQVk7UUFDdEIsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDTCx3QkFBQztBQUFELENBSkEsQUFJQyxDQUorQixJQUFJLEdBSW5DO0FBQ0QsY0FBYztBQUNkO0lBQWlDLHNDQUFJO0lBQXJDOztJQUlBLENBQUM7SUFIVSxtQ0FBTSxHQUFiLFVBQWMsSUFBWTtRQUN0QixPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBQ0wseUJBQUM7QUFBRCxDQUpBLEFBSUMsQ0FKZ0MsSUFBSSxHQUlwQztBQUNELGtCQUFrQjtBQUNsQjtJQUFtQyx3Q0FBSTtJQUF2Qzs7SUFXQSxDQUFDO0lBVlUscUNBQU0sR0FBYixVQUFjLElBQVk7UUFDdEIsSUFBSSxJQUFJLEtBQUssQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLEVBQUU7WUFDMUIsSUFBSSxJQUFJLENBQUMsQ0FBQztZQUNWLElBQUksSUFBSSxHQUFHLENBQUM7Z0JBQ1IsT0FBTyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7O2dCQUUxQyxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUN6RDtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDTCwyQkFBQztBQUFELENBWEEsQUFXQyxDQVhrQyxJQUFJLEdBV3RDO0FBRUQ7SUFBd0IsNkJBQUk7SUFBNUI7O0lBSUEsQ0FBQztJQUhVLDBCQUFNLEdBQWIsVUFBYyxJQUFZO1FBQ3RCLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNMLGdCQUFDO0FBQUQsQ0FKQSxBQUlDLENBSnVCLElBQUksR0FJM0I7QUFFRDtJQUF5Qiw4QkFBSTtJQUE3Qjs7SUFJQSxDQUFDO0lBSFUsMkJBQU0sR0FBYixVQUFjLElBQVk7UUFDdEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBQ0wsaUJBQUM7QUFBRCxDQUpBLEFBSUMsQ0FKd0IsSUFBSSxHQUk1QjtBQUNEO0lBQTJCLGdDQUFJO0lBQS9COztJQUlBLENBQUM7SUFIVSw2QkFBTSxHQUFiLFVBQWMsSUFBWTtRQUN0QixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0lBQ3BELENBQUM7SUFDTCxtQkFBQztBQUFELENBSkEsQUFJQyxDQUowQixJQUFJLEdBSTlCO0FBQ0Q7SUFBMkIsZ0NBQUk7SUFBL0I7O0lBUUEsQ0FBQztJQVBVLDZCQUFNLEdBQWIsVUFBYyxJQUFZO1FBQ3RCLElBQUksSUFBSSxHQUFHLEdBQUcsRUFBRTtZQUNaLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDO1NBQ3RDO2FBQU07WUFDSCxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUNoRDtJQUNMLENBQUM7SUFDTCxtQkFBQztBQUFELENBUkEsQUFRQyxDQVIwQixJQUFJLEdBUTlCO0FBRUQsTUFBTTtBQUNOO0lBQTRCLGlDQUFJO0lBRTVCLHVCQUFtQixJQUFhO1FBQWhDLFlBQ0ksaUJBQU8sU0FFVjtRQURHLEtBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLEdBQUcsQ0FBQzs7SUFDL0IsQ0FBQztJQUNNLDhCQUFNLEdBQWIsVUFBYyxJQUFZO1FBQ3RCLElBQUksSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLEtBQUssQ0FBQztZQUN4QixPQUFPLElBQUksQ0FBQztRQUNoQixJQUFJLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUNoQixPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3hHLENBQUM7SUFDTCxvQkFBQztBQUFELENBWkEsQUFZQyxDQVoyQixJQUFJLEdBWS9CO0FBQ0Q7SUFBNkIsa0NBQUk7SUFFN0Isd0JBQW1CLElBQWE7UUFBaEMsWUFDSSxpQkFBTyxTQUVWO1FBREcsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLElBQUksR0FBRyxDQUFDOztJQUMvQixDQUFDO0lBQ00sK0JBQU0sR0FBYixVQUFjLEVBQVU7UUFDcEIsT0FBTyxDQUFDLEVBQUUsS0FBSyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN0SSxDQUFDO0lBQ0wscUJBQUM7QUFBRCxDQVRBLEFBU0MsQ0FUNEIsSUFBSSxHQVNoQztBQUNEO0lBQStCLG9DQUFJO0lBRS9CLDBCQUFtQixJQUFhO1FBQWhDLFlBQ0ksaUJBQU8sU0FFVjtRQURHLEtBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLEdBQUcsQ0FBQzs7SUFDL0IsQ0FBQztJQUNNLGlDQUFNLEdBQWIsVUFBYyxFQUFVO1FBQ3BCLElBQUksSUFBSSxHQUFHLENBQUMsQ0FBQztRQUNiLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDN0IsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDdEIsSUFBSSxHQUFHLEVBQUUsQ0FBQztTQUNiO2FBQU07WUFDSCxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUNaLElBQUksQ0FBQyxTQUFTO2dCQUNWLFNBQVMsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7WUFDekMsSUFBSSxDQUFDLEdBQUcsU0FBUyxHQUFHLENBQUMsQ0FBQztZQUN0QixFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUNaLElBQUksRUFBRSxHQUFHLENBQUM7Z0JBQ04sSUFBSSxHQUFHLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDOztnQkFFbEYsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsU0FBUyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztTQUM3RjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDTCx1QkFBQztBQUFELENBeEJBLEFBd0JDLENBeEI4QixJQUFJLEdBd0JsQztBQUNELGNBQWM7QUFDZDtJQUEyQixnQ0FBSTtJQUEvQjs7SUFtQkEsQ0FBQztJQWxCVSw2QkFBTSxHQUFiLFVBQWMsRUFBVTtRQUNwQixPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRVMsa0NBQVcsR0FBckIsVUFBc0IsS0FBSztRQUN2QixJQUFJLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxFQUFFO1lBQ2xCLE9BQU8sTUFBTSxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7U0FDakM7YUFBTSxJQUFJLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxFQUFFO1lBQ3pCLEtBQUssSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLE9BQU8sTUFBTSxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDO1NBQ3hDO2FBQU0sSUFBSSxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksRUFBRTtZQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztZQUNyQixPQUFPLE1BQU0sR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUMxQztRQUVELEtBQUssSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLE9BQU8sTUFBTSxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsUUFBUSxDQUFDO0lBQzdDLENBQUM7SUFDTCxtQkFBQztBQUFELENBbkJBLEFBbUJDLENBbkIwQixJQUFJLEdBbUI5QjtBQUVEO0lBQTRCLGlDQUFJO0lBQWhDOztJQW1CQSxDQUFDO0lBbEJVLDhCQUFNLEdBQWIsVUFBYyxFQUFVO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRVMsbUNBQVcsR0FBckIsVUFBc0IsS0FBSztRQUN2QixJQUFJLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxFQUFFO1lBQ2xCLE9BQU8sTUFBTSxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7U0FDakM7YUFBTSxJQUFJLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxFQUFFO1lBQ3pCLEtBQUssSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLE9BQU8sTUFBTSxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDO1NBQ3hDO2FBQU0sSUFBSSxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksRUFBRTtZQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztZQUNyQixPQUFPLE1BQU0sR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUMxQztRQUVELEtBQUssSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLE9BQU8sTUFBTSxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsUUFBUSxDQUFDO0lBQzdDLENBQUM7SUFDTCxvQkFBQztBQUFELENBbkJBLEFBbUJDLENBbkIyQixJQUFJLEdBbUIvQiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG50eXBlIFZlYzMgPSB7XHJcbiAgICB4OiBudW1iZXIsXHJcbiAgICB5OiBudW1iZXIsXHJcbiAgICB6OiBudW1iZXJcclxufVxyXG5cclxuLyoq5Yqo5L2c566h55CG5Zmo57G75Z6LICovXHJcbmV4cG9ydCBlbnVtIEFjdGlvbk1uZ1R5cGUge1xyXG4gICAgLyoqVUnliqjkvZznrqHnkIblmaggKi9cclxuICAgIFVJID0gXCJVSVwiLFxyXG4gICAgLyoq5YWz5Y2h5Yqo5L2c566h55CG5ZmoICovXHJcbiAgICBMZXZlbCA9IFwiTGV2ZWxcIixcclxuXHJcbn1cclxuXHJcbi8qKjNE5Yqo55S7566h55CG5ZmoICovXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEFjdGlvbjNkTWFuYWdlciB7XHJcblxyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBhbGxNbmdzOiB7IFt0eXBlOiBzdHJpbmddOiBBY3Rpb24zZE1hbmFnZXIgfSA9IHt9O1xyXG4gICAgLyoqXHJcbiAgICAgKiDojrflj5bmjIflrprnsbvlnovnmoTliqjkvZznrqHnkIblmajvvIznlKjkuo7kuJPpl6jnrqHnkIbmn5DkuIDnsbvlr7nosaHnmoTliqjkvZxcclxuICAgICAqIEBwYXJhbSB0eXBlIOeuoeeQhuWZqOeahOexu+Wei++8jOWPr+S7peaYr+aemuS4vuWAvO+8jOS5n+WPr+S7peiHquWumuS5ieS4gOS4quaWsOeahOWQjeensO+8jOiOt+WPluaWsOeahOeuoeeQhuWZqFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGdldE1uZyh0eXBlKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmFsbE1uZ3NbdHlwZV0pIHtcclxuICAgICAgICAgICAgdGhpcy5hbGxNbmdzW3R5cGVdID0gbmV3IEFjdGlvbjNkTWFuYWdlcigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5hbGxNbmdzW3R5cGVdO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICB0aGlzLmFsbEFjdGlvbnMgPSBbXTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBhbGxBY3Rpb25zOiBBY3Rpb24zZFtdID0gW107XHJcblxyXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKSB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IHRoaXMuYWxsQWN0aW9ucy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xyXG4gICAgICAgICAgICBsZXQgYWN0ID0gdGhpcy5hbGxBY3Rpb25zW2ldO1xyXG4gICAgICAgICAgICBpZiAoIWFjdCkge1xyXG4gICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYWN0LnVwZGF0ZShkdCk7XHJcbiAgICAgICAgICAgIGlmIChhY3QuZmluaXNoZWQpIHtcclxuICAgICAgICAgICAgICAgIGxldCBpbmRleCA9IGk7XHJcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggPj0gdGhpcy5hbGxBY3Rpb25zLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGluZGV4ID0gdGhpcy5hbGxBY3Rpb25zLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBmb3IgKDsgaW5kZXggPj0gMDsgLS1pbmRleCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmFsbEFjdGlvbnNbaW5kZXhdLklkID09IGFjdC5JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsbEFjdGlvbnMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHVibGljIHJ1bkFjdGlvbihub2RlOiBjYy5Ob2RlLCBhY3Rpb246IEFjdGlvbjNkKSB7XHJcbiAgICAgICAgdGhpcy5zdG9wQWxsQWN0aW9ucyhub2RlKTtcclxuICAgICAgICBhY3Rpb24ucmVzZXRGaW5pc2hTdGF0ZSgpO1xyXG4gICAgICAgIGFjdGlvbi5zZXRUYXJnZXQobm9kZSk7XHJcbiAgICAgICAgdGhpcy5hbGxBY3Rpb25zLnB1c2goYWN0aW9uKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdG9wQWxsQWN0aW9ucyhub2RlOiBjYy5Ob2RlKSB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IHRoaXMuYWxsQWN0aW9ucy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5hbGxBY3Rpb25zW2ldLm5vZGUgPT0gbm9kZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGxBY3Rpb25zLnNwbGljZShpLCAxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIGRlbGF5KGR1cmF0aW9uOiBudW1iZXIpIHtcclxuICAgICAgICByZXR1cm4gbmV3IERlbGF5VGltZShkdXJhdGlvbik7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIG1vdmVUbyhkdXJhdGlvbjogbnVtYmVyLCB4OiBudW1iZXIgfCBWZWMzLCB5PzogbnVtYmVyLCB6PzogbnVtYmVyKTogQWN0aW9uM2Qge1xyXG4gICAgICAgIHJldHVybiBuZXcgTW92ZVRvM2QoZHVyYXRpb24sIHgsIHksIHopO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBtb3ZlQnkoZHVyYXRpb246IG51bWJlciwgeDogbnVtYmVyIHwgVmVjMywgeT86IG51bWJlciwgej86IG51bWJlcik6IEFjdGlvbjNkIHtcclxuICAgICAgICByZXR1cm4gbmV3IE1vdmVCeTNkKGR1cmF0aW9uLCB4LCB5LCB6KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgc2NhbGVUbyhkdXJhdGlvbjogbnVtYmVyLCB4OiBudW1iZXIgfCBWZWMzLCB5PzogbnVtYmVyLCB6PzogbnVtYmVyKTogQWN0aW9uM2Qge1xyXG4gICAgICAgIHJldHVybiBuZXcgU2NhbGVUbzNkKGR1cmF0aW9uLCB4LCB5LCB6KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgcm90YXRlVG8oZHVyYXRpb246IG51bWJlciwgeDogbnVtYmVyIHwgVmVjMywgeT86IG51bWJlciwgej86IG51bWJlcik6IEFjdGlvbjNkIHtcclxuICAgICAgICByZXR1cm4gbmV3IFJvdGF0ZVRvM2QoZHVyYXRpb24sIHgsIHksIHopO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyByb3RhdGVCeShkdXJhdGlvbjogbnVtYmVyLCB4OiBudW1iZXIgfCBWZWMzLCB5PzogbnVtYmVyLCB6PzogbnVtYmVyKTogQWN0aW9uM2Qge1xyXG4gICAgICAgIHJldHVybiBuZXcgUm90YXRlQnkzZChkdXJhdGlvbiwgeCwgeSwgeik7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIHJvdGF0ZVRvMmQoZHVyYXRpb246IG51bWJlciwgYW5nbGU6IG51bWJlcikge1xyXG4gICAgICAgIHJldHVybiBuZXcgUm90YXRlVG8yZChkdXJhdGlvbiwgYW5nbGUpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyByb3RhdGVCeTJkKGR1cmF0aW9uOiBudW1iZXIsIGFuZ2xlOiBudW1iZXIpIHtcclxuICAgICAgICByZXR1cm4gbmV3IFJvdGF0ZUJ5MmQoZHVyYXRpb24sIGFuZ2xlKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZmFkZVRvKGR1cmF0aW9uOiBudW1iZXIsIG9wYWNpdHk6IG51bWJlcik6IEFjdGlvbjNkIHtcclxuICAgICAgICByZXR1cm4gbmV3IEZhZGVUbyhkdXJhdGlvbiwgb3BhY2l0eSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGZhZGVCeShkdXJhdGlvbjogbnVtYmVyLCBvcGFjaXR5OiBudW1iZXIpOiBBY3Rpb24zZCB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBGYWRlQnkoZHVyYXRpb24sIG9wYWNpdHkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5oyJ55uu5qCH5YC855qE5pa55byP5L+u5pS55a+56LGh55qE5Lu75oSP5bGe5oCn5YC8XHJcbiAgICAgKiBAcGFyYW0gZHVyYXRpb24g5Yqo5L2c5oyB57ut55qE5pe26Ze0XHJcbiAgICAgKiBAcGFyYW0gYXR0cmlidXRlIOWPmOmHj+WQjeensFxyXG4gICAgICogQHBhcmFtIHZhbHVlIOWPmOWMlueahOebuOWvueWAvFxyXG4gICAgICogQHBhcmFtIG5ld0F0dHJpYnV0ZSDlgLzlj5jljJbml7bmmK/lkKbpnIDopoHmlrDlu7rlsZ7mgKflho3nu5nnm67moIflr7nosaHotYvlgLzvvIzkvovlpoLopoHkv67mlLnoioLngrnnmoRwb3NpdGlvbuWxnuaAp+aXtuW6lOivpeS4unRydWVcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyB0d2VlblRvKGR1cmF0aW9uOiBudW1iZXIsIGF0dHJpYnV0ZTogc3RyaW5nLCB2YWx1ZTogYW55LCBuZXdBdHRyaWJ1dGU6IGJvb2xlYW4gPSBmYWxzZSkge1xyXG4gICAgICAgIHJldHVybiBuZXcgVHdlZW5UbyhkdXJhdGlvbiwgYXR0cmlidXRlLCB2YWx1ZSwgbmV3QXR0cmlidXRlKTtcclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog5oyJ55u45a+55YC855qE5pa55byP5L+u5pS55a+56LGh55qE5Lu75oSP5bGe5oCn5YC8XHJcbiAgICAgKiBAcGFyYW0gZHVyYXRpb24g5Yqo5L2c5oyB57ut55qE5pe26Ze0XHJcbiAgICAgKiBAcGFyYW0gYXR0cmlidXRlIOWPmOmHj+WQjeensFxyXG4gICAgICogQHBhcmFtIHZhbHVlIOWPmOWMlueahOebuOWvueWAvFxyXG4gICAgICogQHBhcmFtIG5ld0F0dHJpYnV0ZSDlgLzlj5jljJbml7bmmK/lkKbpnIDopoHmlrDlu7rlsZ7mgKflho3nu5nnm67moIflr7nosaHotYvlgLzvvIzkvovlpoLopoHkv67mlLnoioLngrnnmoRwb3NpdGlvbuWxnuaAp+aXtuW6lOivpeS4unRydWVcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyB0d2VlbkJ5KGR1cmF0aW9uOiBudW1iZXIsIGF0dHJpYnV0ZTogc3RyaW5nLCB2YWx1ZTogYW55LCBuZXdBdHRyaWJ1dGU6IGJvb2xlYW4gPSBmYWxzZSkge1xyXG4gICAgICAgIHJldHVybiBuZXcgVHdlZW5CeShkdXJhdGlvbiwgYXR0cmlidXRlLCB2YWx1ZSwgbmV3QXR0cmlidXRlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIGNhbGxGdW4oY2I6IEZ1bmN0aW9uLCB0YXJnZXQ/OiBhbnksIGRhdGE/OiBhbnkpOiBBY3Rpb24zZCB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBDYWxsRnVuM2QoY2IsIHRhcmdldCwgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyBzZXF1ZW5jZSguLi5hY3Rpb25zKTogQWN0aW9uM2Qge1xyXG4gICAgICAgIHJldHVybiBuZXcgU2VxdWVuY2UzZChhY3Rpb25zKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIHNwYXduKC4uLmFjdGlvbnMpOiBBY3Rpb24zZCB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBTcGF3bjNkKGFjdGlvbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgcmVwZWF0Rm9yZXZlcihhY3Rpb246IEFjdGlvbjNkKSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBSZXBlYXRGb3JldmVyKGFjdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLy/nvJPliqjliqjkvZxcclxuICAgIHB1YmxpYyBzdGF0aWMgZWFzZUluKHJhdGU6IG51bWJlcik6IEVhc2Uge1xyXG4gICAgICAgIHJldHVybiBuZXcgRWFzZUluKHJhdGUpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBlYXNlT3V0KHJhdGU6IG51bWJlcik6IEVhc2Uge1xyXG4gICAgICAgIHJldHVybiBuZXcgRWFzZU91dChyYXRlKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZWFzZUluT3V0KHJhdGU6IG51bWJlcik6IEVhc2Uge1xyXG4gICAgICAgIHJldHVybiBuZXcgRWFzZUluT3V0KHJhdGUpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBlYXNlT3V0SW4ocmF0ZTogbnVtYmVyKTogRWFzZSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBFYXNlT3V0SW4ocmF0ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyBlYXNlRXhwb25lbnRpYWxJbigpOiBFYXNlIHtcclxuICAgICAgICByZXR1cm4gbmV3IEVhc2VFeHBvbmVudGlhbEluKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGVhc2VFeHBvbmVudGlhbE91dCgpOiBFYXNlIHtcclxuICAgICAgICByZXR1cm4gbmV3IEVhc2VFeHBvbmVudGlhbE91dCgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBlYXNlRXhwb25lbnRpYWxJbk91dCgpOiBFYXNlIHtcclxuICAgICAgICByZXR1cm4gbmV3IEVhc2VFeHBvbmVudGlhbEluT3V0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyBlYXNlU2luSW4oKTogRWFzZSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBFYXNlU2luSW4oKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZWFzZVNpbk91dCgpOiBFYXNlIHtcclxuICAgICAgICByZXR1cm4gbmV3IEVhc2VTaW5PdXQoKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZWFzZVNpbkluT3V0KCk6IEVhc2Uge1xyXG4gICAgICAgIHJldHVybiBuZXcgRWFzZVNpbkluT3V0KCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGVhc2VTaW5PdXRJbigpOiBFYXNlIHtcclxuICAgICAgICByZXR1cm4gbmV3IEVhc2VTaW5PdXRJbigpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKuW8ueaAp+WPmOWMlui/m+WFpe+8jOWFiOWbnuW8ueWGjeWPmOW/qyAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBlYXNlRWxhc3RpY0luKHJhdGU/OiBudW1iZXIpIHtcclxuICAgICAgICByZXR1cm4gbmV3IEVhc2VFbGFzdGljSW4ocmF0ZSk7XHJcbiAgICB9XHJcbiAgICAvKirlvLnmgKflj5jljJbpgIDlh7rvvIzlhYjlv6vpgJ/liLDovr7nm67moIflgLzlho3lm57lvLkgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgZWFzZUVsYXN0aWNPdXQocmF0ZT86IG51bWJlcikge1xyXG4gICAgICAgIHJldHVybiBuZXcgRWFzZUVsYXN0aWNPdXQocmF0ZSk7XHJcbiAgICB9XHJcbiAgICAvKirlvLnmgKflj5jljJbov5vlhaXlho3pgIDlh7rvvIzlnKjml7bpl7TovbTnmoTkuK3pl7Tpg6jliIbov5vooYzlm57lvLkgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgZWFzZUVsYXN0aWNJbk91dChyYXRlPzogbnVtYmVyKSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBFYXNlRWxhc3RpY0luT3V0KHJhdGUpO1xyXG4gICAgfVxyXG4gICAgLyoq5oyJ5by56Lez5Yqo5L2c6L+b5YWlICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGVhc2VCb3VuY2VJbigpIHtcclxuICAgICAgICByZXR1cm4gbmV3IEVhc2VCb3VuY2VJbigpO1xyXG4gICAgfVxyXG4gICAgLyoq5oyJ5by56Lez5Yqo5L2c6YCA5Ye6ICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGVhc2VCb3VuY2VPdXQoKSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBFYXNlQm91bmNlT3V0KCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8v5Yqo5L2c5Z+657G7XHJcbmV4cG9ydCBjbGFzcyBBY3Rpb24zZCB7XHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIF9pZDogbnVtYmVyID0gMDtcclxuICAgIHByb3RlY3RlZCBteUlkOiBudW1iZXIgPSBudWxsO1xyXG4gICAgcHVibGljIGdldCBJZCgpIHtcclxuICAgICAgICBpZiAobnVsbCA9PT0gdGhpcy5teUlkKSB7XHJcbiAgICAgICAgICAgIHRoaXMubXlJZCA9IEFjdGlvbjNkLl9pZCsrO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5teUlkO1xyXG4gICAgfVxyXG4gICAgcHVibGljIG5vZGU6IGNjLk5vZGU7XHJcbiAgICBwdWJsaWMgZ2V0IGJpbmRlZCgpOiBib29sZWFuIHsgcmV0dXJuICEhdGhpcy5ub2RlOyB9XHJcbiAgICBwdWJsaWMgc2V0VGFyZ2V0KG5vZGU6IGNjLk5vZGUpIHtcclxuICAgICAgICB0aGlzLm5vZGUgPSBub2RlO1xyXG4gICAgfVxyXG4gICAgLyoq57yT5Yqo5Yqo55S755qE5q+U546H6L2s5o2i5Ye95pWwICovXHJcbiAgICBwcm90ZWN0ZWQgX2Vhc2VMaXN0OiBFYXNlW107XHJcbiAgICBwdWJsaWMgZWFzaW5nKC4uLmFyZ3M6IEVhc2VbXSkge1xyXG4gICAgICAgIHRoaXMuX2Vhc2VMaXN0ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGMgPSBhcmdzLmxlbmd0aDsgaSA8IGM7ICsraSkge1xyXG4gICAgICAgICAgICB0aGlzLl9lYXNlTGlzdC5wdXNoKGFyZ3NbaV0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuICAgIC8qKue8k+WKqOWKqOS9nOaXtumXtOe8qeaUviAqL1xyXG4gICAgcHJvdGVjdGVkIGNvbXB1dGVFYXNlVGltZShyYXRlOiBudW1iZXIpIHtcclxuICAgICAgICBsZXQgbG9jTGlzdCA9IHRoaXMuX2Vhc2VMaXN0O1xyXG4gICAgICAgIGlmICgoIWxvY0xpc3QpIHx8IChsb2NMaXN0Lmxlbmd0aCA9PT0gMCkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJhdGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBuID0gbG9jTGlzdC5sZW5ndGg7IGkgPCBuOyBpKyspIHtcclxuICAgICAgICAgICAgcmF0ZSA9IGxvY0xpc3RbaV0uZWFzaW5nKHJhdGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmF0ZTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXQgZmluaXNoZWQoKTogYm9vbGVhbiB7IHJldHVybiBmYWxzZTsgfVxyXG4gICAgcHVibGljIHJlc2V0RmluaXNoU3RhdGUoKSB7XHJcblxyXG4gICAgfVxyXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKSB7IH1cclxufVxyXG5cclxuXHJcbi8v5pyJ6ZmQ5pe26ZW/55qE5Yqo5L2cXHJcbmV4cG9ydCBjbGFzcyBGaW5pdGVUaW1lQWN0aW9uM2QgZXh0ZW5kcyBBY3Rpb24zZCB7XHJcbiAgICAvKirliqjkvZzmjIHnu63nmoTmgLvml7bpl7QgKi9cclxuICAgIHByb3RlY3RlZCBkdXJhdGlvbjogbnVtYmVyO1xyXG4gICAgLyoq5Yqo5L2c57Sv6K6h5bey6L+Q6KGM55qE5pe26Ze0ICovXHJcbiAgICBwcm90ZWN0ZWQgZWxhcHNlOiBudW1iZXI7XHJcblxyXG4gICAgcHVibGljIGdldCBmaW5pc2hlZCgpOiBib29sZWFuIHsgcmV0dXJuIHRoaXMuZWxhcHNlID49IHRoaXMuZHVyYXRpb247IH1cclxuICAgIHB1YmxpYyByZXNldEZpbmlzaFN0YXRlKCkge1xyXG4gICAgICAgIHRoaXMuZWxhcHNlID0gMDtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBfcGF1c2VkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgZ2V0IHBhdXNlZCgpOiBib29sZWFuIHsgcmV0dXJuIHRoaXMuX3BhdXNlZDsgfVxyXG5cclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihkdXJhdGlvbjogbnVtYmVyKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICB0aGlzLmR1cmF0aW9uID0gZHVyYXRpb247XHJcbiAgICAgICAgdGhpcy5lbGFwc2UgPSAwO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IHJhdGUgPSB0aGlzLmFkZEVsYXBzZVRpbWUoZHQpO1xyXG4gICAgICAgIHRoaXMuc3RlcChyYXRlKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBhZGRFbGFwc2VUaW1lKGR0OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHRoaXMuZWxhcHNlICs9IGR0O1xyXG4gICAgICAgIGxldCByYXRlID0gMTtcclxuICAgICAgICBpZiAodGhpcy5kdXJhdGlvbiA+IDApIHtcclxuICAgICAgICAgICAgcmF0ZSA9IHRoaXMuZWxhcHNlIC8gdGhpcy5kdXJhdGlvbjtcclxuICAgICAgICAgICAgaWYgKHJhdGUgPiAxKSByYXRlID0gMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmF0ZSA9IHRoaXMuY29tcHV0ZUVhc2VUaW1lKHJhdGUpO1xyXG4gICAgICAgIHJldHVybiByYXRlO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHN0ZXAocmF0ZTogbnVtYmVyKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBpbnRlcnBvbGF0aW9uKG1pbjogbnVtYmVyLCBtYXg6IG51bWJlciwgcmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgcmV0dXJuIG1pbiArIChtYXggLSBtaW4pICogcmF0ZTtcclxuICAgIH1cclxufVxyXG4vL+W7tui/n1xyXG5leHBvcnQgY2xhc3MgRGVsYXlUaW1lIGV4dGVuZHMgRmluaXRlVGltZUFjdGlvbjNkIHtcclxuXHJcbn1cclxuLy/np7vliqhcclxuZXhwb3J0IGNsYXNzIE1vdmVUbzNkIGV4dGVuZHMgRmluaXRlVGltZUFjdGlvbjNkIHtcclxuICAgIC8qKuWIneWni+WAvCAqL1xyXG4gICAgcHJpdmF0ZSBvcmlnaW5hbDogVmVjMztcclxuICAgIC8qKuebruagh+WAvCAqL1xyXG4gICAgcHJpdmF0ZSB0YXJnZXQ6IFZlYzM7XHJcbiAgICAvKirlvZPliY3lgLwgKi9cclxuICAgIHByaXZhdGUgY3VyVmFsdWU6IFZlYzM7XHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IoZHVyYXRpb246IG51bWJlciwgeDogbnVtYmVyIHwgVmVjMywgeT86IG51bWJlciwgej86IG51bWJlcikge1xyXG4gICAgICAgIHN1cGVyKGR1cmF0aW9uKTtcclxuICAgICAgICBpZiAodHlwZW9mIHggPT09IFwibnVtYmVyXCIpIHtcclxuICAgICAgICAgICAgdGhpcy50YXJnZXQgPSB7XHJcbiAgICAgICAgICAgICAgICB4OiB4LFxyXG4gICAgICAgICAgICAgICAgeTogeSxcclxuICAgICAgICAgICAgICAgIHo6IHpcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnRhcmdldCA9IHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY3VyVmFsdWUgPSB7XHJcbiAgICAgICAgICAgIHg6IDAsXHJcbiAgICAgICAgICAgIHk6IDAsXHJcbiAgICAgICAgICAgIHo6IDBcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRUYXJnZXQobm9kZTogY2MuTm9kZSkge1xyXG4gICAgICAgIHRoaXMubm9kZSA9IG5vZGU7XHJcbiAgICAgICAgdGhpcy5vcmlnaW5hbCA9IHtcclxuICAgICAgICAgICAgeDogbm9kZS54LFxyXG4gICAgICAgICAgICB5OiBub2RlLnksXHJcbiAgICAgICAgICAgIHo6IG5vZGUuelxyXG4gICAgICAgIH07XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGVwKHJhdGU6IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMuY3VyVmFsdWUueCA9IHRoaXMuaW50ZXJwb2xhdGlvbih0aGlzLm9yaWdpbmFsLngsIHRoaXMudGFyZ2V0LngsIHJhdGUpO1xyXG4gICAgICAgIHRoaXMuY3VyVmFsdWUueSA9IHRoaXMuaW50ZXJwb2xhdGlvbih0aGlzLm9yaWdpbmFsLnksIHRoaXMudGFyZ2V0LnksIHJhdGUpO1xyXG4gICAgICAgIHRoaXMuY3VyVmFsdWUueiA9IHRoaXMuaW50ZXJwb2xhdGlvbih0aGlzLm9yaWdpbmFsLnosIHRoaXMudGFyZ2V0LnosIHJhdGUpO1xyXG4gICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih0aGlzLmN1clZhbHVlLngsIHRoaXMuY3VyVmFsdWUueSwgdGhpcy5jdXJWYWx1ZS56KTtcclxuICAgIH1cclxufVxyXG5leHBvcnQgY2xhc3MgTW92ZUJ5M2QgZXh0ZW5kcyBGaW5pdGVUaW1lQWN0aW9uM2Qge1xyXG4gICAgLyoq5Yid5aeL5YC8ICovXHJcbiAgICBwcml2YXRlIG9yaWdpbmFsOiBWZWMzO1xyXG4gICAgLyoq55uu5qCH5YC8ICovXHJcbiAgICBwcml2YXRlIHRhcmdldDogVmVjMztcclxuICAgIC8qKuW9k+WJjeWAvCAqL1xyXG4gICAgcHJpdmF0ZSBjdXJWYWx1ZTogVmVjMztcclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihkdXJhdGlvbjogbnVtYmVyLCB4OiBudW1iZXIgfCBWZWMzLCB5PzogbnVtYmVyLCB6PzogbnVtYmVyKSB7XHJcbiAgICAgICAgc3VwZXIoZHVyYXRpb24pO1xyXG4gICAgICAgIGlmICh0eXBlb2YgeCA9PT0gXCJudW1iZXJcIikge1xyXG4gICAgICAgICAgICB0aGlzLnRhcmdldCA9IHtcclxuICAgICAgICAgICAgICAgIHg6IHgsXHJcbiAgICAgICAgICAgICAgICB5OiB5LFxyXG4gICAgICAgICAgICAgICAgejogelxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMudGFyZ2V0ID0geDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jdXJWYWx1ZSA9IHtcclxuICAgICAgICAgICAgeDogMCxcclxuICAgICAgICAgICAgeTogMCxcclxuICAgICAgICAgICAgejogMFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldFRhcmdldChub2RlOiBjYy5Ob2RlKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlID0gbm9kZTtcclxuICAgICAgICB0aGlzLm9yaWdpbmFsID0ge1xyXG4gICAgICAgICAgICB4OiBub2RlLngsXHJcbiAgICAgICAgICAgIHk6IG5vZGUueSxcclxuICAgICAgICAgICAgejogbm9kZS56XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RlcChyYXRlOiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLmN1clZhbHVlLnggPSB0aGlzLm9yaWdpbmFsLnggKyB0aGlzLnRhcmdldC54ICogcmF0ZTtcclxuICAgICAgICB0aGlzLmN1clZhbHVlLnkgPSB0aGlzLm9yaWdpbmFsLnkgKyB0aGlzLnRhcmdldC55ICogcmF0ZTtcclxuICAgICAgICB0aGlzLmN1clZhbHVlLnogPSB0aGlzLm9yaWdpbmFsLnogKyB0aGlzLnRhcmdldC56ICogcmF0ZTtcclxuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24odGhpcy5jdXJWYWx1ZS54LCB0aGlzLmN1clZhbHVlLnksIHRoaXMuY3VyVmFsdWUueik7XHJcbiAgICB9XHJcbn1cclxuLy/nvKnmlL5cclxuZXhwb3J0IGNsYXNzIFNjYWxlVG8zZCBleHRlbmRzIEZpbml0ZVRpbWVBY3Rpb24zZCB7XHJcbiAgICAvKirliJ3lp4vlgLwgKi9cclxuICAgIHByaXZhdGUgb3JpZ2luYWw6IFZlYzM7XHJcbiAgICAvKirnm67moIflgLwgKi9cclxuICAgIHByaXZhdGUgdGFyZ2V0OiBWZWMzO1xyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKGR1cmF0aW9uOiBudW1iZXIsIHg6IG51bWJlciB8IFZlYzMsIHk/OiBudW1iZXIsIHo/OiBudW1iZXIpIHtcclxuICAgICAgICBzdXBlcihkdXJhdGlvbik7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB4ID09PSBcIm51bWJlclwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMudGFyZ2V0ID0ge1xyXG4gICAgICAgICAgICAgICAgeDogeCxcclxuICAgICAgICAgICAgICAgIHk6IHksXHJcbiAgICAgICAgICAgICAgICB6OiB6XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy50YXJnZXQgPSB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0VGFyZ2V0KG5vZGU6IGNjLk5vZGUpIHtcclxuICAgICAgICB0aGlzLm5vZGUgPSBub2RlO1xyXG4gICAgICAgIHRoaXMub3JpZ2luYWwgPSB7XHJcbiAgICAgICAgICAgIHg6IG5vZGUuc2NhbGVYLFxyXG4gICAgICAgICAgICB5OiBub2RlLnNjYWxlWSxcclxuICAgICAgICAgICAgejogbm9kZS5zY2FsZVpcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGVwKHJhdGU6IG51bWJlcikge1xyXG4gICAgICAgIGxldCB4ID0gdGhpcy5pbnRlcnBvbGF0aW9uKHRoaXMub3JpZ2luYWwueCwgdGhpcy50YXJnZXQueCwgcmF0ZSk7XHJcbiAgICAgICAgbGV0IHkgPSB0aGlzLmludGVycG9sYXRpb24odGhpcy5vcmlnaW5hbC55LCB0aGlzLnRhcmdldC55LCByYXRlKTtcclxuICAgICAgICBsZXQgeiA9IHRoaXMuaW50ZXJwb2xhdGlvbih0aGlzLm9yaWdpbmFsLnosIHRoaXMudGFyZ2V0LnosIHJhdGUpO1xyXG4gICAgICAgIHRoaXMubm9kZS5zZXRTY2FsZSh4LCB5LCB6KTtcclxuICAgIH1cclxufVxyXG4vL+aXi+i9rFxyXG5leHBvcnQgY2xhc3MgUm90YXRlVG8zZCBleHRlbmRzIEZpbml0ZVRpbWVBY3Rpb24zZCB7XHJcbiAgICAvKirliJ3lp4vlgLwgKi9cclxuICAgIHByaXZhdGUgb3JpZ2luYWw6IFZlYzM7XHJcbiAgICAvKirnm67moIflgLwgKi9cclxuICAgIHByaXZhdGUgdGFyZ2V0OiBWZWMzO1xyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKGR1cmF0aW9uOiBudW1iZXIsIHg6IG51bWJlciB8IFZlYzMsIHk/OiBudW1iZXIsIHo/OiBudW1iZXIpIHtcclxuICAgICAgICBzdXBlcihkdXJhdGlvbik7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB4ID09PSBcIm51bWJlclwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMudGFyZ2V0ID0ge1xyXG4gICAgICAgICAgICAgICAgeDogeCxcclxuICAgICAgICAgICAgICAgIHk6IHksXHJcbiAgICAgICAgICAgICAgICB6OiB6XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy50YXJnZXQgPSB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHB1YmxpYyBzZXRUYXJnZXQobm9kZTogY2MuTm9kZSkge1xyXG4gICAgICAgIHRoaXMubm9kZSA9IG5vZGU7XHJcbiAgICAgICAgdGhpcy5vcmlnaW5hbCA9IHtcclxuICAgICAgICAgICAgeDogbm9kZS5ldWxlckFuZ2xlcy54LFxyXG4gICAgICAgICAgICB5OiBub2RlLmV1bGVyQW5nbGVzLnksXHJcbiAgICAgICAgICAgIHo6IG5vZGUuZXVsZXJBbmdsZXMuelxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN0ZXAocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IHggPSB0aGlzLmludGVycG9sYXRpb24odGhpcy5vcmlnaW5hbC54LCB0aGlzLnRhcmdldC54LCByYXRlKTtcclxuICAgICAgICBsZXQgeSA9IHRoaXMuaW50ZXJwb2xhdGlvbih0aGlzLm9yaWdpbmFsLnksIHRoaXMudGFyZ2V0LnksIHJhdGUpO1xyXG4gICAgICAgIGxldCB6ID0gdGhpcy5pbnRlcnBvbGF0aW9uKHRoaXMub3JpZ2luYWwueiwgdGhpcy50YXJnZXQueiwgcmF0ZSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmV1bGVyQW5nbGVzID0gY2MudjMoeCwgeSwgeik7XHJcbiAgICB9XHJcbn1cclxuZXhwb3J0IGNsYXNzIFJvdGF0ZUJ5M2QgZXh0ZW5kcyBGaW5pdGVUaW1lQWN0aW9uM2Qge1xyXG4gICAgLyoq5Yid5aeL5YC8ICovXHJcbiAgICBwcml2YXRlIG9yaWdpbmFsOiBWZWMzO1xyXG4gICAgLyoq55uu5qCH5YC8ICovXHJcbiAgICBwcml2YXRlIHRhcmdldDogVmVjMztcclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihkdXJhdGlvbjogbnVtYmVyLCB4OiBudW1iZXIgfCBWZWMzLCB5PzogbnVtYmVyLCB6PzogbnVtYmVyKSB7XHJcbiAgICAgICAgc3VwZXIoZHVyYXRpb24pO1xyXG4gICAgICAgIGlmICh0eXBlb2YgeCA9PT0gXCJudW1iZXJcIikge1xyXG4gICAgICAgICAgICB0aGlzLnRhcmdldCA9IHtcclxuICAgICAgICAgICAgICAgIHg6IHgsXHJcbiAgICAgICAgICAgICAgICB5OiB5LFxyXG4gICAgICAgICAgICAgICAgejogelxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMudGFyZ2V0ID0geDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldFRhcmdldChub2RlOiBjYy5Ob2RlKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlID0gbm9kZTtcclxuICAgICAgICB0aGlzLm9yaWdpbmFsID0ge1xyXG4gICAgICAgICAgICB4OiBub2RlLmV1bGVyQW5nbGVzLngsXHJcbiAgICAgICAgICAgIHk6IG5vZGUuZXVsZXJBbmdsZXMueSxcclxuICAgICAgICAgICAgejogbm9kZS5ldWxlckFuZ2xlcy56XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RlcChyYXRlOiBudW1iZXIpIHtcclxuICAgICAgICBsZXQgeCA9IHRoaXMub3JpZ2luYWwueCArIHRoaXMudGFyZ2V0LnggKiByYXRlO1xyXG4gICAgICAgIGxldCB5ID0gdGhpcy5vcmlnaW5hbC55ICsgdGhpcy50YXJnZXQueSAqIHJhdGU7XHJcbiAgICAgICAgbGV0IHogPSB0aGlzLm9yaWdpbmFsLnogKyB0aGlzLnRhcmdldC56ICogcmF0ZTtcclxuICAgICAgICB0aGlzLm5vZGUuZXVsZXJBbmdsZXMgPSBjYy52Myh4LCB5LCB6KTtcclxuICAgIH1cclxufVxyXG5cclxuLy8yROaXi+i9rFxyXG5leHBvcnQgY2xhc3MgUm90YXRlVG8yZCBleHRlbmRzIEZpbml0ZVRpbWVBY3Rpb24zZCB7XHJcbiAgICAvKirliJ3lp4vlgLwgKi9cclxuICAgIHByaXZhdGUgb3JpZ2luYWw6IG51bWJlcjtcclxuICAgIC8qKuebruagh+WAvCAqL1xyXG4gICAgcHJpdmF0ZSB0YXJnZXQ6IG51bWJlcjtcclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihkdXJhdGlvbjogbnVtYmVyLCBhbmdsZTogbnVtYmVyKSB7XHJcbiAgICAgICAgc3VwZXIoZHVyYXRpb24pO1xyXG4gICAgICAgIHRoaXMudGFyZ2V0ID0gYW5nbGU7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc2V0VGFyZ2V0KG5vZGU6IGNjLk5vZGUpIHtcclxuICAgICAgICB0aGlzLm5vZGUgPSBub2RlO1xyXG4gICAgICAgIHRoaXMub3JpZ2luYWwgPSBub2RlLmFuZ2xlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGVwKHJhdGU6IG51bWJlcikge1xyXG4gICAgICAgIGxldCBhbmdsZSA9IHRoaXMuaW50ZXJwb2xhdGlvbih0aGlzLm9yaWdpbmFsLCB0aGlzLnRhcmdldCwgcmF0ZSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gYW5nbGU7XHJcbiAgICB9XHJcbn1cclxuLy8yROaXi+i9rFxyXG5leHBvcnQgY2xhc3MgUm90YXRlQnkyZCBleHRlbmRzIEZpbml0ZVRpbWVBY3Rpb24zZCB7XHJcbiAgICAvKirliJ3lp4vlgLwgKi9cclxuICAgIHByaXZhdGUgb3JpZ2luYWw6IG51bWJlcjtcclxuICAgIC8qKuebruagh+WAvCAqL1xyXG4gICAgcHJpdmF0ZSB0YXJnZXQ6IG51bWJlcjtcclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihkdXJhdGlvbjogbnVtYmVyLCBhbmdsZTogbnVtYmVyKSB7XHJcbiAgICAgICAgc3VwZXIoZHVyYXRpb24pO1xyXG4gICAgICAgIHRoaXMudGFyZ2V0ID0gYW5nbGU7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc2V0VGFyZ2V0KG5vZGU6IGNjLk5vZGUpIHtcclxuICAgICAgICB0aGlzLm5vZGUgPSBub2RlO1xyXG4gICAgICAgIHRoaXMub3JpZ2luYWwgPSBub2RlLmFuZ2xlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGVwKHJhdGU6IG51bWJlcikge1xyXG4gICAgICAgIGxldCBhbmdsZSA9IHRoaXMub3JpZ2luYWwgKyB0aGlzLnRhcmdldCAqIHJhdGU7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gYW5nbGU7XHJcbiAgICB9XHJcbn1cclxuLy8yROiKgueCue+8mumAj+aYjuW6puWPmOWMllxyXG5leHBvcnQgY2xhc3MgRmFkZVRvIGV4dGVuZHMgRmluaXRlVGltZUFjdGlvbjNkIHtcclxuICAgIC8qKuWIneWni+WAvCAqL1xyXG4gICAgcHJpdmF0ZSBvcmlnaW5hbDogbnVtYmVyO1xyXG4gICAgLyoq55uu5qCH5YC8ICovXHJcbiAgICBwcml2YXRlIHRhcmdldDogbnVtYmVyO1xyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKGR1cmF0aW9uOiBudW1iZXIsIHg6IG51bWJlcikge1xyXG4gICAgICAgIHN1cGVyKGR1cmF0aW9uKTtcclxuICAgICAgICB0aGlzLnRhcmdldCA9IHg7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc2V0VGFyZ2V0KG5vZGU6IGNjLk5vZGUpIHtcclxuICAgICAgICB0aGlzLm5vZGUgPSBub2RlO1xyXG4gICAgICAgIHRoaXMub3JpZ2luYWwgPSBub2RlLm9wYWNpdHk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN0ZXAocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IG8gPSB0aGlzLmludGVycG9sYXRpb24odGhpcy5vcmlnaW5hbCwgdGhpcy50YXJnZXQsIHJhdGUpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gbztcclxuICAgIH1cclxufVxyXG5leHBvcnQgY2xhc3MgRmFkZUJ5IGV4dGVuZHMgRmluaXRlVGltZUFjdGlvbjNkIHtcclxuICAgIC8qKuWIneWni+WAvCAqL1xyXG4gICAgcHJpdmF0ZSBvcmlnaW5hbDogbnVtYmVyO1xyXG4gICAgLyoq55uu5qCH5YC8ICovXHJcbiAgICBwcml2YXRlIHRhcmdldDogbnVtYmVyO1xyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKGR1cmF0aW9uOiBudW1iZXIsIHg6IG51bWJlcikge1xyXG4gICAgICAgIHN1cGVyKGR1cmF0aW9uKTtcclxuICAgICAgICB0aGlzLnRhcmdldCA9IHg7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc2V0VGFyZ2V0KG5vZGU6IGNjLk5vZGUpIHtcclxuICAgICAgICB0aGlzLm5vZGUgPSBub2RlO1xyXG4gICAgICAgIHRoaXMub3JpZ2luYWwgPSBub2RlLm9wYWNpdHk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN0ZXAocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSB0aGlzLm9yaWdpbmFsICsgdGhpcy50YXJnZXQgKiByYXRlO1xyXG4gICAgfVxyXG59XHJcblxyXG5cclxuLy/ku7vmhI/lsZ7mgKflj5jljJZcclxuY2xhc3MgVHdlZW5UbyBleHRlbmRzIEZpbml0ZVRpbWVBY3Rpb24zZCB7XHJcblxyXG4gICAgcHJvdGVjdGVkIG9iajogYW55O1xyXG4gICAgcHJvdGVjdGVkIGF0dHJpYnV0ZTogc3RyaW5nO1xyXG4gICAgcHJvdGVjdGVkIG9yaWdpbmFsOiBhbnk7XHJcbiAgICBwcm90ZWN0ZWQgdGFyZ2V0VmFsdWU6IGFueTtcclxuICAgIHByb3RlY3RlZCBpc051bWJlcjogYm9vbGVhbjtcclxuICAgIHByb3RlY3RlZCBuZXdBdHRyaWJ1dGU6IGJvb2xlYW47XHJcbiAgICAvKipcclxuICAgICAqIFxyXG4gICAgICogQHBhcmFtIGR1cmF0aW9uIOWKqOS9nOaMgee7reeahOaXtumXtFxyXG4gICAgICogQHBhcmFtIGF0dHJpYnV0ZSDlj5jph4/lkI3np7BcclxuICAgICAqIEBwYXJhbSB2YWx1ZSDlj5jljJbnmoTnm7jlr7nlgLxcclxuICAgICAqIEBwYXJhbSBuZXdBdHRyaWJ1dGUg5YC85Y+Y5YyW5pe25piv5ZCm6ZyA6KaB5paw5bu65bGe5oCn5YaN57uZ55uu5qCH5a+56LGh6LWL5YC877yM5L6L5aaC6KaB5L+u5pS56IqC54K555qEcG9zaXRpb27lsZ7mgKfml7blupTor6XkuLp0cnVlXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihkdXJhdGlvbjogbnVtYmVyLCBhdHRyaWJ1dGU6IHN0cmluZywgdmFsdWU6IGFueSwgbmV3QXR0cmlidXRlOiBib29sZWFuKSB7XHJcbiAgICAgICAgc3VwZXIoZHVyYXRpb24pO1xyXG4gICAgICAgIHRoaXMuYXR0cmlidXRlID0gYXR0cmlidXRlO1xyXG4gICAgICAgIHRoaXMudGFyZ2V0VmFsdWUgPSB2YWx1ZTtcclxuICAgICAgICB0aGlzLmlzTnVtYmVyID0gKHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIik7XHJcbiAgICAgICAgdGhpcy5uZXdBdHRyaWJ1dGUgPSBuZXdBdHRyaWJ1dGU7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc2V0VGFyZ2V0KG9iajogYW55KSB7XHJcbiAgICAgICAgdGhpcy5vYmogPSBvYmo7XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gb2JqW3RoaXMuYXR0cmlidXRlXSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwi5a+56LGh5LiN5a2Y5Zyo5bGe5oCnXCIgKyB0aGlzLmF0dHJpYnV0ZSArIFwi77yM5Yqo5L2cVHdlZW5Ub+WwhuaXoOazleeUn+aViFwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm9yaWdpbmFsID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShvYmpbdGhpcy5hdHRyaWJ1dGVdKSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RlcChyYXRlOiBudW1iZXIpIHtcclxuICAgICAgICBpZiAodGhpcy5pc051bWJlcikge1xyXG4gICAgICAgICAgICB0aGlzLm9ialt0aGlzLmF0dHJpYnV0ZV0gPSB0aGlzLmludGVycG9sYXRpb24odGhpcy5vcmlnaW5hbCwgdGhpcy50YXJnZXRWYWx1ZSwgcmF0ZSk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLm5ld0F0dHJpYnV0ZSkge1xyXG4gICAgICAgICAgICBsZXQgZGF0YTogYW55ID0ge307XHJcbiAgICAgICAgICAgIGZvciAobGV0IGtleSBpbiB0aGlzLm9yaWdpbmFsKSB7XHJcbiAgICAgICAgICAgICAgICBkYXRhW2tleV0gPSB0aGlzLmludGVycG9sYXRpb24odGhpcy5vcmlnaW5hbFtrZXldLCB0aGlzLnRhcmdldFZhbHVlW2tleV0sIHJhdGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMub2JqW3RoaXMuYXR0cmlidXRlXSA9IGRhdGE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMub3JpZ2luYWwpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMub2JqW3RoaXMuYXR0cmlidXRlXVtrZXldID0gdGhpcy5pbnRlcnBvbGF0aW9uKHRoaXMub3JpZ2luYWxba2V5XSwgdGhpcy50YXJnZXRWYWx1ZVtrZXldLCByYXRlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5jbGFzcyBUd2VlbkJ5IGV4dGVuZHMgRmluaXRlVGltZUFjdGlvbjNkIHtcclxuXHJcbiAgICBwcm90ZWN0ZWQgb2JqOiBhbnk7XHJcbiAgICBwcm90ZWN0ZWQgYXR0cmlidXRlOiBzdHJpbmc7XHJcbiAgICBwcm90ZWN0ZWQgb3JpZ2luYWw6IGFueTtcclxuICAgIHByb3RlY3RlZCB0YXJnZXRWYWx1ZTogYW55O1xyXG4gICAgcHJvdGVjdGVkIGlzTnVtYmVyOiBib29sZWFuO1xyXG4gICAgcHJvdGVjdGVkIG5ld0F0dHJpYnV0ZTogYm9vbGVhbjtcclxuICAgIC8qKlxyXG4gICAgICogXHJcbiAgICAgKiBAcGFyYW0gZHVyYXRpb24g5Yqo5L2c5oyB57ut55qE5pe26Ze0XHJcbiAgICAgKiBAcGFyYW0gYXR0cmlidXRlIOWPmOmHj+WQjeensFxyXG4gICAgICogQHBhcmFtIHZhbHVlIOWPmOWMlueahOebuOWvueWAvFxyXG4gICAgICogQHBhcmFtIG5ld0F0dHJpYnV0ZSDlgLzlj5jljJbml7bmmK/lkKbpnIDopoHmlrDlu7rlsZ7mgKflho3nu5nnm67moIflr7nosaHotYvlgLzvvIzkvovlpoLopoHkv67mlLnoioLngrnnmoRwb3NpdGlvbuWxnuaAp+aXtuW6lOivpeS4unRydWVcclxuICAgICAqL1xyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKGR1cmF0aW9uOiBudW1iZXIsIGF0dHJpYnV0ZTogc3RyaW5nLCB2YWx1ZTogYW55LCBuZXdBdHRyaWJ1dGU6IGJvb2xlYW4pIHtcclxuICAgICAgICBzdXBlcihkdXJhdGlvbik7XHJcbiAgICAgICAgdGhpcy5hdHRyaWJ1dGUgPSBhdHRyaWJ1dGU7XHJcbiAgICAgICAgdGhpcy50YXJnZXRWYWx1ZSA9IHZhbHVlO1xyXG4gICAgICAgIHRoaXMuaXNOdW1iZXIgPSAodHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiKTtcclxuICAgICAgICB0aGlzLm5ld0F0dHJpYnV0ZSA9IG5ld0F0dHJpYnV0ZTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzZXRUYXJnZXQob2JqOiBhbnkpIHtcclxuICAgICAgICB0aGlzLm9iaiA9IG9iajtcclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBvYmpbdGhpcy5hdHRyaWJ1dGVdKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCLlr7nosaHkuI3lrZjlnKjlsZ7mgKdcIiArIHRoaXMuYXR0cmlidXRlICsgXCLvvIzliqjkvZxUd2VlblRv5bCG5peg5rOV55Sf5pWIXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMub3JpZ2luYWwgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KG9ialt0aGlzLmF0dHJpYnV0ZV0pKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGVwKHJhdGU6IG51bWJlcikge1xyXG4gICAgICAgIGlmICh0aGlzLmlzTnVtYmVyKSB7XHJcbiAgICAgICAgICAgIHRoaXMub2JqW3RoaXMuYXR0cmlidXRlXSA9IHRoaXMub3JpZ2luYWwgKyB0aGlzLnRhcmdldFZhbHVlICogcmF0ZTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMubmV3QXR0cmlidXRlKSB7XHJcbiAgICAgICAgICAgIGxldCBkYXRhOiBhbnkgPSB7fTtcclxuICAgICAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMub3JpZ2luYWwpIHtcclxuICAgICAgICAgICAgICAgIGRhdGFba2V5XSA9IHRoaXMub3JpZ2luYWxba2V5XSArIHRoaXMudGFyZ2V0VmFsdWVba2V5XSAqIHJhdGU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5vYmpbdGhpcy5hdHRyaWJ1dGVdID0gZGF0YTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBrZXkgaW4gdGhpcy5vcmlnaW5hbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5vYmpbdGhpcy5hdHRyaWJ1dGVdW2tleV0gPSB0aGlzLm9yaWdpbmFsW2tleV0gKyB0aGlzLnRhcmdldFZhbHVlW2tleV0gKiByYXRlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuLy/lm57osIPlh73mlbBcclxuZXhwb3J0IGNsYXNzIENhbGxGdW4zZCBleHRlbmRzIEFjdGlvbjNkIHtcclxuICAgIHByaXZhdGUgdGFyZ2V0OiBhbnk7XHJcbiAgICBwcml2YXRlIGNiOiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgZGF0YTogYW55O1xyXG4gICAgcHJvdGVjdGVkIF9maW5pc2hlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGdldCBmaW5pc2hlZCgpOiBib29sZWFuIHsgcmV0dXJuIHRoaXMuX2ZpbmlzaGVkOyB9XHJcbiAgICBwdWJsaWMgcmVzZXRGaW5pc2hTdGF0ZSgpIHtcclxuICAgICAgICB0aGlzLl9maW5pc2hlZCA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKGNiOiBGdW5jdGlvbiwgdGFyZ2V0PzogYW55LCBkYXRhPzogYW55KSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICB0aGlzLmNiID0gY2I7XHJcbiAgICAgICAgdGhpcy50YXJnZXQgPSB0YXJnZXQ7XHJcbiAgICAgICAgdGhpcy5kYXRhID0gZGF0YTtcclxuICAgIH1cclxuICAgIHB1YmxpYyB1cGRhdGUoZHQ6IG51bWJlcikge1xyXG4gICAgICAgIGlmICh0aGlzLmZpbmlzaGVkKSByZXR1cm47XHJcbiAgICAgICAgaWYgKCEhdGhpcy50YXJnZXQpIHtcclxuICAgICAgICAgICAgdGhpcy5jYi5jYWxsKHRoaXMudGFyZ2V0LCB0aGlzLmRhdGEgfHwgbnVsbCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5jYih0aGlzLmRhdGEgfHwgbnVsbCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2ZpbmlzaGVkID0gdHJ1ZTtcclxuICAgIH1cclxufVxyXG5cclxuXHJcbi8v6Zif5YiX5Yqo5L2cXHJcbmV4cG9ydCBjbGFzcyBTZXF1ZW5jZTNkIGV4dGVuZHMgQWN0aW9uM2Qge1xyXG4gICAgLyoq5Yqo5L2c5YiX6KGoICovXHJcbiAgICBwcm90ZWN0ZWQgYWN0aW9uczogQWN0aW9uM2RbXTtcclxuICAgIC8qKuW9k+WJjeaJp+ihjOeahOWKqOS9nOe0ouW8lSAqL1xyXG4gICAgcHJvdGVjdGVkIGN1ckFjdGlvblB0cjogbnVtYmVyO1xyXG4gICAgcHVibGljIGdldCBmaW5pc2hlZCgpOiBib29sZWFuIHsgcmV0dXJuIHRoaXMuY3VyQWN0aW9uUHRyID49IHRoaXMuYWN0aW9ucy5sZW5ndGg7IH1cclxuICAgIHB1YmxpYyByZXNldEZpbmlzaFN0YXRlKCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSB0aGlzLmFjdGlvbnMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgdGhpcy5hY3Rpb25zW2ldLnJlc2V0RmluaXNoU3RhdGUoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jdXJBY3Rpb25QdHIgPSAwO1xyXG4gICAgICAgIHRoaXMuc2V0Q3VyQWN0aW9uVGFyZ2V0KCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IoYWN0aW9uczogQWN0aW9uM2RbXSkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgdGhpcy5jdXJBY3Rpb25QdHIgPSAwO1xyXG4gICAgICAgIHRoaXMuYWN0aW9ucyA9IFtdLmNvbmNhdChhY3Rpb25zKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzZXRUYXJnZXQobm9kZTogY2MuTm9kZSkge1xyXG4gICAgICAgIHRoaXMubm9kZSA9IG5vZGU7XHJcbiAgICAgICAgLy8gZm9yIChsZXQgaSA9IHRoaXMuYWN0aW9ucy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xyXG4gICAgICAgIC8vICAgICB0aGlzLmFjdGlvbnNbaV0uc2V0VGFyZ2V0KG5vZGUpO1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgICB0aGlzLnNldEN1ckFjdGlvblRhcmdldCgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuZmluaXNoZWQpIHJldHVybjtcclxuICAgICAgICBsZXQgYWN0aW9uID0gdGhpcy5hY3Rpb25zW3RoaXMuY3VyQWN0aW9uUHRyXTtcclxuICAgICAgICBhY3Rpb24udXBkYXRlKGR0KTtcclxuICAgICAgICBpZiAoYWN0aW9uLmZpbmlzaGVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY3VyQWN0aW9uUHRyKys7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0Q3VyQWN0aW9uVGFyZ2V0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLyoq6K6+572u5b2T5YmN5q2j5Zyo5omn6KGM55qE5Yqo5L2c55qE55uu5qCH6IqC54K5ICovXHJcbiAgICBwcm90ZWN0ZWQgc2V0Q3VyQWN0aW9uVGFyZ2V0KCkge1xyXG4gICAgICAgIGlmICghdGhpcy5maW5pc2hlZCkgdGhpcy5hY3Rpb25zW3RoaXMuY3VyQWN0aW9uUHRyXS5zZXRUYXJnZXQodGhpcy5ub2RlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcHVzaEFjdGlvbihhY3Rpb246IEFjdGlvbjNkKSB7XHJcbiAgICAgICAgdGhpcy5hY3Rpb25zLnB1c2goYWN0aW9uKTtcclxuICAgIH1cclxufVxyXG4vL+WQjOatpeWKqOS9nFxyXG5leHBvcnQgY2xhc3MgU3Bhd24zZCBleHRlbmRzIEFjdGlvbjNkIHtcclxuICAgIC8qKuWKqOS9nOWIl+ihqCAqL1xyXG4gICAgcHJvdGVjdGVkIGFjdGlvbnM6IEFjdGlvbjNkW107XHJcbiAgICAvKirliankvZnmnKrlrozmiJDnmoTliqjkvZwgKi9cclxuICAgIHByaXZhdGUgcmVtYWluQ291bnQ6IG51bWJlcjtcclxuICAgIHB1YmxpYyBnZXQgZmluaXNoZWQoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucmVtYWluQ291bnQgPD0gMDtcclxuICAgIH1cclxuICAgIHB1YmxpYyByZXNldEZpbmlzaFN0YXRlKCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSB0aGlzLmFjdGlvbnMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgdGhpcy5hY3Rpb25zW2ldLnJlc2V0RmluaXNoU3RhdGUoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5yZW1haW5Db3VudCA9IHRoaXMuYWN0aW9ucy5sZW5ndGg7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IoYWN0aW9uczogQWN0aW9uM2RbXSkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgdGhpcy5hY3Rpb25zID0gW10uY29uY2F0KGFjdGlvbnMpO1xyXG4gICAgICAgIHRoaXMucmVtYWluQ291bnQgPSB0aGlzLmFjdGlvbnMubGVuZ3RoO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHNldFRhcmdldChub2RlOiBjYy5Ob2RlKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlID0gbm9kZTtcclxuICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5hY3Rpb25zLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYWN0aW9uc1tpXS5zZXRUYXJnZXQobm9kZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuZmluaXNoZWQpIHJldHVybjtcclxuICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5hY3Rpb25zLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5hY3Rpb25zW2ldLmZpbmlzaGVkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFjdGlvbnNbaV0udXBkYXRlKGR0KTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmFjdGlvbnNbaV0uZmluaXNoZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbWFpbkNvdW50LS07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvL+i/veWKoOS4gOS4quWKqOS9nFxyXG4gICAgcHVibGljIHB1c2hBY3Rpb24oYWN0aW9uOiBBY3Rpb24zZCkge1xyXG4gICAgICAgIHRoaXMuYWN0aW9ucy5wdXNoKGFjdGlvbik7XHJcbiAgICAgICAgaWYgKCEhdGhpcy5ub2RlKSBhY3Rpb24uc2V0VGFyZ2V0KHRoaXMubm9kZSk7XHJcbiAgICB9XHJcbn1cclxuLy/ph43lpI3liqjkvZxcclxuZXhwb3J0IGNsYXNzIFJlcGVhdEZvcmV2ZXIgZXh0ZW5kcyBBY3Rpb24zZCB7XHJcbiAgICBwcm90ZWN0ZWQgYWN0aW9uOiBBY3Rpb24zZDtcclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihhY3Rpb246IEFjdGlvbjNkKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICB0aGlzLmFjdGlvbiA9IGFjdGlvbjtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzZXRUYXJnZXQobm9kZTogY2MuTm9kZSkge1xyXG4gICAgICAgIHRoaXMubm9kZSA9IG5vZGU7XHJcbiAgICAgICAgdGhpcy5hY3Rpb24uc2V0VGFyZ2V0KG5vZGUpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy5hY3Rpb24udXBkYXRlKGR0KTtcclxuICAgICAgICBpZiAodGhpcy5hY3Rpb24uZmluaXNoZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5hY3Rpb24ucmVzZXRGaW5pc2hTdGF0ZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcbi8v57yT5Yqo5puy57q/XHJcbmNsYXNzIEVhc2Uge1xyXG4gICAgcHVibGljIGVhc2luZyhyYXRlOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiByYXRlO1xyXG4gICAgfVxyXG59XHJcbmNsYXNzIEVhc2VJbiBleHRlbmRzIEVhc2Uge1xyXG4gICAgcHJvdGVjdGVkIF9yYXRlOiBudW1iZXI7XHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICB0aGlzLl9yYXRlID0gcmF0ZTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gTWF0aC5wb3cocmF0ZSwgdGhpcy5fcmF0ZSk7XHJcbiAgICB9XHJcbn1cclxuY2xhc3MgRWFzZU91dCBleHRlbmRzIEVhc2Uge1xyXG4gICAgcHJvdGVjdGVkIF9yYXRlOiBudW1iZXI7XHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICB0aGlzLl9yYXRlID0gcmF0ZTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gTWF0aC5wb3cocmF0ZSwgMSAvIHRoaXMuX3JhdGUpO1xyXG4gICAgfVxyXG59XHJcbmNsYXNzIEVhc2VJbk91dCBleHRlbmRzIEVhc2Uge1xyXG4gICAgcHJvdGVjdGVkIF9yYXRlOiBudW1iZXI7XHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICB0aGlzLl9yYXRlID0gcmF0ZTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByYXRlICo9IDI7XHJcbiAgICAgICAgaWYgKHJhdGUgPCAxKVxyXG4gICAgICAgICAgICByZXR1cm4gMC41ICogTWF0aC5wb3cocmF0ZSwgdGhpcy5fcmF0ZSk7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICByZXR1cm4gMS4wIC0gMC41ICogTWF0aC5wb3coMiAtIHJhdGUsIHRoaXMuX3JhdGUpO1xyXG4gICAgfVxyXG59XHJcblxyXG5jbGFzcyBFYXNlT3V0SW4gZXh0ZW5kcyBFYXNlIHtcclxuICAgIHByb3RlY3RlZCBfcmF0ZTogbnVtYmVyO1xyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKHJhdGU6IG51bWJlcikge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgdGhpcy5fcmF0ZSA9IHJhdGU7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgZWFzaW5nKHJhdGU6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgcmF0ZSAqPSAyO1xyXG4gICAgICAgIGlmIChyYXRlIDwgMSlcclxuICAgICAgICAgICAgcmV0dXJuIDEuMCAtIDAuNSAqIE1hdGgucG93KDIgLSByYXRlLCB0aGlzLl9yYXRlKTtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIHJldHVybiAwLjUgKiBNYXRoLnBvdyhyYXRlLCB0aGlzLl9yYXRlKTtcclxuICAgIH1cclxufVxyXG4vKirmjIfmlbDlh73mlbDnvJPliqjov5vlhaUgKi9cclxuY2xhc3MgRWFzZUV4cG9uZW50aWFsSW4gZXh0ZW5kcyBFYXNlIHtcclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gcmF0ZSA9PT0gMCA/IDAgOiBNYXRoLnBvdygyLCAxMCAqIChyYXRlIC0gMSkpO1xyXG4gICAgfVxyXG59XHJcbi8qKuaMh+aVsOWHveaVsOe8k+WKqOmAgOWHuiAqL1xyXG5jbGFzcyBFYXNlRXhwb25lbnRpYWxPdXQgZXh0ZW5kcyBFYXNlIHtcclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gcmF0ZSA9PT0gMSA/IDEgOiAoLShNYXRoLnBvdygyLCAtMTAgKiByYXRlKSkgKyAxKTtcclxuICAgIH1cclxufVxyXG4vKirmjIfmlbDlh73mlbDnvJPliqjov5vlhaXigJTigJTpgIDlh7ogKi9cclxuY2xhc3MgRWFzZUV4cG9uZW50aWFsSW5PdXQgZXh0ZW5kcyBFYXNlIHtcclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAocmF0ZSAhPT0gMSAmJiByYXRlICE9PSAwKSB7XHJcbiAgICAgICAgICAgIHJhdGUgKj0gMjtcclxuICAgICAgICAgICAgaWYgKHJhdGUgPCAxKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIDAuNSAqIE1hdGgucG93KDIsIDEwICogKHJhdGUgLSAxKSk7XHJcbiAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgIHJldHVybiAwLjUgKiAoLU1hdGgucG93KDIsIC0xMCAqIChyYXRlIC0gMSkpICsgMik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByYXRlO1xyXG4gICAgfVxyXG59XHJcblxyXG5jbGFzcyBFYXNlU2luSW4gZXh0ZW5kcyBFYXNlIHtcclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgcmV0dXJuIDEgLSBNYXRoLnNpbigoMSAtIHJhdGUpICogMS41Nyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmNsYXNzIEVhc2VTaW5PdXQgZXh0ZW5kcyBFYXNlIHtcclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgcmV0dXJuIE1hdGguc2luKHJhdGUgKiAxLjU3KTtcclxuICAgIH1cclxufVxyXG5jbGFzcyBFYXNlU2luSW5PdXQgZXh0ZW5kcyBFYXNlIHtcclxuICAgIHB1YmxpYyBlYXNpbmcocmF0ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgcmV0dXJuIE1hdGguc2luKHJhdGUgKiAzLjE0ICsgNC43MSkgKiAwLjUgKyAwLjU7XHJcbiAgICB9XHJcbn1cclxuY2xhc3MgRWFzZVNpbk91dEluIGV4dGVuZHMgRWFzZSB7XHJcbiAgICBwdWJsaWMgZWFzaW5nKHJhdGU6IG51bWJlcikge1xyXG4gICAgICAgIGlmIChyYXRlIDwgMC41KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBNYXRoLnNpbihyYXRlICogMy4xNCkgKiAwLjU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIDEgLSBNYXRoLnNpbigoMSAtIHJhdGUpICogMy4xNCkgKiAwLjU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4vL+W8ueaAp+WPmOWMllxyXG5jbGFzcyBFYXNlRWxhc3RpY0luIGV4dGVuZHMgRWFzZSB7XHJcbiAgICBwcm90ZWN0ZWQgX3BlcmlvZDogbnVtYmVyO1xyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKHJhdGU/OiBudW1iZXIpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIHRoaXMuX3BlcmlvZCA9IHJhdGUgfHwgMC4zO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGVhc2luZyhyYXRlOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIGlmIChyYXRlID09PSAwIHx8IHJhdGUgPT09IDEpXHJcbiAgICAgICAgICAgIHJldHVybiByYXRlO1xyXG4gICAgICAgIHJhdGUgPSByYXRlIC0gMTtcclxuICAgICAgICByZXR1cm4gLU1hdGgucG93KDIsIDEwICogcmF0ZSkgKiBNYXRoLnNpbigocmF0ZSAtICh0aGlzLl9wZXJpb2QgLyA0KSkgKiBNYXRoLlBJICogMiAvIHRoaXMuX3BlcmlvZCk7XHJcbiAgICB9XHJcbn1cclxuY2xhc3MgRWFzZUVsYXN0aWNPdXQgZXh0ZW5kcyBFYXNlIHtcclxuICAgIHByb3RlY3RlZCBfcGVyaW9kOiBudW1iZXI7XHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IocmF0ZT86IG51bWJlcikge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgdGhpcy5fcGVyaW9kID0gcmF0ZSB8fCAwLjM7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgZWFzaW5nKGR0OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiAoZHQgPT09IDAgfHwgZHQgPT09IDEpID8gZHQgOiBNYXRoLnBvdygyLCAtMTAgKiBkdCkgKiBNYXRoLnNpbigoZHQgLSAodGhpcy5fcGVyaW9kIC8gNCkpICogTWF0aC5QSSAqIDIgLyB0aGlzLl9wZXJpb2QpICsgMTtcclxuICAgIH1cclxufVxyXG5jbGFzcyBFYXNlRWxhc3RpY0luT3V0IGV4dGVuZHMgRWFzZSB7XHJcbiAgICBwcm90ZWN0ZWQgX3BlcmlvZDogbnVtYmVyO1xyXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKHJhdGU/OiBudW1iZXIpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIHRoaXMuX3BlcmlvZCA9IHJhdGUgfHwgMC4zO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGVhc2luZyhkdDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICB2YXIgbmV3VCA9IDA7XHJcbiAgICAgICAgdmFyIGxvY1BlcmlvZCA9IHRoaXMuX3BlcmlvZDtcclxuICAgICAgICBpZiAoZHQgPT09IDAgfHwgZHQgPT09IDEpIHtcclxuICAgICAgICAgICAgbmV3VCA9IGR0O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGR0ID0gZHQgKiAyO1xyXG4gICAgICAgICAgICBpZiAoIWxvY1BlcmlvZClcclxuICAgICAgICAgICAgICAgIGxvY1BlcmlvZCA9IHRoaXMuX3BlcmlvZCA9IDAuMyAqIDEuNTtcclxuICAgICAgICAgICAgdmFyIHMgPSBsb2NQZXJpb2QgLyA0O1xyXG4gICAgICAgICAgICBkdCA9IGR0IC0gMTtcclxuICAgICAgICAgICAgaWYgKGR0IDwgMClcclxuICAgICAgICAgICAgICAgIG5ld1QgPSAtMC41ICogTWF0aC5wb3coMiwgMTAgKiBkdCkgKiBNYXRoLnNpbigoZHQgLSBzKSAqIE1hdGguUEkgKiAyIC8gbG9jUGVyaW9kKTtcclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgbmV3VCA9IE1hdGgucG93KDIsIC0xMCAqIGR0KSAqIE1hdGguc2luKChkdCAtIHMpICogTWF0aC5QSSAqIDIgLyBsb2NQZXJpb2QpICogMC41ICsgMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5ld1Q7XHJcbiAgICB9XHJcbn1cclxuLy/mjInlvLnot7PliqjkvZznvJPliqjov5vlhaXnmoTliqjkvZxcclxuY2xhc3MgRWFzZUJvdW5jZUluIGV4dGVuZHMgRWFzZSB7XHJcbiAgICBwdWJsaWMgZWFzaW5nKGR0OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiAxIC0gdGhpcy5fYm91bmNlVGltZSgxIC0gZHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBfYm91bmNlVGltZSh0aW1lMSkge1xyXG4gICAgICAgIGlmICh0aW1lMSA8IDEgLyAyLjc1KSB7XHJcbiAgICAgICAgICAgIHJldHVybiA3LjU2MjUgKiB0aW1lMSAqIHRpbWUxO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGltZTEgPCAyIC8gMi43NSkge1xyXG4gICAgICAgICAgICB0aW1lMSAtPSAxLjUgLyAyLjc1O1xyXG4gICAgICAgICAgICByZXR1cm4gNy41NjI1ICogdGltZTEgKiB0aW1lMSArIDAuNzU7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aW1lMSA8IDIuNSAvIDIuNzUpIHtcclxuICAgICAgICAgICAgdGltZTEgLT0gMi4yNSAvIDIuNzU7XHJcbiAgICAgICAgICAgIHJldHVybiA3LjU2MjUgKiB0aW1lMSAqIHRpbWUxICsgMC45Mzc1O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGltZTEgLT0gMi42MjUgLyAyLjc1O1xyXG4gICAgICAgIHJldHVybiA3LjU2MjUgKiB0aW1lMSAqIHRpbWUxICsgMC45ODQzNzU7XHJcbiAgICB9XHJcbn1cclxuXHJcbmNsYXNzIEVhc2VCb3VuY2VPdXQgZXh0ZW5kcyBFYXNlIHtcclxuICAgIHB1YmxpYyBlYXNpbmcoZHQ6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2JvdW5jZVRpbWUoZHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBfYm91bmNlVGltZSh0aW1lMSkge1xyXG4gICAgICAgIGlmICh0aW1lMSA8IDEgLyAyLjc1KSB7XHJcbiAgICAgICAgICAgIHJldHVybiA3LjU2MjUgKiB0aW1lMSAqIHRpbWUxO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGltZTEgPCAyIC8gMi43NSkge1xyXG4gICAgICAgICAgICB0aW1lMSAtPSAxLjUgLyAyLjc1O1xyXG4gICAgICAgICAgICByZXR1cm4gNy41NjI1ICogdGltZTEgKiB0aW1lMSArIDAuNzU7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aW1lMSA8IDIuNSAvIDIuNzUpIHtcclxuICAgICAgICAgICAgdGltZTEgLT0gMi4yNSAvIDIuNzU7XHJcbiAgICAgICAgICAgIHJldHVybiA3LjU2MjUgKiB0aW1lMSAqIHRpbWUxICsgMC45Mzc1O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGltZTEgLT0gMi42MjUgLyAyLjc1O1xyXG4gICAgICAgIHJldHVybiA3LjU2MjUgKiB0aW1lMSAqIHRpbWUxICsgMC45ODQzNzU7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG4iXX0=