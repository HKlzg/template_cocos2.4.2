
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/GameData.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8b8f7V7UqZE24WpKssNCDL7', 'GameData');
// Script/Common/GameData.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GlobalEnum_1 = require("../GameSpecial/GlobalEnum");
var LevelDataTemplate_1 = require("../GameSpecial/LevelDataTemplate");
/**游戏JSON数据管理器 */
var GameData = /** @class */ (function () {
    function GameData() {
    }
    GameData.init = function () {
        this.data = {};
        //一些常见的数据类型，使用默认数据进行初始化
        //关卡：
        this.data[GlobalEnum_1.GlobalEnum.GameDataType.levelData] = LevelDataTemplate_1.default.getData();
    };
    GameData.setData = function (res, urls) {
        for (var key in GlobalEnum_1.GlobalEnum.GameDataType) {
            var index = this.getUrlsIndex(GlobalEnum_1.GlobalEnum.GameDataType[key], urls);
            if (index >= 0) {
                this.data[GlobalEnum_1.GlobalEnum.GameDataType[key]] = res[index].json;
            }
            else {
                console.warn("数据类型不存在：", GlobalEnum_1.GlobalEnum.GameDataType[key]);
            }
        }
        //数据从数组转换为对象
        for (var key in GlobalEnum_1.GlobalEnum.GameDataType) {
            var type = GlobalEnum_1.GlobalEnum.GameDataType[key];
            if (!!this.data[type] && Array.isArray(this.data[type])) {
                var arr = this.data[type];
                var d = {};
                for (var i = arr.length - 1; i >= 0; --i) {
                    d[arr[i].id] = arr[i];
                }
                this.data[type] = d;
            }
        }
    };
    /**获取数据类型字符串在资源url数组中的索引 */
    GameData.getUrlsIndex = function (name, urls) {
        for (var i = urls.length - 1; i >= 0; --i) {
            if (urls[i].indexOf(name) >= 0) {
                return i;
            }
        }
        return -1;
    };
    /**添加记录数据 */
    GameData.addData = function (type, data) {
        if (!!this.data[type]) {
            console.warn("对应类型的数据已经存在，请检查类型是否重名:", type);
            return;
        }
        this.data[type] = data;
    };
    /**
     * 获取游戏数据
     * @param type  数据类型枚举值
     * @param key   需要的具体数据
     */
    GameData.getData = function (type, key) {
        if (undefined === this.data[type]) {
            console.warn("不存在对应类型的数据：", type);
            return null;
        }
        if (undefined === key) {
            return this.data[type];
        }
        else {
            return this.data[type][key];
        }
    };
    //一些常见的数据的快捷获取方法
    /**关卡数据 */
    GameData.getLevelData = function (lv) {
        var data = this.data[GlobalEnum_1.GlobalEnum.GameDataType.levelData];
        if (!data) {
            cc.log("不存在关卡数据，使用示例数据");
            return LevelDataTemplate_1.default.getData(); //不存在关卡数据时，使用示例关卡数据
        }
        //超出关卡数时随机
        if (!data[lv]) {
            var keys = Object.keys(data);
            var index = Math.round(Math.random() * (keys.length - 1));
            if (parseInt(keys[index]) <= 3) {
                cc.log("关卡" + lv + "不存在数据，使用随机关卡数据：" + keys[keys.length - 1]);
                return data[keys[keys.length - 1]];
            }
            else {
                cc.log("关卡" + lv + "不存在数据，使用随机关卡数据：" + keys[index]);
                return data[keys[index]];
            }
        }
        else {
            return data[lv];
        }
    };
    /**
     * 记录所有游戏数据，
     * key:数据类型枚举值；
     * value:数据
     */
    GameData.data = {};
    return GameData;
}());
exports.default = GameData;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXEdhbWVEYXRhLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0RBQXVEO0FBQ3ZELHNFQUFpRTtBQUVqRSxpQkFBaUI7QUFDakI7SUFBQTtJQWlHQSxDQUFDO0lBMUZpQixhQUFJLEdBQWxCO1FBQ0ksSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7UUFDZix1QkFBdUI7UUFDdkIsS0FBSztRQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQVUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsMkJBQWlCLENBQUMsT0FBTyxFQUFFLENBQUM7SUFFL0UsQ0FBQztJQUVhLGdCQUFPLEdBQXJCLFVBQXNCLEdBQVUsRUFBRSxJQUFjO1FBQzVDLEtBQUssSUFBSSxHQUFHLElBQUksdUJBQVUsQ0FBQyxZQUFZLEVBQUU7WUFDckMsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyx1QkFBVSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNsRSxJQUFJLEtBQUssSUFBSSxDQUFDLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7YUFDN0Q7aUJBQU07Z0JBQ0gsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsdUJBQVUsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzthQUMxRDtTQUNKO1FBQ0QsWUFBWTtRQUNaLEtBQUssSUFBSSxHQUFHLElBQUksdUJBQVUsQ0FBQyxZQUFZLEVBQUU7WUFDckMsSUFBSSxJQUFJLEdBQUcsdUJBQVUsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDeEMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRTtnQkFDckQsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNYLEtBQUssSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3pCO2dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ3ZCO1NBQ0o7SUFDTCxDQUFDO0lBQ0QsMkJBQTJCO0lBQ1oscUJBQVksR0FBM0IsVUFBNEIsSUFBWSxFQUFFLElBQWM7UUFDcEQsS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3ZDLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQzVCLE9BQU8sQ0FBQyxDQUFDO2FBQ1o7U0FDSjtRQUNELE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDZCxDQUFDO0lBRUQsWUFBWTtJQUNFLGdCQUFPLEdBQXJCLFVBQXNCLElBQUksRUFBRSxJQUFTO1FBQ2pDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbkIsT0FBTyxDQUFDLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUM3QyxPQUFPO1NBQ1Y7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztJQUMzQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNXLGdCQUFPLEdBQXJCLFVBQXNCLElBQUksRUFBRSxHQUFTO1FBQ2pDLElBQUksU0FBUyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDL0IsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbEMsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUNELElBQUksU0FBUyxLQUFLLEdBQUcsRUFBRTtZQUNuQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTTtZQUNILE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFRCxnQkFBZ0I7SUFDaEIsVUFBVTtJQUNJLHFCQUFZLEdBQTFCLFVBQTJCLEVBQVU7UUFDakMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBVSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN4RCxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ1AsRUFBRSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3pCLE9BQU8sMkJBQWlCLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQSxtQkFBbUI7U0FDekQ7UUFDRCxVQUFVO1FBQ1YsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUNYLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDN0IsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUQsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM1QixFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxFQUFFLEdBQUcsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0QztpQkFBTTtnQkFDSCxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxFQUFFLEdBQUcsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ3BELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2FBQzVCO1NBQ0o7YUFBTTtZQUNILE9BQU8sSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ25CO0lBQ0wsQ0FBQztJQTlGRDs7OztPQUlHO0lBQ1ksYUFBSSxHQUEyQixFQUFFLENBQUM7SUEyRnJELGVBQUM7Q0FqR0QsQUFpR0MsSUFBQTtrQkFqR29CLFFBQVEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHbG9iYWxFbnVtIH0gZnJvbSBcIi4uL0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcclxuaW1wb3J0IExldmVsRGF0YVRlbXBsYXRlIGZyb20gXCIuLi9HYW1lU3BlY2lhbC9MZXZlbERhdGFUZW1wbGF0ZVwiO1xyXG5cclxuLyoq5ri45oiPSlNPTuaVsOaNrueuoeeQhuWZqCAqL1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHYW1lRGF0YSB7XHJcbiAgICAvKipcclxuICAgICAqIOiusOW9leaJgOaciea4uOaIj+aVsOaNru+8jFxyXG4gICAgICoga2V5OuaVsOaNruexu+Wei+aemuS4vuWAvO+8m1xyXG4gICAgICogdmFsdWU65pWw5o2uXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgc3RhdGljIGRhdGE6IHsgW2tleTogc3RyaW5nXTogYW55IH0gPSB7fTtcclxuICAgIHB1YmxpYyBzdGF0aWMgaW5pdCgpIHtcclxuICAgICAgICB0aGlzLmRhdGEgPSB7fTtcclxuICAgICAgICAvL+S4gOS6m+W4uOingeeahOaVsOaNruexu+Wei++8jOS9v+eUqOm7mOiupOaVsOaNrui/m+ihjOWIneWni+WMllxyXG4gICAgICAgIC8v5YWz5Y2h77yaXHJcbiAgICAgICAgdGhpcy5kYXRhW0dsb2JhbEVudW0uR2FtZURhdGFUeXBlLmxldmVsRGF0YV0gPSBMZXZlbERhdGFUZW1wbGF0ZS5nZXREYXRhKCk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgc2V0RGF0YShyZXM6IGFueVtdLCB1cmxzOiBzdHJpbmdbXSkge1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBHbG9iYWxFbnVtLkdhbWVEYXRhVHlwZSkge1xyXG4gICAgICAgICAgICBsZXQgaW5kZXggPSB0aGlzLmdldFVybHNJbmRleChHbG9iYWxFbnVtLkdhbWVEYXRhVHlwZVtrZXldLCB1cmxzKTtcclxuICAgICAgICAgICAgaWYgKGluZGV4ID49IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZGF0YVtHbG9iYWxFbnVtLkdhbWVEYXRhVHlwZVtrZXldXSA9IHJlc1tpbmRleF0uanNvbjtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihcIuaVsOaNruexu+Wei+S4jeWtmOWcqO+8mlwiLCBHbG9iYWxFbnVtLkdhbWVEYXRhVHlwZVtrZXldKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvL+aVsOaNruS7juaVsOe7hOi9rOaNouS4uuWvueixoVxyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBHbG9iYWxFbnVtLkdhbWVEYXRhVHlwZSkge1xyXG4gICAgICAgICAgICBsZXQgdHlwZSA9IEdsb2JhbEVudW0uR2FtZURhdGFUeXBlW2tleV07XHJcbiAgICAgICAgICAgIGlmICghIXRoaXMuZGF0YVt0eXBlXSAmJiBBcnJheS5pc0FycmF5KHRoaXMuZGF0YVt0eXBlXSkpIHtcclxuICAgICAgICAgICAgICAgIGxldCBhcnIgPSB0aGlzLmRhdGFbdHlwZV07XHJcbiAgICAgICAgICAgICAgICBsZXQgZCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IGFyci5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGRbYXJyW2ldLmlkXSA9IGFycltpXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuZGF0YVt0eXBlXSA9IGQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKirojrflj5bmlbDmja7nsbvlnovlrZfnrKbkuLLlnKjotYTmupB1cmzmlbDnu4TkuK3nmoTntKLlvJUgKi9cclxuICAgIHByaXZhdGUgc3RhdGljIGdldFVybHNJbmRleChuYW1lOiBzdHJpbmcsIHVybHM6IHN0cmluZ1tdKTogbnVtYmVyIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gdXJscy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xyXG4gICAgICAgICAgICBpZiAodXJsc1tpXS5pbmRleE9mKG5hbWUpID49IDApIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiAtMTtcclxuICAgIH1cclxuXHJcbiAgICAvKirmt7vliqDorrDlvZXmlbDmja4gKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgYWRkRGF0YSh0eXBlLCBkYXRhOiBhbnkpIHtcclxuICAgICAgICBpZiAoISF0aGlzLmRhdGFbdHlwZV0pIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKFwi5a+55bqU57G75Z6L55qE5pWw5o2u5bey57uP5a2Y5Zyo77yM6K+35qOA5p+l57G75Z6L5piv5ZCm6YeN5ZCNOlwiLCB0eXBlKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmRhdGFbdHlwZV0gPSBkYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog6I635Y+W5ri45oiP5pWw5o2uXHJcbiAgICAgKiBAcGFyYW0gdHlwZSAg5pWw5o2u57G75Z6L5p6a5Li+5YC8XHJcbiAgICAgKiBAcGFyYW0ga2V5ICAg6ZyA6KaB55qE5YW35L2T5pWw5o2uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0RGF0YSh0eXBlLCBrZXk/OiBhbnkpIHtcclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSB0aGlzLmRhdGFbdHlwZV0pIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKFwi5LiN5a2Y5Zyo5a+55bqU57G75Z6L55qE5pWw5o2u77yaXCIsIHR5cGUpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0ga2V5KSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRhdGFbdHlwZV07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGF0YVt0eXBlXVtrZXldO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvL+S4gOS6m+W4uOingeeahOaVsOaNrueahOW/q+aNt+iOt+WPluaWueazlVxyXG4gICAgLyoq5YWz5Y2h5pWw5o2uICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGdldExldmVsRGF0YShsdjogbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IGRhdGEgPSB0aGlzLmRhdGFbR2xvYmFsRW51bS5HYW1lRGF0YVR5cGUubGV2ZWxEYXRhXTtcclxuICAgICAgICBpZiAoIWRhdGEpIHtcclxuICAgICAgICAgICAgY2MubG9nKFwi5LiN5a2Y5Zyo5YWz5Y2h5pWw5o2u77yM5L2/55So56S65L6L5pWw5o2uXCIpO1xyXG4gICAgICAgICAgICByZXR1cm4gTGV2ZWxEYXRhVGVtcGxhdGUuZ2V0RGF0YSgpOy8v5LiN5a2Y5Zyo5YWz5Y2h5pWw5o2u5pe277yM5L2/55So56S65L6L5YWz5Y2h5pWw5o2uXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8v6LaF5Ye65YWz5Y2h5pWw5pe26ZqP5py6XHJcbiAgICAgICAgaWYgKCFkYXRhW2x2XSkge1xyXG4gICAgICAgICAgICBsZXQga2V5cyA9IE9iamVjdC5rZXlzKGRhdGEpO1xyXG4gICAgICAgICAgICBsZXQgaW5kZXggPSBNYXRoLnJvdW5kKE1hdGgucmFuZG9tKCkgKiAoa2V5cy5sZW5ndGggLSAxKSk7XHJcbiAgICAgICAgICAgIGlmIChwYXJzZUludChrZXlzW2luZGV4XSkgPD0gMykge1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi5YWz5Y2hXCIgKyBsdiArIFwi5LiN5a2Y5Zyo5pWw5o2u77yM5L2/55So6ZqP5py65YWz5Y2h5pWw5o2u77yaXCIgKyBrZXlzW2tleXMubGVuZ3RoIC0gMV0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRhdGFba2V5c1trZXlzLmxlbmd0aCAtIDFdXTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIuWFs+WNoVwiICsgbHYgKyBcIuS4jeWtmOWcqOaVsOaNru+8jOS9v+eUqOmaj+acuuWFs+WNoeaVsOaNru+8mlwiICsga2V5c1tpbmRleF0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRhdGFba2V5c1tpbmRleF1dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIGRhdGFbbHZdO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn0iXX0=