
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/Loader.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '76f22jaHdBP6q6d5du5twvn', 'Loader');
// Script/Common/Loader.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventManager_1 = require("./EventManager");
var GameEventType_1 = require("../GameSpecial/GameEventType");
var Loader = /** @class */ (function () {
    function Loader() {
    }
    //#region 进度条及触摸遮罩
    /**显示进度条：发送事件，通知UI节点显示进度 */
    Loader.showProgressBar = function (rate) {
        if (undefined === rate) {
            rate = 0;
        }
        this.showMask();
        EventManager_1.default.emit(GameEventType_1.EventType.LoadAssetEvent.showProgress, rate);
    };
    /**
     * 根据资源加载进度更新进度条
     * @param completedCount    已加载完成的资源数量
     * @param totalCount        要加载的资源总数量
     * @param item              当前加载完成的资源
     */
    Loader.updateProgress = function (completedCount, totalCount, item) {
        var rate = completedCount / totalCount;
        if (rate > 1)
            rate = 1;
        EventManager_1.default.emit(GameEventType_1.EventType.LoadAssetEvent.updateProgress, rate);
    };
    Loader.hideProgressBar = function (count) {
        if (count === void 0) { count = 1; }
        EventManager_1.default.emit(GameEventType_1.EventType.LoadAssetEvent.hideProgress);
        this.hideMask(count);
    };
    //显示遮罩，只屏蔽触摸事件，不显示进度条，不变暗屏幕
    Loader.showMask = function (count) {
        if (count === void 0) { count = 1; }
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTouchMask, count);
    };
    Loader.hideMask = function (count) {
        if (count === void 0) { count = 1; }
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.hideTouchMask, count);
    };
    /**
     * 加载资源包（与原加载子包接口用法一致）
     * @param name      资源包名称
     * @param cb        回调函数，只需后台预加载资源时，传入null即可
     * @param mask      加载过程中是否需要显示进度条并阻断玩家触摸操作，当需要加载完成后才能进行下一步操作时，请传入true
     * @param insert    插队加载，为true时，会在当前任务加载完后立即加载该资源包，队列中的其他任务延后加载
     */
    Loader.loadBundle = function (name, cb, mask, insert) {
        if (mask === void 0) { mask = false; }
        if (insert === void 0) { insert = false; }
        this.loadSubpackage(name, cb, mask, insert);
    };
    /**
     * 加载子包资源
     * @param name      子包名称
     * @param cb        回调函数，只需后台预加载资源时，传入null即可
     * @param mask      加载过程中是否需要显示进度条并阻断玩家触摸操作，当需要加载完成后才能进行下一步操作时，请传入true
     * @param insert    插队加载，为true时，会在当前任务加载完后立即加载该资源包，队列中的其他任务延后加载
     */
    Loader.loadSubpackage = function (name, cb, mask, insert) {
        if (undefined === mask) {
            mask = false;
        }
        if (undefined === insert) {
            insert = false;
        }
        var record = this.subpackageRecords[name];
        if (!record) {
            record = new SubpackageRecord(name, cb, mask);
            this.subpackageRecords[name] = record;
        }
        switch (record.state) {
            case LoadState.inited: {
                if (mask)
                    this.showSubpackageProgress();
                if (insert && this.subpackageSequence.length > 0) {
                    this.subpackageSequence.splice(1, 0, name);
                    record.enterSequence();
                }
                else {
                    this.subpackageSequence.push(name);
                    if (this.subpackageSequence.length > 1) {
                        record.enterSequence();
                    }
                    else {
                        this._loadSubpackage(name);
                    }
                }
                break;
            }
            case LoadState.waiting: {
                if (mask)
                    this.showSubpackageProgress();
                record.pushCb(cb, mask);
                break;
            }
            case LoadState.turnTo: {
                if (mask)
                    this.showSubpackageProgress();
                record.pushCb(cb, mask);
                this._loadSubpackage(name);
                break;
            }
            case LoadState.loading: {
                if (mask)
                    this.showSubpackageProgress();
                record.pushCb(cb, mask);
                break;
            }
            case LoadState.finished: {
                setTimeout(function () {
                    if (!!cb)
                        cb();
                }, 0);
                break;
            }
        }
    };
    Loader._loadSubpackage = function (name) {
        var _this = this;
        console.log("开始加载子包：", name);
        console.log("子包加载队列：", this.subpackageSequence.toString());
        this.subpackageRecords[name].loadStart();
        cc.assetManager.loadBundle(name, function (err, bundle) {
            if (err) {
                console.error("子包加载出错：", name);
                console.error(err);
                return;
            }
            console.log("子包加载完成：", name);
            var index = _this.subpackageSequence.indexOf(name);
            _this.subpackageSequence.splice(index, 1);
            console.log("等待加载的子包列表：", _this.subpackageSequence.toString());
            _this.hideSubpackageProgress();
            _this.subpackageRecords[name].loadFinish();
            if (_this.subpackageSequence.length > 0) {
                // setTimeout(() => {
                var str = _this.subpackageSequence[0];
                console.log("加载下一个子包：", str);
                var record = _this.subpackageRecords[str];
                if (!!record) {
                    record.turnToLoad();
                }
                _this.loadSubpackage(str, null, !!_this.subpackageRecords[str].maskCount);
                // }, 0);
            }
        });
    };
    /**显示子包加载进度条 */
    Loader.showSubpackageProgress = function () {
        if (null === this.subpackageProgressTimer) {
            this.showProgressBar();
            this.subpackageProgress = 0;
            this.subpackageProgressTimer = setInterval(this.updateSubpackageProgress.bind(this), 100);
        }
    };
    Loader.updateSubpackageProgress = function () {
        this.subpackageProgress += 0.03;
        if (this.subpackageProgress >= 1) {
            this.subpackageProgress = 0;
        }
        EventManager_1.default.emit(GameEventType_1.EventType.LoadAssetEvent.updateProgress, this.subpackageProgress);
    };
    Loader.hideSubpackageProgress = function () {
        if (null !== this.subpackageProgressTimer) {
            var count = 0;
            for (var i = this.subpackageSequence.length - 1; i >= 0; --i) {
                count += this.subpackageRecords[this.subpackageSequence[i]].maskCount;
            }
            if (count == 0) {
                clearInterval(this.subpackageProgressTimer);
                this.subpackageProgressTimer = null;
                this.subpackageProgress = 0;
                this.hideProgressBar();
            }
        }
    };
    //#endregion
    //#region 资源加载
    /**
    * 加载单个资源
    * @param url    资源完整的路径名称，不包含后缀
    * @param cb     资源加载完成后的回调
    * @param mask   加载过程中是否阻挡玩家触摸操作，默认阻挡
    */
    Loader.loadRes = function (url, cb, mask) {
        var _this = this;
        if (!!this.singleAsset[url]) {
            setTimeout(function () {
                cb(_this.singleAsset[url]);
            }, 0);
        }
        else {
            if (undefined === mask) {
                mask = true;
            }
            if (mask) {
                this.showMask();
            }
            cc.loader.loadRes(url, function (err, res) {
                if (mask) {
                    _this.hideMask();
                }
                if (err) {
                    cc.error(err.message || err);
                    cb(null);
                    return;
                }
                _this.singleAsset[url] = res;
                cb(res);
            });
        }
    };
    /**
     * 加载整个文件夹内的资源
     * @param dir   文件夹路径
     * @param cb    加载完成回调
     * @param type  资源类型
     * @param mask  加载过程中是否显示加载进度并阻挡玩家触摸操作，默认为true
     */
    Loader.loadResDir = function (dir, cb, type, mask) {
        var _this = this;
        if (!!this.dirAsset[dir]) {
            setTimeout(function () {
                cb(_this.dirAsset[dir]);
            }, 0);
            return;
        }
        var assetType = null;
        if (undefined === type) {
            mask = true;
        }
        else if (typeof type === "boolean") {
            mask = !!type;
        }
        else {
            assetType = type;
            if (undefined === mask) {
                mask = true;
            }
        }
        if (mask) {
            this.showProgressBar();
        }
        if (!!assetType) {
            cc.loader.loadResDir(dir, assetType, this.updateProgress.bind(this), function (err, arr, urls) {
                if (mask) {
                    _this.hideProgressBar();
                }
                if (err) {
                    cc.log(err);
                    cb(null);
                    return;
                }
                _this.dirAsset[dir] = arr;
                for (var i = arr.length - 1; i >= 0; --i) {
                    _this.singleAsset[urls[i]] = arr[i];
                }
                cb(_this.dirAsset[dir]);
            });
        }
        else {
            cc.loader.loadResDir(dir, this.updateProgress.bind(this), function (err, arr, urls) {
                if (mask) {
                    _this.hideProgressBar();
                }
                if (err) {
                    cc.log(err);
                    cb(null);
                    return;
                }
                _this.dirAsset[dir] = arr;
                for (var i = arr.length - 1; i >= 0; --i) {
                    _this.singleAsset[urls[i]] = arr[i];
                }
                cb(_this.dirAsset[dir]);
            });
        }
    };
    /**加载资源数组 */
    Loader.loadResArray = function (urls, cb, mask) {
        var _this = this;
        var assets = [];
        var arr = [];
        for (var i = urls.length - 1; i >= 0; --i) {
            var res = this.getAsset(urls[i]);
            if (!!res) {
                assets.push(res);
            }
            else {
                arr.push(urls[i]);
            }
        }
        if (arr.length == 0) {
            setTimeout(function () {
                cb(assets);
            }, 0);
            return;
        }
        if (undefined === mask) {
            mask = true;
        }
        if (mask) {
            this.showProgressBar();
        }
        cc.loader.loadResArray(arr, this.updateProgress.bind(this), function (err, res) {
            if (mask) {
                _this.hideProgressBar();
            }
            if (!!err) {
                console.log(err);
                cb(null);
                return;
            }
            if (Array.isArray(res)) {
                for (var i = arr.length - 1; i >= 0; --i) {
                    _this.singleAsset[arr[i]] = res[i];
                    assets.push(res[i]);
                }
            }
            else {
                _this.singleAsset[arr[0]] = res;
                assets.push(res);
            }
            cb(assets);
        });
    };
    /**
     * 获取已加载的资源
     * @param url 资源路径
     */
    Loader.getAsset = function (url) {
        if (!this.singleAsset[url]) {
            console.warn("尚未加载资源：", url);
            return null;
        }
        return this.singleAsset[url];
    };
    /**
     * 从资源包加载单个资源，调用前请确保该资源包已加载完成
     * @param bundle    资源包名
     * @param url       资源相对路径
     * @param cb        加载回调
     * @param mask      加载过程中是否阻挡玩家触摸操作，默认阻挡
     */
    Loader.loadBundleRes = function (bundle, url, cb, type, mask) {
        var _this = this;
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            console.error("资源包 " + bundle + " 尚未加载，无法获取资源:", url);
            cb(null);
            return;
        }
        var assetType = null;
        if (undefined === type) {
            mask = true;
        }
        else if (typeof type === "boolean") {
            mask = !!type;
        }
        else {
            assetType = type;
            if (undefined === mask) {
                mask = true;
            }
        }
        if (mask) {
            this.showMask();
        }
        if (null !== assetType) {
            b.load(url, assetType, function (err, res) {
                if (mask) {
                    _this.hideMask();
                }
                if (err) {
                    cc.error(err.message || err);
                    cb(null);
                    return;
                }
                cb(res);
            });
        }
        else {
            b.load(url, function (err, res) {
                if (mask) {
                    _this.hideMask();
                }
                if (err) {
                    cc.error(err.message || err);
                    cb(null);
                    return;
                }
                cb(res);
            });
        }
    };
    /**
     * 从资源包加载多个资源，调用前请确保该资源包已加载完成
     * @param bundle    资源包名
     * @param urls      资源相对路径
     * @param cb        加载回调
     * @param mask      加载过程中是否显示加载进度条并阻挡玩家操作，默认为true
     */
    Loader.loadBundleArray = function (bundle, urls, cb, mask) {
        var _this = this;
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            console.error("资源包 " + bundle + " 尚未加载，无法获取资源数组:", urls);
            cb(null);
            return;
        }
        if (undefined === mask) {
            mask = true;
        }
        if (mask) {
            this.showProgressBar();
        }
        b.load(urls, this.updateProgress.bind(this), function (err, res) {
            if (mask) {
                _this.hideProgressBar();
            }
            if (err) {
                cc.error(err.message || err);
                cb(null);
                return;
            }
            cb(res);
        });
    };
    /**
     * 从资源包中加载文件夹，调用前请确保该资源包已加载完成
     * @param bundle    资源包名
     * @param dir       文件夹路径
     * @param cb        加载回调
     * @param type      要加载的文件夹中的资源类型
     * @param mask      加载过程中是否显示加载进度条并阻挡玩家操作，默认为true
     */
    Loader.loadBundleDir = function (bundle, dir, cb, type, mask) {
        var _this = this;
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            console.error("资源包 " + bundle + " 尚未加载，无法获取资源文件夹:", dir);
            cb(null);
            return;
        }
        var assetType = null;
        if (undefined === type) {
            mask = true;
        }
        else if (typeof type === "boolean") {
            mask = !!type;
        }
        else {
            assetType = type;
            if (undefined === mask) {
                mask = true;
            }
        }
        if (mask) {
            this.showProgressBar();
        }
        if (!!assetType) {
            b.loadDir(dir, assetType, this.updateProgress.bind(this), function (err, arr) {
                if (mask) {
                    _this.hideProgressBar();
                }
                if (err) {
                    cc.log(err);
                    cb(null);
                    return;
                }
                cb(arr);
            });
        }
        else {
            b.loadDir(dir, this.updateProgress.bind(this), function (err, arr) {
                if (mask) {
                    _this.hideProgressBar();
                }
                if (err) {
                    cc.log(err);
                    cb(null);
                    return;
                }
                cb(arr);
            });
        }
    };
    Loader.loadBundleScene = function (bundle, scene, cb, mask) {
        var _this = this;
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            console.error("资源包 " + bundle + " 尚未加载，无法加载场景:", scene);
            cb(null);
            return;
        }
        if (undefined === mask) {
            mask = true;
        }
        if (mask) {
            this.showProgressBar();
        }
        b.loadScene(scene, this.updateProgress.bind(this), function (err, res) {
            if (mask) {
                _this.hideProgressBar();
            }
            if (!!err) {
                console.error(err);
                return;
            }
            cb(res);
        });
    };
    //#endregion
    //#region 预加载
    /**
     * 预加载资源包中的单个资源，调用完后，你仍然需要通过 `loadBundleRes` 来完成加载。
     * @param bundle    资源包名称
     * @param url       资源路径
     * @param assetType 资源类型
     */
    Loader.preLoadBundleRes = function (bundle, url, assetType) {
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            return;
        }
        if (undefined === assetType) {
            b.preload(url);
        }
        else {
            b.preload(url, assetType);
        }
    };
    /**
     * 预加载资源包中的资源数组，调用完后，你仍然需要通过 `loadBundleRes` 或'loadBundleArray'来完成加载。
     * @param bundle    资源包名称
     * @param urls      资源路径数组
     * @param assetType 资源类型
     */
    Loader.preLoadBundleArray = function (bundle, urls, assetType) {
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            return;
        }
        if (undefined === assetType) {
            b.preload(urls);
        }
        else {
            b.preload(urls, assetType);
        }
    };
    /**
     * 预加载资源包中的文件夹，调用完后，你仍然需要通过 `loadBundleDir` 来完成加载。
     * @param bundle    资源包名称
     * @param dir       资源文件夹名称
     * @param assetType 资源类型
     */
    Loader.preLoadBundleDir = function (bundle, dir, assetType) {
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            return;
        }
        if (undefined === assetType) {
            b.preloadDir(dir);
        }
        else {
            b.preloadDir(dir, assetType);
        }
    };
    /**
     * 预加载资源包中的场景文件，调用完后，你仍然需要通过 `loadBundleScene` 来完成加载。
     * @param bundle    资源包名称
     * @param scene     场景名
     */
    Loader.preLoadBundleScene = function (bundle, scene) {
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            return;
        }
        b.preloadScene(scene);
    };
    /**记录文件夹路径对应的资源数组 */
    Loader.dirAsset = {};
    /**记录所有加载完成的资源，包括通过文件夹加载的资源 */
    Loader.singleAsset = {};
    //#endregion
    //#region 子包、资源包加载
    /**子包加载状态记录 */
    Loader.subpackageRecords = {};
    /**需要加载的子包队伍 */
    Loader.subpackageSequence = [];
    Loader.subpackageProgressTimer = null;
    Loader.subpackageProgress = 0;
    return Loader;
}());
exports.default = Loader;
/**子包加载状态 */
var SubpackageRecord = /** @class */ (function () {
    function SubpackageRecord(name, cb, mask) {
        this.name = name;
        this.state = LoadState.inited;
        this.cbs = [];
        if (!!cb)
            this.pushCb(cb);
        this.maskCount = mask ? 1 : 0;
    }
    SubpackageRecord.prototype.pushCb = function (cb, mask) {
        if (!!cb)
            this.cbs.push(cb);
        if (!!mask)
            this.maskCount++;
    };
    SubpackageRecord.prototype.enterSequence = function () {
        this.state = LoadState.waiting;
    };
    SubpackageRecord.prototype.loadStart = function () {
        this.state = LoadState.loading;
    };
    SubpackageRecord.prototype.loadFinish = function () {
        while (this.cbs.length > 0) {
            var cb = this.cbs.shift();
            if (!!cb)
                cb();
        }
        this.state = LoadState.finished;
        this.maskCount = 0;
    };
    SubpackageRecord.prototype.turnToLoad = function () {
        this.state = LoadState.turnTo;
    };
    return SubpackageRecord;
}());
/**资源加载状态 */
var LoadState;
(function (LoadState) {
    /**已准备好加载 */
    LoadState[LoadState["inited"] = 1] = "inited";
    /**在队列中等待加载 */
    LoadState[LoadState["waiting"] = 2] = "waiting";
    /**正在加载中 */
    LoadState[LoadState["loading"] = 3] = "loading";
    /**已加载完成 */
    LoadState[LoadState["finished"] = 4] = "finished";
    /**在队列中，轮到加载它了 */
    LoadState[LoadState["turnTo"] = 5] = "turnTo";
})(LoadState || (LoadState = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXExvYWRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLCtDQUEwQztBQUMxQyw4REFBeUQ7QUFFekQ7SUFBQTtJQXVqQkEsQ0FBQztJQWpqQkcsa0JBQWtCO0lBQ2xCLDJCQUEyQjtJQUNWLHNCQUFlLEdBQWhDLFVBQWlDLElBQWE7UUFDMUMsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLElBQUksR0FBRyxDQUFDLENBQUM7U0FDWjtRQUNELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUNEOzs7OztPQUtHO0lBQ2MscUJBQWMsR0FBL0IsVUFBZ0MsY0FBc0IsRUFBRSxVQUFrQixFQUFFLElBQVM7UUFDakYsSUFBSSxJQUFJLEdBQUcsY0FBYyxHQUFHLFVBQVUsQ0FBQztRQUN2QyxJQUFJLElBQUksR0FBRyxDQUFDO1lBQUUsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUN2QixzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUNnQixzQkFBZSxHQUFoQyxVQUFpQyxLQUFpQjtRQUFqQixzQkFBQSxFQUFBLFNBQWlCO1FBQzlDLHNCQUFZLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3pELElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUNELDJCQUEyQjtJQUNWLGVBQVEsR0FBekIsVUFBMEIsS0FBaUI7UUFBakIsc0JBQUEsRUFBQSxTQUFpQjtRQUN2QyxzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNnQixlQUFRLEdBQXpCLFVBQTBCLEtBQWlCO1FBQWpCLHNCQUFBLEVBQUEsU0FBaUI7UUFDdkMsc0JBQVksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFRRDs7Ozs7O09BTUc7SUFDVyxpQkFBVSxHQUF4QixVQUF5QixJQUFZLEVBQUUsRUFBWSxFQUFFLElBQVksRUFBRSxNQUF1QjtRQUFyQyxxQkFBQSxFQUFBLFlBQVk7UUFBRSx1QkFBQSxFQUFBLGNBQXVCO1FBQ3RGLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUNEOzs7Ozs7T0FNRztJQUNXLHFCQUFjLEdBQTVCLFVBQTZCLElBQVksRUFBRSxFQUFZLEVBQUUsSUFBYyxFQUFFLE1BQWdCO1FBQ3JGLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtZQUNwQixJQUFJLEdBQUcsS0FBSyxDQUFDO1NBQ2hCO1FBQ0QsSUFBSSxTQUFTLEtBQUssTUFBTSxFQUFFO1lBQ3RCLE1BQU0sR0FBRyxLQUFLLENBQUM7U0FDbEI7UUFDRCxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNULE1BQU0sR0FBRyxJQUFJLGdCQUFnQixDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDOUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQztTQUN6QztRQUNELFFBQVEsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNsQixLQUFLLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDbkIsSUFBSSxJQUFJO29CQUFFLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2dCQUN4QyxJQUFJLE1BQU0sSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDOUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUMzQyxNQUFNLENBQUMsYUFBYSxFQUFFLENBQUM7aUJBQzFCO3FCQUFNO29CQUNILElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ25DLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ3BDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsQ0FBQztxQkFDMUI7eUJBQU07d0JBQ0gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDOUI7aUJBQ0o7Z0JBQ0QsTUFBTTthQUNUO1lBQ0QsS0FBSyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ3BCLElBQUksSUFBSTtvQkFBRSxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztnQkFDeEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hCLE1BQU07YUFDVDtZQUNELEtBQUssU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNuQixJQUFJLElBQUk7b0JBQUUsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7Z0JBQ3hDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4QixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMzQixNQUFNO2FBQ1Q7WUFDRCxLQUFLLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDcEIsSUFBSSxJQUFJO29CQUFFLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2dCQUN4QyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeEIsTUFBTTthQUNUO1lBQ0QsS0FBSyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3JCLFVBQVUsQ0FBQztvQkFDUCxJQUFJLENBQUMsQ0FBQyxFQUFFO3dCQUFFLEVBQUUsRUFBRSxDQUFDO2dCQUNuQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ04sTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBQ2dCLHNCQUFlLEdBQWhDLFVBQWlDLElBQUk7UUFBckMsaUJBNEJDO1FBM0JHLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN6QyxFQUFFLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsVUFBQyxHQUFHLEVBQUUsTUFBTTtZQUN6QyxJQUFJLEdBQUcsRUFBRTtnQkFDTCxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDL0IsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDbkIsT0FBTzthQUNWO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDN0IsSUFBSSxLQUFLLEdBQUcsS0FBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsRCxLQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztZQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztZQUM5RCxLQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUM5QixLQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDMUMsSUFBSSxLQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDcEMscUJBQXFCO2dCQUNyQixJQUFJLEdBQUcsR0FBRyxLQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUM3QixJQUFJLE1BQU0sR0FBRyxLQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRTtvQkFDVixNQUFNLENBQUMsVUFBVSxFQUFFLENBQUM7aUJBQ3ZCO2dCQUNELEtBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUN4RSxTQUFTO2FBQ1o7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxlQUFlO0lBQ0UsNkJBQXNCLEdBQXZDO1FBQ0ksSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQ3ZDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDO1lBQzVCLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUM3RjtJQUNMLENBQUM7SUFFZ0IsK0JBQXdCLEdBQXpDO1FBQ0ksSUFBSSxDQUFDLGtCQUFrQixJQUFJLElBQUksQ0FBQztRQUNoQyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLEVBQUU7WUFDOUIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLENBQUMsQ0FBQztTQUMvQjtRQUNELHNCQUFZLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUN4RixDQUFDO0lBQ2dCLDZCQUFzQixHQUF2QztRQUNJLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtZQUN2QyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7WUFDZCxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQzFELEtBQUssSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO2FBQ3pFO1lBQ0QsSUFBSSxLQUFLLElBQUksQ0FBQyxFQUFFO2dCQUNaLGFBQWEsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQztnQkFDNUMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQztnQkFDcEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLENBQUMsQ0FBQztnQkFDNUIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2FBQzFCO1NBQ0o7SUFDTCxDQUFDO0lBQ0QsWUFBWTtJQUVaLGNBQWM7SUFDZDs7Ozs7TUFLRTtJQUNZLGNBQU8sR0FBckIsVUFBc0IsR0FBVyxFQUFFLEVBQXdCLEVBQUUsSUFBYztRQUEzRSxpQkF5QkM7UUF4QkcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN6QixVQUFVLENBQUM7Z0JBQ1AsRUFBRSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUM5QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDVDthQUFNO1lBQ0gsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUNwQixJQUFJLEdBQUcsSUFBSSxDQUFDO2FBQ2Y7WUFDRCxJQUFJLElBQUksRUFBRTtnQkFDTixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDbkI7WUFDRCxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsVUFBQyxHQUFHLEVBQUUsR0FBRztnQkFDNUIsSUFBSSxJQUFJLEVBQUU7b0JBQ04sS0FBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2lCQUNuQjtnQkFDRCxJQUFJLEdBQUcsRUFBRTtvQkFDTCxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLElBQUksR0FBRyxDQUFDLENBQUM7b0JBQzdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDVCxPQUFPO2lCQUNWO2dCQUNELEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO2dCQUM1QixFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUNEOzs7Ozs7T0FNRztJQUNXLGlCQUFVLEdBQXhCLFVBQXlCLEdBQVcsRUFBRSxFQUEyQixFQUFFLElBQWdDLEVBQUUsSUFBYztRQUFuSCxpQkEwREM7UUF6REcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN0QixVQUFVLENBQUM7Z0JBQ1AsRUFBRSxDQUFDLEtBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMzQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDTixPQUFPO1NBQ1Y7UUFDRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDckIsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLElBQUksR0FBRyxJQUFJLENBQUM7U0FDZjthQUFNLElBQUksT0FBTyxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQ2xDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1NBQ2pCO2FBQU07WUFDSCxTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQ2pCLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtnQkFDcEIsSUFBSSxHQUFHLElBQUksQ0FBQzthQUNmO1NBQ0o7UUFDRCxJQUFJLElBQUksRUFBRTtZQUNOLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztTQUMxQjtRQUNELElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRTtZQUNiLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQy9ELFVBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJO2dCQUNYLElBQUksSUFBSSxFQUFFO29CQUNOLEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztpQkFDMUI7Z0JBQ0QsSUFBSSxHQUFHLEVBQUU7b0JBQ0wsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDWixFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ1QsT0FBTztpQkFDVjtnQkFDRCxLQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztnQkFDekIsS0FBSyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN0QyxLQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDdEM7Z0JBQ0QsRUFBRSxDQUFDLEtBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMzQixDQUFDLENBQ0osQ0FBQztTQUNMO2FBQU07WUFDSCxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQ3BELFVBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJO2dCQUNYLElBQUksSUFBSSxFQUFFO29CQUNOLEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztpQkFDMUI7Z0JBQ0QsSUFBSSxHQUFHLEVBQUU7b0JBQ0wsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDWixFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ1QsT0FBTztpQkFDVjtnQkFDRCxLQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztnQkFDekIsS0FBSyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN0QyxLQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDdEM7Z0JBQ0QsRUFBRSxDQUFDLEtBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMzQixDQUFDLENBQ0osQ0FBQztTQUNMO0lBQ0wsQ0FBQztJQUNELFlBQVk7SUFDRSxtQkFBWSxHQUExQixVQUEyQixJQUFjLEVBQUUsRUFBMkIsRUFBRSxJQUFjO1FBQXRGLGlCQTZDQztRQTVDRyxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDaEIsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBQ2IsS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3ZDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO2dCQUNQLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDcEI7aUJBQU07Z0JBQ0gsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNyQjtTQUNKO1FBQ0QsSUFBSSxHQUFHLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtZQUNqQixVQUFVLENBQUM7Z0JBQ1AsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ04sT0FBTztTQUNWO1FBQ0QsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLElBQUksR0FBRyxJQUFJLENBQUM7U0FDZjtRQUNELElBQUksSUFBSSxFQUFFO1lBQ04sSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1NBQzFCO1FBQ0QsRUFBRSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUN0RCxVQUFDLEdBQUcsRUFBRSxHQUFHO1lBQ0wsSUFBSSxJQUFJLEVBQUU7Z0JBQ04sS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2FBQzFCO1lBQ0QsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO2dCQUNQLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ2pCLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDVCxPQUFPO2FBQ1Y7WUFDRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3BCLEtBQUssSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdEMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2xDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3ZCO2FBQ0o7aUJBQU07Z0JBQ0gsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7Z0JBQy9CLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDcEI7WUFDRCxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDZixDQUFDLENBQ0osQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDVyxlQUFRLEdBQXRCLFVBQXVCLEdBQVc7UUFDOUIsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDeEIsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDN0IsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUNELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ1csb0JBQWEsR0FBM0IsVUFBNEIsTUFBYyxFQUFFLEdBQVcsRUFBRSxFQUF3QixFQUFFLElBQWdDLEVBQUUsSUFBYztRQUFuSSxpQkE4Q0M7UUE3Q0csSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUNKLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxlQUFlLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDdEQsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ1QsT0FBTztTQUNWO1FBQ0QsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtZQUNwQixJQUFJLEdBQUcsSUFBSSxDQUFDO1NBQ2Y7YUFBTSxJQUFJLE9BQU8sSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUNsQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztTQUNqQjthQUFNO1lBQ0gsU0FBUyxHQUFHLElBQUksQ0FBQztZQUNqQixJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7Z0JBQ3BCLElBQUksR0FBRyxJQUFJLENBQUM7YUFDZjtTQUNKO1FBQ0QsSUFBSSxJQUFJLEVBQUU7WUFDTixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDbkI7UUFDRCxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLFVBQUMsR0FBRyxFQUFFLEdBQUc7Z0JBQzVCLElBQUksSUFBSSxFQUFFO29CQUNOLEtBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztpQkFDbkI7Z0JBQ0QsSUFBSSxHQUFHLEVBQUU7b0JBQ0wsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxDQUFDO29CQUM3QixFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ1QsT0FBTztpQkFDVjtnQkFDRCxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztTQUNOO2FBQU07WUFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLEdBQUcsRUFBRSxHQUFHO2dCQUNqQixJQUFJLElBQUksRUFBRTtvQkFDTixLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7aUJBQ25CO2dCQUNELElBQUksR0FBRyxFQUFFO29CQUNMLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQztvQkFDN0IsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNULE9BQU87aUJBQ1Y7Z0JBQ0QsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ1osQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFDRDs7Ozs7O09BTUc7SUFDVyxzQkFBZSxHQUE3QixVQUE4QixNQUFjLEVBQUUsSUFBYyxFQUFFLEVBQXlCLEVBQUUsSUFBYztRQUF2RyxpQkF3QkM7UUF2QkcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUNKLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN6RCxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDVCxPQUFPO1NBQ1Y7UUFDRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDcEIsSUFBSSxHQUFHLElBQUksQ0FBQztTQUNmO1FBQ0QsSUFBSSxJQUFJLEVBQUU7WUFDTixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7U0FDMUI7UUFDRCxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxVQUFDLEdBQUcsRUFBRSxHQUFHO1lBQ2xELElBQUksSUFBSSxFQUFFO2dCQUNOLEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzthQUMxQjtZQUNELElBQUksR0FBRyxFQUFFO2dCQUNMLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQztnQkFDN0IsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNULE9BQU87YUFDVjtZQUNELEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNaLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNEOzs7Ozs7O09BT0c7SUFDVyxvQkFBYSxHQUEzQixVQUE0QixNQUFjLEVBQUUsR0FBVyxFQUFFLEVBQTJCLEVBQUUsSUFBZ0MsRUFBRSxJQUFjO1FBQXRJLGlCQStDQztRQTlDRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxQyxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQ0osT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxHQUFHLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ3pELEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNULE9BQU87U0FDVjtRQUNELElBQUksU0FBUyxHQUFHLElBQUksQ0FBQztRQUNyQixJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDcEIsSUFBSSxHQUFHLElBQUksQ0FBQztTQUNmO2FBQU0sSUFBSSxPQUFPLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDbEMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7U0FDakI7YUFBTTtZQUNILFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDakIsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUNwQixJQUFJLEdBQUcsSUFBSSxDQUFDO2FBQ2Y7U0FDSjtRQUNELElBQUksSUFBSSxFQUFFO1lBQ04sSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1NBQzFCO1FBQ0QsSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFO1lBQ2IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLFVBQUMsR0FBRyxFQUFFLEdBQUc7Z0JBQy9ELElBQUksSUFBSSxFQUFFO29CQUNOLEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztpQkFDMUI7Z0JBQ0QsSUFBSSxHQUFHLEVBQUU7b0JBQ0wsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDWixFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ1QsT0FBTztpQkFDVjtnQkFDRCxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztTQUNOO2FBQU07WUFDSCxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxVQUFDLEdBQUcsRUFBRSxHQUFHO2dCQUNwRCxJQUFJLElBQUksRUFBRTtvQkFDTixLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7aUJBQzFCO2dCQUNELElBQUksR0FBRyxFQUFFO29CQUNMLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ1osRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNULE9BQU87aUJBQ1Y7Z0JBQ0QsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ1osQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUVMLENBQUM7SUFDYSxzQkFBZSxHQUE3QixVQUE4QixNQUFjLEVBQUUsS0FBYSxFQUFFLEVBQWlCLEVBQUUsSUFBSztRQUFyRixpQkF1QkM7UUF0QkcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUNKLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDeEQsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ1QsT0FBTztTQUNWO1FBQ0QsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLElBQUksR0FBRyxJQUFJLENBQUM7U0FDZjtRQUNELElBQUksSUFBSSxFQUFFO1lBQ04sSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1NBQzFCO1FBQ0QsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsVUFBQyxHQUFHLEVBQUUsR0FBRztZQUN4RCxJQUFJLElBQUksRUFBRTtnQkFDTixLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7YUFDMUI7WUFDRCxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7Z0JBQ1AsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDbkIsT0FBTzthQUNWO1lBQ0QsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ1osQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0QsWUFBWTtJQUVaLGFBQWE7SUFDYjs7Ozs7T0FLRztJQUNXLHVCQUFnQixHQUE5QixVQUErQixNQUFjLEVBQUUsR0FBVyxFQUFFLFNBQVU7UUFDbEUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUNKLE9BQU87U0FDVjtRQUNELElBQUksU0FBUyxLQUFLLFNBQVMsRUFBRTtZQUN6QixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2xCO2FBQU07WUFDSCxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFDRDs7Ozs7T0FLRztJQUNXLHlCQUFrQixHQUFoQyxVQUFpQyxNQUFjLEVBQUUsSUFBYyxFQUFFLFNBQVU7UUFDdkUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUNKLE9BQU87U0FDVjtRQUNELElBQUksU0FBUyxLQUFLLFNBQVMsRUFBRTtZQUN6QixDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ25CO2FBQU07WUFDSCxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztTQUM5QjtJQUNMLENBQUM7SUFDRDs7Ozs7T0FLRztJQUNXLHVCQUFnQixHQUE5QixVQUErQixNQUFjLEVBQUUsR0FBVyxFQUFFLFNBQVU7UUFDbEUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUNKLE9BQU87U0FDVjtRQUNELElBQUksU0FBUyxLQUFLLFNBQVMsRUFBRTtZQUN6QixDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3JCO2FBQU07WUFDSCxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUNoQztJQUNMLENBQUM7SUFDRDs7OztPQUlHO0lBQ1cseUJBQWtCLEdBQWhDLFVBQWlDLE1BQWMsRUFBRSxLQUFhO1FBQzFELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxDQUFDLEVBQUU7WUFDSixPQUFPO1NBQ1Y7UUFDRCxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFwakJELG9CQUFvQjtJQUNILGVBQVEsR0FBa0MsRUFBRSxDQUFDO0lBQzlELDhCQUE4QjtJQUNiLGtCQUFXLEdBQWdDLEVBQUUsQ0FBQztJQWlDL0QsWUFBWTtJQUVaLGtCQUFrQjtJQUNsQixjQUFjO0lBQ0csd0JBQWlCLEdBQXlDLEVBQUUsQ0FBQztJQUM5RSxlQUFlO0lBQ0UseUJBQWtCLEdBQWEsRUFBRSxDQUFDO0lBbUdsQyw4QkFBdUIsR0FBVyxJQUFJLENBQUM7SUFTdkMseUJBQWtCLEdBQVcsQ0FBQyxDQUFDO0lBZ2FwRCxhQUFDO0NBdmpCRCxBQXVqQkMsSUFBQTtrQkF2akJvQixNQUFNO0FBeWpCM0IsWUFBWTtBQUNaO0lBU0ksMEJBQW1CLElBQVksRUFBRSxFQUFZLEVBQUUsSUFBYTtRQUN4RCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUM7UUFDOUIsSUFBSSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDZCxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVNLGlDQUFNLEdBQWIsVUFBYyxFQUFZLEVBQUUsSUFBYztRQUN0QyxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLENBQUMsSUFBSTtZQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBQ00sd0NBQWEsR0FBcEI7UUFDSSxJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUM7SUFDbkMsQ0FBQztJQUNNLG9DQUFTLEdBQWhCO1FBQ0ksSUFBSSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDO0lBQ25DLENBQUM7SUFDTSxxQ0FBVSxHQUFqQjtRQUNJLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3hCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDMUIsSUFBSSxDQUFDLENBQUMsRUFBRTtnQkFBRSxFQUFFLEVBQUUsQ0FBQztTQUNsQjtRQUNELElBQUksQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUNoQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztJQUN2QixDQUFDO0lBQ00scUNBQVUsR0FBakI7UUFDSSxJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUM7SUFDbEMsQ0FBQztJQUNMLHVCQUFDO0FBQUQsQ0F0Q0EsQUFzQ0MsSUFBQTtBQUNELFlBQVk7QUFDWixJQUFLLFNBV0o7QUFYRCxXQUFLLFNBQVM7SUFDVixZQUFZO0lBQ1osNkNBQVUsQ0FBQTtJQUNWLGNBQWM7SUFDZCwrQ0FBTyxDQUFBO0lBQ1AsV0FBVztJQUNYLCtDQUFPLENBQUE7SUFDUCxXQUFXO0lBQ1gsaURBQVEsQ0FBQTtJQUNSLGlCQUFpQjtJQUNqQiw2Q0FBTSxDQUFBO0FBQ1YsQ0FBQyxFQVhJLFNBQVMsS0FBVCxTQUFTLFFBV2IiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgRXZlbnRNYW5hZ2VyIGZyb20gXCIuL0V2ZW50TWFuYWdlclwiO1xyXG5pbXBvcnQgeyBFdmVudFR5cGUgfSBmcm9tIFwiLi4vR2FtZVNwZWNpYWwvR2FtZUV2ZW50VHlwZVwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTG9hZGVyIHtcclxuICAgIC8qKuiusOW9leaWh+S7tuWkuei3r+W+hOWvueW6lOeahOi1hOa6kOaVsOe7hCAqL1xyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBkaXJBc3NldDogeyBba2V5OiBzdHJpbmddOiBjYy5Bc3NldFtdIH0gPSB7fTtcclxuICAgIC8qKuiusOW9leaJgOacieWKoOi9veWujOaIkOeahOi1hOa6kO+8jOWMheaLrOmAmui/h+aWh+S7tuWkueWKoOi9veeahOi1hOa6kCAqL1xyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBzaW5nbGVBc3NldDogeyBba2V5OiBzdHJpbmddOiBjYy5Bc3NldCB9ID0ge307XHJcblxyXG4gICAgLy8jcmVnaW9uIOi/m+W6puadoeWPiuinpuaRuOmBrue9qVxyXG4gICAgLyoq5pi+56S66L+b5bqm5p2h77ya5Y+R6YCB5LqL5Lu277yM6YCa55+lVUnoioLngrnmmL7npLrov5vluqYgKi9cclxuICAgIHByb3RlY3RlZCBzdGF0aWMgc2hvd1Byb2dyZXNzQmFyKHJhdGU/OiBudW1iZXIpIHtcclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSByYXRlKSB7XHJcbiAgICAgICAgICAgIHJhdGUgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnNob3dNYXNrKCk7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLkxvYWRBc3NldEV2ZW50LnNob3dQcm9ncmVzcywgcmF0ZSk7XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOagueaNrui1hOa6kOWKoOi9vei/m+W6puabtOaWsOi/m+W6puadoVxyXG4gICAgICogQHBhcmFtIGNvbXBsZXRlZENvdW50ICAgIOW3suWKoOi9veWujOaIkOeahOi1hOa6kOaVsOmHj1xyXG4gICAgICogQHBhcmFtIHRvdGFsQ291bnQgICAgICAgIOimgeWKoOi9veeahOi1hOa6kOaAu+aVsOmHj1xyXG4gICAgICogQHBhcmFtIGl0ZW0gICAgICAgICAgICAgIOW9k+WJjeWKoOi9veWujOaIkOeahOi1hOa6kFxyXG4gICAgICovXHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIHVwZGF0ZVByb2dyZXNzKGNvbXBsZXRlZENvdW50OiBudW1iZXIsIHRvdGFsQ291bnQ6IG51bWJlciwgaXRlbTogYW55KSB7XHJcbiAgICAgICAgbGV0IHJhdGUgPSBjb21wbGV0ZWRDb3VudCAvIHRvdGFsQ291bnQ7XHJcbiAgICAgICAgaWYgKHJhdGUgPiAxKSByYXRlID0gMTtcclxuICAgICAgICBFdmVudE1hbmFnZXIuZW1pdChFdmVudFR5cGUuTG9hZEFzc2V0RXZlbnQudXBkYXRlUHJvZ3Jlc3MsIHJhdGUpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBoaWRlUHJvZ3Jlc3NCYXIoY291bnQ6IG51bWJlciA9IDEpIHtcclxuICAgICAgICBFdmVudE1hbmFnZXIuZW1pdChFdmVudFR5cGUuTG9hZEFzc2V0RXZlbnQuaGlkZVByb2dyZXNzKTtcclxuICAgICAgICB0aGlzLmhpZGVNYXNrKGNvdW50KTtcclxuICAgIH1cclxuICAgIC8v5pi+56S66YGu572p77yM5Y+q5bGP6JS96Kem5pG45LqL5Lu277yM5LiN5pi+56S66L+b5bqm5p2h77yM5LiN5Y+Y5pqX5bGP5bmVXHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIHNob3dNYXNrKGNvdW50OiBudW1iZXIgPSAxKSB7XHJcbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuc2hvd1RvdWNoTWFzaywgY291bnQpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBoaWRlTWFzayhjb3VudDogbnVtYmVyID0gMSkge1xyXG4gICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmhpZGVUb3VjaE1hc2ssIGNvdW50KTtcclxuICAgIH1cclxuICAgIC8vI2VuZHJlZ2lvblxyXG5cclxuICAgIC8vI3JlZ2lvbiDlrZDljIXjgIHotYTmupDljIXliqDovb1cclxuICAgIC8qKuWtkOWMheWKoOi9veeKtuaAgeiusOW9lSAqL1xyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBzdWJwYWNrYWdlUmVjb3JkczogeyBbbmFtZTogc3RyaW5nXTogU3VicGFja2FnZVJlY29yZCB9ID0ge307XHJcbiAgICAvKirpnIDopoHliqDovb3nmoTlrZDljIXpmJ/kvI0gKi9cclxuICAgIHByb3RlY3RlZCBzdGF0aWMgc3VicGFja2FnZVNlcXVlbmNlOiBzdHJpbmdbXSA9IFtdO1xyXG4gICAgLyoqXHJcbiAgICAgKiDliqDovb3otYTmupDljIXvvIjkuI7ljp/liqDovb3lrZDljIXmjqXlj6PnlKjms5XkuIDoh7TvvIlcclxuICAgICAqIEBwYXJhbSBuYW1lICAgICAg6LWE5rqQ5YyF5ZCN56ewXHJcbiAgICAgKiBAcGFyYW0gY2IgICAgICAgIOWbnuiwg+WHveaVsO+8jOWPqumcgOWQjuWPsOmihOWKoOi9vei1hOa6kOaXtu+8jOS8oOWFpW51bGzljbPlj69cclxuICAgICAqIEBwYXJhbSBtYXNrICAgICAg5Yqg6L296L+H56iL5Lit5piv5ZCm6ZyA6KaB5pi+56S66L+b5bqm5p2h5bm26Zi75pat546p5a626Kem5pG45pON5L2c77yM5b2T6ZyA6KaB5Yqg6L295a6M5oiQ5ZCO5omN6IO96L+b6KGM5LiL5LiA5q2l5pON5L2c5pe277yM6K+35Lyg5YWldHJ1ZVxyXG4gICAgICogQHBhcmFtIGluc2VydCAgICDmj5LpmJ/liqDovb3vvIzkuLp0cnVl5pe277yM5Lya5Zyo5b2T5YmN5Lu75Yqh5Yqg6L295a6M5ZCO56uL5Y2z5Yqg6L296K+l6LWE5rqQ5YyF77yM6Zif5YiX5Lit55qE5YW25LuW5Lu75Yqh5bu25ZCO5Yqg6L29XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgbG9hZEJ1bmRsZShuYW1lOiBzdHJpbmcsIGNiOiBGdW5jdGlvbiwgbWFzayA9IGZhbHNlLCBpbnNlcnQ6IGJvb2xlYW4gPSBmYWxzZSkge1xyXG4gICAgICAgIHRoaXMubG9hZFN1YnBhY2thZ2UobmFtZSwgY2IsIG1hc2ssIGluc2VydCk7XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOWKoOi9veWtkOWMhei1hOa6kFxyXG4gICAgICogQHBhcmFtIG5hbWUgICAgICDlrZDljIXlkI3np7BcclxuICAgICAqIEBwYXJhbSBjYiAgICAgICAg5Zue6LCD5Ye95pWw77yM5Y+q6ZyA5ZCO5Y+w6aKE5Yqg6L296LWE5rqQ5pe277yM5Lyg5YWlbnVsbOWNs+WPr1xyXG4gICAgICogQHBhcmFtIG1hc2sgICAgICDliqDovb3ov4fnqIvkuK3mmK/lkKbpnIDopoHmmL7npLrov5vluqbmnaHlubbpmLvmlq3njqnlrrbop6bmkbjmk43kvZzvvIzlvZPpnIDopoHliqDovb3lrozmiJDlkI7miY3og73ov5vooYzkuIvkuIDmraXmk43kvZzml7bvvIzor7fkvKDlhaV0cnVlXHJcbiAgICAgKiBAcGFyYW0gaW5zZXJ0ICAgIOaPkumYn+WKoOi9ve+8jOS4unRydWXml7bvvIzkvJrlnKjlvZPliY3ku7vliqHliqDovb3lrozlkI7nq4vljbPliqDovb3or6XotYTmupDljIXvvIzpmJ/liJfkuK3nmoTlhbbku5bku7vliqHlu7blkI7liqDovb1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBsb2FkU3VicGFja2FnZShuYW1lOiBzdHJpbmcsIGNiOiBGdW5jdGlvbiwgbWFzaz86IGJvb2xlYW4sIGluc2VydD86IGJvb2xlYW4pIHtcclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBtYXNrKSB7XHJcbiAgICAgICAgICAgIG1hc2sgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gaW5zZXJ0KSB7XHJcbiAgICAgICAgICAgIGluc2VydCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgcmVjb3JkID0gdGhpcy5zdWJwYWNrYWdlUmVjb3Jkc1tuYW1lXTtcclxuICAgICAgICBpZiAoIXJlY29yZCkge1xyXG4gICAgICAgICAgICByZWNvcmQgPSBuZXcgU3VicGFja2FnZVJlY29yZChuYW1lLCBjYiwgbWFzayk7XHJcbiAgICAgICAgICAgIHRoaXMuc3VicGFja2FnZVJlY29yZHNbbmFtZV0gPSByZWNvcmQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN3aXRjaCAocmVjb3JkLnN0YXRlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgTG9hZFN0YXRlLmluaXRlZDoge1xyXG4gICAgICAgICAgICAgICAgaWYgKG1hc2spIHRoaXMuc2hvd1N1YnBhY2thZ2VQcm9ncmVzcygpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGluc2VydCAmJiB0aGlzLnN1YnBhY2thZ2VTZXF1ZW5jZS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdWJwYWNrYWdlU2VxdWVuY2Uuc3BsaWNlKDEsIDAsIG5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJlY29yZC5lbnRlclNlcXVlbmNlKCk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3VicGFja2FnZVNlcXVlbmNlLnB1c2gobmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuc3VicGFja2FnZVNlcXVlbmNlLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVjb3JkLmVudGVyU2VxdWVuY2UoKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sb2FkU3VicGFja2FnZShuYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYXNlIExvYWRTdGF0ZS53YWl0aW5nOiB7XHJcbiAgICAgICAgICAgICAgICBpZiAobWFzaykgdGhpcy5zaG93U3VicGFja2FnZVByb2dyZXNzKCk7XHJcbiAgICAgICAgICAgICAgICByZWNvcmQucHVzaENiKGNiLCBtYXNrKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhc2UgTG9hZFN0YXRlLnR1cm5Ubzoge1xyXG4gICAgICAgICAgICAgICAgaWYgKG1hc2spIHRoaXMuc2hvd1N1YnBhY2thZ2VQcm9ncmVzcygpO1xyXG4gICAgICAgICAgICAgICAgcmVjb3JkLnB1c2hDYihjYiwgbWFzayk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sb2FkU3VicGFja2FnZShuYW1lKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhc2UgTG9hZFN0YXRlLmxvYWRpbmc6IHtcclxuICAgICAgICAgICAgICAgIGlmIChtYXNrKSB0aGlzLnNob3dTdWJwYWNrYWdlUHJvZ3Jlc3MoKTtcclxuICAgICAgICAgICAgICAgIHJlY29yZC5wdXNoQ2IoY2IsIG1hc2spO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2FzZSBMb2FkU3RhdGUuZmluaXNoZWQ6IHtcclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghIWNiKSBjYigpO1xyXG4gICAgICAgICAgICAgICAgfSwgMCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBzdGF0aWMgX2xvYWRTdWJwYWNrYWdlKG5hbWUpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuW8gOWni+WKoOi9veWtkOWMhe+8mlwiLCBuYW1lKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuWtkOWMheWKoOi9vemYn+WIl++8mlwiLCB0aGlzLnN1YnBhY2thZ2VTZXF1ZW5jZS50b1N0cmluZygpKTtcclxuICAgICAgICB0aGlzLnN1YnBhY2thZ2VSZWNvcmRzW25hbWVdLmxvYWRTdGFydCgpO1xyXG4gICAgICAgIGNjLmFzc2V0TWFuYWdlci5sb2FkQnVuZGxlKG5hbWUsIChlcnIsIGJ1bmRsZSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwi5a2Q5YyF5Yqg6L295Ye66ZSZ77yaXCIsIG5hbWUpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5a2Q5YyF5Yqg6L295a6M5oiQ77yaXCIsIG5hbWUpO1xyXG4gICAgICAgICAgICBsZXQgaW5kZXggPSB0aGlzLnN1YnBhY2thZ2VTZXF1ZW5jZS5pbmRleE9mKG5hbWUpO1xyXG4gICAgICAgICAgICB0aGlzLnN1YnBhY2thZ2VTZXF1ZW5jZS5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuetieW+heWKoOi9veeahOWtkOWMheWIl+ihqO+8mlwiLCB0aGlzLnN1YnBhY2thZ2VTZXF1ZW5jZS50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgdGhpcy5oaWRlU3VicGFja2FnZVByb2dyZXNzKCk7XHJcbiAgICAgICAgICAgIHRoaXMuc3VicGFja2FnZVJlY29yZHNbbmFtZV0ubG9hZEZpbmlzaCgpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5zdWJwYWNrYWdlU2VxdWVuY2UubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgLy8gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc3RyID0gdGhpcy5zdWJwYWNrYWdlU2VxdWVuY2VbMF07XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuWKoOi9veS4i+S4gOS4quWtkOWMhe+8mlwiLCBzdHIpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHJlY29yZCA9IHRoaXMuc3VicGFja2FnZVJlY29yZHNbc3RyXTtcclxuICAgICAgICAgICAgICAgIGlmICghIXJlY29yZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlY29yZC50dXJuVG9Mb2FkKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRTdWJwYWNrYWdlKHN0ciwgbnVsbCwgISF0aGlzLnN1YnBhY2thZ2VSZWNvcmRzW3N0cl0ubWFza0NvdW50KTtcclxuICAgICAgICAgICAgICAgIC8vIH0sIDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIHN1YnBhY2thZ2VQcm9ncmVzc1RpbWVyOiBudW1iZXIgPSBudWxsO1xyXG4gICAgLyoq5pi+56S65a2Q5YyF5Yqg6L296L+b5bqm5p2hICovXHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIHNob3dTdWJwYWNrYWdlUHJvZ3Jlc3MoKSB7XHJcbiAgICAgICAgaWYgKG51bGwgPT09IHRoaXMuc3VicGFja2FnZVByb2dyZXNzVGltZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93UHJvZ3Jlc3NCYXIoKTtcclxuICAgICAgICAgICAgdGhpcy5zdWJwYWNrYWdlUHJvZ3Jlc3MgPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnN1YnBhY2thZ2VQcm9ncmVzc1RpbWVyID0gc2V0SW50ZXJ2YWwodGhpcy51cGRhdGVTdWJwYWNrYWdlUHJvZ3Jlc3MuYmluZCh0aGlzKSwgMTAwKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIHN1YnBhY2thZ2VQcm9ncmVzczogbnVtYmVyID0gMDtcclxuICAgIHByb3RlY3RlZCBzdGF0aWMgdXBkYXRlU3VicGFja2FnZVByb2dyZXNzKCkge1xyXG4gICAgICAgIHRoaXMuc3VicGFja2FnZVByb2dyZXNzICs9IDAuMDM7XHJcbiAgICAgICAgaWYgKHRoaXMuc3VicGFja2FnZVByb2dyZXNzID49IDEpIHtcclxuICAgICAgICAgICAgdGhpcy5zdWJwYWNrYWdlUHJvZ3Jlc3MgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBFdmVudE1hbmFnZXIuZW1pdChFdmVudFR5cGUuTG9hZEFzc2V0RXZlbnQudXBkYXRlUHJvZ3Jlc3MsIHRoaXMuc3VicGFja2FnZVByb2dyZXNzKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBzdGF0aWMgaGlkZVN1YnBhY2thZ2VQcm9ncmVzcygpIHtcclxuICAgICAgICBpZiAobnVsbCAhPT0gdGhpcy5zdWJwYWNrYWdlUHJvZ3Jlc3NUaW1lcikge1xyXG4gICAgICAgICAgICBsZXQgY291bnQgPSAwO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5zdWJwYWNrYWdlU2VxdWVuY2UubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgICAgIGNvdW50ICs9IHRoaXMuc3VicGFja2FnZVJlY29yZHNbdGhpcy5zdWJwYWNrYWdlU2VxdWVuY2VbaV1dLm1hc2tDb3VudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoY291bnQgPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLnN1YnBhY2thZ2VQcm9ncmVzc1RpbWVyKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3VicGFja2FnZVByb2dyZXNzVGltZXIgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zdWJwYWNrYWdlUHJvZ3Jlc3MgPSAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5oaWRlUHJvZ3Jlc3NCYXIoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8vI2VuZHJlZ2lvblxyXG5cclxuICAgIC8vI3JlZ2lvbiDotYTmupDliqDovb1cclxuICAgIC8qKlxyXG4gICAgKiDliqDovb3ljZXkuKrotYTmupBcclxuICAgICogQHBhcmFtIHVybCAgICDotYTmupDlrozmlbTnmoTot6/lvoTlkI3np7DvvIzkuI3ljIXlkKvlkI7nvIBcclxuICAgICogQHBhcmFtIGNiICAgICDotYTmupDliqDovb3lrozmiJDlkI7nmoTlm57osINcclxuICAgICogQHBhcmFtIG1hc2sgICDliqDovb3ov4fnqIvkuK3mmK/lkKbpmLvmjKHnjqnlrrbop6bmkbjmk43kvZzvvIzpu5jorqTpmLvmjKFcclxuICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGxvYWRSZXModXJsOiBzdHJpbmcsIGNiOiAoYXNzZXQ6IGFueSkgPT4gdm9pZCwgbWFzaz86IGJvb2xlYW4pIHtcclxuICAgICAgICBpZiAoISF0aGlzLnNpbmdsZUFzc2V0W3VybF0pIHtcclxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjYih0aGlzLnNpbmdsZUFzc2V0W3VybF0pO1xyXG4gICAgICAgICAgICB9LCAwKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodW5kZWZpbmVkID09PSBtYXNrKSB7XHJcbiAgICAgICAgICAgICAgICBtYXNrID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAobWFzaykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93TWFzaygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKHVybCwgKGVyciwgcmVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAobWFzaykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaGlkZU1hc2soKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYy5lcnJvcihlcnIubWVzc2FnZSB8fCBlcnIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNiKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuc2luZ2xlQXNzZXRbdXJsXSA9IHJlcztcclxuICAgICAgICAgICAgICAgIGNiKHJlcyk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog5Yqg6L295pW05Liq5paH5Lu25aS55YaF55qE6LWE5rqQXHJcbiAgICAgKiBAcGFyYW0gZGlyICAg5paH5Lu25aS56Lev5b6EXHJcbiAgICAgKiBAcGFyYW0gY2IgICAg5Yqg6L295a6M5oiQ5Zue6LCDXHJcbiAgICAgKiBAcGFyYW0gdHlwZSAg6LWE5rqQ57G75Z6LXHJcbiAgICAgKiBAcGFyYW0gbWFzayAg5Yqg6L296L+H56iL5Lit5piv5ZCm5pi+56S65Yqg6L296L+b5bqm5bm26Zi75oyh546p5a626Kem5pG45pON5L2c77yM6buY6K6k5Li6dHJ1ZVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGxvYWRSZXNEaXIoZGlyOiBzdHJpbmcsIGNiOiAoYXNzZXRzOiBhbnlbXSkgPT4gdm9pZCwgdHlwZT86IHR5cGVvZiBjYy5Bc3NldCB8IGJvb2xlYW4sIG1hc2s/OiBib29sZWFuKSB7XHJcbiAgICAgICAgaWYgKCEhdGhpcy5kaXJBc3NldFtkaXJdKSB7XHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY2IodGhpcy5kaXJBc3NldFtkaXJdKTtcclxuICAgICAgICAgICAgfSwgMCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGFzc2V0VHlwZSA9IG51bGw7XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gdHlwZSkge1xyXG4gICAgICAgICAgICBtYXNrID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiB0eXBlID09PSBcImJvb2xlYW5cIikge1xyXG4gICAgICAgICAgICBtYXNrID0gISF0eXBlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGFzc2V0VHlwZSA9IHR5cGU7XHJcbiAgICAgICAgICAgIGlmICh1bmRlZmluZWQgPT09IG1hc2spIHtcclxuICAgICAgICAgICAgICAgIG1hc2sgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChtYXNrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1Byb2dyZXNzQmFyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghIWFzc2V0VHlwZSkge1xyXG4gICAgICAgICAgICBjYy5sb2FkZXIubG9hZFJlc0RpcihkaXIsIGFzc2V0VHlwZSwgdGhpcy51cGRhdGVQcm9ncmVzcy5iaW5kKHRoaXMpLFxyXG4gICAgICAgICAgICAgICAgKGVyciwgYXJyLCB1cmxzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1hc2spIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5oaWRlUHJvZ3Jlc3NCYXIoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2IobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXJBc3NldFtkaXJdID0gYXJyO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSBhcnIubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zaW5nbGVBc3NldFt1cmxzW2ldXSA9IGFycltpXTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2IodGhpcy5kaXJBc3NldFtkaXJdKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjYy5sb2FkZXIubG9hZFJlc0RpcihkaXIsIHRoaXMudXBkYXRlUHJvZ3Jlc3MuYmluZCh0aGlzKSxcclxuICAgICAgICAgICAgICAgIChlcnIsIGFyciwgdXJscykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChtYXNrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaGlkZVByb2dyZXNzQmFyKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNiKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGlyQXNzZXRbZGlyXSA9IGFycjtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gYXJyLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2luZ2xlQXNzZXRbdXJsc1tpXV0gPSBhcnJbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNiKHRoaXMuZGlyQXNzZXRbZGlyXSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLyoq5Yqg6L296LWE5rqQ5pWw57uEICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGxvYWRSZXNBcnJheSh1cmxzOiBzdHJpbmdbXSwgY2I6IChhc3NldHM6IGFueVtdKSA9PiB2b2lkLCBtYXNrPzogYm9vbGVhbikge1xyXG4gICAgICAgIGxldCBhc3NldHMgPSBbXTtcclxuICAgICAgICBsZXQgYXJyID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IHVybHMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgbGV0IHJlcyA9IHRoaXMuZ2V0QXNzZXQodXJsc1tpXSk7XHJcbiAgICAgICAgICAgIGlmICghIXJlcykge1xyXG4gICAgICAgICAgICAgICAgYXNzZXRzLnB1c2gocmVzKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGFyci5wdXNoKHVybHNbaV0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChhcnIubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjYihhc3NldHMpO1xyXG4gICAgICAgICAgICB9LCAwKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBtYXNrKSB7XHJcbiAgICAgICAgICAgIG1hc2sgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAobWFzaykge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dQcm9ncmVzc0JhcigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYy5sb2FkZXIubG9hZFJlc0FycmF5KGFyciwgdGhpcy51cGRhdGVQcm9ncmVzcy5iaW5kKHRoaXMpLFxyXG4gICAgICAgICAgICAoZXJyLCByZXMpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChtYXNrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oaWRlUHJvZ3Jlc3NCYXIoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICghIWVycikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2IobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVzKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSBhcnIubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zaW5nbGVBc3NldFthcnJbaV1dID0gcmVzW2ldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhc3NldHMucHVzaChyZXNbaV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaW5nbGVBc3NldFthcnJbMF1dID0gcmVzO1xyXG4gICAgICAgICAgICAgICAgICAgIGFzc2V0cy5wdXNoKHJlcyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjYihhc3NldHMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOiOt+WPluW3suWKoOi9veeahOi1hOa6kFxyXG4gICAgICogQHBhcmFtIHVybCDotYTmupDot6/lvoRcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBnZXRBc3NldCh1cmw6IHN0cmluZyk6IGNjLkFzc2V0IHtcclxuICAgICAgICBpZiAoIXRoaXMuc2luZ2xlQXNzZXRbdXJsXSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXCLlsJrmnKrliqDovb3otYTmupDvvJpcIiwgdXJsKTtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnNpbmdsZUFzc2V0W3VybF07XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDku47otYTmupDljIXliqDovb3ljZXkuKrotYTmupDvvIzosIPnlKjliY3or7fnoa7kv53or6XotYTmupDljIXlt7LliqDovb3lrozmiJBcclxuICAgICAqIEBwYXJhbSBidW5kbGUgICAg6LWE5rqQ5YyF5ZCNXHJcbiAgICAgKiBAcGFyYW0gdXJsICAgICAgIOi1hOa6kOebuOWvuei3r+W+hFxyXG4gICAgICogQHBhcmFtIGNiICAgICAgICDliqDovb3lm57osINcclxuICAgICAqIEBwYXJhbSBtYXNrICAgICAg5Yqg6L296L+H56iL5Lit5piv5ZCm6Zi75oyh546p5a626Kem5pG45pON5L2c77yM6buY6K6k6Zi75oyhXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgbG9hZEJ1bmRsZVJlcyhidW5kbGU6IHN0cmluZywgdXJsOiBzdHJpbmcsIGNiOiAoYXNzZXQ6IGFueSkgPT4gdm9pZCwgdHlwZT86IHR5cGVvZiBjYy5Bc3NldCB8IGJvb2xlYW4sIG1hc2s/OiBib29sZWFuKSB7XHJcbiAgICAgICAgbGV0IGIgPSBjYy5hc3NldE1hbmFnZXIuZ2V0QnVuZGxlKGJ1bmRsZSk7XHJcbiAgICAgICAgaWYgKCFiKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCLotYTmupDljIUgXCIgKyBidW5kbGUgKyBcIiDlsJrmnKrliqDovb3vvIzml6Dms5Xojrflj5botYTmupA6XCIsIHVybCk7XHJcbiAgICAgICAgICAgIGNiKG51bGwpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBhc3NldFR5cGUgPSBudWxsO1xyXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IHR5cGUpIHtcclxuICAgICAgICAgICAgbWFzayA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgdHlwZSA9PT0gXCJib29sZWFuXCIpIHtcclxuICAgICAgICAgICAgbWFzayA9ICEhdHlwZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBhc3NldFR5cGUgPSB0eXBlO1xyXG4gICAgICAgICAgICBpZiAodW5kZWZpbmVkID09PSBtYXNrKSB7XHJcbiAgICAgICAgICAgICAgICBtYXNrID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAobWFzaykge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dNYXNrKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChudWxsICE9PSBhc3NldFR5cGUpIHtcclxuICAgICAgICAgICAgYi5sb2FkKHVybCwgYXNzZXRUeXBlLCAoZXJyLCByZXMpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChtYXNrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oaWRlTWFzaygpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmVycm9yKGVyci5tZXNzYWdlIHx8IGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2IobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2IocmVzKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYi5sb2FkKHVybCwgKGVyciwgcmVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAobWFzaykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaGlkZU1hc2soKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYy5lcnJvcihlcnIubWVzc2FnZSB8fCBlcnIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNiKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNiKHJlcyk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog5LuO6LWE5rqQ5YyF5Yqg6L295aSa5Liq6LWE5rqQ77yM6LCD55So5YmN6K+356Gu5L+d6K+l6LWE5rqQ5YyF5bey5Yqg6L295a6M5oiQXHJcbiAgICAgKiBAcGFyYW0gYnVuZGxlICAgIOi1hOa6kOWMheWQjVxyXG4gICAgICogQHBhcmFtIHVybHMgICAgICDotYTmupDnm7jlr7not6/lvoRcclxuICAgICAqIEBwYXJhbSBjYiAgICAgICAg5Yqg6L295Zue6LCDXHJcbiAgICAgKiBAcGFyYW0gbWFzayAgICAgIOWKoOi9vei/h+eoi+S4reaYr+WQpuaYvuekuuWKoOi9vei/m+W6puadoeW5tumYu+aMoeeOqeWutuaTjeS9nO+8jOm7mOiupOS4unRydWVcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBsb2FkQnVuZGxlQXJyYXkoYnVuZGxlOiBzdHJpbmcsIHVybHM6IHN0cmluZ1tdLCBjYjogKGFzc2V0czogYW55KSA9PiB2b2lkLCBtYXNrPzogYm9vbGVhbikge1xyXG4gICAgICAgIGxldCBiID0gY2MuYXNzZXRNYW5hZ2VyLmdldEJ1bmRsZShidW5kbGUpO1xyXG4gICAgICAgIGlmICghYikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwi6LWE5rqQ5YyFIFwiICsgYnVuZGxlICsgXCIg5bCa5pyq5Yqg6L2977yM5peg5rOV6I635Y+W6LWE5rqQ5pWw57uEOlwiLCB1cmxzKTtcclxuICAgICAgICAgICAgY2IobnVsbCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gbWFzaykge1xyXG4gICAgICAgICAgICBtYXNrID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG1hc2spIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93UHJvZ3Jlc3NCYXIoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYi5sb2FkKHVybHMsIHRoaXMudXBkYXRlUHJvZ3Jlc3MuYmluZCh0aGlzKSwgKGVyciwgcmVzKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChtYXNrKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmhpZGVQcm9ncmVzc0JhcigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNjLmVycm9yKGVyci5tZXNzYWdlIHx8IGVycik7XHJcbiAgICAgICAgICAgICAgICBjYihudWxsKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYihyZXMpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgLyoqXHJcbiAgICAgKiDku47otYTmupDljIXkuK3liqDovb3mlofku7blpLnvvIzosIPnlKjliY3or7fnoa7kv53or6XotYTmupDljIXlt7LliqDovb3lrozmiJBcclxuICAgICAqIEBwYXJhbSBidW5kbGUgICAg6LWE5rqQ5YyF5ZCNXHJcbiAgICAgKiBAcGFyYW0gZGlyICAgICAgIOaWh+S7tuWkuei3r+W+hFxyXG4gICAgICogQHBhcmFtIGNiICAgICAgICDliqDovb3lm57osINcclxuICAgICAqIEBwYXJhbSB0eXBlICAgICAg6KaB5Yqg6L2955qE5paH5Lu25aS55Lit55qE6LWE5rqQ57G75Z6LXHJcbiAgICAgKiBAcGFyYW0gbWFzayAgICAgIOWKoOi9vei/h+eoi+S4reaYr+WQpuaYvuekuuWKoOi9vei/m+W6puadoeW5tumYu+aMoeeOqeWutuaTjeS9nO+8jOm7mOiupOS4unRydWVcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBsb2FkQnVuZGxlRGlyKGJ1bmRsZTogc3RyaW5nLCBkaXI6IHN0cmluZywgY2I6IChhc3NldHM6IGFueVtdKSA9PiB2b2lkLCB0eXBlPzogdHlwZW9mIGNjLkFzc2V0IHwgYm9vbGVhbiwgbWFzaz86IGJvb2xlYW4pIHtcclxuICAgICAgICBsZXQgYiA9IGNjLmFzc2V0TWFuYWdlci5nZXRCdW5kbGUoYnVuZGxlKTtcclxuICAgICAgICBpZiAoIWIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIui1hOa6kOWMhSBcIiArIGJ1bmRsZSArIFwiIOWwmuacquWKoOi9ve+8jOaXoOazleiOt+WPlui1hOa6kOaWh+S7tuWkuTpcIiwgZGlyKTtcclxuICAgICAgICAgICAgY2IobnVsbCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGFzc2V0VHlwZSA9IG51bGw7XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gdHlwZSkge1xyXG4gICAgICAgICAgICBtYXNrID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiB0eXBlID09PSBcImJvb2xlYW5cIikge1xyXG4gICAgICAgICAgICBtYXNrID0gISF0eXBlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGFzc2V0VHlwZSA9IHR5cGU7XHJcbiAgICAgICAgICAgIGlmICh1bmRlZmluZWQgPT09IG1hc2spIHtcclxuICAgICAgICAgICAgICAgIG1hc2sgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChtYXNrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1Byb2dyZXNzQmFyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghIWFzc2V0VHlwZSkge1xyXG4gICAgICAgICAgICBiLmxvYWREaXIoZGlyLCBhc3NldFR5cGUsIHRoaXMudXBkYXRlUHJvZ3Jlc3MuYmluZCh0aGlzKSwgKGVyciwgYXJyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAobWFzaykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaGlkZVByb2dyZXNzQmFyKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2IobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2IoYXJyKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYi5sb2FkRGlyKGRpciwgdGhpcy51cGRhdGVQcm9ncmVzcy5iaW5kKHRoaXMpLCAoZXJyLCBhcnIpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChtYXNrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oaWRlUHJvZ3Jlc3NCYXIoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICBjYihudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjYihhcnIpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBsb2FkQnVuZGxlU2NlbmUoYnVuZGxlOiBzdHJpbmcsIHNjZW5lOiBzdHJpbmcsIGNiOiAocmVzKSA9PiB2b2lkLCBtYXNrPykge1xyXG4gICAgICAgIGxldCBiID0gY2MuYXNzZXRNYW5hZ2VyLmdldEJ1bmRsZShidW5kbGUpO1xyXG4gICAgICAgIGlmICghYikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwi6LWE5rqQ5YyFIFwiICsgYnVuZGxlICsgXCIg5bCa5pyq5Yqg6L2977yM5peg5rOV5Yqg6L295Zy65pmvOlwiLCBzY2VuZSk7XHJcbiAgICAgICAgICAgIGNiKG51bGwpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IG1hc2spIHtcclxuICAgICAgICAgICAgbWFzayA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChtYXNrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1Byb2dyZXNzQmFyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGIubG9hZFNjZW5lKHNjZW5lLCB0aGlzLnVwZGF0ZVByb2dyZXNzLmJpbmQodGhpcyksIChlcnIsIHJlcykgPT4ge1xyXG4gICAgICAgICAgICBpZiAobWFzaykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5oaWRlUHJvZ3Jlc3NCYXIoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoISFlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYihyZXMpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgLy8jZW5kcmVnaW9uXHJcblxyXG4gICAgLy8jcmVnaW9uIOmihOWKoOi9vVxyXG4gICAgLyoqXHJcbiAgICAgKiDpooTliqDovb3otYTmupDljIXkuK3nmoTljZXkuKrotYTmupDvvIzosIPnlKjlrozlkI7vvIzkvaDku43nhLbpnIDopoHpgJrov4cgYGxvYWRCdW5kbGVSZXNgIOadpeWujOaIkOWKoOi9veOAglxyXG4gICAgICogQHBhcmFtIGJ1bmRsZSAgICDotYTmupDljIXlkI3np7BcclxuICAgICAqIEBwYXJhbSB1cmwgICAgICAg6LWE5rqQ6Lev5b6EXHJcbiAgICAgKiBAcGFyYW0gYXNzZXRUeXBlIOi1hOa6kOexu+Wei1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIHByZUxvYWRCdW5kbGVSZXMoYnVuZGxlOiBzdHJpbmcsIHVybDogc3RyaW5nLCBhc3NldFR5cGU/KSB7XHJcbiAgICAgICAgbGV0IGIgPSBjYy5hc3NldE1hbmFnZXIuZ2V0QnVuZGxlKGJ1bmRsZSk7XHJcbiAgICAgICAgaWYgKCFiKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gYXNzZXRUeXBlKSB7XHJcbiAgICAgICAgICAgIGIucHJlbG9hZCh1cmwpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGIucHJlbG9hZCh1cmwsIGFzc2V0VHlwZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLyoqXHJcbiAgICAgKiDpooTliqDovb3otYTmupDljIXkuK3nmoTotYTmupDmlbDnu4TvvIzosIPnlKjlrozlkI7vvIzkvaDku43nhLbpnIDopoHpgJrov4cgYGxvYWRCdW5kbGVSZXNgIOaIlidsb2FkQnVuZGxlQXJyYXkn5p2l5a6M5oiQ5Yqg6L2944CCXHJcbiAgICAgKiBAcGFyYW0gYnVuZGxlICAgIOi1hOa6kOWMheWQjeensFxyXG4gICAgICogQHBhcmFtIHVybHMgICAgICDotYTmupDot6/lvoTmlbDnu4RcclxuICAgICAqIEBwYXJhbSBhc3NldFR5cGUg6LWE5rqQ57G75Z6LXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgcHJlTG9hZEJ1bmRsZUFycmF5KGJ1bmRsZTogc3RyaW5nLCB1cmxzOiBzdHJpbmdbXSwgYXNzZXRUeXBlPykge1xyXG4gICAgICAgIGxldCBiID0gY2MuYXNzZXRNYW5hZ2VyLmdldEJ1bmRsZShidW5kbGUpO1xyXG4gICAgICAgIGlmICghYikge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IGFzc2V0VHlwZSkge1xyXG4gICAgICAgICAgICBiLnByZWxvYWQodXJscyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYi5wcmVsb2FkKHVybHMsIGFzc2V0VHlwZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLyoqXHJcbiAgICAgKiDpooTliqDovb3otYTmupDljIXkuK3nmoTmlofku7blpLnvvIzosIPnlKjlrozlkI7vvIzkvaDku43nhLbpnIDopoHpgJrov4cgYGxvYWRCdW5kbGVEaXJgIOadpeWujOaIkOWKoOi9veOAglxyXG4gICAgICogQHBhcmFtIGJ1bmRsZSAgICDotYTmupDljIXlkI3np7BcclxuICAgICAqIEBwYXJhbSBkaXIgICAgICAg6LWE5rqQ5paH5Lu25aS55ZCN56ewXHJcbiAgICAgKiBAcGFyYW0gYXNzZXRUeXBlIOi1hOa6kOexu+Wei1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIHByZUxvYWRCdW5kbGVEaXIoYnVuZGxlOiBzdHJpbmcsIGRpcjogc3RyaW5nLCBhc3NldFR5cGU/KSB7XHJcbiAgICAgICAgbGV0IGIgPSBjYy5hc3NldE1hbmFnZXIuZ2V0QnVuZGxlKGJ1bmRsZSk7XHJcbiAgICAgICAgaWYgKCFiKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gYXNzZXRUeXBlKSB7XHJcbiAgICAgICAgICAgIGIucHJlbG9hZERpcihkaXIpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGIucHJlbG9hZERpcihkaXIsIGFzc2V0VHlwZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLyoqXHJcbiAgICAgKiDpooTliqDovb3otYTmupDljIXkuK3nmoTlnLrmma/mlofku7bvvIzosIPnlKjlrozlkI7vvIzkvaDku43nhLbpnIDopoHpgJrov4cgYGxvYWRCdW5kbGVTY2VuZWAg5p2l5a6M5oiQ5Yqg6L2944CCXHJcbiAgICAgKiBAcGFyYW0gYnVuZGxlICAgIOi1hOa6kOWMheWQjeensFxyXG4gICAgICogQHBhcmFtIHNjZW5lICAgICDlnLrmma/lkI1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBwcmVMb2FkQnVuZGxlU2NlbmUoYnVuZGxlOiBzdHJpbmcsIHNjZW5lOiBzdHJpbmcpIHtcclxuICAgICAgICBsZXQgYiA9IGNjLmFzc2V0TWFuYWdlci5nZXRCdW5kbGUoYnVuZGxlKTtcclxuICAgICAgICBpZiAoIWIpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBiLnByZWxvYWRTY2VuZShzY2VuZSk7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxufVxyXG5cclxuLyoq5a2Q5YyF5Yqg6L2954q25oCBICovXHJcbmNsYXNzIFN1YnBhY2thZ2VSZWNvcmQge1xyXG4gICAgLyoq5a2Q5YyF5ZCN56ewICovXHJcbiAgICBwdWJsaWMgbmFtZTogc3RyaW5nO1xyXG4gICAgLyoq5Yqg6L2954q25oCBICovXHJcbiAgICBwdWJsaWMgc3RhdGU6IExvYWRTdGF0ZTtcclxuICAgIC8qKuWbnuiwg+aVsOe7hCAqL1xyXG4gICAgcHVibGljIGNiczogRnVuY3Rpb25bXTtcclxuICAgIHB1YmxpYyBtYXNrQ291bnQ6IG51bWJlcjtcclxuXHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IobmFtZTogc3RyaW5nLCBjYjogRnVuY3Rpb24sIG1hc2s6IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLm5hbWUgPSBuYW1lO1xyXG4gICAgICAgIHRoaXMuc3RhdGUgPSBMb2FkU3RhdGUuaW5pdGVkO1xyXG4gICAgICAgIHRoaXMuY2JzID0gW107XHJcbiAgICAgICAgaWYgKCEhY2IpIHRoaXMucHVzaENiKGNiKTtcclxuICAgICAgICB0aGlzLm1hc2tDb3VudCA9IG1hc2sgPyAxIDogMDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcHVzaENiKGNiOiBGdW5jdGlvbiwgbWFzaz86IGJvb2xlYW4pIHtcclxuICAgICAgICBpZiAoISFjYikgdGhpcy5jYnMucHVzaChjYik7XHJcbiAgICAgICAgaWYgKCEhbWFzaykgdGhpcy5tYXNrQ291bnQrKztcclxuICAgIH1cclxuICAgIHB1YmxpYyBlbnRlclNlcXVlbmNlKCkge1xyXG4gICAgICAgIHRoaXMuc3RhdGUgPSBMb2FkU3RhdGUud2FpdGluZztcclxuICAgIH1cclxuICAgIHB1YmxpYyBsb2FkU3RhcnQoKSB7XHJcbiAgICAgICAgdGhpcy5zdGF0ZSA9IExvYWRTdGF0ZS5sb2FkaW5nO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGxvYWRGaW5pc2goKSB7XHJcbiAgICAgICAgd2hpbGUgKHRoaXMuY2JzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgbGV0IGNiID0gdGhpcy5jYnMuc2hpZnQoKTtcclxuICAgICAgICAgICAgaWYgKCEhY2IpIGNiKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuc3RhdGUgPSBMb2FkU3RhdGUuZmluaXNoZWQ7XHJcbiAgICAgICAgdGhpcy5tYXNrQ291bnQgPSAwO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHR1cm5Ub0xvYWQoKSB7XHJcbiAgICAgICAgdGhpcy5zdGF0ZSA9IExvYWRTdGF0ZS50dXJuVG87XHJcbiAgICB9XHJcbn1cclxuLyoq6LWE5rqQ5Yqg6L2954q25oCBICovXHJcbmVudW0gTG9hZFN0YXRlIHtcclxuICAgIC8qKuW3suWHhuWkh+WlveWKoOi9vSAqL1xyXG4gICAgaW5pdGVkID0gMSxcclxuICAgIC8qKuWcqOmYn+WIl+S4reetieW+heWKoOi9vSAqL1xyXG4gICAgd2FpdGluZyxcclxuICAgIC8qKuato+WcqOWKoOi9veS4rSAqL1xyXG4gICAgbG9hZGluZyxcclxuICAgIC8qKuW3suWKoOi9veWujOaIkCAqL1xyXG4gICAgZmluaXNoZWQsXHJcbiAgICAvKirlnKjpmJ/liJfkuK3vvIzova7liLDliqDovb3lroPkuoYgKi9cclxuICAgIHR1cm5UbyxcclxufVxyXG4iXX0=