
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/AudioManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c3ffd4uKblBBKHFHlRW8W83', 'AudioManager');
// Script/Common/AudioManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameEventType_1 = require("../GameSpecial/GameEventType");
var EventManager_1 = require("./EventManager");
var GlobalEnum_1 = require("../GameSpecial/GlobalEnum");
var GameConfig_1 = require("../GameSpecial/GameConfig");
var Loader_1 = require("./Loader");
//音效管理器
var AudioManager = /** @class */ (function () {
    function AudioManager() {
    }
    AudioManager.init = function () {
        this.playingEffectCount = 0;
        cc.audioEngine.setMusicVolume(1);
        cc.audioEngine.setEffectsVolume(1);
        this.onEvents();
    };
    AudioManager.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.playBGM, this.playBGM, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.playClickBtn, this.playClickBtn, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.playEffect, this.playEffect, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.stopBGM, this.stop, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.pause, this.pauseBGM, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.resume, this.resumeBGM, this);
    };
    AudioManager.playClickBtn = function () {
        this.playEffect(GlobalEnum_1.GlobalEnum.AudioClip.clickBtn);
    };
    AudioManager.playEffect = function (clip) {
        var _this = this;
        if (undefined === this.allClips[clip]) {
            Loader_1.default.loadBundle("Audio", function () {
                Loader_1.default.loadBundleRes("Audio", clip, function (res) {
                    if (!res) {
                        _this.allClips[clip] = null;
                        cc.warn("要播放的音效资源未找到：", clip);
                        return;
                    }
                    _this.allClips[clip] = res;
                    _this._playEffect(clip);
                }, false);
            }, false);
        }
        else {
            this._playEffect(clip);
        }
    };
    AudioManager._playEffect = function (clip) {
        if (!GameConfig_1.default.audioConfig.effect)
            return;
        if (null === this.allClips[clip])
            return;
        if (this.playingEffectCount < this.maxEffectCount) {
            this.playingEffectCount++;
            var id = cc.audioEngine.play(this.allClips[clip], false, 1);
            cc.audioEngine.setFinishCallback(id, this._effectFinish.bind(this));
        }
    };
    AudioManager._effectFinish = function () {
        this.playingEffectCount--;
        if (this.playingEffectCount < 0)
            this.playingEffectCount = 0;
    };
    AudioManager.playBGM = function (clip, loop) {
        var _this = this;
        if (loop === void 0) { loop = true; }
        if (this.curBGM == clip) {
            return;
        }
        if (undefined === this.allClips[clip]) {
            Loader_1.default.loadBundle("Audio", function () {
                Loader_1.default.loadBundleRes("Audio", clip, function (res) {
                    if (!res) {
                        _this.allClips[clip] = null;
                        cc.warn("要播放的音效资源未找到：", clip);
                        return;
                    }
                    _this.allClips[clip] = res;
                    _this._playBGM(clip, loop);
                }, false);
            }, false);
        }
        else {
            this._playBGM(clip, loop);
        }
    };
    AudioManager._playBGM = function (clip, loop) {
        if (!GameConfig_1.default.audioConfig.bgm)
            return;
        if (null === this.allClips[clip])
            return;
        cc.audioEngine.stopMusic();
        cc.audioEngine.playMusic(this.allClips[clip], loop);
        this.curBGM = clip;
    };
    AudioManager.stop = function () {
        this.curBGM = null;
        cc.audioEngine.stopMusic();
    };
    AudioManager.pauseBGM = function () {
        cc.audioEngine.pauseMusic();
        console.log("暂停背景音乐");
    };
    AudioManager.resumeBGM = function () {
        cc.audioEngine.resumeMusic();
        console.log("继续播放背景音乐");
    };
    /**音效资源 */
    AudioManager.allClips = {};
    AudioManager.playingEffectCount = 0;
    /**可同时播放的最大音效数量 */
    AudioManager.maxEffectCount = 3;
    AudioManager.curBGM = null;
    return AudioManager;
}());
exports.default = AudioManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXEF1ZGlvTWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDhEQUF5RDtBQUN6RCwrQ0FBMEM7QUFDMUMsd0RBQXVEO0FBQ3ZELHdEQUFtRDtBQUNuRCxtQ0FBOEI7QUFFOUIsT0FBTztBQUNQO0lBQUE7SUFnR0EsQ0FBQztJQXpGaUIsaUJBQUksR0FBbEI7UUFDSSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDO1FBQzVCLEVBQUUsQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLEVBQUUsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFDZ0IscUJBQVEsR0FBekI7UUFDSSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNsRSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM1RSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN4RSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMvRCxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUN2RSxDQUFDO0lBRWdCLHlCQUFZLEdBQTdCO1FBQ0ksSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRWdCLHVCQUFVLEdBQTNCLFVBQTRCLElBQVk7UUFBeEMsaUJBZ0JDO1FBZkcsSUFBSSxTQUFTLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNuQyxnQkFBTSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUU7Z0JBQ3ZCLGdCQUFNLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsVUFBQyxHQUFHO29CQUNwQyxJQUFJLENBQUMsR0FBRyxFQUFFO3dCQUNOLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO3dCQUMzQixFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFDOUIsT0FBTztxQkFDVjtvQkFDRCxLQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztvQkFDMUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDM0IsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2QsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ2I7YUFBTTtZQUNILElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7SUFDTCxDQUFDO0lBQ2dCLHdCQUFXLEdBQTVCLFVBQTZCLElBQVk7UUFDckMsSUFBSSxDQUFDLG9CQUFVLENBQUMsV0FBVyxDQUFDLE1BQU07WUFBRSxPQUFPO1FBQzNDLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQUUsT0FBTztRQUN6QyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFO1lBQy9DLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzFCLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzVELEVBQUUsQ0FBQyxXQUFXLENBQUMsaUJBQWlCLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7U0FDdkU7SUFDTCxDQUFDO0lBQ2dCLDBCQUFhLEdBQTlCO1FBQ0ksSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDMUIsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQztZQUFFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVnQixvQkFBTyxHQUF4QixVQUF5QixJQUFZLEVBQUUsSUFBb0I7UUFBM0QsaUJBbUJDO1FBbkJzQyxxQkFBQSxFQUFBLFdBQW9CO1FBQ3ZELElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLEVBQUU7WUFDckIsT0FBTztTQUNWO1FBQ0QsSUFBSSxTQUFTLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNuQyxnQkFBTSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUU7Z0JBQ3ZCLGdCQUFNLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsVUFBQyxHQUFHO29CQUNwQyxJQUFJLENBQUMsR0FBRyxFQUFFO3dCQUNOLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO3dCQUMzQixFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFDOUIsT0FBTztxQkFDVjtvQkFDRCxLQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztvQkFDMUIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzlCLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNkLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztTQUNiO2FBQU07WUFDSCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFDZ0IscUJBQVEsR0FBekIsVUFBMEIsSUFBWSxFQUFFLElBQWE7UUFDakQsSUFBSSxDQUFDLG9CQUFVLENBQUMsV0FBVyxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBQ3hDLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQUUsT0FBTztRQUN6QyxFQUFFLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQzNCLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7SUFDdkIsQ0FBQztJQUNnQixpQkFBSSxHQUFyQjtRQUNJLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ25CLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUNnQixxQkFBUSxHQUF6QjtRQUNJLEVBQUUsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBQ2dCLHNCQUFTLEdBQTFCO1FBQ0ksRUFBRSxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM3QixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUE5RkQsVUFBVTtJQUNPLHFCQUFRLEdBQW9DLEVBQUUsQ0FBQztJQUMvQywrQkFBa0IsR0FBVyxDQUFDLENBQUM7SUFDaEQsa0JBQWtCO0lBQ0QsMkJBQWMsR0FBVyxDQUFDLENBQUM7SUFtRDNCLG1CQUFNLEdBQUcsSUFBSSxDQUFDO0lBd0NuQyxtQkFBQztDQWhHRCxBQWdHQyxJQUFBO2tCQWhHb0IsWUFBWSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XG5pbXBvcnQgRXZlbnRNYW5hZ2VyIGZyb20gXCIuL0V2ZW50TWFuYWdlclwiO1xuaW1wb3J0IHsgR2xvYmFsRW51bSB9IGZyb20gXCIuLi9HYW1lU3BlY2lhbC9HbG9iYWxFbnVtXCI7XG5pbXBvcnQgR2FtZUNvbmZpZyBmcm9tIFwiLi4vR2FtZVNwZWNpYWwvR2FtZUNvbmZpZ1wiO1xuaW1wb3J0IExvYWRlciBmcm9tIFwiLi9Mb2FkZXJcIjtcblxuLy/pn7PmlYjnrqHnkIblmahcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEF1ZGlvTWFuYWdlciB7XG4gICAgLyoq6Z+z5pWI6LWE5rqQICovXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBhbGxDbGlwczogeyBba2V5OiBzdHJpbmddOiBjYy5BdWRpb0NsaXAgfSA9IHt9O1xuICAgIHByb3RlY3RlZCBzdGF0aWMgcGxheWluZ0VmZmVjdENvdW50OiBudW1iZXIgPSAwO1xuICAgIC8qKuWPr+WQjOaXtuaSreaUvueahOacgOWkp+mfs+aViOaVsOmHjyAqL1xuICAgIHByb3RlY3RlZCBzdGF0aWMgbWF4RWZmZWN0Q291bnQ6IG51bWJlciA9IDM7XG5cbiAgICBwdWJsaWMgc3RhdGljIGluaXQoKSB7XG4gICAgICAgIHRoaXMucGxheWluZ0VmZmVjdENvdW50ID0gMDtcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUuc2V0TXVzaWNWb2x1bWUoMSk7XG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnNldEVmZmVjdHNWb2x1bWUoMSk7XG4gICAgICAgIHRoaXMub25FdmVudHMoKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHN0YXRpYyBvbkV2ZW50cygpIHtcbiAgICAgICAgRXZlbnRNYW5hZ2VyLm9uKEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlCR00sIHRoaXMucGxheUJHTSwgdGhpcyk7XG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuQXVkaW9FdmVudC5wbGF5Q2xpY2tCdG4sIHRoaXMucGxheUNsaWNrQnRuLCB0aGlzKTtcbiAgICAgICAgRXZlbnRNYW5hZ2VyLm9uKEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlFZmZlY3QsIHRoaXMucGxheUVmZmVjdCwgdGhpcyk7XG4gICAgICAgIEV2ZW50TWFuYWdlci5vbihFdmVudFR5cGUuQXVkaW9FdmVudC5zdG9wQkdNLCB0aGlzLnN0b3AsIHRoaXMpO1xuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGF1c2UsIHRoaXMucGF1c2VCR00sIHRoaXMpO1xuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLkF1ZGlvRXZlbnQucmVzdW1lLCB0aGlzLnJlc3VtZUJHTSwgdGhpcyk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBwbGF5Q2xpY2tCdG4oKSB7XG4gICAgICAgIHRoaXMucGxheUVmZmVjdChHbG9iYWxFbnVtLkF1ZGlvQ2xpcC5jbGlja0J0bik7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBwbGF5RWZmZWN0KGNsaXA6IHN0cmluZykge1xuICAgICAgICBpZiAodW5kZWZpbmVkID09PSB0aGlzLmFsbENsaXBzW2NsaXBdKSB7XG4gICAgICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZShcIkF1ZGlvXCIsICgpID0+IHtcbiAgICAgICAgICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZVJlcyhcIkF1ZGlvXCIsIGNsaXAsIChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFyZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxsQ2xpcHNbY2xpcF0gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2Mud2FybihcIuimgeaSreaUvueahOmfs+aViOi1hOa6kOacquaJvuWIsO+8mlwiLCBjbGlwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsbENsaXBzW2NsaXBdID0gcmVzO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9wbGF5RWZmZWN0KGNsaXApO1xuICAgICAgICAgICAgICAgIH0sIGZhbHNlKTtcbiAgICAgICAgICAgIH0sIGZhbHNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX3BsYXlFZmZlY3QoY2xpcCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJvdGVjdGVkIHN0YXRpYyBfcGxheUVmZmVjdChjbGlwOiBzdHJpbmcpIHtcbiAgICAgICAgaWYgKCFHYW1lQ29uZmlnLmF1ZGlvQ29uZmlnLmVmZmVjdCkgcmV0dXJuO1xuICAgICAgICBpZiAobnVsbCA9PT0gdGhpcy5hbGxDbGlwc1tjbGlwXSkgcmV0dXJuO1xuICAgICAgICBpZiAodGhpcy5wbGF5aW5nRWZmZWN0Q291bnQgPCB0aGlzLm1heEVmZmVjdENvdW50KSB7XG4gICAgICAgICAgICB0aGlzLnBsYXlpbmdFZmZlY3RDb3VudCsrO1xuICAgICAgICAgICAgbGV0IGlkID0gY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmFsbENsaXBzW2NsaXBdLCBmYWxzZSwgMSk7XG4gICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5zZXRGaW5pc2hDYWxsYmFjayhpZCwgdGhpcy5fZWZmZWN0RmluaXNoLmJpbmQodGhpcykpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByb3RlY3RlZCBzdGF0aWMgX2VmZmVjdEZpbmlzaCgpIHtcbiAgICAgICAgdGhpcy5wbGF5aW5nRWZmZWN0Q291bnQtLTtcbiAgICAgICAgaWYgKHRoaXMucGxheWluZ0VmZmVjdENvdW50IDwgMCkgdGhpcy5wbGF5aW5nRWZmZWN0Q291bnQgPSAwO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgc3RhdGljIGN1ckJHTSA9IG51bGw7XG4gICAgcHJvdGVjdGVkIHN0YXRpYyBwbGF5QkdNKGNsaXA6IHN0cmluZywgbG9vcDogYm9vbGVhbiA9IHRydWUpIHtcbiAgICAgICAgaWYgKHRoaXMuY3VyQkdNID09IGNsaXApIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSB0aGlzLmFsbENsaXBzW2NsaXBdKSB7XG4gICAgICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZShcIkF1ZGlvXCIsICgpID0+IHtcbiAgICAgICAgICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZVJlcyhcIkF1ZGlvXCIsIGNsaXAsIChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFyZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxsQ2xpcHNbY2xpcF0gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2Mud2FybihcIuimgeaSreaUvueahOmfs+aViOi1hOa6kOacquaJvuWIsO+8mlwiLCBjbGlwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsbENsaXBzW2NsaXBdID0gcmVzO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9wbGF5QkdNKGNsaXAsIGxvb3ApO1xuICAgICAgICAgICAgICAgIH0sIGZhbHNlKTtcbiAgICAgICAgICAgIH0sIGZhbHNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX3BsYXlCR00oY2xpcCwgbG9vcCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJvdGVjdGVkIHN0YXRpYyBfcGxheUJHTShjbGlwOiBzdHJpbmcsIGxvb3A6IGJvb2xlYW4pIHtcbiAgICAgICAgaWYgKCFHYW1lQ29uZmlnLmF1ZGlvQ29uZmlnLmJnbSkgcmV0dXJuO1xuICAgICAgICBpZiAobnVsbCA9PT0gdGhpcy5hbGxDbGlwc1tjbGlwXSkgcmV0dXJuO1xuICAgICAgICBjYy5hdWRpb0VuZ2luZS5zdG9wTXVzaWMoKTtcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheU11c2ljKHRoaXMuYWxsQ2xpcHNbY2xpcF0sIGxvb3ApO1xuICAgICAgICB0aGlzLmN1ckJHTSA9IGNsaXA7XG4gICAgfVxuICAgIHByb3RlY3RlZCBzdGF0aWMgc3RvcCgpIHtcbiAgICAgICAgdGhpcy5jdXJCR00gPSBudWxsO1xuICAgICAgICBjYy5hdWRpb0VuZ2luZS5zdG9wTXVzaWMoKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHN0YXRpYyBwYXVzZUJHTSgpIHtcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGF1c2VNdXNpYygpO1xuICAgICAgICBjb25zb2xlLmxvZyhcIuaaguWBnOiDjOaZr+mfs+S5kFwiKTtcbiAgICB9XG4gICAgcHJvdGVjdGVkIHN0YXRpYyByZXN1bWVCR00oKSB7XG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnJlc3VtZU11c2ljKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwi57un57ut5pKt5pS+6IOM5pmv6Z+z5LmQXCIpO1xuICAgIH1cbn1cbiJdfQ==