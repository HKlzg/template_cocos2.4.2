
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/CommonGameConfig.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'adf24pKBfVFoZ3UCJW+E7Fs', 'CommonGameConfig');
// Script/Common/CommonGameConfig.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 全局使用的游戏配置，只包含静态数据
 *
 * 基类中包含了适用于框架的游戏通用的配置，可在子类中根据实际游戏自定义新的属性
 */
var CommonGameConfig = /** @class */ (function () {
    function CommonGameConfig() {
    }
    CommonGameConfig.initAudioConfig = function () {
        if (!this._audioConfig) {
            var config = cc.sys.localStorage.getItem("audioConfig");
            if (!!config) {
                this._audioConfig = JSON.parse(config);
            }
            else {
                this._audioConfig = new AudioConfig();
            }
        }
    };
    Object.defineProperty(CommonGameConfig, "audioConfig", {
        get: function () {
            this.initAudioConfig();
            return this._audioConfig;
        },
        set: function (config) {
            this.initAudioConfig();
            this._audioConfig.bgm = !!config.bgm;
            this._audioConfig.effect = !!config.effect;
            cc.sys.localStorage.setItem("audioConfig", JSON.stringify(this._audioConfig));
        },
        enumerable: false,
        configurable: true
    });
    CommonGameConfig.initDriveConfig = function () {
        if (!this._driveConfig) {
            var config = cc.sys.localStorage.getItem("driveConfig");
            if (!!config) {
                this._driveConfig = JSON.parse(config);
            }
            else {
                this._driveConfig = new DriveConfig();
            }
        }
    };
    Object.defineProperty(CommonGameConfig, "driveConfig", {
        get: function () {
            this.initDriveConfig();
            return this._driveConfig;
        },
        set: function (config) {
            this.initDriveConfig();
            this._driveConfig.vibrate = !!config.vibrate;
            cc.sys.localStorage.setItem("driveConfig", JSON.stringify(this._driveConfig));
        },
        enumerable: false,
        configurable: true
    });
    /**游戏名称字符串 */
    CommonGameConfig.gameName = "myGame";
    //音效设置
    //#region 音效设置
    CommonGameConfig._audioConfig = null;
    //#endregion
    //#region 与设备相关的设置
    CommonGameConfig._driveConfig = null;
    return CommonGameConfig;
}());
exports.default = CommonGameConfig;
/**音效配置 */
var AudioConfig = /** @class */ (function () {
    function AudioConfig() {
        /**是否可播放背景音乐 */
        this.bgm = true;
        /**是否可播放特效 */
        this.effect = true;
    }
    return AudioConfig;
}());
var DriveConfig = /** @class */ (function () {
    function DriveConfig() {
        this.vibrate = true;
    }
    return DriveConfig;
}());

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXENvbW1vbkdhbWVDb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTs7OztHQUlHO0FBQ0g7SUFBQTtJQXFEQSxDQUFDO0lBN0NvQixnQ0FBZSxHQUFoQztRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3BCLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN4RCxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUU7Z0JBQ1YsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQzFDO2lCQUFNO2dCQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQzthQUN6QztTQUNKO0lBQ0wsQ0FBQztJQUNELHNCQUFrQiwrQkFBVzthQUE3QjtZQUNJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUN2QixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDN0IsQ0FBQzthQUNELFVBQThCLE1BQU07WUFDaEMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQzNDLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUNsRixDQUFDOzs7T0FOQTtJQVdnQixnQ0FBZSxHQUFoQztRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3BCLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN4RCxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUU7Z0JBQ1YsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQzFDO2lCQUFNO2dCQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQzthQUN6QztTQUNKO0lBQ0wsQ0FBQztJQUNELHNCQUFrQiwrQkFBVzthQUE3QjtZQUNJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUN2QixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDN0IsQ0FBQzthQUNELFVBQThCLE1BQU07WUFDaEMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1lBQzdDLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUNsRixDQUFDOzs7T0FMQTtJQTNDRCxhQUFhO0lBQ0MseUJBQVEsR0FBVyxRQUFRLENBQUM7SUFFMUMsTUFBTTtJQUNOLGNBQWM7SUFDRyw2QkFBWSxHQUFnQixJQUFJLENBQUM7SUFxQmxELFlBQVk7SUFFWixrQkFBa0I7SUFDRCw2QkFBWSxHQUFnQixJQUFJLENBQUM7SUFzQnRELHVCQUFDO0NBckRELEFBcURDLElBQUE7a0JBckRvQixnQkFBZ0I7QUFzRHJDLFVBQVU7QUFDVjtJQUFBO1FBQ0ksZUFBZTtRQUNSLFFBQUcsR0FBWSxJQUFJLENBQUM7UUFDM0IsYUFBYTtRQUNOLFdBQU0sR0FBWSxJQUFJLENBQUM7SUFDbEMsQ0FBQztJQUFELGtCQUFDO0FBQUQsQ0FMQSxBQUtDLElBQUE7QUFDRDtJQUFBO1FBQ1csWUFBTyxHQUFZLElBQUksQ0FBQztJQUNuQyxDQUFDO0lBQUQsa0JBQUM7QUFBRCxDQUZBLEFBRUMsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4vKipcclxuICog5YWo5bGA5L2/55So55qE5ri45oiP6YWN572u77yM5Y+q5YyF5ZCr6Z2Z5oCB5pWw5o2uXHJcbiAqIFxyXG4gKiDln7rnsbvkuK3ljIXlkKvkuobpgILnlKjkuo7moYbmnrbnmoTmuLjmiI/pgJrnlKjnmoTphY3nva7vvIzlj6/lnKjlrZDnsbvkuK3moLnmja7lrp7pmYXmuLjmiI/oh6rlrprkuYnmlrDnmoTlsZ7mgKdcclxuICovXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIENvbW1vbkdhbWVDb25maWcge1xyXG5cclxuICAgIC8qKua4uOaIj+WQjeensOWtl+espuS4siAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBnYW1lTmFtZTogc3RyaW5nID0gXCJteUdhbWVcIjtcclxuXHJcbiAgICAvL+mfs+aViOiuvue9rlxyXG4gICAgLy8jcmVnaW9uIOmfs+aViOiuvue9rlxyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBfYXVkaW9Db25maWc6IEF1ZGlvQ29uZmlnID0gbnVsbDtcclxuICAgIHByb3RlY3RlZCBzdGF0aWMgaW5pdEF1ZGlvQ29uZmlnKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5fYXVkaW9Db25maWcpIHtcclxuICAgICAgICAgICAgbGV0IGNvbmZpZyA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImF1ZGlvQ29uZmlnXCIpO1xyXG4gICAgICAgICAgICBpZiAoISFjb25maWcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2F1ZGlvQ29uZmlnID0gSlNPTi5wYXJzZShjb25maWcpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYXVkaW9Db25maWcgPSBuZXcgQXVkaW9Db25maWcoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0IGF1ZGlvQ29uZmlnKCkge1xyXG4gICAgICAgIHRoaXMuaW5pdEF1ZGlvQ29uZmlnKCk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2F1ZGlvQ29uZmlnO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBzZXQgYXVkaW9Db25maWcoY29uZmlnKSB7XHJcbiAgICAgICAgdGhpcy5pbml0QXVkaW9Db25maWcoKTtcclxuICAgICAgICB0aGlzLl9hdWRpb0NvbmZpZy5iZ20gPSAhIWNvbmZpZy5iZ207XHJcbiAgICAgICAgdGhpcy5fYXVkaW9Db25maWcuZWZmZWN0ID0gISFjb25maWcuZWZmZWN0O1xyXG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImF1ZGlvQ29uZmlnXCIsIEpTT04uc3RyaW5naWZ5KHRoaXMuX2F1ZGlvQ29uZmlnKSk7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAvLyNyZWdpb24g5LiO6K6+5aSH55u45YWz55qE6K6+572uXHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIF9kcml2ZUNvbmZpZzogRHJpdmVDb25maWcgPSBudWxsO1xyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBpbml0RHJpdmVDb25maWcoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9kcml2ZUNvbmZpZykge1xyXG4gICAgICAgICAgICBsZXQgY29uZmlnID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZHJpdmVDb25maWdcIik7XHJcbiAgICAgICAgICAgIGlmICghIWNvbmZpZykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZHJpdmVDb25maWcgPSBKU09OLnBhcnNlKGNvbmZpZyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kcml2ZUNvbmZpZyA9IG5ldyBEcml2ZUNvbmZpZygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBnZXQgZHJpdmVDb25maWcoKSB7XHJcbiAgICAgICAgdGhpcy5pbml0RHJpdmVDb25maWcoKTtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZHJpdmVDb25maWc7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIHNldCBkcml2ZUNvbmZpZyhjb25maWcpIHtcclxuICAgICAgICB0aGlzLmluaXREcml2ZUNvbmZpZygpO1xyXG4gICAgICAgIHRoaXMuX2RyaXZlQ29uZmlnLnZpYnJhdGUgPSAhIWNvbmZpZy52aWJyYXRlO1xyXG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImRyaXZlQ29uZmlnXCIsIEpTT04uc3RyaW5naWZ5KHRoaXMuX2RyaXZlQ29uZmlnKSk7XHJcbiAgICB9XHJcbiAgICAvLyNlbmRyZWdpb25cclxuXHJcbn1cclxuLyoq6Z+z5pWI6YWN572uICovXHJcbmNsYXNzIEF1ZGlvQ29uZmlnIHtcclxuICAgIC8qKuaYr+WQpuWPr+aSreaUvuiDjOaZr+mfs+S5kCAqL1xyXG4gICAgcHVibGljIGJnbTogYm9vbGVhbiA9IHRydWU7XHJcbiAgICAvKirmmK/lkKblj6/mkq3mlL7nibnmlYggKi9cclxuICAgIHB1YmxpYyBlZmZlY3Q6IGJvb2xlYW4gPSB0cnVlO1xyXG59XHJcbmNsYXNzIERyaXZlQ29uZmlnIHtcclxuICAgIHB1YmxpYyB2aWJyYXRlOiBib29sZWFuID0gdHJ1ZTtcclxufSJdfQ==