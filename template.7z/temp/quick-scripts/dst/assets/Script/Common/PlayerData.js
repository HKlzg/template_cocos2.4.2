
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/PlayerData.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bc9d8TfjwRC0J+4t02oPAHq', 'PlayerData');
// Script/Common/PlayerData.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventManager_1 = require("./EventManager");
var PlayerDataTemplate_1 = require("../GameSpecial/PlayerDataTemplate");
var GameConfig_1 = require("../GameSpecial/GameConfig");
var GameEventType_1 = require("../GameSpecial/GameEventType");
//玩家数据管理器
var PlayerData = /** @class */ (function () {
    function PlayerData() {
    }
    PlayerData.init = function () {
        this.Data = PlayerDataTemplate_1.default.getData();
        var resetPlayerData = cc.sys.localStorage.getItem(GameConfig_1.default.gameName + "needResetPlayerData7");
        if (!resetPlayerData || !JSON.parse(resetPlayerData)) {
            var v = cc.sys.localStorage.getItem(GameConfig_1.default.gameName + "PlayerData");
            if (!!v) {
                v = JSON.parse(v);
                this.copyObject(this.Data, v);
            }
        }
        cc.sys.localStorage.setItem(GameConfig_1.default.gameName + "needResetPlayerData7", JSON.stringify(false));
        this.resetTrySkin();
        this.onEvents();
    };
    PlayerData.copyObject = function (target, src) {
        for (var key in src) {
            switch (typeof src[key]) {
                case "number":
                case "boolean":
                case "string": {
                    target[key] = src[key];
                    break;
                }
                case "object": {
                    if (Array.isArray(src[key])) {
                        target[key] = [].concat(src[key]);
                    }
                    else {
                        if (undefined == target[key])
                            target[key] = {};
                        this.copyObject(target[key], src[key]);
                    }
                    break;
                }
                default: {
                    break;
                }
            }
        }
    };
    PlayerData.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, this.onUpdatePlayerData, this);
    };
    /**
     * 更新玩家数据
     * @param data
     * @param {string} [data.attribute] 要修改的数据的字段名称，用“.”号分割多级子属性，例如“gameData.curLevel”
     * @param {number|string} [data.value] 属性改变的量
     * @param {string} [data.mode] 数据修改方式
     * @param {boolean} [data.save] 是否需要及时保存数据，默认为true
     * @param {boolean} [data.emit] 是否需要及时通知外界玩家数据已变化，默认为true
     */
    PlayerData.onUpdatePlayerData = function (data) {
        if (data.attribute.indexOf(".") < 0) {
            this.updateData(this.Data, data.attribute, data.value, data.mode);
        }
        else {
            var str = data.attribute.split(".");
            var playerData = this.Data;
            for (var i = 0; i < str.length - 1; ++i) {
                if (undefined != playerData[str[i]]) {
                    playerData = playerData[str[i]];
                }
                else {
                    cc.log("修改玩家数据失败，玩家数据未定义对应属性：" + str[i]);
                    cc.log(data);
                    return;
                }
            }
            this.updateData(playerData, str[str.length - 1], data.value, data.mode);
        }
        if (undefined === data.save || true === data.save) {
            this.saveData();
        }
        if (undefined === data.emit || true === data.emit) {
            //数据更新后发送事件，UI组件自动处理
            EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
                attribute: data.attribute,
                value: this.getData(data.attribute),
            });
        }
    };
    /**
     * 更新对象的字段值
     * @param data      字段所属对象
     * @param attribute 字段名称
     * @param value     要改变的值
     * @param mode      改变方式
     */
    PlayerData.updateData = function (data, attribute, value, mode) {
        switch (mode) {
            case "+": {
                data[attribute] += parseFloat(value);
                break;
            }
            case "-": {
                data[attribute] -= parseFloat(value);
                break;
            }
            case "*": {
                data[attribute] *= parseFloat(value);
                break;
            }
            case "=": {
                data[attribute] = parseFloat(value);
                break;
            }
            case "push": {
                data[attribute].push(value);
                break;
            }
            default: {
                cc.log("数据修改失败，未定义的数据修改方式：" + mode);
                break;
            }
        }
    };
    /**
     * 获取玩家数据
     * @param attribute 字段名称，用“.”号分割多级子属性，例如“gameData.curLevel”
     */
    PlayerData.getData = function (attribute) {
        if (!attribute) {
            return this.Data;
        }
        if (attribute.indexOf(".") < 0) {
            return this.Data[attribute];
        }
        var str = attribute.split(".");
        var playerData = this.Data;
        for (var i = 0; i < str.length; ++i) {
            if (undefined != playerData[str[i]]) {
                playerData = playerData[str[i]];
            }
            else {
                return playerData;
            }
        }
        return playerData;
    };
    //存储数据，将在本地存储，并发送给服务端
    PlayerData.saveData = function () {
        cc.sys.localStorage.setItem(GameConfig_1.default.gameName + "PlayerData", JSON.stringify(this.Data));
        //todo: 发送给服务端
    };
    //一些通用的快捷方法：
    //金币
    /**增加金币 */
    PlayerData.addGold = function (gold) {
        this.Data.gameData.asset.gold += gold;
        EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
            type: "gameData",
            attribute: "gameData.asset.gold",
            value: this.Data.gameData.asset.gold,
        });
    };
    /**
     * 快捷方法：减少金币
     * @param gold  减少的金币数量
     */
    PlayerData.subGold = function (gold) {
        if (gold <= this.Data.gameData.asset.gold) {
            this.Data.gameData.asset.gold -= gold;
        }
        else {
            this.Data.gameData.asset.gold = 0;
        }
        EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
            type: "gameData",
            attribute: "gameData.asset.gold",
            value: this.Data.gameData.asset.gold,
        });
    };
    //皮肤
    /**
     * 获取当前使用的皮肤，激活了试用皮肤时，将返回试用皮肤
     * @param type 皮肤类型
     */
    PlayerData.getCurSkinId = function (type) {
        var data = this.Data.gameData[type];
        var id = data.try;
        if (id == -1) {
            id = data.cur;
        }
        return id;
    };
    /**
     * 解锁皮肤
     * @param type  皮肤类型
     * @param id    皮肤id
     */
    PlayerData.unlockSkin = function (type, id) {
        var data = this.Data.gameData[type];
        if (data.owned.indexOf(id) >= 0) {
            return;
        }
        data.owned.push(id);
        EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
            type: "gameData",
            attribute: "gameData." + type + ".owned",
            value: data.owned,
        });
    };
    /**
     * 设置指定皮肤为当前使用的皮肤
     * @param type  皮肤类型
     * @param id    皮肤id
     */
    PlayerData.setCurSkin = function (type, id) {
        var data = this.Data.gameData[type];
        if (data.cur == id)
            return;
        data.cur = id;
        EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
            type: "gameData",
            attribute: "gameData." + type + ".cur",
            value: data.cur,
        });
    };
    /**
     * 试用皮肤
     * @param type  皮肤类型
     * @param id    皮肤id
     */
    PlayerData.onTrySkin = function (type, id) {
        this.Data.gameData[type].try = id;
    };
    /**
     * 皮肤试用结束
     * @param type  皮肤类型
     */
    PlayerData.onTrySkinEnd = function (type) {
        this.Data.gameData[type].try = -1;
    };
    PlayerData.resetTrySkin = function () {
        var data = this.Data.gameData;
        for (var key in data) {
            if (typeof data[key] == "object" && !!data[key].try) {
                data[key].try = -1;
            }
        }
    };
    PlayerData.Data = {};
    return PlayerData;
}());
exports.default = PlayerData;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXFBsYXllckRhdGEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrQ0FBMEM7QUFDMUMsd0VBQW1FO0FBQ25FLHdEQUFtRDtBQUNuRCw4REFBeUQ7QUFFekQsU0FBUztBQUNUO0lBQUE7SUFrUEEsQ0FBQztJQWhQaUIsZUFBSSxHQUFsQjtRQUNJLElBQUksQ0FBQyxJQUFJLEdBQUcsNEJBQWtCLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDekMsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLG9CQUFVLENBQUMsUUFBUSxHQUFHLHNCQUFzQixDQUFDLENBQUM7UUFDaEcsSUFBSSxDQUFDLGVBQWUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLEVBQUU7WUFDbEQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLG9CQUFVLENBQUMsUUFBUSxHQUFHLFlBQVksQ0FBQyxDQUFDO1lBQ3hFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDTCxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ2pDO1NBQ0o7UUFDRCxFQUFFLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsb0JBQVUsQ0FBQyxRQUFRLEdBQUcsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRWpHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUNnQixxQkFBVSxHQUEzQixVQUE0QixNQUFXLEVBQUUsR0FBUTtRQUM3QyxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRTtZQUNqQixRQUFRLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNyQixLQUFLLFFBQVEsQ0FBQztnQkFDZCxLQUFLLFNBQVMsQ0FBQztnQkFDZixLQUFLLFFBQVEsQ0FBQyxDQUFDO29CQUNYLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3ZCLE1BQU07aUJBQ1Q7Z0JBQ0QsS0FBSyxRQUFRLENBQUMsQ0FBQztvQkFDWCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7d0JBQ3pCLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO3FCQUNyQzt5QkFBTTt3QkFDSCxJQUFJLFNBQVMsSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDOzRCQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7d0JBQy9DLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO3FCQUMxQztvQkFDRCxNQUFNO2lCQUNUO2dCQUNELE9BQU8sQ0FBQyxDQUFDO29CQUNMLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUNnQixtQkFBUSxHQUF6QjtRQUNJLHNCQUFZLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsZUFBZSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMvRixDQUFDO0lBQ0Q7Ozs7Ozs7O09BUUc7SUFDYyw2QkFBa0IsR0FBbkMsVUFBb0MsSUFBaUc7UUFDakksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDckU7YUFBTTtZQUNILElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDM0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNyQyxJQUFJLFNBQVMsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ2pDLFVBQVUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ25DO3FCQUFNO29CQUNILEVBQUUsQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3pDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ2IsT0FBTztpQkFDVjthQUNKO1lBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDM0U7UUFDRCxJQUFJLFNBQVMsS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQy9DLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNuQjtRQUNELElBQUksU0FBUyxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDL0Msb0JBQW9CO1lBQ3BCLHNCQUFZLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFFO2dCQUMzRCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0JBQ3pCLEtBQUssRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7YUFDdEMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBQ0Q7Ozs7OztPQU1HO0lBQ2MscUJBQVUsR0FBM0IsVUFBNEIsSUFBUyxFQUFFLFNBQWlCLEVBQUUsS0FBVSxFQUFFLElBQVk7UUFDOUUsUUFBUSxJQUFJLEVBQUU7WUFDVixLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNOLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3JDLE1BQU07YUFDVDtZQUNELEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ04sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDckMsTUFBTTthQUNUO1lBQ0QsS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDTixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNyQyxNQUFNO2FBQ1Q7WUFDRCxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNOLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3BDLE1BQU07YUFDVDtZQUNELEtBQUssTUFBTSxDQUFDLENBQUM7Z0JBQ1QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDNUIsTUFBTTthQUNUO1lBQ0QsT0FBTyxDQUFDLENBQUM7Z0JBQ0wsRUFBRSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsQ0FBQztnQkFDcEMsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBQ0Q7OztPQUdHO0lBQ1csa0JBQU8sR0FBckIsVUFBc0IsU0FBaUI7UUFDbkMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNaLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQztTQUNwQjtRQUNELElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDNUIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQy9CO1FBQ0QsSUFBSSxHQUFHLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMvQixJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzNCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2pDLElBQUksU0FBUyxJQUFJLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDakMsVUFBVSxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNuQztpQkFBTTtnQkFDSCxPQUFPLFVBQVUsQ0FBQzthQUNyQjtTQUNKO1FBQ0QsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUNELHFCQUFxQjtJQUNKLG1CQUFRLEdBQXpCO1FBQ0ksRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLG9CQUFVLENBQUMsUUFBUSxHQUFHLFlBQVksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzNGLGNBQWM7SUFDbEIsQ0FBQztJQUVELFlBQVk7SUFDWixJQUFJO0lBQ0osVUFBVTtJQUNJLGtCQUFPLEdBQXJCLFVBQXNCLElBQVk7UUFDOUIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUM7UUFDdEMsc0JBQVksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEVBQUU7WUFDM0QsSUFBSSxFQUFFLFVBQVU7WUFDaEIsU0FBUyxFQUFFLHFCQUFxQjtZQUNoQyxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUk7U0FDdkMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNEOzs7T0FHRztJQUNXLGtCQUFPLEdBQXJCLFVBQXNCLElBQVk7UUFDOUIsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRTtZQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQztTQUN6QzthQUFNO1lBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7U0FDckM7UUFDRCxzQkFBWSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsRUFBRTtZQUMzRCxJQUFJLEVBQUUsVUFBVTtZQUNoQixTQUFTLEVBQUUscUJBQXFCO1lBQ2hDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSTtTQUN2QyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsSUFBSTtJQUNKOzs7T0FHRztJQUNXLHVCQUFZLEdBQTFCLFVBQTJCLElBQUk7UUFDM0IsSUFBSSxJQUFJLEdBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDekMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUNsQixJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRTtZQUNWLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1NBQ2pCO1FBQ0QsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBQ0Q7Ozs7T0FJRztJQUNXLHFCQUFVLEdBQXhCLFVBQXlCLElBQUksRUFBRSxFQUFFO1FBQzdCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzdCLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3BCLHNCQUFZLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFFO1lBQzNELElBQUksRUFBRSxVQUFVO1lBQ2hCLFNBQVMsRUFBRSxXQUFXLEdBQUcsSUFBSSxHQUFHLFFBQVE7WUFDeEMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO1NBQ3BCLENBQUMsQ0FBQztJQUNQLENBQUM7SUFDRDs7OztPQUlHO0lBQ1cscUJBQVUsR0FBeEIsVUFBeUIsSUFBSSxFQUFFLEVBQUU7UUFDN0IsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEMsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLEVBQUU7WUFBRSxPQUFPO1FBQzNCLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBQ2Qsc0JBQVksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEVBQUU7WUFDM0QsSUFBSSxFQUFFLFVBQVU7WUFDaEIsU0FBUyxFQUFFLFdBQVcsR0FBRyxJQUFJLEdBQUcsTUFBTTtZQUN0QyxLQUFLLEVBQUUsSUFBSSxDQUFDLEdBQUc7U0FDbEIsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNEOzs7O09BSUc7SUFDYyxvQkFBUyxHQUExQixVQUEyQixJQUFJLEVBQUUsRUFBRTtRQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO0lBQ3RDLENBQUM7SUFDRDs7O09BR0c7SUFDYyx1QkFBWSxHQUE3QixVQUE4QixJQUFJO1FBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ2dCLHVCQUFZLEdBQTdCO1FBQ0ksSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDOUIsS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUU7WUFDbEIsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxRQUFRLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pELElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDdEI7U0FDSjtJQUNMLENBQUM7SUE5T2dCLGVBQUksR0FBUSxFQUFFLENBQUM7SUFpUHBDLGlCQUFDO0NBbFBELEFBa1BDLElBQUE7a0JBbFBvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEV2ZW50TWFuYWdlciBmcm9tIFwiLi9FdmVudE1hbmFnZXJcIjtcbmltcG9ydCBQbGF5ZXJEYXRhVGVtcGxhdGUgZnJvbSBcIi4uL0dhbWVTcGVjaWFsL1BsYXllckRhdGFUZW1wbGF0ZVwiO1xuaW1wb3J0IEdhbWVDb25maWcgZnJvbSBcIi4uL0dhbWVTcGVjaWFsL0dhbWVDb25maWdcIjtcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XG5cbi8v546p5a625pWw5o2u566h55CG5ZmoXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBQbGF5ZXJEYXRhIHtcbiAgICBwcm90ZWN0ZWQgc3RhdGljIERhdGE6IGFueSA9IHt9O1xuICAgIHB1YmxpYyBzdGF0aWMgaW5pdCgpIHtcbiAgICAgICAgdGhpcy5EYXRhID0gUGxheWVyRGF0YVRlbXBsYXRlLmdldERhdGEoKTtcbiAgICAgICAgbGV0IHJlc2V0UGxheWVyRGF0YSA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShHYW1lQ29uZmlnLmdhbWVOYW1lICsgXCJuZWVkUmVzZXRQbGF5ZXJEYXRhN1wiKTtcbiAgICAgICAgaWYgKCFyZXNldFBsYXllckRhdGEgfHwgIUpTT04ucGFyc2UocmVzZXRQbGF5ZXJEYXRhKSkge1xuICAgICAgICAgICAgbGV0IHYgPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oR2FtZUNvbmZpZy5nYW1lTmFtZSArIFwiUGxheWVyRGF0YVwiKTtcbiAgICAgICAgICAgIGlmICghIXYpIHtcbiAgICAgICAgICAgICAgICB2ID0gSlNPTi5wYXJzZSh2KTtcbiAgICAgICAgICAgICAgICB0aGlzLmNvcHlPYmplY3QodGhpcy5EYXRhLCB2KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oR2FtZUNvbmZpZy5nYW1lTmFtZSArIFwibmVlZFJlc2V0UGxheWVyRGF0YTdcIiwgSlNPTi5zdHJpbmdpZnkoZmFsc2UpKTtcblxuICAgICAgICB0aGlzLnJlc2V0VHJ5U2tpbigpO1xuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XG4gICAgfVxuICAgIHByb3RlY3RlZCBzdGF0aWMgY29weU9iamVjdCh0YXJnZXQ6IGFueSwgc3JjOiBhbnkpIHtcbiAgICAgICAgZm9yIChsZXQga2V5IGluIHNyYykge1xuICAgICAgICAgICAgc3dpdGNoICh0eXBlb2Ygc3JjW2tleV0pIHtcbiAgICAgICAgICAgICAgICBjYXNlIFwibnVtYmVyXCI6XG4gICAgICAgICAgICAgICAgY2FzZSBcImJvb2xlYW5cIjpcbiAgICAgICAgICAgICAgICBjYXNlIFwic3RyaW5nXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0W2tleV0gPSBzcmNba2V5XTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhc2UgXCJvYmplY3RcIjoge1xuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShzcmNba2V5XSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldFtrZXldID0gW10uY29uY2F0KHNyY1trZXldKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1bmRlZmluZWQgPT0gdGFyZ2V0W2tleV0pIHRhcmdldFtrZXldID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvcHlPYmplY3QodGFyZ2V0W2tleV0sIHNyY1trZXldKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZGVmYXVsdDoge1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJvdGVjdGVkIHN0YXRpYyBvbkV2ZW50cygpIHtcbiAgICAgICAgRXZlbnRNYW5hZ2VyLm9uKEV2ZW50VHlwZS5QbGF5ZXJEYXRhRXZlbnQudXBkYXRlUGxheWVyRGF0YSwgdGhpcy5vblVwZGF0ZVBsYXllckRhdGEsIHRoaXMpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiDmm7TmlrDnjqnlrrbmlbDmja5cbiAgICAgKiBAcGFyYW0gZGF0YSBcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gW2RhdGEuYXR0cmlidXRlXSDopoHkv67mlLnnmoTmlbDmja7nmoTlrZfmrrXlkI3np7DvvIznlKjigJwu4oCd5Y+35YiG5Ymy5aSa57qn5a2Q5bGe5oCn77yM5L6L5aaC4oCcZ2FtZURhdGEuY3VyTGV2ZWzigJ1cbiAgICAgKiBAcGFyYW0ge251bWJlcnxzdHJpbmd9IFtkYXRhLnZhbHVlXSDlsZ7mgKfmlLnlj5jnmoTph49cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gW2RhdGEubW9kZV0g5pWw5o2u5L+u5pS55pa55byPXG4gICAgICogQHBhcmFtIHtib29sZWFufSBbZGF0YS5zYXZlXSDmmK/lkKbpnIDopoHlj4rml7bkv53lrZjmlbDmja7vvIzpu5jorqTkuLp0cnVlXG4gICAgICogQHBhcmFtIHtib29sZWFufSBbZGF0YS5lbWl0XSDmmK/lkKbpnIDopoHlj4rml7bpgJrnn6XlpJbnlYznjqnlrrbmlbDmja7lt7Llj5jljJbvvIzpu5jorqTkuLp0cnVlXG4gICAgICovXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBvblVwZGF0ZVBsYXllckRhdGEoZGF0YTogeyBhdHRyaWJ1dGU6IHN0cmluZywgdmFsdWU6IG51bWJlciB8IHN0cmluZywgbW9kZTogc3RyaW5nLCBzYXZlPzogYm9vbGVhbiwgZW1pdD86IGJvb2xlYW4gfSkge1xuICAgICAgICBpZiAoZGF0YS5hdHRyaWJ1dGUuaW5kZXhPZihcIi5cIikgPCAwKSB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZURhdGEodGhpcy5EYXRhLCBkYXRhLmF0dHJpYnV0ZSwgZGF0YS52YWx1ZSwgZGF0YS5tb2RlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGxldCBzdHIgPSBkYXRhLmF0dHJpYnV0ZS5zcGxpdChcIi5cIik7XG4gICAgICAgICAgICBsZXQgcGxheWVyRGF0YSA9IHRoaXMuRGF0YTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc3RyLmxlbmd0aCAtIDE7ICsraSkge1xuICAgICAgICAgICAgICAgIGlmICh1bmRlZmluZWQgIT0gcGxheWVyRGF0YVtzdHJbaV1dKSB7XG4gICAgICAgICAgICAgICAgICAgIHBsYXllckRhdGEgPSBwbGF5ZXJEYXRhW3N0cltpXV07XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5L+u5pS5546p5a625pWw5o2u5aSx6LSl77yM546p5a625pWw5o2u5pyq5a6a5LmJ5a+55bqU5bGe5oCn77yaXCIgKyBzdHJbaV0pO1xuICAgICAgICAgICAgICAgICAgICBjYy5sb2coZGF0YSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZURhdGEocGxheWVyRGF0YSwgc3RyW3N0ci5sZW5ndGggLSAxXSwgZGF0YS52YWx1ZSwgZGF0YS5tb2RlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBkYXRhLnNhdmUgfHwgdHJ1ZSA9PT0gZGF0YS5zYXZlKSB7XG4gICAgICAgICAgICB0aGlzLnNhdmVEYXRhKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gZGF0YS5lbWl0IHx8IHRydWUgPT09IGRhdGEuZW1pdCkge1xuICAgICAgICAgICAgLy/mlbDmja7mm7TmlrDlkI7lj5HpgIHkuovku7bvvIxVSee7hOS7tuiHquWKqOWkhOeQhlxuICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlBsYXllckRhdGFFdmVudC5wbGF5ZXJEYXRhQ2hhbmdlZCwge1xuICAgICAgICAgICAgICAgIGF0dHJpYnV0ZTogZGF0YS5hdHRyaWJ1dGUsICAgICAgICAgICAgICAvL+aVsOaNruWQjeensFxuICAgICAgICAgICAgICAgIHZhbHVlOiB0aGlzLmdldERhdGEoZGF0YS5hdHRyaWJ1dGUpLCAgICAvL+WPmOabtOWQjueahOaVsOaNruWAvFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICog5pu05paw5a+56LGh55qE5a2X5q615YC8XG4gICAgICogQHBhcmFtIGRhdGEgICAgICDlrZfmrrXmiYDlsZ7lr7nosaFcbiAgICAgKiBAcGFyYW0gYXR0cmlidXRlIOWtl+auteWQjeensFxuICAgICAqIEBwYXJhbSB2YWx1ZSAgICAg6KaB5pS55Y+Y55qE5YC8XG4gICAgICogQHBhcmFtIG1vZGUgICAgICDmlLnlj5jmlrnlvI9cbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgc3RhdGljIHVwZGF0ZURhdGEoZGF0YTogYW55LCBhdHRyaWJ1dGU6IHN0cmluZywgdmFsdWU6IGFueSwgbW9kZTogc3RyaW5nKSB7XG4gICAgICAgIHN3aXRjaCAobW9kZSkge1xuICAgICAgICAgICAgY2FzZSBcIitcIjoge1xuICAgICAgICAgICAgICAgIGRhdGFbYXR0cmlidXRlXSArPSBwYXJzZUZsb2F0KHZhbHVlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgXCItXCI6IHtcbiAgICAgICAgICAgICAgICBkYXRhW2F0dHJpYnV0ZV0gLT0gcGFyc2VGbG9hdCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIFwiKlwiOiB7XG4gICAgICAgICAgICAgICAgZGF0YVthdHRyaWJ1dGVdICo9IHBhcnNlRmxvYXQodmFsdWUpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBcIj1cIjoge1xuICAgICAgICAgICAgICAgIGRhdGFbYXR0cmlidXRlXSA9IHBhcnNlRmxvYXQodmFsdWUpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBcInB1c2hcIjoge1xuICAgICAgICAgICAgICAgIGRhdGFbYXR0cmlidXRlXS5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgICAgICAgICBjYy5sb2coXCLmlbDmja7kv67mlLnlpLHotKXvvIzmnKrlrprkuYnnmoTmlbDmja7kv67mlLnmlrnlvI/vvJpcIiArIG1vZGUpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIOiOt+WPlueOqeWutuaVsOaNrlxuICAgICAqIEBwYXJhbSBhdHRyaWJ1dGUg5a2X5q615ZCN56ew77yM55So4oCcLuKAneWPt+WIhuWJsuWkmue6p+WtkOWxnuaAp++8jOS+i+WmguKAnGdhbWVEYXRhLmN1ckxldmVs4oCdXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXREYXRhKGF0dHJpYnV0ZTogc3RyaW5nKSB7XG4gICAgICAgIGlmICghYXR0cmlidXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5EYXRhO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhdHRyaWJ1dGUuaW5kZXhPZihcIi5cIikgPCAwKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5EYXRhW2F0dHJpYnV0ZV07XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHN0ciA9IGF0dHJpYnV0ZS5zcGxpdChcIi5cIik7XG4gICAgICAgIGxldCBwbGF5ZXJEYXRhID0gdGhpcy5EYXRhO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ci5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgaWYgKHVuZGVmaW5lZCAhPSBwbGF5ZXJEYXRhW3N0cltpXV0pIHtcbiAgICAgICAgICAgICAgICBwbGF5ZXJEYXRhID0gcGxheWVyRGF0YVtzdHJbaV1dO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcGxheWVyRGF0YTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcGxheWVyRGF0YTtcbiAgICB9XG4gICAgLy/lrZjlgqjmlbDmja7vvIzlsIblnKjmnKzlnLDlrZjlgqjvvIzlubblj5HpgIHnu5nmnI3liqHnq69cbiAgICBwcm90ZWN0ZWQgc3RhdGljIHNhdmVEYXRhKCkge1xuICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oR2FtZUNvbmZpZy5nYW1lTmFtZSArIFwiUGxheWVyRGF0YVwiLCBKU09OLnN0cmluZ2lmeSh0aGlzLkRhdGEpKTtcbiAgICAgICAgLy90b2RvOiDlj5HpgIHnu5nmnI3liqHnq69cbiAgICB9XG5cbiAgICAvL+S4gOS6m+mAmueUqOeahOW/q+aNt+aWueazle+8mlxuICAgIC8v6YeR5biBXG4gICAgLyoq5aKe5Yqg6YeR5biBICovXG4gICAgcHVibGljIHN0YXRpYyBhZGRHb2xkKGdvbGQ6IG51bWJlcikge1xuICAgICAgICB0aGlzLkRhdGEuZ2FtZURhdGEuYXNzZXQuZ29sZCArPSBnb2xkO1xuICAgICAgICBFdmVudE1hbmFnZXIuZW1pdChFdmVudFR5cGUuUGxheWVyRGF0YUV2ZW50LnBsYXllckRhdGFDaGFuZ2VkLCB7XG4gICAgICAgICAgICB0eXBlOiBcImdhbWVEYXRhXCIsICAgICAgICAgICAgICAgICAgICAgICAgLy/mlbDmja7nsbvlnotcbiAgICAgICAgICAgIGF0dHJpYnV0ZTogXCJnYW1lRGF0YS5hc3NldC5nb2xkXCIsICAgICAgICAvL+aVsOaNruWQjeensFxuICAgICAgICAgICAgdmFsdWU6IHRoaXMuRGF0YS5nYW1lRGF0YS5hc3NldC5nb2xkLCAgICAvL+WPmOabtOWQjueahOaVsOaNruWAvFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICog5b+r5o235pa55rOV77ya5YeP5bCR6YeR5biBXG4gICAgICogQHBhcmFtIGdvbGQgIOWHj+WwkeeahOmHkeW4geaVsOmHj1xuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgc3ViR29sZChnb2xkOiBudW1iZXIpIHtcbiAgICAgICAgaWYgKGdvbGQgPD0gdGhpcy5EYXRhLmdhbWVEYXRhLmFzc2V0LmdvbGQpIHtcbiAgICAgICAgICAgIHRoaXMuRGF0YS5nYW1lRGF0YS5hc3NldC5nb2xkIC09IGdvbGQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLkRhdGEuZ2FtZURhdGEuYXNzZXQuZ29sZCA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlBsYXllckRhdGFFdmVudC5wbGF5ZXJEYXRhQ2hhbmdlZCwge1xuICAgICAgICAgICAgdHlwZTogXCJnYW1lRGF0YVwiLCAgICAgICAgICAgICAgICAgICAgICAgIC8v5pWw5o2u57G75Z6LXG4gICAgICAgICAgICBhdHRyaWJ1dGU6IFwiZ2FtZURhdGEuYXNzZXQuZ29sZFwiLCAgICAgICAgLy/mlbDmja7lkI3np7BcbiAgICAgICAgICAgIHZhbHVlOiB0aGlzLkRhdGEuZ2FtZURhdGEuYXNzZXQuZ29sZCwgICAgLy/lj5jmm7TlkI7nmoTmlbDmja7lgLxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy/nmq7ogqRcbiAgICAvKipcbiAgICAgKiDojrflj5blvZPliY3kvb/nlKjnmoTnmq7ogqTvvIzmv4DmtLvkuobor5XnlKjnmq7ogqTml7bvvIzlsIbov5Tlm57or5XnlKjnmq7ogqRcbiAgICAgKiBAcGFyYW0gdHlwZSDnmq7ogqTnsbvlnotcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldEN1clNraW5JZCh0eXBlKSB7XG4gICAgICAgIGxldCBkYXRhOiBhbnkgPSB0aGlzLkRhdGEuZ2FtZURhdGFbdHlwZV07XG4gICAgICAgIGxldCBpZCA9IGRhdGEudHJ5O1xuICAgICAgICBpZiAoaWQgPT0gLTEpIHtcbiAgICAgICAgICAgIGlkID0gZGF0YS5jdXI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGlkO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiDop6PplIHnmq7ogqRcbiAgICAgKiBAcGFyYW0gdHlwZSAg55qu6IKk57G75Z6LXG4gICAgICogQHBhcmFtIGlkICAgIOearuiCpGlkXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyB1bmxvY2tTa2luKHR5cGUsIGlkKSB7XG4gICAgICAgIGxldCBkYXRhID0gdGhpcy5EYXRhLmdhbWVEYXRhW3R5cGVdO1xuICAgICAgICBpZiAoZGF0YS5vd25lZC5pbmRleE9mKGlkKSA+PSAwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZGF0YS5vd25lZC5wdXNoKGlkKTtcbiAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlBsYXllckRhdGFFdmVudC5wbGF5ZXJEYXRhQ2hhbmdlZCwge1xuICAgICAgICAgICAgdHlwZTogXCJnYW1lRGF0YVwiLCAgICAgICAgICAgICAgICAgICAgICAgICAgIC8v5pWw5o2u57G75Z6LXG4gICAgICAgICAgICBhdHRyaWJ1dGU6IFwiZ2FtZURhdGEuXCIgKyB0eXBlICsgXCIub3duZWRcIiwgICAvL+aVsOaNruWQjeensFxuICAgICAgICAgICAgdmFsdWU6IGRhdGEub3duZWQsICAgICAgICAgICAgICAgICAgICAgICAgICAvL+WPmOabtOWQjueahOaVsOaNruWAvFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICog6K6+572u5oyH5a6a55qu6IKk5Li65b2T5YmN5L2/55So55qE55qu6IKkXG4gICAgICogQHBhcmFtIHR5cGUgIOearuiCpOexu+Wei1xuICAgICAqIEBwYXJhbSBpZCAgICDnmq7ogqRpZFxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgc2V0Q3VyU2tpbih0eXBlLCBpZCkge1xuICAgICAgICBsZXQgZGF0YSA9IHRoaXMuRGF0YS5nYW1lRGF0YVt0eXBlXTtcbiAgICAgICAgaWYgKGRhdGEuY3VyID09IGlkKSByZXR1cm47XG4gICAgICAgIGRhdGEuY3VyID0gaWQ7XG4gICAgICAgIEV2ZW50TWFuYWdlci5lbWl0KEV2ZW50VHlwZS5QbGF5ZXJEYXRhRXZlbnQucGxheWVyRGF0YUNoYW5nZWQsIHtcbiAgICAgICAgICAgIHR5cGU6IFwiZ2FtZURhdGFcIiwgICAgICAgICAgICAgICAgICAgICAgICAgICAvL+aVsOaNruexu+Wei1xuICAgICAgICAgICAgYXR0cmlidXRlOiBcImdhbWVEYXRhLlwiICsgdHlwZSArIFwiLmN1clwiLCAgIC8v5pWw5o2u5ZCN56ewXG4gICAgICAgICAgICB2YWx1ZTogZGF0YS5jdXIsICAgICAgICAgICAgICAgICAgICAgICAgICAvL+WPmOabtOWQjueahOaVsOaNruWAvFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICog6K+V55So55qu6IKkXG4gICAgICogQHBhcmFtIHR5cGUgIOearuiCpOexu+Wei1xuICAgICAqIEBwYXJhbSBpZCAgICDnmq7ogqRpZFxuICAgICAqL1xuICAgIHByb3RlY3RlZCBzdGF0aWMgb25UcnlTa2luKHR5cGUsIGlkKSB7XG4gICAgICAgIHRoaXMuRGF0YS5nYW1lRGF0YVt0eXBlXS50cnkgPSBpZDtcbiAgICB9XG4gICAgLyoqXG4gICAgICog55qu6IKk6K+V55So57uT5p2fXG4gICAgICogQHBhcmFtIHR5cGUgIOearuiCpOexu+Wei1xuICAgICAqL1xuICAgIHByb3RlY3RlZCBzdGF0aWMgb25UcnlTa2luRW5kKHR5cGUpIHtcbiAgICAgICAgdGhpcy5EYXRhLmdhbWVEYXRhW3R5cGVdLnRyeSA9IC0xO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgc3RhdGljIHJlc2V0VHJ5U2tpbigpIHtcbiAgICAgICAgbGV0IGRhdGEgPSB0aGlzLkRhdGEuZ2FtZURhdGE7XG4gICAgICAgIGZvciAobGV0IGtleSBpbiBkYXRhKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIGRhdGFba2V5XSA9PSBcIm9iamVjdFwiICYmICEhZGF0YVtrZXldLnRyeSkge1xuICAgICAgICAgICAgICAgIGRhdGFba2V5XS50cnkgPSAtMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuXG59XG4iXX0=