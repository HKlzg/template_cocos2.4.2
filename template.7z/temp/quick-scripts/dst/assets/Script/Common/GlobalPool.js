
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Common/GlobalPool.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ae615r/ewxBWItVZs4jX0Qa', 'GlobalPool');
// Script/Common/GlobalPool.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoNodePool = void 0;
/**全局节点对象池 */
var GlobalPool = /** @class */ (function () {
    function GlobalPool() {
    }
    /**
     * 创建新的对象池
     * @param nodeName 节点名称
     * @param prefab 节点预制资源
     * @param scriptName 节点上挂载的脚本名称，必须实现接口IPoolObject，用于处理节点进出对象池时的逻辑
     */
    GlobalPool.createPool = function (nodeName, prefab, scriptName) {
        if (this.allPools.hasOwnProperty(nodeName)) {
            console.warn("已存在该名称的对象池，请确认是否名字冲突：", nodeName);
            return;
        }
        this.allPools[nodeName] = new AutoNodePool(prefab, scriptName);
    };
    /**
     * 获取实例
     * @param nodeName 要获取的节点名称
     * @param data 节点需要的数据
     * @returns {cc.Node} 按传入的数据进行设置的节点实例
     */
    GlobalPool.get = function (nodeName, data) {
        if (!this.allPools[nodeName]) {
            console.error("未创建对应名称的对象池，获取实例失败：", nodeName);
            return null;
        }
        return this.allPools[nodeName].get(data);
    };
    /**
     * 回收节点
     * @param nodeName 节点名称，与节点要放回的对象池名称对应
     * @param node 回收的节点
     */
    GlobalPool.put = function (node, nodeName) {
        if (!nodeName)
            nodeName = node.name;
        if (!this.allPools[nodeName]) {
            console.warn("未创建对应名称的对象池，将销毁节点：", nodeName);
            var js = node.getComponent(nodeName);
            if (!!js && !!js.unuse) {
                js.unuse();
            }
            node.destroy();
            return;
        }
        this.allPools[nodeName].put(node);
    };
    /**
     * 回收节点的所有子节点
     * @param node
     * @param sameNode  是否所有子节点为相同名字的节点，为true时可极轻微地加快回收速度
     */
    GlobalPool.putAllChildren = function (node, sameNode) {
        if (sameNode === void 0) { sameNode = false; }
        if (node.children.length == 0)
            return;
        if (!!sameNode) {
            var nodeName = node.children[0].name;
            if (!!this.allPools[nodeName]) {
                var pool = this.allPools[nodeName];
                for (var i = node.children.length - 1; i >= 0; --i) {
                    pool.put(node.children[i]);
                }
            }
            else {
                for (var i = node.children.length - 1; i >= 0; --i) {
                    var js = node.children[i].getComponent(nodeName);
                    if (!!js && !!js.unuse) {
                        js.unuse();
                    }
                    node.destroy();
                }
            }
        }
        else {
            for (var i = node.children.length - 1; i >= 0; --i) {
                var child = node.children[i];
                this.put(child);
            }
        }
    };
    /**
     * 清空对象池缓存，未指定名称时将清空所有的对象池
     * @param nodeName 对象池名称
     */
    GlobalPool.clear = function (nodeName) {
        if (!!nodeName) {
            if (this.allPools.hasOwnProperty(nodeName)) {
                this.allPools[nodeName].clear();
                delete this.allPools[nodeName];
            }
        }
        else {
            for (var key in this.allPools) {
                this.allPools[key].clear();
            }
            this.allPools = {};
        }
    };
    /**获取指定对象池中的可用对象数量 */
    GlobalPool.getSize = function (nodeName) {
        if (!!this.allPools[nodeName]) {
            return this.allPools[nodeName].count;
        }
        else {
            return 0;
        }
    };
    /**
     * 预先创建指定数量的对象并存储在对象池中
     * @param nodeName  与预制件名称对应的对象池名称
     * @param count     要创建的对象数量
     */
    GlobalPool.preCreate = function (nodeName, count) {
        if (!!this.allPools[nodeName]) {
            this.allPools[nodeName].preCreate(count);
        }
        else {
            console.warn("不存在对应名称的对象池，无法预先创建实例：", nodeName);
        }
    };
    GlobalPool.allPools = {};
    return GlobalPool;
}());
exports.default = GlobalPool;
/**
 * 节点对象池，对象池为空时可自动实例化新的对象
 */
var AutoNodePool = /** @class */ (function () {
    /**
     * 节点对象池，对象池为空时可自动实例化新的对象
     * @param prefab 预制
     * @param scriptName 节点挂载的脚本，管理节点进出对象池时的逻辑，必须实现接口IPoolObject
     */
    function AutoNodePool(prefab, scriptName) {
        this.prefab = prefab;
        this.scripteName = scriptName;
        this.pool = new cc.NodePool(scriptName);
    }
    /**
     * 获取实例
     * @param data 给实例赋值的数据
     */
    AutoNodePool.prototype.get = function (data) {
        var item = this.pool.get(data);
        if (!item) {
            item = cc.instantiate(this.prefab);
            if (!!this.scripteName) {
                var s = item.getComponent(this.scripteName);
                if (!!s) {
                    s.init(data);
                }
                else {
                    this.scripteName = null;
                }
            }
        }
        return item;
    };
    /**
     * 回收节点
     * @param item
     */
    AutoNodePool.prototype.put = function (item) {
        this.pool.put(item);
    };
    /**
     * 清空对象池，将销毁所有缓存的实例
     */
    AutoNodePool.prototype.clear = function () {
        this.pool.clear();
    };
    Object.defineProperty(AutoNodePool.prototype, "count", {
        /**对象池中已存储的对象数量 */
        get: function () {
            return this.pool.size();
        },
        enumerable: false,
        configurable: true
    });
    /**预先创建指定数量的对象存储在对象池中 */
    AutoNodePool.prototype.preCreate = function (count) {
        var c = count - this.count;
        if (c <= 0)
            return;
        for (var i = 0; i < c; ++i) {
            var item = cc.instantiate(this.prefab);
            if (!!this.scripteName) {
                var s = item.getComponent(this.scripteName);
                if (!!s) {
                    s.init();
                }
                else {
                    this.scripteName = null;
                }
            }
            this.put(item);
        }
    };
    return AutoNodePool;
}());
exports.AutoNodePool = AutoNodePool;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXEdsb2JhbFBvb2wudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsYUFBYTtBQUNiO0lBQUE7SUFrSEEsQ0FBQztJQWhIRzs7Ozs7T0FLRztJQUNXLHFCQUFVLEdBQXhCLFVBQXlCLFFBQWdCLEVBQUUsTUFBaUIsRUFBRSxVQUFtQjtRQUM3RSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hDLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDaEQsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUNEOzs7OztPQUtHO0lBQ1csY0FBRyxHQUFqQixVQUFrQixRQUFnQixFQUFFLElBQVU7UUFDMUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDMUIsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUMvQyxPQUFPLElBQUksQ0FBQztTQUNmO1FBQ0QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0Q7Ozs7T0FJRztJQUNXLGNBQUcsR0FBakIsVUFBa0IsSUFBYSxFQUFFLFFBQWlCO1FBQzlDLElBQUksQ0FBQyxRQUFRO1lBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDMUIsT0FBTyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUM3QyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRTtnQkFDcEIsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ2Q7WUFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDZixPQUFPO1NBQ1Y7UUFDRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0Q7Ozs7T0FJRztJQUNXLHlCQUFjLEdBQTVCLFVBQTZCLElBQWEsRUFBRSxRQUF5QjtRQUF6Qix5QkFBQSxFQUFBLGdCQUF5QjtRQUNqRSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLENBQUM7WUFBRSxPQUFPO1FBQ3RDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRTtZQUNaLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ3JDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzNCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ25DLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ2hELElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM5QjthQUNKO2lCQUFNO2dCQUNILEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ2hELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBUSxDQUFDO29CQUN4RCxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLEVBQUU7d0JBQ3BCLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztxQkFDZDtvQkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7aUJBQ2xCO2FBQ0o7U0FDSjthQUFNO1lBQ0gsS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDaEQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNuQjtTQUNKO0lBQ0wsQ0FBQztJQUNEOzs7T0FHRztJQUNXLGdCQUFLLEdBQW5CLFVBQW9CLFFBQWlCO1FBQ2pDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRTtZQUNaLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQ3hDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ2hDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUNsQztTQUNKO2FBQU07WUFDSCxLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQzNCLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDOUI7WUFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztTQUN0QjtJQUNMLENBQUM7SUFFRCxxQkFBcUI7SUFDUCxrQkFBTyxHQUFyQixVQUFzQixRQUFnQjtRQUNsQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzNCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUM7U0FDeEM7YUFBTTtZQUNILE9BQU8sQ0FBQyxDQUFDO1NBQ1o7SUFDTCxDQUFDO0lBQ0Q7Ozs7T0FJRztJQUNXLG9CQUFTLEdBQXZCLFVBQXdCLFFBQWdCLEVBQUUsS0FBYTtRQUNuRCxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzNCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzVDO2FBQU07WUFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQ25EO0lBQ0wsQ0FBQztJQWhIYyxtQkFBUSxHQUF5QyxFQUFFLENBQUM7SUFpSHZFLGlCQUFDO0NBbEhELEFBa0hDLElBQUE7a0JBbEhvQixVQUFVO0FBb0gvQjs7R0FFRztBQUNIO0lBSUk7Ozs7T0FJRztJQUNILHNCQUFZLE1BQWlCLEVBQUUsVUFBbUI7UUFDOUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUM7UUFDOUIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVEOzs7T0FHRztJQUNJLDBCQUFHLEdBQVYsVUFBVyxJQUFVO1FBQ2pCLElBQUksSUFBSSxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDUCxJQUFJLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbkMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDcEIsSUFBSSxDQUFDLEdBQWdCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUN6RCxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ0wsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDaEI7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7aUJBQzNCO2FBQ0o7U0FDSjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7O09BR0c7SUFDSSwwQkFBRyxHQUFWLFVBQVcsSUFBYTtRQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN4QixDQUFDO0lBRUQ7O09BRUc7SUFDSSw0QkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBR0Qsc0JBQVcsK0JBQUs7UUFEaEIsa0JBQWtCO2FBQ2xCO1lBQ0ksT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzVCLENBQUM7OztPQUFBO0lBQ0Qsd0JBQXdCO0lBQ2pCLGdDQUFTLEdBQWhCLFVBQWlCLEtBQWE7UUFDMUIsSUFBSSxDQUFDLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQztZQUFFLE9BQU87UUFDbkIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN4QixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUNwQixJQUFJLENBQUMsR0FBZ0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ3pELElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDTCxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7aUJBQ1o7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7aUJBQzNCO2FBQ0o7WUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ2xCO0lBQ0wsQ0FBQztJQUNMLG1CQUFDO0FBQUQsQ0F2RUEsQUF1RUMsSUFBQTtBQXZFWSxvQ0FBWSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qKuWFqOWxgOiKgueCueWvueixoeaxoCAqL1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHbG9iYWxQb29sIHtcclxuICAgIHByaXZhdGUgc3RhdGljIGFsbFBvb2xzOiB7IFtub2RlTmFtZTogc3RyaW5nXTogQXV0b05vZGVQb29sIH0gPSB7fTtcclxuICAgIC8qKlxyXG4gICAgICog5Yib5bu65paw55qE5a+56LGh5rGgXHJcbiAgICAgKiBAcGFyYW0gbm9kZU5hbWUg6IqC54K55ZCN56ewXHJcbiAgICAgKiBAcGFyYW0gcHJlZmFiIOiKgueCuemihOWItui1hOa6kFxyXG4gICAgICogQHBhcmFtIHNjcmlwdE5hbWUg6IqC54K55LiK5oyC6L2955qE6ISa5pys5ZCN56ew77yM5b+F6aG75a6e546w5o6l5Y+jSVBvb2xPYmplY3TvvIznlKjkuo7lpITnkIboioLngrnov5vlh7rlr7nosaHmsaDml7bnmoTpgLvovpFcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVQb29sKG5vZGVOYW1lOiBzdHJpbmcsIHByZWZhYjogY2MuUHJlZmFiLCBzY3JpcHROYW1lPzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuYWxsUG9vbHMuaGFzT3duUHJvcGVydHkobm9kZU5hbWUpKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcIuW3suWtmOWcqOivpeWQjeensOeahOWvueixoeaxoO+8jOivt+ehruiupOaYr+WQpuWQjeWtl+WGsueqge+8mlwiLCBub2RlTmFtZSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5hbGxQb29sc1tub2RlTmFtZV0gPSBuZXcgQXV0b05vZGVQb29sKHByZWZhYiwgc2NyaXB0TmFtZSk7XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOiOt+WPluWunuS+i1xyXG4gICAgICogQHBhcmFtIG5vZGVOYW1lIOimgeiOt+WPlueahOiKgueCueWQjeensFxyXG4gICAgICogQHBhcmFtIGRhdGEg6IqC54K56ZyA6KaB55qE5pWw5o2uXHJcbiAgICAgKiBAcmV0dXJucyB7Y2MuTm9kZX0g5oyJ5Lyg5YWl55qE5pWw5o2u6L+b6KGM6K6+572u55qE6IqC54K55a6e5L6LXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0KG5vZGVOYW1lOiBzdHJpbmcsIGRhdGE/OiBhbnkpOiBjYy5Ob2RlIHtcclxuICAgICAgICBpZiAoIXRoaXMuYWxsUG9vbHNbbm9kZU5hbWVdKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCLmnKrliJvlu7rlr7nlupTlkI3np7DnmoTlr7nosaHmsaDvvIzojrflj5blrp7kvovlpLHotKXvvJpcIiwgbm9kZU5hbWUpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYWxsUG9vbHNbbm9kZU5hbWVdLmdldChkYXRhKTtcclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog5Zue5pS26IqC54K5XHJcbiAgICAgKiBAcGFyYW0gbm9kZU5hbWUg6IqC54K55ZCN56ew77yM5LiO6IqC54K56KaB5pS+5Zue55qE5a+56LGh5rGg5ZCN56ew5a+55bqUXHJcbiAgICAgKiBAcGFyYW0gbm9kZSDlm57mlLbnmoToioLngrlcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBwdXQobm9kZTogY2MuTm9kZSwgbm9kZU5hbWU/OiBzdHJpbmcpIHtcclxuICAgICAgICBpZiAoIW5vZGVOYW1lKSBub2RlTmFtZSA9IG5vZGUubmFtZTtcclxuICAgICAgICBpZiAoIXRoaXMuYWxsUG9vbHNbbm9kZU5hbWVdKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcIuacquWIm+W7uuWvueW6lOWQjeensOeahOWvueixoeaxoO+8jOWwhumUgOavgeiKgueCue+8mlwiLCBub2RlTmFtZSk7XHJcbiAgICAgICAgICAgIGxldCBqcyA9IG5vZGUuZ2V0Q29tcG9uZW50KG5vZGVOYW1lKTtcclxuICAgICAgICAgICAgaWYgKCEhanMgJiYgISFqcy51bnVzZSkge1xyXG4gICAgICAgICAgICAgICAganMudW51c2UoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBub2RlLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmFsbFBvb2xzW25vZGVOYW1lXS5wdXQobm9kZSk7XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOWbnuaUtuiKgueCueeahOaJgOacieWtkOiKgueCuVxyXG4gICAgICogQHBhcmFtIG5vZGUgXHJcbiAgICAgKiBAcGFyYW0gc2FtZU5vZGUgIOaYr+WQpuaJgOacieWtkOiKgueCueS4uuebuOWQjOWQjeWtl+eahOiKgueCue+8jOS4unRydWXml7blj6/mnoHovbvlvq7lnLDliqDlv6vlm57mlLbpgJ/luqZcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBwdXRBbGxDaGlsZHJlbihub2RlOiBjYy5Ob2RlLCBzYW1lTm9kZTogYm9vbGVhbiA9IGZhbHNlKSB7XHJcbiAgICAgICAgaWYgKG5vZGUuY2hpbGRyZW4ubGVuZ3RoID09IDApIHJldHVybjtcclxuICAgICAgICBpZiAoISFzYW1lTm9kZSkge1xyXG4gICAgICAgICAgICBsZXQgbm9kZU5hbWUgPSBub2RlLmNoaWxkcmVuWzBdLm5hbWU7XHJcbiAgICAgICAgICAgIGlmICghIXRoaXMuYWxsUG9vbHNbbm9kZU5hbWVdKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcG9vbCA9IHRoaXMuYWxsUG9vbHNbbm9kZU5hbWVdO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IG5vZGUuY2hpbGRyZW4ubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgICAgICAgICBwb29sLnB1dChub2RlLmNoaWxkcmVuW2ldKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSBub2RlLmNoaWxkcmVuLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGpzID0gbm9kZS5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQobm9kZU5hbWUpIGFzIGFueTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoISFqcyAmJiAhIWpzLnVudXNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGpzLnVudXNlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG5vZGUuZGVzdHJveSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IG5vZGUuY2hpbGRyZW4ubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgICAgIGxldCBjaGlsZCA9IG5vZGUuY2hpbGRyZW5baV07XHJcbiAgICAgICAgICAgICAgICB0aGlzLnB1dChjaGlsZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOa4heepuuWvueixoeaxoOe8k+WtmO+8jOacquaMh+WumuWQjeensOaXtuWwhua4heepuuaJgOacieeahOWvueixoeaxoFxyXG4gICAgICogQHBhcmFtIG5vZGVOYW1lIOWvueixoeaxoOWQjeensFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGNsZWFyKG5vZGVOYW1lPzogc3RyaW5nKSB7XHJcbiAgICAgICAgaWYgKCEhbm9kZU5hbWUpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuYWxsUG9vbHMuaGFzT3duUHJvcGVydHkobm9kZU5hbWUpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsbFBvb2xzW25vZGVOYW1lXS5jbGVhcigpO1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIHRoaXMuYWxsUG9vbHNbbm9kZU5hbWVdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuYWxsUG9vbHMpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWxsUG9vbHNba2V5XS5jbGVhcigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuYWxsUG9vbHMgPSB7fTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoq6I635Y+W5oyH5a6a5a+56LGh5rGg5Lit55qE5Y+v55So5a+56LGh5pWw6YePICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGdldFNpemUobm9kZU5hbWU6IHN0cmluZykge1xyXG4gICAgICAgIGlmICghIXRoaXMuYWxsUG9vbHNbbm9kZU5hbWVdKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmFsbFBvb2xzW25vZGVOYW1lXS5jb3VudDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gMDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOmihOWFiOWIm+W7uuaMh+WumuaVsOmHj+eahOWvueixoeW5tuWtmOWCqOWcqOWvueixoeaxoOS4rVxyXG4gICAgICogQHBhcmFtIG5vZGVOYW1lICDkuI7pooTliLbku7blkI3np7Dlr7nlupTnmoTlr7nosaHmsaDlkI3np7BcclxuICAgICAqIEBwYXJhbSBjb3VudCAgICAg6KaB5Yib5bu655qE5a+56LGh5pWw6YePXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgcHJlQ3JlYXRlKG5vZGVOYW1lOiBzdHJpbmcsIGNvdW50OiBudW1iZXIpIHtcclxuICAgICAgICBpZiAoISF0aGlzLmFsbFBvb2xzW25vZGVOYW1lXSkge1xyXG4gICAgICAgICAgICB0aGlzLmFsbFBvb2xzW25vZGVOYW1lXS5wcmVDcmVhdGUoY291bnQpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcIuS4jeWtmOWcqOWvueW6lOWQjeensOeahOWvueixoeaxoO+8jOaXoOazlemihOWFiOWIm+W7uuWunuS+i++8mlwiLCBub2RlTmFtZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICog6IqC54K55a+56LGh5rGg77yM5a+56LGh5rGg5Li656m65pe25Y+v6Ieq5Yqo5a6e5L6L5YyW5paw55qE5a+56LGhXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgQXV0b05vZGVQb29sIHtcclxuICAgIHByaXZhdGUgcHJlZmFiOiBjYy5QcmVmYWI7XHJcbiAgICBwcml2YXRlIHNjcmlwdGVOYW1lOiBzdHJpbmc7XHJcbiAgICBwcml2YXRlIHBvb2w6IGNjLk5vZGVQb29sO1xyXG4gICAgLyoqXHJcbiAgICAgKiDoioLngrnlr7nosaHmsaDvvIzlr7nosaHmsaDkuLrnqbrml7blj6/oh6rliqjlrp7kvovljJbmlrDnmoTlr7nosaFcclxuICAgICAqIEBwYXJhbSBwcmVmYWIg6aKE5Yi2XHJcbiAgICAgKiBAcGFyYW0gc2NyaXB0TmFtZSDoioLngrnmjILovb3nmoTohJrmnKzvvIznrqHnkIboioLngrnov5vlh7rlr7nosaHmsaDml7bnmoTpgLvovpHvvIzlv4Xpobvlrp7njrDmjqXlj6NJUG9vbE9iamVjdFxyXG4gICAgICovXHJcbiAgICBjb25zdHJ1Y3RvcihwcmVmYWI6IGNjLlByZWZhYiwgc2NyaXB0TmFtZT86IHN0cmluZykge1xyXG4gICAgICAgIHRoaXMucHJlZmFiID0gcHJlZmFiO1xyXG4gICAgICAgIHRoaXMuc2NyaXB0ZU5hbWUgPSBzY3JpcHROYW1lO1xyXG4gICAgICAgIHRoaXMucG9vbCA9IG5ldyBjYy5Ob2RlUG9vbChzY3JpcHROYW1lKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOiOt+WPluWunuS+i1xyXG4gICAgICogQHBhcmFtIGRhdGEg57uZ5a6e5L6L6LWL5YC855qE5pWw5o2uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXQoZGF0YT86IGFueSk6IGNjLk5vZGUge1xyXG4gICAgICAgIGxldCBpdGVtOiBjYy5Ob2RlID0gdGhpcy5wb29sLmdldChkYXRhKTtcclxuICAgICAgICBpZiAoIWl0ZW0pIHtcclxuICAgICAgICAgICAgaXRlbSA9IGNjLmluc3RhbnRpYXRlKHRoaXMucHJlZmFiKTtcclxuICAgICAgICAgICAgaWYgKCEhdGhpcy5zY3JpcHRlTmFtZSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHM6IElQb29sT2JqZWN0ID0gaXRlbS5nZXRDb21wb25lbnQodGhpcy5zY3JpcHRlTmFtZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoISFzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcy5pbml0KGRhdGEpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNjcmlwdGVOYW1lID0gbnVsbDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gaXRlbTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOWbnuaUtuiKgueCuVxyXG4gICAgICogQHBhcmFtIGl0ZW1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHB1dChpdGVtOiBjYy5Ob2RlKSB7XHJcbiAgICAgICAgdGhpcy5wb29sLnB1dChpdGVtKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOa4heepuuWvueixoeaxoO+8jOWwhumUgOavgeaJgOaciee8k+WtmOeahOWunuS+i1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgY2xlYXIoKSB7XHJcbiAgICAgICAgdGhpcy5wb29sLmNsZWFyKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoq5a+56LGh5rGg5Lit5bey5a2Y5YKo55qE5a+56LGh5pWw6YePICovXHJcbiAgICBwdWJsaWMgZ2V0IGNvdW50KCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnBvb2wuc2l6ZSgpO1xyXG4gICAgfVxyXG4gICAgLyoq6aKE5YWI5Yib5bu65oyH5a6a5pWw6YeP55qE5a+56LGh5a2Y5YKo5Zyo5a+56LGh5rGg5LitICovXHJcbiAgICBwdWJsaWMgcHJlQ3JlYXRlKGNvdW50OiBudW1iZXIpIHtcclxuICAgICAgICBsZXQgYyA9IGNvdW50IC0gdGhpcy5jb3VudDtcclxuICAgICAgICBpZiAoYyA8PSAwKSByZXR1cm47XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjOyArK2kpIHtcclxuICAgICAgICAgICAgbGV0IGl0ZW0gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnByZWZhYik7XHJcbiAgICAgICAgICAgIGlmICghIXRoaXMuc2NyaXB0ZU5hbWUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzOiBJUG9vbE9iamVjdCA9IGl0ZW0uZ2V0Q29tcG9uZW50KHRoaXMuc2NyaXB0ZU5hbWUpO1xyXG4gICAgICAgICAgICAgICAgaWYgKCEhcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHMuaW5pdCgpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNjcmlwdGVOYW1lID0gbnVsbDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLnB1dChpdGVtKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8v5Y+v5pS+5YWl5a+56LGh5rGg55qE5a+56LGh55qE5o6l5Y+jXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVBvb2xPYmplY3Qge1xyXG4gICAgLyoqXHJcbiAgICAgKiDlr7nosaHmsaDkuK3liJvlu7rmlrDnmoTlrp7kvovml7bvvIzlsIbosIPnlKjmraTlh73mlbDliJ3lp4vljJblrp7kvotcclxuICAgICAqL1xyXG4gICAgaW5pdDogKGRhdGE/OiBhbnkpID0+IHZvaWQ7XHJcbiAgICAvKipcclxuICAgICAqIOWvueixoeaxoOS4reW3sue7j+WtmOWcqOeahOWunuS+i+mHjeaWsOWPluWHuuS9v+eUqOaXtu+8jOWwhuiwg+eUqOatpOWHveaVsFxyXG4gICAgICovXHJcbiAgICByZXVzZTogKGRhdGE/OiBhbnkpID0+IHZvaWQ7XHJcbiAgICAvKipcclxuICAgICAqIOiKgueCueaUvuWbnuWvueixoeaxoOaXtuWwhuiwg+eUqOeahOWHveaVsFxyXG4gICAgICovXHJcbiAgICB1bnVzZTogKCkgPT4gdm9pZDtcclxufSJdfQ==