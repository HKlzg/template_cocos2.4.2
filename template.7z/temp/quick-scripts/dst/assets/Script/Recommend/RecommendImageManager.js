
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Recommend/RecommendImageManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '18302fHUq5LtrvfsvUJVvFS', 'RecommendImageManager');
// Script/Recommend/RecommendImageManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MyAtlas_1 = require("./MyAtlas");
/**
 * 互推模块纹理管理器，将大量的小图存入同一张大的纹理中,
 * 显示图片的节点需挂载 MyAtlasSprite 取代 cc.Sprite，并调用其 setAtlasData 方法显示对应的图片
 */
var RecommendImageManager = /** @class */ (function () {
    function RecommendImageManager() {
    }
    Object.defineProperty(RecommendImageManager, "atlas", {
        get: function () {
            if (!this._atlas) {
                this._atlas = new MyAtlas_1.default();
            }
            return this._atlas;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 从远程地址加载图片并添加到图集中
     * @param url
     * @param cb 给挂载了 MyAtlasSprite 组件的节点设置要显示的图片，例如：(data) => { node.getComponent(MyAtlasSprite).setAtlasData(data); }
     */
    RecommendImageManager.load = function (url, cb) {
        var _this = this;
        var sf = this.get(url);
        if (!!sf) {
            if (!!cb)
                cb(sf);
            return;
        }
        cc.assetManager.loadRemote(url, function (err, res) {
            if (!!err) {
                console.log("互推远程图片下载错误：", err);
                return;
            }
            var sf = new cc.SpriteFrame(res);
            var uv = _this.atlas.insertSpriteFrame(sf, url);
            if (!!cb)
                cb({
                    spriteFrame: _this.atlas.getSpriteFrame(),
                    texture: _this.atlas.getTexture(),
                    uv: uv,
                });
        });
    };
    /**
     * 从图集中获取小图信息
     * @param url
     */
    RecommendImageManager.get = function (url) {
        var uv = this.atlas.getUV(url);
        if (!uv)
            return null;
        return {
            spriteFrame: this.atlas.getSpriteFrame(),
            texture: this.atlas.getTexture(),
            uv: this.atlas.getUV(url),
        };
    };
    /**
     * 将已有的图片添加到图集中
     * @param sf
     * @param url 图片名称
     * @param cb
     */
    RecommendImageManager.add = function (sf, url, cb) {
        var name = url;
        if (undefined === url || typeof url != "string") {
            name = sf._uuid;
        }
        var uv = this.atlas.insertSpriteFrame(sf, name);
        if (typeof url === "function") {
            cb = url;
        }
        if (!!cb)
            cb({
                spriteFrame: this.atlas.getSpriteFrame(),
                texture: this.atlas.getTexture(),
                uv: uv,
            });
    };
    RecommendImageManager.sfMap = {};
    return RecommendImageManager;
}());
exports.default = RecommendImageManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxSZWNvbW1lbmRcXFJlY29tbWVuZEltYWdlTWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHFDQUFnQztBQUVoQzs7O0dBR0c7QUFDSDtJQUFBO0lBdUVBLENBQUM7SUFuRUcsc0JBQXFCLDhCQUFLO2FBQTFCO1lBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLGlCQUFPLEVBQUUsQ0FBQzthQUMvQjtZQUNELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUN2QixDQUFDOzs7T0FBQTtJQUVEOzs7O09BSUc7SUFDVywwQkFBSSxHQUFsQixVQUFtQixHQUFXLEVBQUUsRUFBYTtRQUE3QyxpQkFtQkM7UUFsQkcsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN2QixJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDTixJQUFJLENBQUMsQ0FBQyxFQUFFO2dCQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNqQixPQUFPO1NBQ1Y7UUFDRCxFQUFFLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsVUFBQyxHQUFHLEVBQUUsR0FBRztZQUNyQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7Z0JBQ1AsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ2hDLE9BQU87YUFDVjtZQUNELElBQUksRUFBRSxHQUFHLElBQUksRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQyxJQUFJLEVBQUUsR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsQ0FBQyxFQUFFO2dCQUFFLEVBQUUsQ0FBQztvQkFDVCxXQUFXLEVBQUUsS0FBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUU7b0JBQ3hDLE9BQU8sRUFBRSxLQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtvQkFDaEMsRUFBRSxFQUFFLEVBQUU7aUJBQ1QsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7OztPQUdHO0lBQ1cseUJBQUcsR0FBakIsVUFBa0IsR0FBVztRQUN6QixJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsRUFBRTtZQUFFLE9BQU8sSUFBSSxDQUFDO1FBQ3JCLE9BQU87WUFDSCxXQUFXLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUU7WUFDeEMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO1lBQ2hDLEVBQUUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7U0FDNUIsQ0FBQztJQUNOLENBQUM7SUFDRDs7Ozs7T0FLRztJQUNXLHlCQUFHLEdBQWpCLFVBQWtCLEVBQWtCLEVBQUUsR0FBWSxFQUFFLEVBQWE7UUFDN0QsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDO1FBQ2YsSUFBSSxTQUFTLEtBQUssR0FBRyxJQUFJLE9BQU8sR0FBRyxJQUFJLFFBQVEsRUFBRTtZQUM3QyxJQUFJLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQztTQUNuQjtRQUNELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2hELElBQUksT0FBTyxHQUFHLEtBQUssVUFBVSxFQUFFO1lBQzNCLEVBQUUsR0FBRyxHQUFHLENBQUM7U0FDWjtRQUNELElBQUksQ0FBQyxDQUFDLEVBQUU7WUFBRSxFQUFFLENBQUM7Z0JBQ1QsV0FBVyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFO2dCQUN4QyxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7Z0JBQ2hDLEVBQUUsRUFBRSxFQUFFO2FBQ1QsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQXBFZ0IsMkJBQUssR0FBc0MsRUFBRSxDQUFDO0lBcUVuRSw0QkFBQztDQXZFRCxBQXVFQyxJQUFBO2tCQXZFb0IscUJBQXFCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE15QXRsYXMgZnJvbSBcIi4vTXlBdGxhc1wiO1xyXG5cclxuLyoqXHJcbiAqIOS6kuaOqOaooeWdl+e6ueeQhueuoeeQhuWZqO+8jOWwhuWkp+mHj+eahOWwj+WbvuWtmOWFpeWQjOS4gOW8oOWkp+eahOe6ueeQhuS4rSxcclxuICog5pi+56S65Zu+54mH55qE6IqC54K56ZyA5oyC6L29IE15QXRsYXNTcHJpdGUg5Y+W5LujIGNjLlNwcml0Ze+8jOW5tuiwg+eUqOWFtiBzZXRBdGxhc0RhdGEg5pa55rOV5pi+56S65a+55bqU55qE5Zu+54mHXHJcbiAqL1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZWNvbW1lbmRJbWFnZU1hbmFnZXIge1xyXG5cclxuICAgIHByb3RlY3RlZCBzdGF0aWMgc2ZNYXA6IHsgW3VybDogc3RyaW5nXTogY2MuU3ByaXRlRnJhbWUgfSA9IHt9O1xyXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBfYXRsYXM6IE15QXRsYXM7XHJcbiAgICBwcm90ZWN0ZWQgc3RhdGljIGdldCBhdGxhcygpIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2F0bGFzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2F0bGFzID0gbmV3IE15QXRsYXMoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2F0bGFzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5LuO6L+c56iL5Zyw5Z2A5Yqg6L295Zu+54mH5bm25re75Yqg5Yiw5Zu+6ZuG5LitXHJcbiAgICAgKiBAcGFyYW0gdXJsIFxyXG4gICAgICogQHBhcmFtIGNiIOe7meaMgui9veS6hiBNeUF0bGFzU3ByaXRlIOe7hOS7tueahOiKgueCueiuvue9ruimgeaYvuekuueahOWbvueJh++8jOS+i+Wmgu+8mihkYXRhKSA9PiB7IG5vZGUuZ2V0Q29tcG9uZW50KE15QXRsYXNTcHJpdGUpLnNldEF0bGFzRGF0YShkYXRhKTsgfVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGxvYWQodXJsOiBzdHJpbmcsIGNiPzogRnVuY3Rpb24pIHtcclxuICAgICAgICBsZXQgc2YgPSB0aGlzLmdldCh1cmwpO1xyXG4gICAgICAgIGlmICghIXNmKSB7XHJcbiAgICAgICAgICAgIGlmICghIWNiKSBjYihzZik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2MuYXNzZXRNYW5hZ2VyLmxvYWRSZW1vdGUodXJsLCAoZXJyLCByZXMpID0+IHtcclxuICAgICAgICAgICAgaWYgKCEhZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuS6kuaOqOi/nOeoi+WbvueJh+S4i+i9vemUmeivr++8mlwiLCBlcnIpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCBzZiA9IG5ldyBjYy5TcHJpdGVGcmFtZShyZXMpO1xyXG4gICAgICAgICAgICBsZXQgdXYgPSB0aGlzLmF0bGFzLmluc2VydFNwcml0ZUZyYW1lKHNmLCB1cmwpO1xyXG4gICAgICAgICAgICBpZiAoISFjYikgY2Ioe1xyXG4gICAgICAgICAgICAgICAgc3ByaXRlRnJhbWU6IHRoaXMuYXRsYXMuZ2V0U3ByaXRlRnJhbWUoKSxcclxuICAgICAgICAgICAgICAgIHRleHR1cmU6IHRoaXMuYXRsYXMuZ2V0VGV4dHVyZSgpLFxyXG4gICAgICAgICAgICAgICAgdXY6IHV2LFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOS7juWbvumbhuS4reiOt+WPluWwj+WbvuS/oeaBr1xyXG4gICAgICogQHBhcmFtIHVybCBcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBnZXQodXJsOiBzdHJpbmcpIHtcclxuICAgICAgICBsZXQgdXYgPSB0aGlzLmF0bGFzLmdldFVWKHVybCk7XHJcbiAgICAgICAgaWYgKCF1dikgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc3ByaXRlRnJhbWU6IHRoaXMuYXRsYXMuZ2V0U3ByaXRlRnJhbWUoKSxcclxuICAgICAgICAgICAgdGV4dHVyZTogdGhpcy5hdGxhcy5nZXRUZXh0dXJlKCksXHJcbiAgICAgICAgICAgIHV2OiB0aGlzLmF0bGFzLmdldFVWKHVybCksXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog5bCG5bey5pyJ55qE5Zu+54mH5re75Yqg5Yiw5Zu+6ZuG5LitXHJcbiAgICAgKiBAcGFyYW0gc2YgICAgXHJcbiAgICAgKiBAcGFyYW0gdXJsIOWbvueJh+WQjeensFxyXG4gICAgICogQHBhcmFtIGNiIFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGFkZChzZjogY2MuU3ByaXRlRnJhbWUsIHVybD86IHN0cmluZywgY2I/OiBGdW5jdGlvbikge1xyXG4gICAgICAgIGxldCBuYW1lID0gdXJsO1xyXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IHVybCB8fCB0eXBlb2YgdXJsICE9IFwic3RyaW5nXCIpIHtcclxuICAgICAgICAgICAgbmFtZSA9IHNmLl91dWlkO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgdXYgPSB0aGlzLmF0bGFzLmluc2VydFNwcml0ZUZyYW1lKHNmLCBuYW1lKTtcclxuICAgICAgICBpZiAodHlwZW9mIHVybCA9PT0gXCJmdW5jdGlvblwiKSB7XHJcbiAgICAgICAgICAgIGNiID0gdXJsO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoISFjYikgY2Ioe1xyXG4gICAgICAgICAgICBzcHJpdGVGcmFtZTogdGhpcy5hdGxhcy5nZXRTcHJpdGVGcmFtZSgpLFxyXG4gICAgICAgICAgICB0ZXh0dXJlOiB0aGlzLmF0bGFzLmdldFRleHR1cmUoKSxcclxuICAgICAgICAgICAgdXY6IHV2LFxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==