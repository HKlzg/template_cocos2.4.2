
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Recommend/Recommend.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4460azqs/1CM7A+qOUvnNjl', 'Recommend');
// Script/Recommend/Recommend.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../Common/yyComponent");
var GameEventType_1 = require("../GameSpecial/GameEventType");
var GlobalPool_1 = require("../Common/GlobalPool");
var RecommendDataManager_1 = require("./RecommendDataManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Recommend = /** @class */ (function (_super) {
    __extends(Recommend, _super);
    function Recommend() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Recommend.prototype.init = function () {
        this.scheduledRecommend = false;
        this.initSceneStack();
        this.onEvents();
    };
    Recommend.prototype.onEvents = function () {
        this.once(GameEventType_1.EventType.RecommendEvent.assetLoadFinish, this.onConfigLoadFinish, this);
        this.on(GameEventType_1.EventType.RecommendEvent.clickRecommendItem, this.navigateGame, this);
        this.on(GameEventType_1.EventType.RecommendEvent.hideRecommend, this.onHideRecommend, this);
        // this.on(EventType.RecommendEvent.enterRecommendScene, this.onEnterScene, this);
        // this.on(EventType.RecommendEvent.exitRecommendScene, this.onExitScene, this);
        this.on(GameEventType_1.EventType.UIEvent.entered, this.onEnterScene, this);
        this.on(GameEventType_1.EventType.UIEvent.exited, this.onExitScene, this);
    };
    Recommend.prototype.initSceneStack = function () {
        this.sceneStack = [];
    };
    /**回收所有主推游戏节点 */
    Recommend.prototype.reset = function () {
        this.scheduledRecommend = false;
        this.resetSceneStack();
        GlobalPool_1.default.putAllChildren(this.node);
    };
    Recommend.prototype.resetSceneStack = function () {
        this.sceneStack = [];
    };
    /**跳转到其他小游戏 */
    Recommend.prototype.navigateGame = function (recommendId) {
        //发送事件，由各平台SDK执行
        var data = RecommendDataManager_1.default.getRecommendData(recommendId);
        this.emit(GameEventType_1.EventType.SDKEvent.navigateToMiniProgram, data);
    };
    /**进入需要显示互推的场景/UI */
    Recommend.prototype.onEnterScene = function (scene) {
        if (undefined === scene || null === scene)
            return;
        //未对该场景进行互推配置时，不对其进行记录
        var config = RecommendDataManager_1.default.getRecommendConfig(scene);
        if (undefined === config)
            return;
        var curScene = this.getCurScene();
        if (curScene == scene)
            return;
        for (var i = this.sceneStack.length - 1; i >= 0; --i) {
            if (this.sceneStack[i] == scene) {
                this.sceneStack.splice(i, 1);
                break;
            }
        }
        this.sceneStack.push(scene);
        this.updateRecommends();
    };
    /**获取当前显示在最上层的互推场景/UI */
    Recommend.prototype.getCurScene = function () {
        var count = this.sceneStack.length;
        if (count == 0)
            return null;
        return this.sceneStack[count - 1];
    };
    /**退出需要显示互推的场景/UI */
    Recommend.prototype.onExitScene = function (scene) {
        if (undefined === scene || null === scene)
            return;
        //未对该场景进行互推配置时，不需要进行处理
        var config = RecommendDataManager_1.default.getRecommendConfig(scene);
        if (undefined === config)
            return;
        var curScene = this.getCurScene();
        if (curScene == scene) {
            this.sceneStack.pop();
            this.updateRecommends();
        }
        else {
            for (var i = this.sceneStack.length - 1; i >= 0; --i) {
                if (this.sceneStack[i] == scene) {
                    this.sceneStack.splice(i, 1);
                    break;
                }
            }
        }
    };
    /**互推配置表加载完毕，延迟更新互推内容 */
    Recommend.prototype.onConfigLoadFinish = function () {
        console.log("互推资源加载完毕，更新互推内容，scheduledRecommend:", this.scheduledRecommend);
        this.updateRecommends();
    };
    /**切换UI/场景，显示对应的互推内容 */
    Recommend.prototype.updateRecommends = function () {
        //使用计时器，到下一帧才更新互推内容，
        //避免游戏中执行初始化、重置等流程时场景/UI切换过多，
        //需要在一帧中反复显隐互推内容
        if (this.scheduledRecommend)
            return;
        this.scheduleOnce(this.showCurSceneRecommend, 0);
        this.scheduledRecommend = true;
    };
    /**根据显示在最上层的场景/UI，显示相应的互推内容 */
    Recommend.prototype.showCurSceneRecommend = function () {
        this.scheduledRecommend = false;
        GlobalPool_1.default.putAllChildren(this.node);
        var config = null;
        for (var i = this.sceneStack.length - 1; i >= 0; --i) {
            var scene = this.sceneStack[i];
            config = RecommendDataManager_1.default.getRecommendConfig(scene);
            if (!!config) {
                break;
            }
        }
        if (!config)
            return; //可能会出现未配置对应场景的互推内容、互推配置文件尚未加载完成的情况
        for (var key in config) {
            var item = GlobalPool_1.default.get(key, config[key]);
            this.node.addChild(item);
        }
    };
    /**隐藏互推 */
    Recommend.prototype.onHideRecommend = function (recommend) {
    };
    Recommend = __decorate([
        ccclass
    ], Recommend);
    return Recommend;
}(yyComponent_1.default));
exports.default = Recommend;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxSZWNvbW1lbmRcXFJlY29tbWVuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxxREFBZ0Q7QUFDaEQsOERBQXlEO0FBQ3pELG1EQUE4QztBQUM5QywrREFBMEQ7QUFHcEQsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBdUMsNkJBQVc7SUFBbEQ7O0lBMEhBLENBQUM7SUFwSFUsd0JBQUksR0FBWDtRQUNJLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7UUFDaEMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBQ1MsNEJBQVEsR0FBbEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbkYsSUFBSSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzlFLElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDNUUsa0ZBQWtGO1FBQ2xGLGdGQUFnRjtRQUNoRixJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVELElBQUksQ0FBQyxFQUFFLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNTLGtDQUFjLEdBQXhCO1FBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUNELGdCQUFnQjtJQUNULHlCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN2QixvQkFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNTLG1DQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVELGNBQWM7SUFDSixnQ0FBWSxHQUF0QixVQUF1QixXQUFnQjtRQUNuQyxnQkFBZ0I7UUFDaEIsSUFBSSxJQUFJLEdBQUcsOEJBQW9CLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQsb0JBQW9CO0lBQ1YsZ0NBQVksR0FBdEIsVUFBdUIsS0FBSztRQUN4QixJQUFJLFNBQVMsS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUs7WUFBRSxPQUFPO1FBQ2xELHNCQUFzQjtRQUN0QixJQUFJLE1BQU0sR0FBRyw4QkFBb0IsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM1RCxJQUFJLFNBQVMsS0FBSyxNQUFNO1lBQUUsT0FBTztRQUNqQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbEMsSUFBSSxRQUFRLElBQUksS0FBSztZQUFFLE9BQU87UUFDOUIsS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNsRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxFQUFFO2dCQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQzdCLE1BQU07YUFDVDtTQUNKO1FBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUNELHdCQUF3QjtJQUNkLCtCQUFXLEdBQXJCO1FBQ0ksSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFDbkMsSUFBSSxLQUFLLElBQUksQ0FBQztZQUFFLE9BQU8sSUFBSSxDQUFDO1FBQzVCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELG9CQUFvQjtJQUNWLCtCQUFXLEdBQXJCLFVBQXNCLEtBQUs7UUFDdkIsSUFBSSxTQUFTLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLO1lBQUUsT0FBTztRQUNsRCxzQkFBc0I7UUFDdEIsSUFBSSxNQUFNLEdBQUcsOEJBQW9CLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUQsSUFBSSxTQUFTLEtBQUssTUFBTTtZQUFFLE9BQU87UUFDakMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2xDLElBQUksUUFBUSxJQUFJLEtBQUssRUFBRTtZQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1NBQzNCO2FBQU07WUFDSCxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNsRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxFQUFFO29CQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQzdCLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVELHdCQUF3QjtJQUNkLHNDQUFrQixHQUE1QjtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELHVCQUF1QjtJQUNiLG9DQUFnQixHQUExQjtRQUNJLG9CQUFvQjtRQUNwQiw2QkFBNkI7UUFDN0IsZ0JBQWdCO1FBQ2hCLElBQUksSUFBSSxDQUFDLGtCQUFrQjtZQUFFLE9BQU87UUFDcEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDakQsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztJQUNuQyxDQUFDO0lBQ0QsOEJBQThCO0lBQ3BCLHlDQUFxQixHQUEvQjtRQUNJLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7UUFDaEMsb0JBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztRQUNsQixLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2xELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0IsTUFBTSxHQUFHLDhCQUFvQixDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3hELElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRTtnQkFDVixNQUFNO2FBQ1Q7U0FDSjtRQUNELElBQUksQ0FBQyxNQUFNO1lBQUUsT0FBTyxDQUFJLG1DQUFtQztRQUMzRCxLQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sRUFBRTtZQUNwQixJQUFJLElBQUksR0FBRyxvQkFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBR0QsVUFBVTtJQUNBLG1DQUFlLEdBQXpCLFVBQTBCLFNBQWU7SUFFekMsQ0FBQztJQXpIZ0IsU0FBUztRQUQ3QixPQUFPO09BQ2EsU0FBUyxDQTBIN0I7SUFBRCxnQkFBQztDQTFIRCxBQTBIQyxDQTFIc0MscUJBQVcsR0EwSGpEO2tCQTFIb0IsU0FBUyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB5eUNvbXBvbmVudCBmcm9tIFwiLi4vQ29tbW9uL3l5Q29tcG9uZW50XCI7XHJcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XHJcbmltcG9ydCBHbG9iYWxQb29sIGZyb20gXCIuLi9Db21tb24vR2xvYmFsUG9vbFwiO1xyXG5pbXBvcnQgUmVjb21tZW5kRGF0YU1hbmFnZXIgZnJvbSBcIi4vUmVjb21tZW5kRGF0YU1hbmFnZXJcIjtcclxuaW1wb3J0IHsgR2xvYmFsRW51bSB9IGZyb20gXCIuLi9HYW1lU3BlY2lhbC9HbG9iYWxFbnVtXCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVjb21tZW5kIGV4dGVuZHMgeXlDb21wb25lbnQge1xyXG4gICAgLyoq5pi+56S65LqS5o6o55qE5Zy65pmvL1VJ77yM5L2/55So5aCG5qCI5p2l566h55CGICovXHJcbiAgICBwcm90ZWN0ZWQgc2NlbmVTdGFjaztcclxuICAgIC8qKuaYr+WQpuW3suS9nOWHuuiuoeWIkuimgeagueaNruWcuuaZr+abtOaWsOS6kuaOqOWGheWuuSAqL1xyXG4gICAgcHJvdGVjdGVkIHNjaGVkdWxlZFJlY29tbWVuZDogYm9vbGVhbjtcclxuXHJcbiAgICBwdWJsaWMgaW5pdCgpIHtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlZFJlY29tbWVuZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuaW5pdFNjZW5lU3RhY2soKTtcclxuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgb25FdmVudHMoKSB7XHJcbiAgICAgICAgdGhpcy5vbmNlKEV2ZW50VHlwZS5SZWNvbW1lbmRFdmVudC5hc3NldExvYWRGaW5pc2gsIHRoaXMub25Db25maWdMb2FkRmluaXNoLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5SZWNvbW1lbmRFdmVudC5jbGlja1JlY29tbWVuZEl0ZW0sIHRoaXMubmF2aWdhdGVHYW1lLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm9uKEV2ZW50VHlwZS5SZWNvbW1lbmRFdmVudC5oaWRlUmVjb21tZW5kLCB0aGlzLm9uSGlkZVJlY29tbWVuZCwgdGhpcyk7XHJcbiAgICAgICAgLy8gdGhpcy5vbihFdmVudFR5cGUuUmVjb21tZW5kRXZlbnQuZW50ZXJSZWNvbW1lbmRTY2VuZSwgdGhpcy5vbkVudGVyU2NlbmUsIHRoaXMpO1xyXG4gICAgICAgIC8vIHRoaXMub24oRXZlbnRUeXBlLlJlY29tbWVuZEV2ZW50LmV4aXRSZWNvbW1lbmRTY2VuZSwgdGhpcy5vbkV4aXRTY2VuZSwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuVUlFdmVudC5lbnRlcmVkLCB0aGlzLm9uRW50ZXJTY2VuZSwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuVUlFdmVudC5leGl0ZWQsIHRoaXMub25FeGl0U2NlbmUsIHRoaXMpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIGluaXRTY2VuZVN0YWNrKCkge1xyXG4gICAgICAgIHRoaXMuc2NlbmVTdGFjayA9IFtdO1xyXG4gICAgfVxyXG4gICAgLyoq5Zue5pS25omA5pyJ5Li75o6o5ri45oiP6IqC54K5ICovXHJcbiAgICBwdWJsaWMgcmVzZXQoKSB7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZWRSZWNvbW1lbmQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLnJlc2V0U2NlbmVTdGFjaygpO1xyXG4gICAgICAgIEdsb2JhbFBvb2wucHV0QWxsQ2hpbGRyZW4odGhpcy5ub2RlKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCByZXNldFNjZW5lU3RhY2soKSB7XHJcbiAgICAgICAgdGhpcy5zY2VuZVN0YWNrID0gW107XHJcbiAgICB9XHJcblxyXG4gICAgLyoq6Lez6L2s5Yiw5YW25LuW5bCP5ri45oiPICovXHJcbiAgICBwcm90ZWN0ZWQgbmF2aWdhdGVHYW1lKHJlY29tbWVuZElkOiBhbnkpIHtcclxuICAgICAgICAvL+WPkemAgeS6i+S7tu+8jOeUseWQhOW5s+WPsFNES+aJp+ihjFxyXG4gICAgICAgIGxldCBkYXRhID0gUmVjb21tZW5kRGF0YU1hbmFnZXIuZ2V0UmVjb21tZW5kRGF0YShyZWNvbW1lbmRJZCk7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5TREtFdmVudC5uYXZpZ2F0ZVRvTWluaVByb2dyYW0sIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKui/m+WFpemcgOimgeaYvuekuuS6kuaOqOeahOWcuuaZry9VSSAqL1xyXG4gICAgcHJvdGVjdGVkIG9uRW50ZXJTY2VuZShzY2VuZSkge1xyXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IHNjZW5lIHx8IG51bGwgPT09IHNjZW5lKSByZXR1cm47XHJcbiAgICAgICAgLy/mnKrlr7nor6XlnLrmma/ov5vooYzkupLmjqjphY3nva7ml7bvvIzkuI3lr7nlhbbov5vooYzorrDlvZVcclxuICAgICAgICBsZXQgY29uZmlnID0gUmVjb21tZW5kRGF0YU1hbmFnZXIuZ2V0UmVjb21tZW5kQ29uZmlnKHNjZW5lKTtcclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBjb25maWcpIHJldHVybjtcclxuICAgICAgICBsZXQgY3VyU2NlbmUgPSB0aGlzLmdldEN1clNjZW5lKCk7XHJcbiAgICAgICAgaWYgKGN1clNjZW5lID09IHNjZW5lKSByZXR1cm47XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IHRoaXMuc2NlbmVTdGFjay5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5zY2VuZVN0YWNrW2ldID09IHNjZW5lKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjZW5lU3RhY2suc3BsaWNlKGksIDEpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5zY2VuZVN0YWNrLnB1c2goc2NlbmUpO1xyXG4gICAgICAgIHRoaXMudXBkYXRlUmVjb21tZW5kcygpO1xyXG4gICAgfVxyXG4gICAgLyoq6I635Y+W5b2T5YmN5pi+56S65Zyo5pyA5LiK5bGC55qE5LqS5o6o5Zy65pmvL1VJICovXHJcbiAgICBwcm90ZWN0ZWQgZ2V0Q3VyU2NlbmUoKSB7XHJcbiAgICAgICAgbGV0IGNvdW50ID0gdGhpcy5zY2VuZVN0YWNrLmxlbmd0aDtcclxuICAgICAgICBpZiAoY291bnQgPT0gMCkgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuc2NlbmVTdGFja1tjb3VudCAtIDFdO1xyXG4gICAgfVxyXG4gICAgLyoq6YCA5Ye66ZyA6KaB5pi+56S65LqS5o6o55qE5Zy65pmvL1VJICovXHJcbiAgICBwcm90ZWN0ZWQgb25FeGl0U2NlbmUoc2NlbmUpIHtcclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBzY2VuZSB8fCBudWxsID09PSBzY2VuZSkgcmV0dXJuO1xyXG4gICAgICAgIC8v5pyq5a+56K+l5Zy65pmv6L+b6KGM5LqS5o6o6YWN572u5pe277yM5LiN6ZyA6KaB6L+b6KGM5aSE55CGXHJcbiAgICAgICAgbGV0IGNvbmZpZyA9IFJlY29tbWVuZERhdGFNYW5hZ2VyLmdldFJlY29tbWVuZENvbmZpZyhzY2VuZSk7XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gY29uZmlnKSByZXR1cm47XHJcbiAgICAgICAgbGV0IGN1clNjZW5lID0gdGhpcy5nZXRDdXJTY2VuZSgpO1xyXG4gICAgICAgIGlmIChjdXJTY2VuZSA9PSBzY2VuZSkge1xyXG4gICAgICAgICAgICB0aGlzLnNjZW5lU3RhY2sucG9wKCk7XHJcbiAgICAgICAgICAgIHRoaXMudXBkYXRlUmVjb21tZW5kcygpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSB0aGlzLnNjZW5lU3RhY2subGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnNjZW5lU3RhY2tbaV0gPT0gc2NlbmUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNjZW5lU3RhY2suc3BsaWNlKGksIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKuS6kuaOqOmFjee9ruihqOWKoOi9veWujOavle+8jOW7tui/n+abtOaWsOS6kuaOqOWGheWuuSAqL1xyXG4gICAgcHJvdGVjdGVkIG9uQ29uZmlnTG9hZEZpbmlzaCgpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuS6kuaOqOi1hOa6kOWKoOi9veWujOavle+8jOabtOaWsOS6kuaOqOWGheWuue+8jHNjaGVkdWxlZFJlY29tbWVuZDpcIiwgdGhpcy5zY2hlZHVsZWRSZWNvbW1lbmQpO1xyXG4gICAgICAgIHRoaXMudXBkYXRlUmVjb21tZW5kcygpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKuWIh+aNolVJL+WcuuaZr++8jOaYvuekuuWvueW6lOeahOS6kuaOqOWGheWuuSAqL1xyXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVJlY29tbWVuZHMoKSB7XHJcbiAgICAgICAgLy/kvb/nlKjorqHml7blmajvvIzliLDkuIvkuIDluKfmiY3mm7TmlrDkupLmjqjlhoXlrrnvvIxcclxuICAgICAgICAvL+mBv+WFjea4uOaIj+S4reaJp+ihjOWIneWni+WMluOAgemHjee9ruetiea1geeoi+aXtuWcuuaZry9VSeWIh+aNoui/h+Wkmu+8jFxyXG4gICAgICAgIC8v6ZyA6KaB5Zyo5LiA5bin5Lit5Y+N5aSN5pi+6ZqQ5LqS5o6o5YaF5a65XHJcbiAgICAgICAgaWYgKHRoaXMuc2NoZWR1bGVkUmVjb21tZW5kKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UodGhpcy5zaG93Q3VyU2NlbmVSZWNvbW1lbmQsIDApO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVkUmVjb21tZW5kID0gdHJ1ZTtcclxuICAgIH1cclxuICAgIC8qKuagueaNruaYvuekuuWcqOacgOS4iuWxgueahOWcuuaZry9VSe+8jOaYvuekuuebuOW6lOeahOS6kuaOqOWGheWuuSAqL1xyXG4gICAgcHJvdGVjdGVkIHNob3dDdXJTY2VuZVJlY29tbWVuZCgpIHtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlZFJlY29tbWVuZCA9IGZhbHNlO1xyXG4gICAgICAgIEdsb2JhbFBvb2wucHV0QWxsQ2hpbGRyZW4odGhpcy5ub2RlKTtcclxuICAgICAgICBsZXQgY29uZmlnID0gbnVsbDtcclxuICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5zY2VuZVN0YWNrLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICAgIGxldCBzY2VuZSA9IHRoaXMuc2NlbmVTdGFja1tpXTtcclxuICAgICAgICAgICAgY29uZmlnID0gUmVjb21tZW5kRGF0YU1hbmFnZXIuZ2V0UmVjb21tZW5kQ29uZmlnKHNjZW5lKTtcclxuICAgICAgICAgICAgaWYgKCEhY29uZmlnKSB7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIWNvbmZpZykgcmV0dXJuOyAgICAvL+WPr+iDveS8muWHuueOsOacqumFjee9ruWvueW6lOWcuuaZr+eahOS6kuaOqOWGheWuueOAgeS6kuaOqOmFjee9ruaWh+S7tuWwmuacquWKoOi9veWujOaIkOeahOaDheWGtVxyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBjb25maWcpIHtcclxuICAgICAgICAgICAgbGV0IGl0ZW0gPSBHbG9iYWxQb29sLmdldChrZXksIGNvbmZpZ1trZXldKTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoq6ZqQ6JeP5LqS5o6oICovXHJcbiAgICBwcm90ZWN0ZWQgb25IaWRlUmVjb21tZW5kKHJlY29tbWVuZD86IGFueSkge1xyXG5cclxuICAgIH1cclxufVxyXG4iXX0=