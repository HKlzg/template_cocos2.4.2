
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Recommend/RecommendManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4d9775Zlg1AlYPqAHFIRaiS', 'RecommendManager');
// Script/Recommend/RecommendManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendDataManager_1 = require("./RecommendDataManager");
var Recommend_1 = require("./Recommend");
var RecommendConfig_1 = require("./RecommendConfig");
var GamePlatform_1 = require("../Platform/GamePlatform");
var GamePlatformType_1 = require("../Platform/GamePlatformType");
//互推管理器(仅初始化Recommend与RecommendDataManager，为避免两者相互引用而使用本脚本)
var RecommendManager = /** @class */ (function () {
    function RecommendManager() {
    }
    RecommendManager.init = function (node) {
        var recommend = this.addRecommendComponent(node);
        if (!!recommend) {
            recommend.init();
            RecommendDataManager_1.default.init(node);
        }
    };
    RecommendManager.addRecommendComponent = function (node) {
        var config = node.getComponent(RecommendConfig_1.default);
        if (!config) {
            switch (GamePlatform_1.default.instance.Config.type) {
                case GamePlatformType_1.GamePlatformType.OPPO:
                case GamePlatformType_1.GamePlatformType.PC:
                case GamePlatformType_1.GamePlatformType.WX: {
                    return node.addComponent(Recommend_1.default);
                }
                case GamePlatformType_1.GamePlatformType.TT: {
                    //头条 iOS 不支持互推
                    var systemInfo = window["tt"].getSystemInfoSync();
                    if (systemInfo.platform == "ios" || systemInfo.appName == "XiGua") {
                        return null;
                    }
                    return null;
                }
                default: {
                    return null;
                }
            }
        }
        else {
            switch (config.type) {
                case RecommendConfig_1.default.recommendPlatformType.PC:
                case RecommendConfig_1.default.recommendPlatformType.OPPO:
                case RecommendConfig_1.default.recommendPlatformType.WX: {
                    return node.addComponent(Recommend_1.default);
                }
                case RecommendConfig_1.default.recommendPlatformType.TT: {
                    //头条 iOS 不支持互推
                    var systemInfo = window["tt"].getSystemInfoSync();
                    if (systemInfo.platform == "ios" || systemInfo.appName == "XiGua") {
                        return null;
                    }
                    return null;
                }
                default: {
                    return null;
                }
            }
        }
    };
    return RecommendManager;
}());
exports.default = RecommendManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxSZWNvbW1lbmRcXFJlY29tbWVuZE1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrREFBMEQ7QUFDMUQseUNBQW9DO0FBQ3BDLHFEQUFnRDtBQUNoRCx5REFBb0Q7QUFDcEQsaUVBQWdFO0FBR2hFLDJEQUEyRDtBQUMzRDtJQUFBO0lBcURBLENBQUM7SUFwRGlCLHFCQUFJLEdBQWxCLFVBQW1CLElBQWE7UUFDNUIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRTtZQUNiLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNqQiw4QkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDbkM7SUFDTCxDQUFDO0lBQ2Esc0NBQXFCLEdBQW5DLFVBQW9DLElBQWE7UUFDN0MsSUFBSSxNQUFNLEdBQW9CLElBQUksQ0FBQyxZQUFZLENBQUMseUJBQWUsQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDVCxRQUFRLHNCQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7Z0JBQ3ZDLEtBQUssbUNBQWdCLENBQUMsSUFBSSxDQUFDO2dCQUMzQixLQUFLLG1DQUFnQixDQUFDLEVBQUUsQ0FBQztnQkFDekIsS0FBSyxtQ0FBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDdEIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLG1CQUFTLENBQUMsQ0FBQztpQkFDdkM7Z0JBQ0QsS0FBSyxtQ0FBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDdEIsY0FBYztvQkFDZCxJQUFJLFVBQVUsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFDbEQsSUFBSSxVQUFVLENBQUMsUUFBUSxJQUFJLEtBQUssSUFBSSxVQUFVLENBQUMsT0FBTyxJQUFJLE9BQU8sRUFBRTt3QkFDL0QsT0FBTyxJQUFJLENBQUM7cUJBQ2Y7b0JBQ0QsT0FBTyxJQUFJLENBQUM7aUJBQ2Y7Z0JBQ0QsT0FBTyxDQUFDLENBQUM7b0JBQ0wsT0FBTyxJQUFJLENBQUM7aUJBQ2Y7YUFDSjtTQUNKO2FBQU07WUFDSCxRQUFRLE1BQU0sQ0FBQyxJQUFJLEVBQUU7Z0JBQ2pCLEtBQUsseUJBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUM7Z0JBQzlDLEtBQUsseUJBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUM7Z0JBQ2hELEtBQUsseUJBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDM0MsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLG1CQUFTLENBQUMsQ0FBQztpQkFDdkM7Z0JBQ0QsS0FBSyx5QkFBZSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUMzQyxjQUFjO29CQUNkLElBQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO29CQUNsRCxJQUFJLFVBQVUsQ0FBQyxRQUFRLElBQUksS0FBSyxJQUFJLFVBQVUsQ0FBQyxPQUFPLElBQUksT0FBTyxFQUFFO3dCQUMvRCxPQUFPLElBQUksQ0FBQztxQkFDZjtvQkFDRCxPQUFPLElBQUksQ0FBQztpQkFDZjtnQkFHRCxPQUFPLENBQUMsQ0FBQztvQkFDTCxPQUFPLElBQUksQ0FBQztpQkFDZjthQUVKO1NBQ0o7SUFDTCxDQUFDO0lBQ0wsdUJBQUM7QUFBRCxDQXJEQSxBQXFEQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlY29tbWVuZERhdGFNYW5hZ2VyIGZyb20gXCIuL1JlY29tbWVuZERhdGFNYW5hZ2VyXCI7XHJcbmltcG9ydCBSZWNvbW1lbmQgZnJvbSBcIi4vUmVjb21tZW5kXCI7XHJcbmltcG9ydCBSZWNvbW1lbmRDb25maWcgZnJvbSBcIi4vUmVjb21tZW5kQ29uZmlnXCI7XHJcbmltcG9ydCBHYW1lUGxhdGZvcm0gZnJvbSBcIi4uL1BsYXRmb3JtL0dhbWVQbGF0Zm9ybVwiO1xyXG5pbXBvcnQgeyBHYW1lUGxhdGZvcm1UeXBlIH0gZnJvbSBcIi4uL1BsYXRmb3JtL0dhbWVQbGF0Zm9ybVR5cGVcIjtcclxuXHJcblxyXG4vL+S6kuaOqOeuoeeQhuWZqCjku4XliJ3lp4vljJZSZWNvbW1lbmTkuI5SZWNvbW1lbmREYXRhTWFuYWdlcu+8jOS4uumBv+WFjeS4pOiAheebuOS6kuW8leeUqOiAjOS9v+eUqOacrOiEmuacrClcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVjb21tZW5kTWFuYWdlciB7XHJcbiAgICBwdWJsaWMgc3RhdGljIGluaXQobm9kZTogY2MuTm9kZSkge1xyXG4gICAgICAgIGxldCByZWNvbW1lbmQgPSB0aGlzLmFkZFJlY29tbWVuZENvbXBvbmVudChub2RlKTtcclxuICAgICAgICBpZiAoISFyZWNvbW1lbmQpIHtcclxuICAgICAgICAgICAgcmVjb21tZW5kLmluaXQoKTtcclxuICAgICAgICAgICAgUmVjb21tZW5kRGF0YU1hbmFnZXIuaW5pdChub2RlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGFkZFJlY29tbWVuZENvbXBvbmVudChub2RlOiBjYy5Ob2RlKTogUmVjb21tZW5kIHtcclxuICAgICAgICBsZXQgY29uZmlnOiBSZWNvbW1lbmRDb25maWcgPSBub2RlLmdldENvbXBvbmVudChSZWNvbW1lbmRDb25maWcpO1xyXG4gICAgICAgIGlmICghY29uZmlnKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy50eXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIEdhbWVQbGF0Zm9ybVR5cGUuT1BQTzpcclxuICAgICAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5QQzpcclxuICAgICAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5XWDoge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBub2RlLmFkZENvbXBvbmVudChSZWNvbW1lbmQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2FzZSBHYW1lUGxhdGZvcm1UeXBlLlRUOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy/lpLTmnaEgaU9TIOS4jeaUr+aMgeS6kuaOqFxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBzeXN0ZW1JbmZvID0gd2luZG93W1widHRcIl0uZ2V0U3lzdGVtSW5mb1N5bmMoKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoc3lzdGVtSW5mby5wbGF0Zm9ybSA9PSBcImlvc1wiIHx8IHN5c3RlbUluZm8uYXBwTmFtZSA9PSBcIlhpR3VhXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDoge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc3dpdGNoIChjb25maWcudHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSBSZWNvbW1lbmRDb25maWcucmVjb21tZW5kUGxhdGZvcm1UeXBlLlBDOlxyXG4gICAgICAgICAgICAgICAgY2FzZSBSZWNvbW1lbmRDb25maWcucmVjb21tZW5kUGxhdGZvcm1UeXBlLk9QUE86XHJcbiAgICAgICAgICAgICAgICBjYXNlIFJlY29tbWVuZENvbmZpZy5yZWNvbW1lbmRQbGF0Zm9ybVR5cGUuV1g6IHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbm9kZS5hZGRDb21wb25lbnQoUmVjb21tZW5kKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNhc2UgUmVjb21tZW5kQ29uZmlnLnJlY29tbWVuZFBsYXRmb3JtVHlwZS5UVDoge1xyXG4gICAgICAgICAgICAgICAgICAgIC8v5aS05p2hIGlPUyDkuI3mlK/mjIHkupLmjqhcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc3lzdGVtSW5mbyA9IHdpbmRvd1tcInR0XCJdLmdldFN5c3RlbUluZm9TeW5jKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN5c3RlbUluZm8ucGxhdGZvcm0gPT0gXCJpb3NcIiB8fCBzeXN0ZW1JbmZvLmFwcE5hbWUgPT0gXCJYaUd1YVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==