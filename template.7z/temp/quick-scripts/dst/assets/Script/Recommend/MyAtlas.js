
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Recommend/MyAtlas.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '69d9bvmEndMR4oOopJj24pV', 'MyAtlas');
// Script/Common/MyAtlas.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var space = 2;
var _textureSize = 2048;
var MyAtlas = /** @class */ (function () {
    function MyAtlas(width, height) {
        if (undefined === height) {
            height = _textureSize;
        }
        if (undefined === width) {
            width = _textureSize;
        }
        var texture = new cc.RenderTexture();
        texture.initWithSize(width, height);
        texture.update();
        this._texture = texture;
        this._spriteFrame = new cc.SpriteFrame(this._texture);
        this._x = space;
        this._y = space;
        this._nexty = space;
        this._width = width;
        this._height = height;
        this.uvMap = {};
    }
    MyAtlas.prototype.insertSpriteFrame = function (spriteFrame, name) {
        if (undefined === name) {
            name = spriteFrame._uuid;
        }
        if (!!this.uvMap[name]) {
            return this.uvMap[name];
        }
        var texture = spriteFrame._texture;
        var width = texture.width, height = texture.height;
        if ((this._x + width + space) > this._width) {
            this._x = space;
            this._y = this._nexty;
        }
        if ((this._y + height + space) > this._nexty) {
            this._nexty = this._y + height + space;
        }
        if (this._nexty > this._height) {
            console.warn("自定义图集已满");
            return null;
        }
        this._texture.drawTextureAt(texture, this._x, this._y);
        this._texture.update();
        this.uvMap[name] = {
            left: (this._x) / this._width,
            right: (this._x + width) / this._width,
            top: this._y / this._height,
            bottom: (this._y + height) / this._height,
            width: width,
            height: height,
        };
        this._x += width + space;
        return this.uvMap[name];
    };
    MyAtlas.prototype.getUV = function (name) {
        if (!!this.uvMap[name]) {
            return this.uvMap[name];
        }
        else {
            console.warn("自定义图集中不存在指定图集：", name);
            return null;
        }
    };
    MyAtlas.prototype.getTexture = function () {
        return this._texture;
    };
    MyAtlas.prototype.getSpriteFrame = function () {
        return this._spriteFrame;
    };
    return MyAtlas;
}());
exports.default = MyAtlas;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDb21tb25cXE15QXRsYXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFNLEtBQUssR0FBRyxDQUFDLENBQUM7QUFDaEIsSUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDO0FBRTFCO0lBcUJJLGlCQUFtQixLQUFjLEVBQUUsTUFBZTtRQUM5QyxJQUFJLFNBQVMsS0FBSyxNQUFNLEVBQUU7WUFDdEIsTUFBTSxHQUFHLFlBQVksQ0FBQztTQUN6QjtRQUNELElBQUksU0FBUyxLQUFLLEtBQUssRUFBRTtZQUNyQixLQUFLLEdBQUcsWUFBWSxDQUFDO1NBQ3hCO1FBQ0QsSUFBSSxPQUFPLEdBQUcsSUFBSSxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckMsT0FBTyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDcEMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWpCLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUV0RCxJQUFJLENBQUMsRUFBRSxHQUFHLEtBQUssQ0FBQztRQUNoQixJQUFJLENBQUMsRUFBRSxHQUFHLEtBQUssQ0FBQztRQUNoQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUVwQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUNwQixJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztRQUV0QixJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBQ00sbUNBQWlCLEdBQXhCLFVBQXlCLFdBQTJCLEVBQUUsSUFBYTtRQUMvRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDcEIsSUFBSSxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7U0FDNUI7UUFDRCxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3BCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMzQjtRQUNELElBQUksT0FBTyxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUM7UUFDbkMsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssRUFBRSxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztRQUNuRCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUN6QyxJQUFJLENBQUMsRUFBRSxHQUFHLEtBQUssQ0FBQztZQUNoQixJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7U0FDekI7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxNQUFNLEdBQUcsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUMxQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxFQUFFLEdBQUcsTUFBTSxHQUFHLEtBQUssQ0FBQztTQUMxQztRQUNELElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQzVCLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDeEIsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUNELElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFDZixJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU07WUFDN0IsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTTtZQUN0QyxHQUFHLEVBQUUsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsT0FBTztZQUMzQixNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPO1lBQ3pDLEtBQUssRUFBRSxLQUFLO1lBQ1osTUFBTSxFQUFFLE1BQU07U0FFakIsQ0FBQztRQUNGLElBQUksQ0FBQyxFQUFFLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQztRQUN6QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUNNLHVCQUFLLEdBQVosVUFBYSxJQUFZO1FBQ3JCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDcEIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzNCO2FBQU07WUFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3JDLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7SUFDTCxDQUFDO0lBQ00sNEJBQVUsR0FBakI7UUFDSSxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDekIsQ0FBQztJQUNNLGdDQUFjLEdBQXJCO1FBQ0ksT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzdCLENBQUM7SUFFTCxjQUFDO0FBQUQsQ0E3RkEsQUE2RkMsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5jb25zdCBzcGFjZSA9IDI7XHJcbmNvbnN0IF90ZXh0dXJlU2l6ZSA9IDIwNDg7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNeUF0bGFzIHtcclxuXHJcbiAgICBwcm90ZWN0ZWQgX3Nwcml0ZUZyYW1lOiBjYy5TcHJpdGVGcmFtZTtcclxuICAgIHByb3RlY3RlZCBfdGV4dHVyZTogY2MuVGV4dHVyZTJEO1xyXG4gICAgcHJvdGVjdGVkIF94O1xyXG4gICAgcHJvdGVjdGVkIF95O1xyXG4gICAgcHJvdGVjdGVkIF9uZXh0eTtcclxuICAgIHByb3RlY3RlZCBfd2lkdGg7XHJcbiAgICBwcm90ZWN0ZWQgX2hlaWdodDtcclxuXHJcbiAgICBwcm90ZWN0ZWQgdXZNYXA6IHtcclxuICAgICAgICBbdXJsOiBzdHJpbmddOiB7XHJcbiAgICAgICAgICAgIGxlZnQ6IG51bWJlcixcclxuICAgICAgICAgICAgcmlnaHQ6IG51bWJlcixcclxuICAgICAgICAgICAgdG9wOiBudW1iZXIsXHJcbiAgICAgICAgICAgIGJvdHRvbTogbnVtYmVyLFxyXG4gICAgICAgICAgICB3aWR0aDogbnVtYmVyLFxyXG4gICAgICAgICAgICBoZWlnaHQ6IG51bWJlcixcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHB1YmxpYyBjb25zdHJ1Y3Rvcih3aWR0aD86IG51bWJlciwgaGVpZ2h0PzogbnVtYmVyKSB7XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gaGVpZ2h0KSB7XHJcbiAgICAgICAgICAgIGhlaWdodCA9IF90ZXh0dXJlU2l6ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gd2lkdGgpIHtcclxuICAgICAgICAgICAgd2lkdGggPSBfdGV4dHVyZVNpemU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCB0ZXh0dXJlID0gbmV3IGNjLlJlbmRlclRleHR1cmUoKTtcclxuICAgICAgICB0ZXh0dXJlLmluaXRXaXRoU2l6ZSh3aWR0aCwgaGVpZ2h0KTtcclxuICAgICAgICB0ZXh0dXJlLnVwZGF0ZSgpO1xyXG5cclxuICAgICAgICB0aGlzLl90ZXh0dXJlID0gdGV4dHVyZTtcclxuICAgICAgICB0aGlzLl9zcHJpdGVGcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSh0aGlzLl90ZXh0dXJlKTtcclxuXHJcbiAgICAgICAgdGhpcy5feCA9IHNwYWNlO1xyXG4gICAgICAgIHRoaXMuX3kgPSBzcGFjZTtcclxuICAgICAgICB0aGlzLl9uZXh0eSA9IHNwYWNlO1xyXG5cclxuICAgICAgICB0aGlzLl93aWR0aCA9IHdpZHRoO1xyXG4gICAgICAgIHRoaXMuX2hlaWdodCA9IGhlaWdodDtcclxuXHJcbiAgICAgICAgdGhpcy51dk1hcCA9IHt9O1xyXG4gICAgfVxyXG4gICAgcHVibGljIGluc2VydFNwcml0ZUZyYW1lKHNwcml0ZUZyYW1lOiBjYy5TcHJpdGVGcmFtZSwgbmFtZT86IHN0cmluZykge1xyXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IG5hbWUpIHtcclxuICAgICAgICAgICAgbmFtZSA9IHNwcml0ZUZyYW1lLl91dWlkO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoISF0aGlzLnV2TWFwW25hbWVdKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnV2TWFwW25hbWVdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgdGV4dHVyZSA9IHNwcml0ZUZyYW1lLl90ZXh0dXJlO1xyXG4gICAgICAgIGxldCB3aWR0aCA9IHRleHR1cmUud2lkdGgsIGhlaWdodCA9IHRleHR1cmUuaGVpZ2h0O1xyXG4gICAgICAgIGlmICgodGhpcy5feCArIHdpZHRoICsgc3BhY2UpID4gdGhpcy5fd2lkdGgpIHtcclxuICAgICAgICAgICAgdGhpcy5feCA9IHNwYWNlO1xyXG4gICAgICAgICAgICB0aGlzLl95ID0gdGhpcy5fbmV4dHk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICgodGhpcy5feSArIGhlaWdodCArIHNwYWNlKSA+IHRoaXMuX25leHR5KSB7XHJcbiAgICAgICAgICAgIHRoaXMuX25leHR5ID0gdGhpcy5feSArIGhlaWdodCArIHNwYWNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5fbmV4dHkgPiB0aGlzLl9oZWlnaHQpIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKFwi6Ieq5a6a5LmJ5Zu+6ZuG5bey5ruhXCIpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fdGV4dHVyZS5kcmF3VGV4dHVyZUF0KHRleHR1cmUsIHRoaXMuX3gsIHRoaXMuX3kpO1xyXG4gICAgICAgIHRoaXMuX3RleHR1cmUudXBkYXRlKCk7XHJcbiAgICAgICAgdGhpcy51dk1hcFtuYW1lXSA9IHtcclxuICAgICAgICAgICAgbGVmdDogKHRoaXMuX3gpIC8gdGhpcy5fd2lkdGgsXHJcbiAgICAgICAgICAgIHJpZ2h0OiAodGhpcy5feCArIHdpZHRoKSAvIHRoaXMuX3dpZHRoLFxyXG4gICAgICAgICAgICB0b3A6IHRoaXMuX3kgLyB0aGlzLl9oZWlnaHQsXHJcbiAgICAgICAgICAgIGJvdHRvbTogKHRoaXMuX3kgKyBoZWlnaHQpIC8gdGhpcy5faGVpZ2h0LFxyXG4gICAgICAgICAgICB3aWR0aDogd2lkdGgsXHJcbiAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxyXG5cclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuX3ggKz0gd2lkdGggKyBzcGFjZTtcclxuICAgICAgICByZXR1cm4gdGhpcy51dk1hcFtuYW1lXTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXRVVihuYW1lOiBzdHJpbmcpIHtcclxuICAgICAgICBpZiAoISF0aGlzLnV2TWFwW25hbWVdKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnV2TWFwW25hbWVdO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcIuiHquWumuS5ieWbvumbhuS4reS4jeWtmOWcqOaMh+WumuWbvumbhu+8mlwiLCBuYW1lKTtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHVibGljIGdldFRleHR1cmUoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3RleHR1cmU7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgZ2V0U3ByaXRlRnJhbWUoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3Nwcml0ZUZyYW1lO1xyXG4gICAgfVxyXG5cclxufSJdfQ==