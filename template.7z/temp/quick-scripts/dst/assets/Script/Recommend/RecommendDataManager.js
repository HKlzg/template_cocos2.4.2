
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Recommend/RecommendDataManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '41aa7Aqw4BHO4CSSBBAQXff', 'RecommendDataManager');
// Script/Recommend/RecommendDataManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendConfig_1 = require("./RecommendConfig");
var EventManager_1 = require("../Common/EventManager");
var GameEventType_1 = require("../GameSpecial/GameEventType");
var GamePlatform_1 = require("../Platform/GamePlatform");
var GamePlatformType_1 = require("../Platform/GamePlatformType");
var GlobalPool_1 = require("../Common/GlobalPool");
var Loader_1 = require("../Common/Loader");
/**互推需要的资源类型 */
var AssetType = {
    config: 1,
    gameIcon: 2,
    prefab: 3,
};
//互推配置数据管理器
var RecommendDataManager = /** @class */ (function () {
    function RecommendDataManager() {
    }
    RecommendDataManager.init = function (node) {
        var _this = this;
        this.allAssetLoad = false;
        this.assetState = {};
        var str = this.getJsonName(node);
        if (!!str) {
            Loader_1.default.loadBundle("Recommend", function () {
                _this.loadConfig(str);
                _this.loadPrefab();
                _this.loadGameIcon();
            }, false);
        }
    };
    /**资源加载完成回调 */
    RecommendDataManager.loadFinish = function (key) {
        this.assetState[key] = true;
        //若全部资源加载完成，则发送事件，通知互推节点更新内容
        var finish = true;
        for (var key_1 in AssetType) {
            if (!this.assetState[AssetType[key_1]]) {
                finish = false;
                break;
            }
        }
        if (finish) {
            this.allAssetLoad = true;
            this.assetState = null;
            EventManager_1.default.emit(GameEventType_1.EventType.RecommendEvent.assetLoadFinish);
        }
    };
    /**加载互推配置表 */
    RecommendDataManager.loadConfig = function (str) {
        var _this = this;
        Loader_1.default.loadBundleRes("Recommend", "Config/" + str, function (res) {
            if (null === res) {
                console.log("互推配置表加载失败：", str);
                return;
            }
            _this.data = res.json;
            _this.loadFinish(AssetType.config);
        }, cc.JsonAsset, false);
    };
    /**根据游戏平台获取互推配置文件名 */
    RecommendDataManager.getJsonName = function (node) {
        var config = null;
        if (!!node) {
            config = node.getComponent(RecommendConfig_1.default);
        }
        if (!config) {
            switch (GamePlatform_1.default.instance.Config.type) {
                case GamePlatformType_1.GamePlatformType.OPPO: return "RecommendConfig_OPPO";
                case GamePlatformType_1.GamePlatformType.QQ: return null;
                case GamePlatformType_1.GamePlatformType.TT: return "RecommendConfig_TT";
                case GamePlatformType_1.GamePlatformType.WX: return "RecommendConfig_WX";
                // case GamePlatformType.PC: return "RecommendConfig_WX";
                case GamePlatformType_1.GamePlatformType.VIVO: return null;
                default: return null;
            }
        }
        else {
            switch (config.type) {
                case RecommendConfig_1.default.recommendPlatformType.OPPO: return "RecommendConfig_OPPO";
                case RecommendConfig_1.default.recommendPlatformType.QQ: return null;
                case RecommendConfig_1.default.recommendPlatformType.TT: return "RecommendConfig_TT";
                case RecommendConfig_1.default.recommendPlatformType.WX: return "RecommendConfig_WX";
                case RecommendConfig_1.default.recommendPlatformType.PC: return "RecommendConfig_WX";
                case RecommendConfig_1.default.recommendPlatformType.VIVO: return null;
                case RecommendConfig_1.default.recommendPlatformType.Youzi: return "RecommendConfig_Youzi";
                default: return null;
            }
        }
    };
    /**加载互推使用的所有预制件 */
    RecommendDataManager.loadPrefab = function () {
        var _this = this;
        var url = "Prefab/";
        switch (GamePlatform_1.default.instance.Config.type) {
            case GamePlatformType_1.GamePlatformType.TT: {
                url += "Recommend_TT";
                break;
            }
            case GamePlatformType_1.GamePlatformType.PC:
            default: {
                url += "Common";
                break;
            }
        }
        Loader_1.default.loadBundleDir("Recommend", url, function (res) {
            if (null === res) {
                console.log("互推预制件加载失败:", url);
                return;
            }
            for (var i = res.length - 1; i >= 0; --i) {
                var prefab = res[i];
                GlobalPool_1.default.createPool(prefab.name, prefab, prefab.name);
            }
            _this.loadFinish(AssetType.prefab);
        }, cc.Prefab, false);
    };
    /**加载所有互推游戏的icon */
    RecommendDataManager.loadGameIcon = function () {
        var _this = this;
        var url = "GameIcon/";
        switch (GamePlatform_1.default.instance.Config.type) {
            case GamePlatformType_1.GamePlatformType.OPPO: {
                url += "Icon_OPPO";
                break;
            }
            case GamePlatformType_1.GamePlatformType.TT: {
                url += "Icon_TT";
                break;
            }
            case GamePlatformType_1.GamePlatformType.PC:
            default: {
                url += "Common";
                break;
            }
        }
        Loader_1.default.loadBundleDir("Recommend", url, function (res) {
            if (null === res) {
                console.log("加载互推图片失败");
                return;
            }
            _this.gameIcons = {};
            for (var i = res.length - 1; i >= 0; --i) {
                _this.gameIcons[res[i].name] = res[i];
            }
            _this.loadFinish(AssetType.gameIcon);
        });
    };
    /**
     * 获取互推数据
     * @param id    互推数据id
     */
    RecommendDataManager.getRecommendData = function (id) {
        if (!this.data)
            return null;
        return this.data.data[id];
    };
    /**
     * 获取全部互推数据
     */
    RecommendDataManager.getAllRecommendData = function () {
        if (!this.data)
            return [];
        return this.data.data;
    };
    /**
     * 获取互推游戏的图标
     * @param icon 游戏图标文件名
     */
    RecommendDataManager.getGameIcon = function (icon) {
        return this.gameIcons[icon];
    };
    /**
     * 获取指定场景的互推配置
     * @param scene     场景/UI类型
     */
    RecommendDataManager.getRecommendConfig = function (scene) {
        if (!this.allAssetLoad || !this.data)
            return null;
        return this.data[scene];
    };
    RecommendDataManager.data = null;
    return RecommendDataManager;
}());
exports.default = RecommendDataManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxSZWNvbW1lbmRcXFJlY29tbWVuZERhdGFNYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEscURBQWdEO0FBQ2hELHVEQUFrRDtBQUNsRCw4REFBeUQ7QUFDekQseURBQW9EO0FBQ3BELGlFQUFnRTtBQUNoRSxtREFBOEM7QUFDOUMsMkNBQXNDO0FBQ3RDLGVBQWU7QUFDZixJQUFJLFNBQVMsR0FBRztJQUNaLE1BQU0sRUFBRSxDQUFDO0lBQ1QsUUFBUSxFQUFFLENBQUM7SUFDWCxNQUFNLEVBQUUsQ0FBQztDQUNaLENBQUE7QUFDRCxXQUFXO0FBQ1g7SUFBQTtJQXFLQSxDQUFDO0lBN0ppQix5QkFBSSxHQUFsQixVQUFtQixJQUFjO1FBQWpDLGlCQVdDO1FBVkcsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDMUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7UUFDckIsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7WUFDUCxnQkFBTSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUU7Z0JBQzNCLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3JCLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDbEIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztTQUNiO0lBQ0wsQ0FBQztJQUVELGNBQWM7SUFDQywrQkFBVSxHQUF6QixVQUEwQixHQUFXO1FBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQzVCLDRCQUE0QjtRQUM1QixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDbEIsS0FBSyxJQUFJLEtBQUcsSUFBSSxTQUFTLEVBQUU7WUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEtBQUcsQ0FBQyxDQUFDLEVBQUU7Z0JBQ2xDLE1BQU0sR0FBRyxLQUFLLENBQUM7Z0JBQ2YsTUFBTTthQUNUO1NBQ0o7UUFDRCxJQUFJLE1BQU0sRUFBRTtZQUNSLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ3ZCLHNCQUFZLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1NBQy9EO0lBQ0wsQ0FBQztJQUNELGFBQWE7SUFDRSwrQkFBVSxHQUF6QixVQUEwQixHQUFXO1FBQXJDLGlCQVNDO1FBUkcsZ0JBQU0sQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLFNBQVMsR0FBRyxHQUFHLEVBQUUsVUFBQyxHQUFHO1lBQ25ELElBQUksSUFBSSxLQUFLLEdBQUcsRUFBRTtnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDL0IsT0FBTzthQUNWO1lBQ0QsS0FBSSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ3JCLEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLENBQUMsRUFBRSxFQUFFLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFDRCxxQkFBcUI7SUFDTixnQ0FBVyxHQUExQixVQUEyQixJQUFjO1FBQ3JDLElBQUksTUFBTSxHQUFvQixJQUFJLENBQUM7UUFDbkMsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFO1lBQ1IsTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMseUJBQWUsQ0FBQyxDQUFDO1NBQy9DO1FBQ0QsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNULFFBQVEsc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTtnQkFDdkMsS0FBSyxtQ0FBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLHNCQUFzQixDQUFDO2dCQUMxRCxLQUFLLG1DQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDO2dCQUN0QyxLQUFLLG1DQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLENBQUM7Z0JBQ3RELEtBQUssbUNBQWdCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxvQkFBb0IsQ0FBQztnQkFDdEQseURBQXlEO2dCQUN6RCxLQUFLLG1DQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDO2dCQUN4QyxPQUFPLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQzthQUN4QjtTQUNKO2FBQU07WUFDSCxRQUFRLE1BQU0sQ0FBQyxJQUFJLEVBQUU7Z0JBQ2pCLEtBQUsseUJBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLHNCQUFzQixDQUFDO2dCQUMvRSxLQUFLLHlCQUFlLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUM7Z0JBQzNELEtBQUsseUJBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLG9CQUFvQixDQUFDO2dCQUMzRSxLQUFLLHlCQUFlLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxvQkFBb0IsQ0FBQztnQkFDM0UsS0FBSyx5QkFBZSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLENBQUM7Z0JBQzNFLEtBQUsseUJBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQztnQkFDN0QsS0FBSyx5QkFBZSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sdUJBQXVCLENBQUM7Z0JBRWpGLE9BQU8sQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDO2FBQ3hCO1NBQ0o7SUFDTCxDQUFDO0lBQ0Qsa0JBQWtCO0lBQ0gsK0JBQVUsR0FBekI7UUFBQSxpQkF3QkM7UUF2QkcsSUFBSSxHQUFHLEdBQUcsU0FBUyxDQUFDO1FBQ3BCLFFBQVEsc0JBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTtZQUN2QyxLQUFLLG1DQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN0QixHQUFHLElBQUksY0FBYyxDQUFDO2dCQUN0QixNQUFNO2FBQ1Q7WUFDRCxLQUFLLG1DQUFnQixDQUFDLEVBQUUsQ0FBQztZQUN6QixPQUFPLENBQUMsQ0FBQztnQkFDTCxHQUFHLElBQUksUUFBUSxDQUFDO2dCQUNoQixNQUFNO2FBQ1Q7U0FDSjtRQUNELGdCQUFNLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxHQUFHLEVBQUUsVUFBQyxHQUFHO1lBQ3ZDLElBQUksSUFBSSxLQUFLLEdBQUcsRUFBRTtnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDL0IsT0FBTzthQUNWO1lBQ0QsS0FBSyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN0QyxJQUFJLE1BQU0sR0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLG9CQUFVLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMzRDtZQUNELEtBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLENBQUMsRUFBRSxFQUFFLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pCLENBQUM7SUFDRCxtQkFBbUI7SUFDSixpQ0FBWSxHQUEzQjtRQUFBLGlCQTRCQztRQTNCRyxJQUFJLEdBQUcsR0FBRyxXQUFXLENBQUM7UUFDdEIsUUFBUSxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFO1lBQ3ZDLEtBQUssbUNBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3hCLEdBQUcsSUFBSSxXQUFXLENBQUM7Z0JBQ25CLE1BQU07YUFDVDtZQUNELEtBQUssbUNBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3RCLEdBQUcsSUFBSSxTQUFTLENBQUM7Z0JBQ2pCLE1BQU07YUFDVDtZQUNELEtBQUssbUNBQWdCLENBQUMsRUFBRSxDQUFDO1lBQ3pCLE9BQU8sQ0FBQyxDQUFDO2dCQUNMLEdBQUcsSUFBSSxRQUFRLENBQUM7Z0JBQ2hCLE1BQU07YUFDVDtTQUNKO1FBQ0QsZ0JBQU0sQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLEdBQUcsRUFBRSxVQUFDLEdBQUc7WUFDdkMsSUFBSSxJQUFJLEtBQUssR0FBRyxFQUFFO2dCQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3hCLE9BQU87YUFDVjtZQUNELEtBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1lBQ3BCLEtBQUssSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDdEMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3hDO1lBQ0QsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0Q7OztPQUdHO0lBQ1cscUNBQWdCLEdBQTlCLFVBQStCLEVBQVU7UUFDckMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJO1lBQUUsT0FBTyxJQUFJLENBQUM7UUFDNUIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBQ0Q7O09BRUc7SUFDVyx3Q0FBbUIsR0FBakM7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUk7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUMxQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzFCLENBQUM7SUFDRDs7O09BR0c7SUFDVyxnQ0FBVyxHQUF6QixVQUEwQixJQUFZO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBQ0Q7OztPQUdHO0lBQ1csdUNBQWtCLEdBQWhDLFVBQWlDLEtBQUs7UUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSTtZQUFFLE9BQU8sSUFBSSxDQUFDO1FBQ2xELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM1QixDQUFDO0lBbktjLHlCQUFJLEdBQVEsSUFBSSxDQUFDO0lBb0twQywyQkFBQztDQXJLRCxBQXFLQyxJQUFBO2tCQXJLb0Isb0JBQW9CIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlY29tbWVuZENvbmZpZyBmcm9tIFwiLi9SZWNvbW1lbmRDb25maWdcIjtcclxuaW1wb3J0IEV2ZW50TWFuYWdlciBmcm9tIFwiLi4vQ29tbW9uL0V2ZW50TWFuYWdlclwiO1xyXG5pbXBvcnQgeyBFdmVudFR5cGUgfSBmcm9tIFwiLi4vR2FtZVNwZWNpYWwvR2FtZUV2ZW50VHlwZVwiO1xyXG5pbXBvcnQgR2FtZVBsYXRmb3JtIGZyb20gXCIuLi9QbGF0Zm9ybS9HYW1lUGxhdGZvcm1cIjtcclxuaW1wb3J0IHsgR2FtZVBsYXRmb3JtVHlwZSB9IGZyb20gXCIuLi9QbGF0Zm9ybS9HYW1lUGxhdGZvcm1UeXBlXCI7XHJcbmltcG9ydCBHbG9iYWxQb29sIGZyb20gXCIuLi9Db21tb24vR2xvYmFsUG9vbFwiO1xyXG5pbXBvcnQgTG9hZGVyIGZyb20gXCIuLi9Db21tb24vTG9hZGVyXCI7XHJcbi8qKuS6kuaOqOmcgOimgeeahOi1hOa6kOexu+WeiyAqL1xyXG5sZXQgQXNzZXRUeXBlID0ge1xyXG4gICAgY29uZmlnOiAxLCAgICAgLy/kupLmjqjphY3nva7ooahcclxuICAgIGdhbWVJY29uOiAyLCAgICAgICAvL+a4uOaIj+Wbvuagh1xyXG4gICAgcHJlZmFiOiAzLCAgICAgICAgIC8v5LqS5o6o6aKE5Yi25Lu2XHJcbn1cclxuLy/kupLmjqjphY3nva7mlbDmja7nrqHnkIblmahcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVjb21tZW5kRGF0YU1hbmFnZXIge1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgZGF0YTogYW55ID0gbnVsbDtcclxuICAgIC8qKuWtmOWCqOaJgOaciea4uOaIj+Wbvuagh+i1hOa6kCAqL1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgZ2FtZUljb25zOiB7IFtrZXk6IHN0cmluZ106IGNjLlNwcml0ZUZyYW1lIH07XHJcbiAgICAvKirorrDlvZXmiYDmnInkupLmjqjpnIDopoHnmoTotYTmupDmmK/lkKblt7LliqDovb3lrozmiJAgKi9cclxuICAgIHByaXZhdGUgc3RhdGljIGFzc2V0U3RhdGU6IHsgW2tleTogbnVtYmVyXTogYm9vbGVhbiB9O1xyXG4gICAgLyoq5piv5ZCm5bey5Yqg6L295a6M5omA5pyJ6LWE5rqQICovXHJcbiAgICBwcml2YXRlIHN0YXRpYyBhbGxBc3NldExvYWQ6IGJvb2xlYW47XHJcbiAgICBwdWJsaWMgc3RhdGljIGluaXQobm9kZT86IGNjLk5vZGUpIHtcclxuICAgICAgICB0aGlzLmFsbEFzc2V0TG9hZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuYXNzZXRTdGF0ZSA9IHt9O1xyXG4gICAgICAgIGxldCBzdHIgPSB0aGlzLmdldEpzb25OYW1lKG5vZGUpO1xyXG4gICAgICAgIGlmICghIXN0cikge1xyXG4gICAgICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZShcIlJlY29tbWVuZFwiLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRDb25maWcoc3RyKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubG9hZFByZWZhYigpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkR2FtZUljb24oKTtcclxuICAgICAgICAgICAgfSwgZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKirotYTmupDliqDovb3lrozmiJDlm57osIMgKi9cclxuICAgIHByaXZhdGUgc3RhdGljIGxvYWRGaW5pc2goa2V5OiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLmFzc2V0U3RhdGVba2V5XSA9IHRydWU7XHJcbiAgICAgICAgLy/oi6Xlhajpg6jotYTmupDliqDovb3lrozmiJDvvIzliJnlj5HpgIHkuovku7bvvIzpgJrnn6XkupLmjqjoioLngrnmm7TmlrDlhoXlrrlcclxuICAgICAgICBsZXQgZmluaXNoID0gdHJ1ZTtcclxuICAgICAgICBmb3IgKGxldCBrZXkgaW4gQXNzZXRUeXBlKSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5hc3NldFN0YXRlW0Fzc2V0VHlwZVtrZXldXSkge1xyXG4gICAgICAgICAgICAgICAgZmluaXNoID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZmluaXNoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYWxsQXNzZXRMb2FkID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5hc3NldFN0YXRlID0gbnVsbDtcclxuICAgICAgICAgICAgRXZlbnRNYW5hZ2VyLmVtaXQoRXZlbnRUeXBlLlJlY29tbWVuZEV2ZW50LmFzc2V0TG9hZEZpbmlzaCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLyoq5Yqg6L295LqS5o6o6YWN572u6KGoICovXHJcbiAgICBwcml2YXRlIHN0YXRpYyBsb2FkQ29uZmlnKHN0cjogc3RyaW5nKSB7XHJcbiAgICAgICAgTG9hZGVyLmxvYWRCdW5kbGVSZXMoXCJSZWNvbW1lbmRcIiwgXCJDb25maWcvXCIgKyBzdHIsIChyZXMpID0+IHtcclxuICAgICAgICAgICAgaWYgKG51bGwgPT09IHJlcykge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLkupLmjqjphY3nva7ooajliqDovb3lpLHotKXvvJpcIiwgc3RyKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmRhdGEgPSByZXMuanNvbjtcclxuICAgICAgICAgICAgdGhpcy5sb2FkRmluaXNoKEFzc2V0VHlwZS5jb25maWcpO1xyXG4gICAgICAgIH0sIGNjLkpzb25Bc3NldCwgZmFsc2UpO1xyXG4gICAgfVxyXG4gICAgLyoq5qC55o2u5ri45oiP5bmz5Y+w6I635Y+W5LqS5o6o6YWN572u5paH5Lu25ZCNICovXHJcbiAgICBwcml2YXRlIHN0YXRpYyBnZXRKc29uTmFtZShub2RlPzogY2MuTm9kZSk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGNvbmZpZzogUmVjb21tZW5kQ29uZmlnID0gbnVsbDtcclxuICAgICAgICBpZiAoISFub2RlKSB7XHJcbiAgICAgICAgICAgIGNvbmZpZyA9IG5vZGUuZ2V0Q29tcG9uZW50KFJlY29tbWVuZENvbmZpZyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghY29uZmlnKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy50eXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIEdhbWVQbGF0Zm9ybVR5cGUuT1BQTzogcmV0dXJuIFwiUmVjb21tZW5kQ29uZmlnX09QUE9cIjtcclxuICAgICAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5RUTogcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgICAgICBjYXNlIEdhbWVQbGF0Zm9ybVR5cGUuVFQ6IHJldHVybiBcIlJlY29tbWVuZENvbmZpZ19UVFwiO1xyXG4gICAgICAgICAgICAgICAgY2FzZSBHYW1lUGxhdGZvcm1UeXBlLldYOiByZXR1cm4gXCJSZWNvbW1lbmRDb25maWdfV1hcIjtcclxuICAgICAgICAgICAgICAgIC8vIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5QQzogcmV0dXJuIFwiUmVjb21tZW5kQ29uZmlnX1dYXCI7XHJcbiAgICAgICAgICAgICAgICBjYXNlIEdhbWVQbGF0Zm9ybVR5cGUuVklWTzogcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OiByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoY29uZmlnLnR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgUmVjb21tZW5kQ29uZmlnLnJlY29tbWVuZFBsYXRmb3JtVHlwZS5PUFBPOiByZXR1cm4gXCJSZWNvbW1lbmRDb25maWdfT1BQT1wiO1xyXG4gICAgICAgICAgICAgICAgY2FzZSBSZWNvbW1lbmRDb25maWcucmVjb21tZW5kUGxhdGZvcm1UeXBlLlFROiByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgIGNhc2UgUmVjb21tZW5kQ29uZmlnLnJlY29tbWVuZFBsYXRmb3JtVHlwZS5UVDogcmV0dXJuIFwiUmVjb21tZW5kQ29uZmlnX1RUXCI7XHJcbiAgICAgICAgICAgICAgICBjYXNlIFJlY29tbWVuZENvbmZpZy5yZWNvbW1lbmRQbGF0Zm9ybVR5cGUuV1g6IHJldHVybiBcIlJlY29tbWVuZENvbmZpZ19XWFwiO1xyXG4gICAgICAgICAgICAgICAgY2FzZSBSZWNvbW1lbmRDb25maWcucmVjb21tZW5kUGxhdGZvcm1UeXBlLlBDOiByZXR1cm4gXCJSZWNvbW1lbmRDb25maWdfV1hcIjtcclxuICAgICAgICAgICAgICAgIGNhc2UgUmVjb21tZW5kQ29uZmlnLnJlY29tbWVuZFBsYXRmb3JtVHlwZS5WSVZPOiByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgIGNhc2UgUmVjb21tZW5kQ29uZmlnLnJlY29tbWVuZFBsYXRmb3JtVHlwZS5Zb3V6aTogcmV0dXJuIFwiUmVjb21tZW5kQ29uZmlnX1lvdXppXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDogcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKirliqDovb3kupLmjqjkvb/nlKjnmoTmiYDmnInpooTliLbku7YgKi9cclxuICAgIHByaXZhdGUgc3RhdGljIGxvYWRQcmVmYWIoKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IFwiUHJlZmFiL1wiO1xyXG4gICAgICAgIHN3aXRjaCAoR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy50eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5UVDoge1xyXG4gICAgICAgICAgICAgICAgdXJsICs9IFwiUmVjb21tZW5kX1RUXCI7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYXNlIEdhbWVQbGF0Zm9ybVR5cGUuUEM6XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IHtcclxuICAgICAgICAgICAgICAgIHVybCArPSBcIkNvbW1vblwiO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgTG9hZGVyLmxvYWRCdW5kbGVEaXIoXCJSZWNvbW1lbmRcIiwgdXJsLCAocmVzKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChudWxsID09PSByZXMpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5LqS5o6o6aKE5Yi25Lu25Yqg6L295aSx6LSlOlwiLCB1cmwpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSByZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgICAgIGxldCBwcmVmYWI6IGNjLlByZWZhYiA9IHJlc1tpXTtcclxuICAgICAgICAgICAgICAgIEdsb2JhbFBvb2wuY3JlYXRlUG9vbChwcmVmYWIubmFtZSwgcHJlZmFiLCBwcmVmYWIubmFtZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5sb2FkRmluaXNoKEFzc2V0VHlwZS5wcmVmYWIpO1xyXG4gICAgICAgIH0sIGNjLlByZWZhYiwgZmFsc2UpO1xyXG4gICAgfVxyXG4gICAgLyoq5Yqg6L295omA5pyJ5LqS5o6o5ri45oiP55qEaWNvbiAqL1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgbG9hZEdhbWVJY29uKCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBcIkdhbWVJY29uL1wiO1xyXG4gICAgICAgIHN3aXRjaCAoR2FtZVBsYXRmb3JtLmluc3RhbmNlLkNvbmZpZy50eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5PUFBPOiB7XHJcbiAgICAgICAgICAgICAgICB1cmwgKz0gXCJJY29uX09QUE9cIjtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhc2UgR2FtZVBsYXRmb3JtVHlwZS5UVDoge1xyXG4gICAgICAgICAgICAgICAgdXJsICs9IFwiSWNvbl9UVFwiO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2FzZSBHYW1lUGxhdGZvcm1UeXBlLlBDOlxyXG4gICAgICAgICAgICBkZWZhdWx0OiB7XHJcbiAgICAgICAgICAgICAgICB1cmwgKz0gXCJDb21tb25cIjtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIExvYWRlci5sb2FkQnVuZGxlRGlyKFwiUmVjb21tZW5kXCIsIHVybCwgKHJlcykgPT4ge1xyXG4gICAgICAgICAgICBpZiAobnVsbCA9PT0gcmVzKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuWKoOi9veS6kuaOqOWbvueJh+Wksei0pVwiKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmdhbWVJY29ucyA9IHt9O1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gcmVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdhbWVJY29uc1tyZXNbaV0ubmFtZV0gPSByZXNbaV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5sb2FkRmluaXNoKEFzc2V0VHlwZS5nYW1lSWNvbik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOiOt+WPluS6kuaOqOaVsOaNriBcclxuICAgICAqIEBwYXJhbSBpZCAgICDkupLmjqjmlbDmja5pZFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGdldFJlY29tbWVuZERhdGEoaWQ6IG51bWJlcikge1xyXG4gICAgICAgIGlmICghdGhpcy5kYXRhKSByZXR1cm4gbnVsbDtcclxuICAgICAgICByZXR1cm4gdGhpcy5kYXRhLmRhdGFbaWRdO1xyXG4gICAgfVxyXG4gICAgLyoqXHJcbiAgICAgKiDojrflj5blhajpg6jkupLmjqjmlbDmja5cclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBnZXRBbGxSZWNvbW1lbmREYXRhKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5kYXRhKSByZXR1cm4gW107XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZGF0YS5kYXRhO1xyXG4gICAgfVxyXG4gICAgLyoqXHJcbiAgICAgKiDojrflj5bkupLmjqjmuLjmiI/nmoTlm77moIdcclxuICAgICAqIEBwYXJhbSBpY29uIOa4uOaIj+Wbvuagh+aWh+S7tuWQjVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIGdldEdhbWVJY29uKGljb246IHN0cmluZyk6IGNjLlNwcml0ZUZyYW1lIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5nYW1lSWNvbnNbaWNvbl07XHJcbiAgICB9XHJcbiAgICAvKipcclxuICAgICAqIOiOt+WPluaMh+WumuWcuuaZr+eahOS6kuaOqOmFjee9rlxyXG4gICAgICogQHBhcmFtIHNjZW5lICAgICDlnLrmma8vVUnnsbvlnotcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBnZXRSZWNvbW1lbmRDb25maWcoc2NlbmUpIHtcclxuICAgICAgICBpZiAoIXRoaXMuYWxsQXNzZXRMb2FkIHx8ICF0aGlzLmRhdGEpIHJldHVybiBudWxsO1xyXG4gICAgICAgIHJldHVybiB0aGlzLmRhdGFbc2NlbmVdO1xyXG4gICAgfVxyXG59Il19