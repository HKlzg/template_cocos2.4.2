
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Recommend/MyAtlasSprite.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd48f33Sg+hOu7KjHW8NOSEm', 'MyAtlasSprite');
// Script/Recommend/MyAtlasSprite.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MyAtlasAssembler = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MyAtlasSprite = /** @class */ (function (_super) {
    __extends(MyAtlasSprite, _super);
    function MyAtlasSprite() {
        var _this = _super.call(this) || this;
        _this._assembler = new MyAtlasAssembler();
        _this._assembler.init(_this);
        return _this;
    }
    MyAtlasSprite.prototype.setAtlasData = function (data) {
        this.trim = false;
        this.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.node.width = data.uv.width;
        this.node.height = data.uv.height;
        this.spriteFrame = data.spriteFrame;
        this._assembler.setAtlasUV(data.uv);
    };
    MyAtlasSprite = __decorate([
        ccclass
    ], MyAtlasSprite);
    return MyAtlasSprite;
}(cc.Sprite));
exports.default = MyAtlasSprite;
var MyAtlasAssembler = /** @class */ (function (_super) {
    __extends(MyAtlasAssembler, _super);
    function MyAtlasAssembler() {
        var _this = _super.call(this) || this;
        _this.floatsPerVert = 5;
        _this.verticesCount = 4;
        _this.indicesCount = 6;
        _this.uvOffset = 2;
        _this.colorOffset = 4;
        _this._renderData = new cc.RenderData();
        _this._renderData.init(_this);
        _this.initData();
        _this.initLocal();
        return _this;
    }
    Object.defineProperty(MyAtlasAssembler.prototype, "verticesFloats", {
        get: function () {
            return this.verticesCount * this.floatsPerVert;
        },
        enumerable: false,
        configurable: true
    });
    MyAtlasAssembler.prototype.initData = function () {
        var data = this._renderData;
        data.createQuadData(0, this.verticesFloats, this.indicesCount);
    };
    MyAtlasAssembler.prototype.initLocal = function () {
        this._local = [0, 0, 0, 0];
    };
    MyAtlasAssembler.prototype.updateColor = function (comp, color) {
        var uintVerts = this._renderData.uintVDatas[0];
        if (!uintVerts)
            return;
        color = color != null ? color : comp.node.color._val;
        var floatsPerVert = this.floatsPerVert;
        var colorOffset = this.colorOffset;
        for (var i = colorOffset, l = uintVerts.length; i < l; i += floatsPerVert) {
            uintVerts[i] = color;
        }
    };
    MyAtlasAssembler.prototype.getBuffer = function (renderer) {
        return cc.renderer._handle._meshBuffer;
    };
    MyAtlasAssembler.prototype.updateWorldVerts = function (comp) {
        var local = this._local;
        var verts = this._renderData.vDatas[0];
        var matrix = this._renderComp.node._worldMatrix;
        var matrixm = matrix.m, a = matrixm[0], b = matrixm[1], c = matrixm[4], d = matrixm[5], tx = matrixm[12], ty = matrixm[13];
        var vl = local[0], vr = local[2], vb = local[1], vt = local[3];
        var justTranslate = a === 1 && b === 0 && c === 0 && d === 1;
        if (justTranslate) {
            // left bottom
            verts[0] = vl + tx;
            verts[1] = vb + ty;
            // right bottom
            verts[5] = vr + tx;
            verts[6] = vb + ty;
            // left top
            verts[10] = vl + tx;
            verts[11] = vt + ty;
            // right top
            verts[15] = vr + tx;
            verts[16] = vt + ty;
        }
        else {
            var al = a * vl, ar = a * vr, bl = b * vl, br = b * vr, cb = c * vb, ct = c * vt, db = d * vb, dt = d * vt;
            // left bottom
            verts[0] = al + cb + tx;
            verts[1] = bl + db + ty;
            // right bottom
            verts[5] = ar + cb + tx;
            verts[6] = br + db + ty;
            // left top
            verts[10] = al + ct + tx;
            verts[11] = bl + dt + ty;
            // right top
            verts[15] = ar + ct + tx;
            verts[16] = br + dt + ty;
        }
    };
    MyAtlasAssembler.prototype.fillBuffers = function (comp, renderer) {
        if (renderer.worldMatDirty) {
            this.updateWorldVerts(comp);
        }
        var renderData = this._renderData;
        var vData = renderData.vDatas[0];
        var iData = renderData.iDatas[0];
        var buffer = this.getBuffer(renderer);
        var offsetInfo = buffer.request(this.verticesCount, this.indicesCount);
        // buffer data may be realloc, need get reference after request.
        // fill vertices
        var vertexOffset = offsetInfo.byteOffset >> 2, vbuf = buffer._vData;
        if (vData.length + vertexOffset > vbuf.length) {
            vbuf.set(vData.subarray(0, vbuf.length - vertexOffset), vertexOffset);
        }
        else {
            vbuf.set(vData, vertexOffset);
        }
        // fill indices
        var ibuf = buffer._iData, indiceOffset = offsetInfo.indiceOffset, vertexId = offsetInfo.vertexOffset;
        for (var i = 0, l = iData.length; i < l; i++) {
            ibuf[indiceOffset++] = vertexId + iData[i];
        }
    };
    MyAtlasAssembler.prototype.updateVerts = function () {
        var node = this._renderComp.node, cw = node.width, ch = node.height, appx = node.anchorX * cw, appy = node.anchorY * ch, l, b, r, t;
        l = -appx;
        b = -appy;
        r = cw - appx;
        t = ch - appy;
        var local = this._local;
        local[0] = l;
        local[1] = b;
        local[2] = r;
        local[3] = t;
        this.updateWorldVerts(this._renderComp);
    };
    MyAtlasAssembler.prototype.setAtlasUV = function (uv) {
        this.updateVerts();
        var vData = this._renderData.vDatas[0];
        var floatsPerVert = this.floatsPerVert;
        var offset = this.uvOffset;
        vData[offset] = uv.left;
        vData[offset + 1] = uv.bottom;
        offset += floatsPerVert;
        vData[offset] = uv.right;
        vData[offset + 1] = uv.bottom;
        offset += floatsPerVert;
        vData[offset] = uv.left;
        vData[offset + 1] = uv.top;
        offset += floatsPerVert;
        vData[offset] = uv.right;
        vData[offset + 1] = uv.top;
    };
    return MyAtlasAssembler;
}(cc.Assembler));
exports.MyAtlasAssembler = MyAtlasAssembler;
cc.Assembler.register(MyAtlasSprite, MyAtlasAssembler);

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxSZWNvbW1lbmRcXE15QXRsYXNTcHJpdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNNLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQTJDLGlDQUFTO0lBQ2hEO1FBQUEsWUFDSSxpQkFBTyxTQUdWO1FBRkcsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLGdCQUFnQixFQUFFLENBQUM7UUFDekMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLENBQUM7O0lBQy9CLENBQUM7SUFFTSxvQ0FBWSxHQUFuQixVQUFvQixJQUFnRTtRQUNoRixJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztRQUNsQixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztRQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUNsQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFkZ0IsYUFBYTtRQURqQyxPQUFPO09BQ2EsYUFBYSxDQWVqQztJQUFELG9CQUFDO0NBZkQsQUFlQyxDQWYwQyxFQUFFLENBQUMsTUFBTSxHQWVuRDtrQkFmb0IsYUFBYTtBQWlCbEM7SUFBc0Msb0NBQVk7SUFXOUM7UUFBQSxZQUNJLGlCQUFPLFNBTVY7UUFoQkQsbUJBQWEsR0FBRyxDQUFDLENBQUM7UUFFbEIsbUJBQWEsR0FBRyxDQUFDLENBQUM7UUFDbEIsa0JBQVksR0FBRyxDQUFDLENBQUM7UUFFakIsY0FBUSxHQUFHLENBQUMsQ0FBQztRQUNiLGlCQUFXLEdBQUcsQ0FBQyxDQUFDO1FBS1osS0FBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLEVBQUUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUN2QyxLQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsQ0FBQztRQUU1QixLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsS0FBSSxDQUFDLFNBQVMsRUFBRSxDQUFDOztJQUNyQixDQUFDO0lBRUQsc0JBQUksNENBQWM7YUFBbEI7WUFDSSxPQUFPLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUNuRCxDQUFDOzs7T0FBQTtJQUVELG1DQUFRLEdBQVI7UUFDSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQzVCLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFDRCxvQ0FBUyxHQUFUO1FBQ0ksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRCxzQ0FBVyxHQUFYLFVBQWEsSUFBSSxFQUFFLEtBQUs7UUFDcEIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLFNBQVM7WUFBRSxPQUFPO1FBQ3ZCLEtBQUssR0FBRyxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztRQUNyRCxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3ZDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDbkMsS0FBSyxJQUFJLENBQUMsR0FBRyxXQUFXLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksYUFBYSxFQUFFO1lBQ3ZFLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7U0FDeEI7SUFDTCxDQUFDO0lBRUQsb0NBQVMsR0FBVCxVQUFVLFFBQVE7UUFDZCxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztJQUMzQyxDQUFDO0lBRUQsMkNBQWdCLEdBQWhCLFVBQWlCLElBQUk7UUFDakIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUN4QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV2QyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDaEQsSUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLENBQUMsRUFDbEIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFDOUQsRUFBRSxHQUFHLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXZDLElBQUksRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUM1QixFQUFFLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFakMsSUFBSSxhQUFhLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUU3RCxJQUFJLGFBQWEsRUFBRTtZQUNmLGNBQWM7WUFDZCxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUNuQixLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUNuQixlQUFlO1lBQ2YsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7WUFDbkIsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7WUFDbkIsV0FBVztZQUNYLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3BCLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3BCLFlBQVk7WUFDWixLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUNwQixLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztTQUN2QjthQUFNO1lBQ0gsSUFBSSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFDeEIsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQ3hCLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUN4QixFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUU3QixjQUFjO1lBQ2QsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3hCLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUN4QixlQUFlO1lBQ2YsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3hCLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUN4QixXQUFXO1lBQ1gsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3pCLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUN6QixZQUFZO1lBQ1osS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3pCLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztTQUM1QjtJQUNMLENBQUM7SUFFRCxzQ0FBVyxHQUFYLFVBQVksSUFBSSxFQUFFLFFBQVE7UUFDdEIsSUFBSSxRQUFRLENBQUMsYUFBYSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDbEMsSUFBSSxLQUFLLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNqQyxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWpDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEMsSUFBSSxVQUFVLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUV2RSxnRUFBZ0U7UUFFaEUsZ0JBQWdCO1FBQ2hCLElBQUksWUFBWSxHQUFHLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxFQUN6QyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUV6QixJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDM0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDO1NBQ3pFO2FBQU07WUFDSCxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxZQUFZLENBQUMsQ0FBQztTQUNqQztRQUVELGVBQWU7UUFDZixJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxFQUNwQixZQUFZLEdBQUcsVUFBVSxDQUFDLFlBQVksRUFDdEMsUUFBUSxHQUFHLFVBQVUsQ0FBQyxZQUFZLENBQUM7UUFDdkMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMxQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxRQUFRLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzlDO0lBQ0wsQ0FBQztJQUdELHNDQUFXLEdBQVg7UUFDSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFDNUIsRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsRUFBRSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQ2pDLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsRUFBRSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLEVBQ2xELENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUVmLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNWLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNWLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBQ2QsQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFFZCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3hCLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDYixLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNiLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDYixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFTSxxQ0FBVSxHQUFqQixVQUFrQixFQUFFO1FBQ2hCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3ZDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDM0IsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUM7UUFDeEIsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDO1FBRTlCLE1BQU0sSUFBSSxhQUFhLENBQUM7UUFDeEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDekIsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDO1FBRTlCLE1BQU0sSUFBSSxhQUFhLENBQUM7UUFDeEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUM7UUFDeEIsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDO1FBRTNCLE1BQU0sSUFBSSxhQUFhLENBQUM7UUFDeEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDekIsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDO0lBQy9CLENBQUM7SUFDTCx1QkFBQztBQUFELENBeEtBLEFBd0tDLENBeEtxQyxFQUFFLENBQUMsU0FBUyxHQXdLakQ7QUF4S1ksNENBQWdCO0FBeUs3QixFQUFFLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlBdGxhc1Nwcml0ZSBleHRlbmRzIGNjLlNwcml0ZSB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIHRoaXMuX2Fzc2VtYmxlciA9IG5ldyBNeUF0bGFzQXNzZW1ibGVyKCk7XHJcbiAgICAgICAgdGhpcy5fYXNzZW1ibGVyLmluaXQodGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldEF0bGFzRGF0YShkYXRhOiB7IHNwcml0ZUZyYW1lOiBjYy5TcHJpdGVGcmFtZSwgdGV4dHVyZTogY2MuVGV4dHVyZTJELCB1diB9KSB7XHJcbiAgICAgICAgdGhpcy50cmltID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5zaXplTW9kZSA9IGNjLlNwcml0ZS5TaXplTW9kZS5DVVNUT007XHJcbiAgICAgICAgdGhpcy5ub2RlLndpZHRoID0gZGF0YS51di53aWR0aDtcclxuICAgICAgICB0aGlzLm5vZGUuaGVpZ2h0ID0gZGF0YS51di5oZWlnaHQ7XHJcbiAgICAgICAgdGhpcy5zcHJpdGVGcmFtZSA9IGRhdGEuc3ByaXRlRnJhbWU7XHJcbiAgICAgICAgdGhpcy5fYXNzZW1ibGVyLnNldEF0bGFzVVYoZGF0YS51dik7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBNeUF0bGFzQXNzZW1ibGVyIGV4dGVuZHMgY2MuQXNzZW1ibGVyIHtcclxuICAgIHByb3RlY3RlZCBfcmVuZGVyRGF0YTtcclxuICAgIGZsb2F0c1BlclZlcnQgPSA1O1xyXG5cclxuICAgIHZlcnRpY2VzQ291bnQgPSA0O1xyXG4gICAgaW5kaWNlc0NvdW50ID0gNjtcclxuXHJcbiAgICB1dk9mZnNldCA9IDI7XHJcbiAgICBjb2xvck9mZnNldCA9IDQ7XHJcbiAgICBfbG9jYWw7XHJcblxyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICB0aGlzLl9yZW5kZXJEYXRhID0gbmV3IGNjLlJlbmRlckRhdGEoKTtcclxuICAgICAgICB0aGlzLl9yZW5kZXJEYXRhLmluaXQodGhpcyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5pbml0RGF0YSgpO1xyXG4gICAgICAgIHRoaXMuaW5pdExvY2FsKCk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0IHZlcnRpY2VzRmxvYXRzKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnZlcnRpY2VzQ291bnQgKiB0aGlzLmZsb2F0c1BlclZlcnQ7XHJcbiAgICB9XHJcblxyXG4gICAgaW5pdERhdGEgKCkge1xyXG4gICAgICAgIGxldCBkYXRhID0gdGhpcy5fcmVuZGVyRGF0YTtcclxuICAgICAgICBkYXRhLmNyZWF0ZVF1YWREYXRhKDAsIHRoaXMudmVydGljZXNGbG9hdHMsIHRoaXMuaW5kaWNlc0NvdW50KTtcclxuICAgIH1cclxuICAgIGluaXRMb2NhbCgpIHtcclxuICAgICAgICB0aGlzLl9sb2NhbCA9IFswLCAwLCAwLCAwXTtcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGVDb2xvciAoY29tcCwgY29sb3IpIHtcclxuICAgICAgICBsZXQgdWludFZlcnRzID0gdGhpcy5fcmVuZGVyRGF0YS51aW50VkRhdGFzWzBdO1xyXG4gICAgICAgIGlmICghdWludFZlcnRzKSByZXR1cm47XHJcbiAgICAgICAgY29sb3IgPSBjb2xvciAhPSBudWxsID8gY29sb3IgOiBjb21wLm5vZGUuY29sb3IuX3ZhbDtcclxuICAgICAgICBsZXQgZmxvYXRzUGVyVmVydCA9IHRoaXMuZmxvYXRzUGVyVmVydDtcclxuICAgICAgICBsZXQgY29sb3JPZmZzZXQgPSB0aGlzLmNvbG9yT2Zmc2V0O1xyXG4gICAgICAgIGZvciAobGV0IGkgPSBjb2xvck9mZnNldCwgbCA9IHVpbnRWZXJ0cy5sZW5ndGg7IGkgPCBsOyBpICs9IGZsb2F0c1BlclZlcnQpIHtcclxuICAgICAgICAgICAgdWludFZlcnRzW2ldID0gY29sb3I7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGdldEJ1ZmZlcihyZW5kZXJlcikge1xyXG4gICAgICAgIHJldHVybiBjYy5yZW5kZXJlci5faGFuZGxlLl9tZXNoQnVmZmVyO1xyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZVdvcmxkVmVydHMoY29tcCkge1xyXG4gICAgICAgIGxldCBsb2NhbCA9IHRoaXMuX2xvY2FsO1xyXG4gICAgICAgIGxldCB2ZXJ0cyA9IHRoaXMuX3JlbmRlckRhdGEudkRhdGFzWzBdO1xyXG5cclxuICAgICAgICBsZXQgbWF0cml4ID0gdGhpcy5fcmVuZGVyQ29tcC5ub2RlLl93b3JsZE1hdHJpeDtcclxuICAgICAgICBsZXQgbWF0cml4bSA9IG1hdHJpeC5tLFxyXG4gICAgICAgICAgICBhID0gbWF0cml4bVswXSwgYiA9IG1hdHJpeG1bMV0sIGMgPSBtYXRyaXhtWzRdLCBkID0gbWF0cml4bVs1XSxcclxuICAgICAgICAgICAgdHggPSBtYXRyaXhtWzEyXSwgdHkgPSBtYXRyaXhtWzEzXTtcclxuXHJcbiAgICAgICAgbGV0IHZsID0gbG9jYWxbMF0sIHZyID0gbG9jYWxbMl0sXHJcbiAgICAgICAgICAgIHZiID0gbG9jYWxbMV0sIHZ0ID0gbG9jYWxbM107XHJcblxyXG4gICAgICAgIGxldCBqdXN0VHJhbnNsYXRlID0gYSA9PT0gMSAmJiBiID09PSAwICYmIGMgPT09IDAgJiYgZCA9PT0gMTtcclxuXHJcbiAgICAgICAgaWYgKGp1c3RUcmFuc2xhdGUpIHtcclxuICAgICAgICAgICAgLy8gbGVmdCBib3R0b21cclxuICAgICAgICAgICAgdmVydHNbMF0gPSB2bCArIHR4O1xyXG4gICAgICAgICAgICB2ZXJ0c1sxXSA9IHZiICsgdHk7XHJcbiAgICAgICAgICAgIC8vIHJpZ2h0IGJvdHRvbVxyXG4gICAgICAgICAgICB2ZXJ0c1s1XSA9IHZyICsgdHg7XHJcbiAgICAgICAgICAgIHZlcnRzWzZdID0gdmIgKyB0eTtcclxuICAgICAgICAgICAgLy8gbGVmdCB0b3BcclxuICAgICAgICAgICAgdmVydHNbMTBdID0gdmwgKyB0eDtcclxuICAgICAgICAgICAgdmVydHNbMTFdID0gdnQgKyB0eTtcclxuICAgICAgICAgICAgLy8gcmlnaHQgdG9wXHJcbiAgICAgICAgICAgIHZlcnRzWzE1XSA9IHZyICsgdHg7XHJcbiAgICAgICAgICAgIHZlcnRzWzE2XSA9IHZ0ICsgdHk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IGFsID0gYSAqIHZsLCBhciA9IGEgKiB2cixcclxuICAgICAgICAgICAgICAgIGJsID0gYiAqIHZsLCBiciA9IGIgKiB2cixcclxuICAgICAgICAgICAgICAgIGNiID0gYyAqIHZiLCBjdCA9IGMgKiB2dCxcclxuICAgICAgICAgICAgICAgIGRiID0gZCAqIHZiLCBkdCA9IGQgKiB2dDtcclxuXHJcbiAgICAgICAgICAgIC8vIGxlZnQgYm90dG9tXHJcbiAgICAgICAgICAgIHZlcnRzWzBdID0gYWwgKyBjYiArIHR4O1xyXG4gICAgICAgICAgICB2ZXJ0c1sxXSA9IGJsICsgZGIgKyB0eTtcclxuICAgICAgICAgICAgLy8gcmlnaHQgYm90dG9tXHJcbiAgICAgICAgICAgIHZlcnRzWzVdID0gYXIgKyBjYiArIHR4O1xyXG4gICAgICAgICAgICB2ZXJ0c1s2XSA9IGJyICsgZGIgKyB0eTtcclxuICAgICAgICAgICAgLy8gbGVmdCB0b3BcclxuICAgICAgICAgICAgdmVydHNbMTBdID0gYWwgKyBjdCArIHR4O1xyXG4gICAgICAgICAgICB2ZXJ0c1sxMV0gPSBibCArIGR0ICsgdHk7XHJcbiAgICAgICAgICAgIC8vIHJpZ2h0IHRvcFxyXG4gICAgICAgICAgICB2ZXJ0c1sxNV0gPSBhciArIGN0ICsgdHg7XHJcbiAgICAgICAgICAgIHZlcnRzWzE2XSA9IGJyICsgZHQgKyB0eTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZmlsbEJ1ZmZlcnMoY29tcCwgcmVuZGVyZXIpIHtcclxuICAgICAgICBpZiAocmVuZGVyZXIud29ybGRNYXREaXJ0eSkge1xyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVdvcmxkVmVydHMoY29tcCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcmVuZGVyRGF0YSA9IHRoaXMuX3JlbmRlckRhdGE7XHJcbiAgICAgICAgbGV0IHZEYXRhID0gcmVuZGVyRGF0YS52RGF0YXNbMF07XHJcbiAgICAgICAgbGV0IGlEYXRhID0gcmVuZGVyRGF0YS5pRGF0YXNbMF07XHJcblxyXG4gICAgICAgIGxldCBidWZmZXIgPSB0aGlzLmdldEJ1ZmZlcihyZW5kZXJlcik7XHJcbiAgICAgICAgbGV0IG9mZnNldEluZm8gPSBidWZmZXIucmVxdWVzdCh0aGlzLnZlcnRpY2VzQ291bnQsIHRoaXMuaW5kaWNlc0NvdW50KTtcclxuXHJcbiAgICAgICAgLy8gYnVmZmVyIGRhdGEgbWF5IGJlIHJlYWxsb2MsIG5lZWQgZ2V0IHJlZmVyZW5jZSBhZnRlciByZXF1ZXN0LlxyXG5cclxuICAgICAgICAvLyBmaWxsIHZlcnRpY2VzXHJcbiAgICAgICAgbGV0IHZlcnRleE9mZnNldCA9IG9mZnNldEluZm8uYnl0ZU9mZnNldCA+PiAyLFxyXG4gICAgICAgICAgICB2YnVmID0gYnVmZmVyLl92RGF0YTtcclxuXHJcbiAgICAgICAgaWYgKHZEYXRhLmxlbmd0aCArIHZlcnRleE9mZnNldCA+IHZidWYubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHZidWYuc2V0KHZEYXRhLnN1YmFycmF5KDAsIHZidWYubGVuZ3RoIC0gdmVydGV4T2Zmc2V0KSwgdmVydGV4T2Zmc2V0KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB2YnVmLnNldCh2RGF0YSwgdmVydGV4T2Zmc2V0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIGZpbGwgaW5kaWNlc1xyXG4gICAgICAgIGxldCBpYnVmID0gYnVmZmVyLl9pRGF0YSxcclxuICAgICAgICAgICAgaW5kaWNlT2Zmc2V0ID0gb2Zmc2V0SW5mby5pbmRpY2VPZmZzZXQsXHJcbiAgICAgICAgICAgIHZlcnRleElkID0gb2Zmc2V0SW5mby52ZXJ0ZXhPZmZzZXQ7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGwgPSBpRGF0YS5sZW5ndGg7IGkgPCBsOyBpKyspIHtcclxuICAgICAgICAgICAgaWJ1ZltpbmRpY2VPZmZzZXQrK10gPSB2ZXJ0ZXhJZCArIGlEYXRhW2ldO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgdXBkYXRlVmVydHMoKSB7XHJcbiAgICAgICAgbGV0IG5vZGUgPSB0aGlzLl9yZW5kZXJDb21wLm5vZGUsXHJcbiAgICAgICAgICAgIGN3ID0gbm9kZS53aWR0aCwgY2ggPSBub2RlLmhlaWdodCxcclxuICAgICAgICAgICAgYXBweCA9IG5vZGUuYW5jaG9yWCAqIGN3LCBhcHB5ID0gbm9kZS5hbmNob3JZICogY2gsXHJcbiAgICAgICAgICAgIGwsIGIsIHIsIHQ7XHJcblxyXG4gICAgICAgIGwgPSAtYXBweDtcclxuICAgICAgICBiID0gLWFwcHk7XHJcbiAgICAgICAgciA9IGN3IC0gYXBweDtcclxuICAgICAgICB0ID0gY2ggLSBhcHB5O1xyXG5cclxuICAgICAgICBsZXQgbG9jYWwgPSB0aGlzLl9sb2NhbDtcclxuICAgICAgICBsb2NhbFswXSA9IGw7XHJcbiAgICAgICAgbG9jYWxbMV0gPSBiO1xyXG4gICAgICAgIGxvY2FsWzJdID0gcjtcclxuICAgICAgICBsb2NhbFszXSA9IHQ7XHJcbiAgICAgICAgdGhpcy51cGRhdGVXb3JsZFZlcnRzKHRoaXMuX3JlbmRlckNvbXApO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRBdGxhc1VWKHV2KSB7XHJcbiAgICAgICAgdGhpcy51cGRhdGVWZXJ0cygpO1xyXG4gICAgICAgIGxldCB2RGF0YSA9IHRoaXMuX3JlbmRlckRhdGEudkRhdGFzWzBdO1xyXG4gICAgICAgIGxldCBmbG9hdHNQZXJWZXJ0ID0gdGhpcy5mbG9hdHNQZXJWZXJ0O1xyXG4gICAgICAgIGxldCBvZmZzZXQgPSB0aGlzLnV2T2Zmc2V0O1xyXG4gICAgICAgIHZEYXRhW29mZnNldF0gPSB1di5sZWZ0O1xyXG4gICAgICAgIHZEYXRhW29mZnNldCArIDFdID0gdXYuYm90dG9tO1xyXG5cclxuICAgICAgICBvZmZzZXQgKz0gZmxvYXRzUGVyVmVydDtcclxuICAgICAgICB2RGF0YVtvZmZzZXRdID0gdXYucmlnaHQ7XHJcbiAgICAgICAgdkRhdGFbb2Zmc2V0ICsgMV0gPSB1di5ib3R0b207XHJcblxyXG4gICAgICAgIG9mZnNldCArPSBmbG9hdHNQZXJWZXJ0O1xyXG4gICAgICAgIHZEYXRhW29mZnNldF0gPSB1di5sZWZ0O1xyXG4gICAgICAgIHZEYXRhW29mZnNldCArIDFdID0gdXYudG9wO1xyXG5cclxuICAgICAgICBvZmZzZXQgKz0gZmxvYXRzUGVyVmVydDtcclxuICAgICAgICB2RGF0YVtvZmZzZXRdID0gdXYucmlnaHQ7XHJcbiAgICAgICAgdkRhdGFbb2Zmc2V0ICsgMV0gPSB1di50b3A7XHJcbiAgICB9XHJcbn1cclxuY2MuQXNzZW1ibGVyLnJlZ2lzdGVyKE15QXRsYXNTcHJpdGUsIE15QXRsYXNBc3NlbWJsZXIpO1xyXG4iXX0=