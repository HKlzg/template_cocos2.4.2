
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Recommend/RecommendContainer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ba32fZzFh9Kwr/9o3ZFk9hA', 'RecommendContainer');
// Script/Recommend/RecommendContainer.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../Common/yyComponent");
var GlobalPool_1 = require("../Common/GlobalPool");
var GlobalEnum_1 = require("../GameSpecial/GlobalEnum");
var RecommendDataManager_1 = require("./RecommendDataManager");
//互推游戏节点容器
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecommendContainer = /** @class */ (function (_super) {
    __extends(RecommendContainer, _super);
    function RecommendContainer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.content = null; //存放互推节点的父节点
        return _this;
    }
    RecommendContainer.prototype.init = function (data) {
        this.onEvents();
        if (!!data) {
            this.setData(data);
        }
    };
    RecommendContainer.prototype.onEvents = function () {
    };
    RecommendContainer.prototype.reset = function () {
        this.resetItems();
    };
    RecommendContainer.prototype.resetItems = function () {
        GlobalPool_1.default.putAllChildren(this.content);
    };
    RecommendContainer.prototype.reuse = function (data) {
        this.reset();
        this.setData(data);
    };
    RecommendContainer.prototype.unuse = function () {
    };
    RecommendContainer.prototype.setData = function (data) {
        var items = data.items;
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        this.addItems(items);
    };
    //添加互推游戏节点
    RecommendContainer.prototype.addItems = function (data, type) {
        if (type === void 0) { type = GlobalEnum_1.GlobalEnum.RecommendItemType.normal; }
        for (var i = 0, count = data.length; i < count; ++i) {
            var item = this.getItem(type, data[i]);
            this.content.addChild(item);
        }
    };
    /**根据类型获取对应的预制件 */
    RecommendContainer.prototype.getItem = function (prefabName, data) {
        return GlobalPool_1.default.get(prefabName, data);
    };
    //设置布局组件
    RecommendContainer.prototype.setWidget = function (node, widget, targetNode) {
        var wg = node.getComponent(cc.Widget);
        if (!wg) {
            wg = node.addComponent(cc.Widget);
        }
        wg.isAbsoluteBottom = true;
        wg.isAbsoluteLeft = true;
        wg.isAbsoluteRight = true;
        wg.isAbsoluteTop = true;
        wg.isAbsoluteHorizontalCenter = true;
        wg.isAbsoluteVerticalCenter = true;
        if (!widget)
            return;
        if (!!targetNode) {
            wg.target = targetNode;
        }
        else {
            wg.target = node.parent;
        }
        if (undefined != widget.top) {
            wg.isAlignTop = true;
            wg.top = parseFloat(widget.top);
        }
        else {
            wg.isAlignTop = false;
        }
        if (undefined != widget.bottom) {
            wg.isAlignBottom = true;
            wg.bottom = parseFloat(widget.bottom);
        }
        else {
            wg.isAlignBottom = false;
        }
        if (undefined != widget.left) {
            wg.isAlignLeft = true;
            wg.left = parseFloat(widget.left);
        }
        else {
            wg.isAlignLeft = false;
        }
        if (undefined != widget.right) {
            wg.isAlignRight = true;
            wg.right = parseFloat(widget.right);
        }
        else {
            wg.isAlignRight = false;
        }
        wg.isAlignHorizontalCenter = !!widget.horizontalCenter;
        wg.isAlignVerticalCenter = !!widget.verticalCenter;
        wg.updateAlignment();
    };
    __decorate([
        property(cc.Node)
    ], RecommendContainer.prototype, "content", void 0);
    RecommendContainer = __decorate([
        ccclass
    ], RecommendContainer);
    return RecommendContainer;
}(yyComponent_1.default));
exports.default = RecommendContainer;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxSZWNvbW1lbmRcXFJlY29tbWVuZENvbnRhaW5lci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxxREFBZ0Q7QUFDaEQsbURBQThDO0FBQzlDLHdEQUF1RDtBQUN2RCwrREFBMEQ7QUFFMUQsVUFBVTtBQUNKLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQWdELHNDQUFXO0lBQTNEO1FBQUEscUVBK0ZDO1FBN0ZhLGFBQU8sR0FBWSxJQUFJLENBQUMsQ0FBSSxZQUFZOztJQTZGdEQsQ0FBQztJQTNGVSxpQ0FBSSxHQUFYLFVBQVksSUFBVTtRQUVsQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFO1lBQ1IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN0QjtJQUNMLENBQUM7SUFDUyxxQ0FBUSxHQUFsQjtJQUVBLENBQUM7SUFDTSxrQ0FBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFDUyx1Q0FBVSxHQUFwQjtRQUNJLG9CQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ00sa0NBQUssR0FBWixVQUFhLElBQVM7UUFDbEIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN2QixDQUFDO0lBRU0sa0NBQUssR0FBWjtJQUVBLENBQUM7SUFFUyxvQ0FBTyxHQUFqQixVQUFrQixJQUFTO1FBQ3ZCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLEtBQUssRUFBRTtZQUNSLEtBQUssR0FBRyw4QkFBb0IsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1NBQ3REO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBRUQsVUFBVTtJQUNBLHFDQUFRLEdBQWxCLFVBQW1CLElBQVcsRUFBRSxJQUEwQztRQUExQyxxQkFBQSxFQUFBLE9BQU8sdUJBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNO1FBQ3RFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDakQsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7SUFDTCxDQUFDO0lBQ0Qsa0JBQWtCO0lBQ1Isb0NBQU8sR0FBakIsVUFBa0IsVUFBVSxFQUFFLElBQVM7UUFDbkMsT0FBTyxvQkFBVSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELFFBQVE7SUFDRSxzQ0FBUyxHQUFuQixVQUFvQixJQUFhLEVBQUUsTUFBVyxFQUFFLFVBQW9CO1FBQ2hFLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDTCxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDckM7UUFDRCxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBQzNCLEVBQUUsQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQ3pCLEVBQUUsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQzFCLEVBQUUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLEVBQUUsQ0FBQywwQkFBMEIsR0FBRyxJQUFJLENBQUM7UUFDckMsRUFBRSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQztRQUNuQyxJQUFJLENBQUMsTUFBTTtZQUFFLE9BQU87UUFDcEIsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFO1lBQ2QsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7U0FDMUI7YUFBTTtZQUNILEVBQUUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztTQUMzQjtRQUNELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxHQUFHLEVBQUU7WUFDekIsRUFBRSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDckIsRUFBRSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ25DO2FBQU07WUFDSCxFQUFFLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztTQUN6QjtRQUNELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEVBQUU7WUFDNUIsRUFBRSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7WUFDeEIsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3pDO2FBQU07WUFDSCxFQUFFLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztTQUM1QjtRQUNELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEVBQUU7WUFDMUIsRUFBRSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFDdEIsRUFBRSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3JDO2FBQU07WUFDSCxFQUFFLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUMxQjtRQUNELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDM0IsRUFBRSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDdkIsRUFBRSxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3ZDO2FBQU07WUFDSCxFQUFFLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztTQUMzQjtRQUNELEVBQUUsQ0FBQyx1QkFBdUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1FBQ3ZELEVBQUUsQ0FBQyxxQkFBcUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQztRQUNuRCxFQUFFLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQTVGRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO3VEQUNnQjtJQUZqQixrQkFBa0I7UUFEdEMsT0FBTztPQUNhLGtCQUFrQixDQStGdEM7SUFBRCx5QkFBQztDQS9GRCxBQStGQyxDQS9GK0MscUJBQVcsR0ErRjFEO2tCQS9Gb0Isa0JBQWtCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHl5Q29tcG9uZW50IGZyb20gXCIuLi9Db21tb24veXlDb21wb25lbnRcIjtcclxuaW1wb3J0IEdsb2JhbFBvb2wgZnJvbSBcIi4uL0NvbW1vbi9HbG9iYWxQb29sXCI7XHJcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vR2FtZVNwZWNpYWwvR2xvYmFsRW51bVwiO1xyXG5pbXBvcnQgUmVjb21tZW5kRGF0YU1hbmFnZXIgZnJvbSBcIi4vUmVjb21tZW5kRGF0YU1hbmFnZXJcIjtcclxuXHJcbi8v5LqS5o6o5ri45oiP6IqC54K55a655ZmoXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZWNvbW1lbmRDb250YWluZXIgZXh0ZW5kcyB5eUNvbXBvbmVudCB7XHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb3RlY3RlZCBjb250ZW50OiBjYy5Ob2RlID0gbnVsbDsgICAgLy/lrZjmlL7kupLmjqjoioLngrnnmoTniLboioLngrlcclxuXHJcbiAgICBwdWJsaWMgaW5pdChkYXRhPzogYW55KSB7XHJcblxyXG4gICAgICAgIHRoaXMub25FdmVudHMoKTtcclxuICAgICAgICBpZiAoISFkYXRhKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YShkYXRhKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgb25FdmVudHMoKSB7XHJcblxyXG4gICAgfVxyXG4gICAgcHVibGljIHJlc2V0KCkge1xyXG4gICAgICAgIHRoaXMucmVzZXRJdGVtcygpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHJlc2V0SXRlbXMoKSB7XHJcbiAgICAgICAgR2xvYmFsUG9vbC5wdXRBbGxDaGlsZHJlbih0aGlzLmNvbnRlbnQpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHJldXNlKGRhdGE6IGFueSkge1xyXG4gICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICB0aGlzLnNldERhdGEoZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHVudXNlKCkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0RGF0YShkYXRhOiBhbnkpIHtcclxuICAgICAgICBsZXQgaXRlbXMgPSBkYXRhLml0ZW1zO1xyXG4gICAgICAgIGlmICghaXRlbXMpIHtcclxuICAgICAgICAgICAgaXRlbXMgPSBSZWNvbW1lbmREYXRhTWFuYWdlci5nZXRBbGxSZWNvbW1lbmREYXRhKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuYWRkSXRlbXMoaXRlbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8v5re75Yqg5LqS5o6o5ri45oiP6IqC54K5XHJcbiAgICBwcm90ZWN0ZWQgYWRkSXRlbXMoZGF0YTogYW55W10sIHR5cGUgPSBHbG9iYWxFbnVtLlJlY29tbWVuZEl0ZW1UeXBlLm5vcm1hbCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBjb3VudCA9IGRhdGEubGVuZ3RoOyBpIDwgY291bnQ7ICsraSkge1xyXG4gICAgICAgICAgICBsZXQgaXRlbSA9IHRoaXMuZ2V0SXRlbSh0eXBlLCBkYXRhW2ldKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50LmFkZENoaWxkKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8qKuagueaNruexu+Wei+iOt+WPluWvueW6lOeahOmihOWItuS7tiAqL1xyXG4gICAgcHJvdGVjdGVkIGdldEl0ZW0ocHJlZmFiTmFtZSwgZGF0YTogYW55KSB7XHJcbiAgICAgICAgcmV0dXJuIEdsb2JhbFBvb2wuZ2V0KHByZWZhYk5hbWUsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8v6K6+572u5biD5bGA57uE5Lu2XHJcbiAgICBwcm90ZWN0ZWQgc2V0V2lkZ2V0KG5vZGU6IGNjLk5vZGUsIHdpZGdldDogYW55LCB0YXJnZXROb2RlPzogY2MuTm9kZSkge1xyXG4gICAgICAgIGxldCB3ZyA9IG5vZGUuZ2V0Q29tcG9uZW50KGNjLldpZGdldCk7XHJcbiAgICAgICAgaWYgKCF3Zykge1xyXG4gICAgICAgICAgICB3ZyA9IG5vZGUuYWRkQ29tcG9uZW50KGNjLldpZGdldCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHdnLmlzQWJzb2x1dGVCb3R0b20gPSB0cnVlO1xyXG4gICAgICAgIHdnLmlzQWJzb2x1dGVMZWZ0ID0gdHJ1ZTtcclxuICAgICAgICB3Zy5pc0Fic29sdXRlUmlnaHQgPSB0cnVlO1xyXG4gICAgICAgIHdnLmlzQWJzb2x1dGVUb3AgPSB0cnVlO1xyXG4gICAgICAgIHdnLmlzQWJzb2x1dGVIb3Jpem9udGFsQ2VudGVyID0gdHJ1ZTtcclxuICAgICAgICB3Zy5pc0Fic29sdXRlVmVydGljYWxDZW50ZXIgPSB0cnVlO1xyXG4gICAgICAgIGlmICghd2lkZ2V0KSByZXR1cm47XHJcbiAgICAgICAgaWYgKCEhdGFyZ2V0Tm9kZSkge1xyXG4gICAgICAgICAgICB3Zy50YXJnZXQgPSB0YXJnZXROb2RlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHdnLnRhcmdldCA9IG5vZGUucGFyZW50O1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodW5kZWZpbmVkICE9IHdpZGdldC50b3ApIHtcclxuICAgICAgICAgICAgd2cuaXNBbGlnblRvcCA9IHRydWU7XHJcbiAgICAgICAgICAgIHdnLnRvcCA9IHBhcnNlRmxvYXQod2lkZ2V0LnRvcCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgd2cuaXNBbGlnblRvcCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodW5kZWZpbmVkICE9IHdpZGdldC5ib3R0b20pIHtcclxuICAgICAgICAgICAgd2cuaXNBbGlnbkJvdHRvbSA9IHRydWU7XHJcbiAgICAgICAgICAgIHdnLmJvdHRvbSA9IHBhcnNlRmxvYXQod2lkZ2V0LmJvdHRvbSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgd2cuaXNBbGlnbkJvdHRvbSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodW5kZWZpbmVkICE9IHdpZGdldC5sZWZ0KSB7XHJcbiAgICAgICAgICAgIHdnLmlzQWxpZ25MZWZ0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgd2cubGVmdCA9IHBhcnNlRmxvYXQod2lkZ2V0LmxlZnQpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHdnLmlzQWxpZ25MZWZ0ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh1bmRlZmluZWQgIT0gd2lkZ2V0LnJpZ2h0KSB7XHJcbiAgICAgICAgICAgIHdnLmlzQWxpZ25SaWdodCA9IHRydWU7XHJcbiAgICAgICAgICAgIHdnLnJpZ2h0ID0gcGFyc2VGbG9hdCh3aWRnZXQucmlnaHQpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHdnLmlzQWxpZ25SaWdodCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICB3Zy5pc0FsaWduSG9yaXpvbnRhbENlbnRlciA9ICEhd2lkZ2V0Lmhvcml6b250YWxDZW50ZXI7XHJcbiAgICAgICAgd2cuaXNBbGlnblZlcnRpY2FsQ2VudGVyID0gISF3aWRnZXQudmVydGljYWxDZW50ZXI7XHJcbiAgICAgICAgd2cudXBkYXRlQWxpZ25tZW50KCk7XHJcbiAgICB9XHJcbn1cclxuIl19