
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Recommend/RecommendConfig.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5e757y7KrNODqAfXpNcgrrP', 'RecommendConfig');
// Script/Recommend/RecommendConfig.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**使用Youzi互推时，管理后台提供的平台渠道 默认微信 */
var PLAT_TYPE_CHANNELID = {
    Test: 1001,
    WeChat: 1002,
    Oppo: 8001,
    TouTiao: 11001 //头条小游戏
};
/**互推配置脚本，挂载在互推根节点上 */
var RecommendConfig = /** @class */ (function (_super) {
    __extends(RecommendConfig, _super);
    function RecommendConfig() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = RecommendConfig_1.recommendPlatformType.PC;
        _this.Youzi_Appid = "";
        _this.Youzi_ResVersion = "1.00.00";
        _this._Youzi_ChannelId = RecommendConfig_1.YouziChannelType.WeChat;
        return _this;
    }
    RecommendConfig_1 = RecommendConfig;
    Object.defineProperty(RecommendConfig.prototype, "Youzi_ChannelId", {
        get: function () {
            if (this._Youzi_ChannelId == PLAT_TYPE_CHANNELID.Test) {
                return PLAT_TYPE_CHANNELID.WeChat;
            }
            else {
                return this._Youzi_ChannelId;
            }
        },
        enumerable: false,
        configurable: true
    });
    var RecommendConfig_1;
    RecommendConfig.recommendPlatformType = cc.Enum({
        PC: 0,
        WX: -1,
        TT: -1,
        QQ: -1,
        OPPO: -1,
        VIVO: -1,
        XiaoMi: -1,
        LeYou: -1,
        DYB_QQ: -1,
        Blue_Android: -1,
        Blue_IOS: -1,
        Youzi: -1,
    });
    RecommendConfig.YouziChannelType = cc.Enum(PLAT_TYPE_CHANNELID);
    __decorate([
        property({
            type: RecommendConfig_1.recommendPlatformType,
            tooltip: "互推类型",
        })
    ], RecommendConfig.prototype, "type", void 0);
    __decorate([
        property({
            tooltip: "使用Youzi互推时，渠道提供的appid 如果是微信渠道 填写微信后台提供的appid。"
        })
    ], RecommendConfig.prototype, "Youzi_Appid", void 0);
    __decorate([
        property({
            tooltip: "使用Youzi互推时，中心化资源版本 中心化提供的资源版本号 向中心化对接组咨询 默认'1.00.00'。"
        })
    ], RecommendConfig.prototype, "Youzi_ResVersion", void 0);
    __decorate([
        property({
            type: RecommendConfig_1.YouziChannelType,
            tooltip: "使用Youzi互推时，管理后台提供的平台渠道 默认微信",
            visible: true,
        })
    ], RecommendConfig.prototype, "_Youzi_ChannelId", void 0);
    RecommendConfig = RecommendConfig_1 = __decorate([
        ccclass
    ], RecommendConfig);
    return RecommendConfig;
}(cc.Component));
exports.default = RecommendConfig;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxSZWNvbW1lbmRcXFJlY29tbWVuZENvbmZpZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDTSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUM1QyxpQ0FBaUM7QUFDakMsSUFBTSxtQkFBbUIsR0FBRztJQUN4QixJQUFJLEVBQUUsSUFBSTtJQUNWLE1BQU0sRUFBRSxJQUFJO0lBQ1osSUFBSSxFQUFFLElBQUk7SUFDVixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87Q0FDekIsQ0FBQztBQUVGLHNCQUFzQjtBQUV0QjtJQUE2QyxtQ0FBWTtJQUF6RDtRQUFBLHFFQThDQztRQXpCVSxVQUFJLEdBQVcsaUJBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUM7UUFJeEQsaUJBQVcsR0FBVyxFQUFFLENBQUM7UUFJekIsc0JBQWdCLEdBQVcsU0FBUyxDQUFDO1FBT2xDLHNCQUFnQixHQUFXLGlCQUFlLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDOztJQVVqRixDQUFDO3dCQTlDb0IsZUFBZTtJQXFDaEMsc0JBQVcsNENBQWU7YUFBMUI7WUFDSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxtQkFBbUIsQ0FBQyxJQUFJLEVBQUU7Z0JBQ25ELE9BQU8sbUJBQW1CLENBQUMsTUFBTSxDQUFDO2FBQ3JDO2lCQUFNO2dCQUNILE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO2FBQ2hDO1FBQ0wsQ0FBQzs7O09BQUE7O0lBekNhLHFDQUFxQixHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUM7UUFDMUMsRUFBRSxFQUFFLENBQUM7UUFDTCxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ04sRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNOLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDTixJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQ1IsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUNSLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVixLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQ1QsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWLFlBQVksRUFBRSxDQUFDLENBQUM7UUFDaEIsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUNaLEtBQUssRUFBRSxDQUFDLENBQUM7S0FDWixDQUFDLENBQUM7SUFlVyxnQ0FBZ0IsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFUOUQ7UUFKQyxRQUFRLENBQUM7WUFDTixJQUFJLEVBQUUsaUJBQWUsQ0FBQyxxQkFBcUI7WUFDM0MsT0FBTyxFQUFFLE1BQU07U0FDbEIsQ0FBQztpREFDNkQ7SUFJL0Q7UUFIQyxRQUFRLENBQUM7WUFDTixPQUFPLEVBQUUsK0NBQStDO1NBQzNELENBQUM7d0RBQzhCO0lBSWhDO1FBSEMsUUFBUSxDQUFDO1lBQ04sT0FBTyxFQUFFLHVEQUF1RDtTQUNuRSxDQUFDOzZEQUMwQztJQU81QztRQUxDLFFBQVEsQ0FBQztZQUNOLElBQUksRUFBRSxpQkFBZSxDQUFDLGdCQUFnQjtZQUN0QyxPQUFPLEVBQUUsNkJBQTZCO1lBQ3RDLE9BQU8sRUFBRSxJQUFJO1NBQ2hCLENBQUM7NkRBQzJFO0lBcEM1RCxlQUFlO1FBRG5DLE9BQU87T0FDYSxlQUFlLENBOENuQztJQUFELHNCQUFDO0NBOUNELEFBOENDLENBOUM0QyxFQUFFLENBQUMsU0FBUyxHQThDeEQ7a0JBOUNvQixlQUFlIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcbi8qKuS9v+eUqFlvdXpp5LqS5o6o5pe277yM566h55CG5ZCO5Y+w5o+Q5L6b55qE5bmz5Y+w5rig6YGTIOm7mOiupOW+ruS/oSAqL1xyXG5jb25zdCBQTEFUX1RZUEVfQ0hBTk5FTElEID0ge1xyXG4gICAgVGVzdDogMTAwMSwgLy/mtYvor5XkuZ/nlKjlvq7kv6HvvIzmraTlpITkuLrpgb/lhY1jYy5FbnVt5oql6ZSZ77yM5L2/55SoMTAwMSzvvIxnZXTorr/pl67ml7bkvJroh6rliqjlj5jkuLoxMDAyXHJcbiAgICBXZUNoYXQ6IDEwMDIsIC8v5b6u5L+hXHJcbiAgICBPcHBvOiA4MDAxLCAgLy9vcHBv5bCP5ri45oiPXHJcbiAgICBUb3VUaWFvOiAxMTAwMSAvL+WktOadoeWwj+a4uOaIj1xyXG59O1xyXG5cclxuLyoq5LqS5o6o6YWN572u6ISa5pys77yM5oyC6L295Zyo5LqS5o6o5qC56IqC54K55LiKICovXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFJlY29tbWVuZENvbmZpZyBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyByZWNvbW1lbmRQbGF0Zm9ybVR5cGUgPSBjYy5FbnVtKHtcclxuICAgICAgICBQQzogMCxcclxuICAgICAgICBXWDogLTEsXHJcbiAgICAgICAgVFQ6IC0xLFxyXG4gICAgICAgIFFROiAtMSxcclxuICAgICAgICBPUFBPOiAtMSxcclxuICAgICAgICBWSVZPOiAtMSxcclxuICAgICAgICBYaWFvTWk6IC0xLFxyXG4gICAgICAgIExlWW91OiAtMSxcclxuICAgICAgICBEWUJfUVE6IC0xLFxyXG4gICAgICAgIEJsdWVfQW5kcm9pZDogLTEsXHJcbiAgICAgICAgQmx1ZV9JT1M6IC0xLFxyXG4gICAgICAgIFlvdXppOiAtMSxcclxuICAgIH0pO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTogUmVjb21tZW5kQ29uZmlnLnJlY29tbWVuZFBsYXRmb3JtVHlwZSxcclxuICAgICAgICB0b29sdGlwOiBcIuS6kuaOqOexu+Wei1wiLFxyXG4gICAgfSlcclxuICAgIHB1YmxpYyB0eXBlOiBudW1iZXIgPSBSZWNvbW1lbmRDb25maWcucmVjb21tZW5kUGxhdGZvcm1UeXBlLlBDO1xyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB0b29sdGlwOiBcIuS9v+eUqFlvdXpp5LqS5o6o5pe277yM5rig6YGT5o+Q5L6b55qEYXBwaWQg5aaC5p6c5piv5b6u5L+h5rig6YGTIOWhq+WGmeW+ruS/oeWQjuWPsOaPkOS+m+eahGFwcGlk44CCXCJcclxuICAgIH0pXHJcbiAgICBwdWJsaWMgWW91emlfQXBwaWQ6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHRvb2x0aXA6IFwi5L2/55SoWW91emnkupLmjqjml7bvvIzkuK3lv4PljJbotYTmupDniYjmnKwg5Lit5b+D5YyW5o+Q5L6b55qE6LWE5rqQ54mI5pys5Y+3IOWQkeS4reW/g+WMluWvueaOpee7hOWSqOivoiDpu5jorqQnMS4wMC4wMCfjgIJcIlxyXG4gICAgfSlcclxuICAgIHB1YmxpYyBZb3V6aV9SZXNWZXJzaW9uOiBzdHJpbmcgPSBcIjEuMDAuMDBcIjtcclxuICAgIHB1YmxpYyBzdGF0aWMgWW91emlDaGFubmVsVHlwZSA9IGNjLkVudW0oUExBVF9UWVBFX0NIQU5ORUxJRCk7XHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6IFJlY29tbWVuZENvbmZpZy5Zb3V6aUNoYW5uZWxUeXBlLFxyXG4gICAgICAgIHRvb2x0aXA6IFwi5L2/55SoWW91emnkupLmjqjml7bvvIznrqHnkIblkI7lj7Dmj5DkvpvnmoTlubPlj7DmuKDpgZMg6buY6K6k5b6u5L+hXCIsXHJcbiAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgIH0pXHJcbiAgICBwcm90ZWN0ZWQgX1lvdXppX0NoYW5uZWxJZDogbnVtYmVyID0gUmVjb21tZW5kQ29uZmlnLllvdXppQ2hhbm5lbFR5cGUuV2VDaGF0O1xyXG4gICAgcHVibGljIGdldCBZb3V6aV9DaGFubmVsSWQoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX1lvdXppX0NoYW5uZWxJZCA9PSBQTEFUX1RZUEVfQ0hBTk5FTElELlRlc3QpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFBMQVRfVFlQRV9DSEFOTkVMSUQuV2VDaGF0O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9Zb3V6aV9DaGFubmVsSWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbn1cclxuXHJcbiJdfQ==