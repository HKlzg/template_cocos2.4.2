
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LobbyUI/ShopUI/ShopItem.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5a631MrW1ZFcYMlXrLofj5W', 'ShopItem');
// LobbyUI/ShopUI/ShopItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var Loader_1 = require("../../Script/Common/Loader");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * 单个商品
 */
var ShopItem = /** @class */ (function (_super) {
    __extends(ShopItem, _super);
    function ShopItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.itemSprite = null;
        _this.LockMask = null;
        _this._unclock = false;
        _this.chooseMask = null;
        _this._isChecked = false;
        _this.itemName = null;
        _this.price = null;
        return _this;
    }
    Object.defineProperty(ShopItem.prototype, "unlock", {
        /**商品项是否已解锁 */
        get: function () { return this._unclock; },
        set: function (v) {
            this._unclock = !!v;
            this.LockMask.active = !this._unclock;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ShopItem.prototype, "isChecked", {
        /**商品项是否被选中 */
        get: function () { return this._isChecked; },
        set: function (v) {
            this._isChecked = !!v;
            this.chooseMask.active = this._isChecked;
        },
        enumerable: false,
        configurable: true
    });
    ShopItem.prototype.init = function (data) {
        this.isChecked = false;
        this.onEvents();
        if (!!data)
            this.setData(data);
    };
    ShopItem.prototype.onEvents = function () {
        this.node.on("touchend", this.onTouchEnd, this);
    };
    ShopItem.prototype.reset = function () {
        this.data = null;
        this.isChecked = false;
    };
    ShopItem.prototype.reuse = function (data) {
        this.reset();
        this.setData(data);
    };
    ShopItem.prototype.unuse = function () {
        this.reset();
    };
    ShopItem.prototype.setData = function (data) {
        //数据
        this.data = data;
        //图片
        this.setImg(data.itemUrl);
        //名称
        if (!!this.itemName)
            this.itemName.string = data.name;
        //价格
        if (!!this.price)
            this.price.string = data.price.toString();
        //状态
        this.unlock = data.unlock;
    };
    ShopItem.prototype.setImg = function (url) {
        var _this = this;
        Loader_1.default.loadBundleRes("Skin", url, function (res) {
            if (!res)
                return;
            if (res instanceof cc.Texture2D) {
                _this.itemSprite.spriteFrame = new cc.SpriteFrame(res);
            }
            else if (res instanceof cc.SpriteFrame) {
                _this.itemSprite.spriteFrame = res;
            }
        }, false);
    };
    ShopItem.prototype.onTouchEnd = function () {
        if (this.isChecked)
            return;
        this.isChecked = true;
        this.emit(GameEventType_1.EventType.ShopEvent.chooseItem, this);
    };
    __decorate([
        property(cc.Sprite)
    ], ShopItem.prototype, "itemSprite", void 0);
    __decorate([
        property(cc.Node)
    ], ShopItem.prototype, "LockMask", void 0);
    __decorate([
        property(cc.Node)
    ], ShopItem.prototype, "chooseMask", void 0);
    __decorate([
        property(cc.Label)
    ], ShopItem.prototype, "itemName", void 0);
    __decorate([
        property(cc.Label)
    ], ShopItem.prototype, "price", void 0);
    ShopItem = __decorate([
        ccclass
    ], ShopItem);
    return ShopItem;
}(yyComponent_1.default));
exports.default = ShopItem;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTG9iYnlVSVxcU2hvcFVJXFxTaG9wSXRlbS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrREFBMEQ7QUFDMUQscURBQWdEO0FBQ2hELHdFQUFtRTtBQUU3RCxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUM1Qzs7R0FFRztBQUVIO0lBQXNDLDRCQUFXO0lBQWpEO1FBQUEscUVBb0ZDO1FBbEZhLGdCQUFVLEdBQWMsSUFBSSxDQUFDO1FBRzdCLGNBQVEsR0FBWSxJQUFJLENBQUM7UUFDekIsY0FBUSxHQUFZLEtBQUssQ0FBQztRQVMxQixnQkFBVSxHQUFZLElBQUksQ0FBQztRQUMzQixnQkFBVSxHQUFZLEtBQUssQ0FBQztRQVM1QixjQUFRLEdBQWEsSUFBSSxDQUFDO1FBRTFCLFdBQUssR0FBYSxJQUFJLENBQUM7O0lBeURyQyxDQUFDO0lBNUVHLHNCQUFXLDRCQUFNO1FBRGpCLGNBQWM7YUFDZCxjQUFzQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2FBQzdDLFVBQWtCLENBQUM7WUFDZixJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDcEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQzFDLENBQUM7OztPQUo0QztJQVU3QyxzQkFBVywrQkFBUztRQURwQixjQUFjO2FBQ2QsY0FBeUIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQzthQUNsRCxVQUFxQixDQUFDO1lBQ2xCLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQzdDLENBQUM7OztPQUppRDtJQWEzQyx1QkFBSSxHQUFYLFVBQVksSUFBVTtRQUNsQixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN2QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLENBQUMsSUFBSTtZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVTLDJCQUFRLEdBQWxCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVNLHdCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUMzQixDQUFDO0lBRU0sd0JBQUssR0FBWixVQUFhLElBQVM7UUFDbEIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN2QixDQUFDO0lBRU0sd0JBQUssR0FBWjtRQUNJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNqQixDQUFDO0lBR1MsMEJBQU8sR0FBakIsVUFBa0IsSUFBbUY7UUFDakcsSUFBSTtRQUNKLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUk7UUFDSixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMxQixJQUFJO1FBQ0osSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3RELElBQUk7UUFDSixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDNUQsSUFBSTtRQUNKLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUM5QixDQUFDO0lBQ1MseUJBQU0sR0FBaEIsVUFBaUIsR0FBRztRQUFwQixpQkFTQztRQVJHLGdCQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsVUFBQyxHQUFHO1lBQ2xDLElBQUksQ0FBQyxHQUFHO2dCQUFFLE9BQU87WUFDakIsSUFBSSxHQUFHLFlBQVksRUFBRSxDQUFDLFNBQVMsRUFBRTtnQkFDN0IsS0FBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ3pEO2lCQUFNLElBQUksR0FBRyxZQUFZLEVBQUUsQ0FBQyxXQUFXLEVBQUU7Z0JBQ3RDLEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQzthQUNyQztRQUNMLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNkLENBQUM7SUFFUyw2QkFBVSxHQUFwQjtRQUNJLElBQUksSUFBSSxDQUFDLFNBQVM7WUFBRSxPQUFPO1FBQzNCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFqRkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztnREFDbUI7SUFHdkM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzs4Q0FDaUI7SUFVbkM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztnREFDbUI7SUFVckM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQzs4Q0FDaUI7SUFFcEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQzsyQ0FDYztJQTNCaEIsUUFBUTtRQUQ1QixPQUFPO09BQ2EsUUFBUSxDQW9GNUI7SUFBRCxlQUFDO0NBcEZELEFBb0ZDLENBcEZxQyxxQkFBVyxHQW9GaEQ7a0JBcEZvQixRQUFRIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHl5Q29tcG9uZW50IGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL3l5Q29tcG9uZW50XCI7XHJcbmltcG9ydCBMb2FkZXIgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vTG9hZGVyXCI7XHJcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2FtZUV2ZW50VHlwZVwiO1xyXG5cclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuLyoqXHJcbiAqIOWNleS4quWVhuWTgVxyXG4gKi9cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2hvcEl0ZW0gZXh0ZW5kcyB5eUNvbXBvbmVudCB7XHJcbiAgICBAcHJvcGVydHkoY2MuU3ByaXRlKVxyXG4gICAgcHJvdGVjdGVkIGl0ZW1TcHJpdGU6IGNjLlNwcml0ZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgTG9ja01hc2s6IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgcHJvdGVjdGVkIF91bmNsb2NrOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAvKirllYblk4HpobnmmK/lkKblt7Lop6PplIEgKi9cclxuICAgIHB1YmxpYyBnZXQgdW5sb2NrKCkgeyByZXR1cm4gdGhpcy5fdW5jbG9jazsgfVxyXG4gICAgcHVibGljIHNldCB1bmxvY2sodikge1xyXG4gICAgICAgIHRoaXMuX3VuY2xvY2sgPSAhIXY7XHJcbiAgICAgICAgdGhpcy5Mb2NrTWFzay5hY3RpdmUgPSAhdGhpcy5fdW5jbG9jaztcclxuICAgIH1cclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb3RlY3RlZCBjaG9vc2VNYXNrOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIHByb3RlY3RlZCBfaXNDaGVja2VkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAvKirllYblk4HpobnmmK/lkKbooqvpgInkuK0gKi9cclxuICAgIHB1YmxpYyBnZXQgaXNDaGVja2VkKCkgeyByZXR1cm4gdGhpcy5faXNDaGVja2VkOyB9XHJcbiAgICBwdWJsaWMgc2V0IGlzQ2hlY2tlZCh2KSB7XHJcbiAgICAgICAgdGhpcy5faXNDaGVja2VkID0gISF2O1xyXG4gICAgICAgIHRoaXMuY2hvb3NlTWFzay5hY3RpdmUgPSB0aGlzLl9pc0NoZWNrZWQ7XHJcbiAgICB9XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLkxhYmVsKVxyXG4gICAgcHJvdGVjdGVkIGl0ZW1OYW1lOiBjYy5MYWJlbCA9IG51bGw7XHJcbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXHJcbiAgICBwcm90ZWN0ZWQgcHJpY2U6IGNjLkxhYmVsID0gbnVsbDtcclxuXHJcbiAgICBwdWJsaWMgZGF0YTogYW55O1xyXG5cclxuICAgIHB1YmxpYyBpbml0KGRhdGE/OiBhbnkpIHtcclxuICAgICAgICB0aGlzLmlzQ2hlY2tlZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMub25FdmVudHMoKTtcclxuICAgICAgICBpZiAoISFkYXRhKSB0aGlzLnNldERhdGEoZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIG9uRXZlbnRzKCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihcInRvdWNoZW5kXCIsIHRoaXMub25Ub3VjaEVuZCwgdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlc2V0KCkge1xyXG4gICAgICAgIHRoaXMuZGF0YSA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5pc0NoZWNrZWQgPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmV1c2UoZGF0YTogYW55KSB7XHJcbiAgICAgICAgdGhpcy5yZXNldCgpO1xyXG4gICAgICAgIHRoaXMuc2V0RGF0YShkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdW51c2UoKSB7XHJcbiAgICAgICAgdGhpcy5yZXNldCgpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0RGF0YShkYXRhOiB7IGlkOiBudW1iZXIsIGl0ZW1Vcmw6IHN0cmluZywgbmFtZTogc3RyaW5nLCBwcmljZTogbnVtYmVyLCB1bmxvY2s6IGJvb2xlYW4gfSkge1xyXG4gICAgICAgIC8v5pWw5o2uXHJcbiAgICAgICAgdGhpcy5kYXRhID0gZGF0YTtcclxuICAgICAgICAvL+WbvueJh1xyXG4gICAgICAgIHRoaXMuc2V0SW1nKGRhdGEuaXRlbVVybCk7XHJcbiAgICAgICAgLy/lkI3np7BcclxuICAgICAgICBpZiAoISF0aGlzLml0ZW1OYW1lKSB0aGlzLml0ZW1OYW1lLnN0cmluZyA9IGRhdGEubmFtZTtcclxuICAgICAgICAvL+S7t+agvFxyXG4gICAgICAgIGlmICghIXRoaXMucHJpY2UpIHRoaXMucHJpY2Uuc3RyaW5nID0gZGF0YS5wcmljZS50b1N0cmluZygpO1xyXG4gICAgICAgIC8v54q25oCBXHJcbiAgICAgICAgdGhpcy51bmxvY2sgPSBkYXRhLnVubG9jaztcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBzZXRJbWcodXJsKSB7XHJcbiAgICAgICAgTG9hZGVyLmxvYWRCdW5kbGVSZXMoXCJTa2luXCIsIHVybCwgKHJlcykgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIXJlcykgcmV0dXJuO1xyXG4gICAgICAgICAgICBpZiAocmVzIGluc3RhbmNlb2YgY2MuVGV4dHVyZTJEKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLml0ZW1TcHJpdGUuc3ByaXRlRnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUocmVzKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChyZXMgaW5zdGFuY2VvZiBjYy5TcHJpdGVGcmFtZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtU3ByaXRlLnNwcml0ZUZyYW1lID0gcmVzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZmFsc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBvblRvdWNoRW5kKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmlzQ2hlY2tlZCkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuaXNDaGVja2VkID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlNob3BFdmVudC5jaG9vc2VJdGVtLCB0aGlzKTtcclxuICAgIH1cclxufVxyXG5cclxuIl19