
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LobbyUI/ShopUI/ShopStage.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2aa0dpyd3VCraGsx3pxEXt6', 'ShopStage');
// LobbyUI/ShopUI/ShopStage.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
var Loader_1 = require("../../Script/Common/Loader");
var yyComponent_1 = require("../../Script/Common/yyComponent");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**商城的商品展示台 */
var ShopStage = /** @class */ (function (_super) {
    __extends(ShopStage, _super);
    function ShopStage() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //2D展示方式：
        /**展示商品详情的图片精灵 */
        _this.displaySprite = null;
        //3D展示方式：
        /**商品展示台 */
        _this.displayStage = null;
        /**展示3D模型节点的父节点 */
        _this.modelStage = null;
        /**商品展示台相机 */
        _this.camera = null;
        /**当前用来展示的3D模型节点 */
        _this.curItemModel = null;
        /**3D模型动作 */
        _this.modelTween = null;
        return _this;
    }
    ShopStage.prototype.init = function () {
        this.initComponents();
        this.initDisplayStage();
        this.initSprite();
    };
    ShopStage.prototype.reset = function () {
        this.resetDisplayStage();
        this.resetSprite();
    };
    ShopStage.prototype.initSprite = function () {
        if (!this.displaySprite)
            return;
        this.displaySprite.spriteFrame = null;
    };
    ShopStage.prototype.resetSprite = function () {
        if (!this.displaySprite)
            return;
        this.displaySprite.spriteFrame = null;
    };
    ShopStage.prototype.showGoodsImg = function (img) {
        var _this = this;
        if (!this.displaySprite)
            return;
        Loader_1.default.loadBundleRes("Skin", img, function (res) {
            if (_this.displaySprite.isValid) {
                _this.displaySprite.spriteFrame = res;
            }
        }, cc.SpriteFrame, false);
    };
    ShopStage.prototype.initDisplayStage = function () {
        if (!this.displayStage)
            return;
        var wg = this.displayStage.getComponent(cc.Widget);
        if (!!wg) {
            wg.updateAlignment();
        }
        var y = this.displayStage.y;
        var rate = y / cc.find("Canvas").height;
        this.camera.rect = cc.rect(0, rate, 1, 1);
    };
    ShopStage.prototype.resetDisplayStage = function () {
        if (!this.displayStage)
            return;
        if (!!this.modelTween) {
            this.modelTween.stop();
            this.modelTween = null;
        }
        if (!!this.curItemModel) {
            GlobalPool_1.default.put(this.curItemModel);
            this.curItemModel = null;
        }
    };
    /**展示商品详情 */
    ShopStage.prototype.showItemData = function (data) {
        //图片展示方式：
        this.showGoodsImg(data.displayUrl);
        //3D模型展示方式：
        // this.showGoodsModel(data.model, data.skin);
    };
    /**3D模型展示 */
    ShopStage.prototype.showGoodsModel = function (model, skin) {
        var _this = this;
        if (!this.displayStage)
            return;
        var angle = cc.v3();
        if (!!this.modelTween) {
            this.modelTween.stop();
            this.modelTween = null;
        }
        if (!!this.curItemModel) {
            angle.set(this.curItemModel.eulerAngles);
            GlobalPool_1.default.put(this.curItemModel);
            this.curItemModel = null;
        }
        this.curItemModel = GlobalPool_1.default.get(model);
        var url = skin;
        Loader_1.default.loadBundleRes("Skin", url, function (res) {
            if (!_this.node.active || !_this.node.isValid)
                return;
            var mesh = _this.curItemModel.getComponentInChildren(cc.MeshRenderer);
            var sf;
            if (res instanceof cc.SpriteFrame) {
                sf = res;
            }
            else if (res instanceof cc.Texture2D) {
                sf = new cc.SpriteFrame(res);
            }
            mesh.getMaterial(0).setProperty("diffuseTexture", sf);
        }, false);
        this.modelStage.addChild(this.curItemModel);
        this.curItemModel.setPosition(cc.v3(0, 0, 0));
        this.curItemModel.eulerAngles = angle;
        this.modelTween = cc.tween(this.curItemModel).repeatForever(cc.tween(this.curItemModel).by(2, { eulerAngles: cc.v3(0, 90, 0) })).union().start();
    };
    __decorate([
        property(cc.Sprite)
    ], ShopStage.prototype, "displaySprite", void 0);
    __decorate([
        property(cc.Node)
    ], ShopStage.prototype, "displayStage", void 0);
    __decorate([
        property(cc.Node)
    ], ShopStage.prototype, "modelStage", void 0);
    __decorate([
        property(cc.Camera)
    ], ShopStage.prototype, "camera", void 0);
    ShopStage = __decorate([
        ccclass
    ], ShopStage);
    return ShopStage;
}(yyComponent_1.default));
exports.default = ShopStage;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTG9iYnlVSVxcU2hvcFVJXFxTaG9wU3RhZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsNkRBQXdEO0FBQ3hELHFEQUFnRDtBQUNoRCwrREFBMEQ7QUFFcEQsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFDNUMsY0FBYztBQUVkO0lBQXVDLDZCQUFXO0lBQWxEO1FBQUEscUVBZ0hDO1FBcEdHLFNBQVM7UUFDVCxpQkFBaUI7UUFFUCxtQkFBYSxHQUFjLElBQUksQ0FBQztRQWtCMUMsU0FBUztRQUNULFdBQVc7UUFFRCxrQkFBWSxHQUFZLElBQUksQ0FBQztRQUN2QyxrQkFBa0I7UUFFUixnQkFBVSxHQUFZLElBQUksQ0FBQztRQUNyQyxhQUFhO1FBRUgsWUFBTSxHQUFjLElBQUksQ0FBQztRQUNuQyxtQkFBbUI7UUFDVCxrQkFBWSxHQUFZLElBQUksQ0FBQztRQUN2QyxZQUFZO1FBQ0YsZ0JBQVUsR0FBYSxJQUFJLENBQUM7O0lBa0UxQyxDQUFDO0lBOUdVLHdCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFDTSx5QkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFNUyw4QkFBVSxHQUFwQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYTtZQUFFLE9BQU87UUFDaEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFDUywrQkFBVyxHQUFyQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYTtZQUFFLE9BQU87UUFDaEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFDUyxnQ0FBWSxHQUF0QixVQUF1QixHQUFXO1FBQWxDLGlCQU9DO1FBTkcsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhO1lBQUUsT0FBTztRQUNoQyxnQkFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLFVBQUMsR0FBRztZQUNsQyxJQUFJLEtBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFO2dCQUM1QixLQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7YUFDeEM7UUFDTCxDQUFDLEVBQUUsRUFBRSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBZ0JTLG9DQUFnQixHQUExQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWTtZQUFFLE9BQU87UUFDL0IsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNOLEVBQUUsQ0FBQyxlQUFlLEVBQUUsQ0FBQztTQUN4QjtRQUNELElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQzVCLElBQUksSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUN4QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFDUyxxQ0FBaUIsR0FBM0I7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVk7WUFBRSxPQUFPO1FBQy9CLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztTQUMxQjtRQUNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDckIsb0JBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1NBQzVCO0lBQ0wsQ0FBQztJQUVELFlBQVk7SUFDTCxnQ0FBWSxHQUFuQixVQUFvQixJQUFJO1FBQ3BCLFNBQVM7UUFDVCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNuQyxXQUFXO1FBQ1gsOENBQThDO0lBRWxELENBQUM7SUFFRCxZQUFZO0lBQ0Ysa0NBQWMsR0FBeEIsVUFBeUIsS0FBYSxFQUFFLElBQVk7UUFBcEQsaUJBK0JDO1FBOUJHLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWTtZQUFFLE9BQU87UUFDL0IsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztTQUMxQjtRQUNELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDckIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3pDLG9CQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztTQUM1QjtRQUNELElBQUksQ0FBQyxZQUFZLEdBQUcsb0JBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFMUMsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDO1FBQ2YsZ0JBQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxVQUFDLEdBQUc7WUFDbEMsSUFBSSxDQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxPQUFPO2dCQUFFLE9BQU87WUFDcEQsSUFBSSxJQUFJLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDckUsSUFBSSxFQUFFLENBQUM7WUFDUCxJQUFJLEdBQUcsWUFBWSxFQUFFLENBQUMsV0FBVyxFQUFFO2dCQUMvQixFQUFFLEdBQUcsR0FBRyxDQUFDO2FBQ1o7aUJBQU0sSUFBSSxHQUFHLFlBQVksRUFBRSxDQUFDLFNBQVMsRUFBRTtnQkFDcEMsRUFBRSxHQUFHLElBQUksRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNoQztZQUNELElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzFELENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVWLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5QyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFDdEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLFdBQVcsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDckosQ0FBQztJQS9GRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO29EQUNzQjtJQXFCMUM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzttREFDcUI7SUFHdkM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztpREFDbUI7SUFHckM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzs2Q0FDZTtJQTFDbEIsU0FBUztRQUQ3QixPQUFPO09BQ2EsU0FBUyxDQWdIN0I7SUFBRCxnQkFBQztDQWhIRCxBQWdIQyxDQWhIc0MscUJBQVcsR0FnSGpEO2tCQWhIb0IsU0FBUyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBHbG9iYWxQb29sIGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL0dsb2JhbFBvb2xcIjtcclxuaW1wb3J0IExvYWRlciBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9Mb2FkZXJcIjtcclxuaW1wb3J0IHl5Q29tcG9uZW50IGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL3l5Q29tcG9uZW50XCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG4vKirllYbln47nmoTllYblk4HlsZXnpLrlj7AgKi9cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2hvcFN0YWdlIGV4dGVuZHMgeXlDb21wb25lbnQge1xyXG5cclxuICAgIHB1YmxpYyBpbml0KCkge1xyXG4gICAgICAgIHRoaXMuaW5pdENvbXBvbmVudHMoKTtcclxuICAgICAgICB0aGlzLmluaXREaXNwbGF5U3RhZ2UoKTtcclxuICAgICAgICB0aGlzLmluaXRTcHJpdGUoKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyByZXNldCgpIHtcclxuICAgICAgICB0aGlzLnJlc2V0RGlzcGxheVN0YWdlKCk7XHJcbiAgICAgICAgdGhpcy5yZXNldFNwcml0ZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vMkTlsZXnpLrmlrnlvI/vvJpcclxuICAgIC8qKuWxleekuuWVhuWTgeivpuaDheeahOWbvueJh+eyvueBtSAqL1xyXG4gICAgQHByb3BlcnR5KGNjLlNwcml0ZSlcclxuICAgIHByb3RlY3RlZCBkaXNwbGF5U3ByaXRlOiBjYy5TcHJpdGUgPSBudWxsO1xyXG4gICAgcHJvdGVjdGVkIGluaXRTcHJpdGUoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmRpc3BsYXlTcHJpdGUpIHJldHVybjtcclxuICAgICAgICB0aGlzLmRpc3BsYXlTcHJpdGUuc3ByaXRlRnJhbWUgPSBudWxsO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHJlc2V0U3ByaXRlKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5kaXNwbGF5U3ByaXRlKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5kaXNwbGF5U3ByaXRlLnNwcml0ZUZyYW1lID0gbnVsbDtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBzaG93R29vZHNJbWcoaW1nOiBzdHJpbmcpIHtcclxuICAgICAgICBpZiAoIXRoaXMuZGlzcGxheVNwcml0ZSkgcmV0dXJuO1xyXG4gICAgICAgIExvYWRlci5sb2FkQnVuZGxlUmVzKFwiU2tpblwiLCBpbWcsIChyZXMpID0+IHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuZGlzcGxheVNwcml0ZS5pc1ZhbGlkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRpc3BsYXlTcHJpdGUuc3ByaXRlRnJhbWUgPSByZXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBjYy5TcHJpdGVGcmFtZSwgZmFsc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vM0TlsZXnpLrmlrnlvI/vvJpcclxuICAgIC8qKuWVhuWTgeWxleekuuWPsCAqL1xyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgZGlzcGxheVN0YWdlOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIC8qKuWxleekujNE5qih5Z6L6IqC54K555qE54i26IqC54K5ICovXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb3RlY3RlZCBtb2RlbFN0YWdlOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIC8qKuWVhuWTgeWxleekuuWPsOebuOacuiAqL1xyXG4gICAgQHByb3BlcnR5KGNjLkNhbWVyYSlcclxuICAgIHByb3RlY3RlZCBjYW1lcmE6IGNjLkNhbWVyYSA9IG51bGw7XHJcbiAgICAvKirlvZPliY3nlKjmnaXlsZXnpLrnmoQzROaooeWei+iKgueCuSAqL1xyXG4gICAgcHJvdGVjdGVkIGN1ckl0ZW1Nb2RlbDogY2MuTm9kZSA9IG51bGw7XHJcbiAgICAvKiozROaooeWei+WKqOS9nCAqL1xyXG4gICAgcHJvdGVjdGVkIG1vZGVsVHdlZW46IGNjLlR3ZWVuID0gbnVsbDtcclxuICAgIHByb3RlY3RlZCBpbml0RGlzcGxheVN0YWdlKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5kaXNwbGF5U3RhZ2UpIHJldHVybjtcclxuICAgICAgICBsZXQgd2cgPSB0aGlzLmRpc3BsYXlTdGFnZS5nZXRDb21wb25lbnQoY2MuV2lkZ2V0KTtcclxuICAgICAgICBpZiAoISF3Zykge1xyXG4gICAgICAgICAgICB3Zy51cGRhdGVBbGlnbm1lbnQoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHkgPSB0aGlzLmRpc3BsYXlTdGFnZS55O1xyXG4gICAgICAgIGxldCByYXRlID0geSAvIGNjLmZpbmQoXCJDYW52YXNcIikuaGVpZ2h0O1xyXG4gICAgICAgIHRoaXMuY2FtZXJhLnJlY3QgPSBjYy5yZWN0KDAsIHJhdGUsIDEsIDEpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHJlc2V0RGlzcGxheVN0YWdlKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5kaXNwbGF5U3RhZ2UpIHJldHVybjtcclxuICAgICAgICBpZiAoISF0aGlzLm1vZGVsVHdlZW4pIHtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbFR3ZWVuLnN0b3AoKTtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbFR3ZWVuID0gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCEhdGhpcy5jdXJJdGVtTW9kZWwpIHtcclxuICAgICAgICAgICAgR2xvYmFsUG9vbC5wdXQodGhpcy5jdXJJdGVtTW9kZWwpO1xyXG4gICAgICAgICAgICB0aGlzLmN1ckl0ZW1Nb2RlbCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKuWxleekuuWVhuWTgeivpuaDhSAqL1xyXG4gICAgcHVibGljIHNob3dJdGVtRGF0YShkYXRhKSB7XHJcbiAgICAgICAgLy/lm77niYflsZXnpLrmlrnlvI/vvJpcclxuICAgICAgICB0aGlzLnNob3dHb29kc0ltZyhkYXRhLmRpc3BsYXlVcmwpO1xyXG4gICAgICAgIC8vM0TmqKHlnovlsZXnpLrmlrnlvI/vvJpcclxuICAgICAgICAvLyB0aGlzLnNob3dHb29kc01vZGVsKGRhdGEubW9kZWwsIGRhdGEuc2tpbik7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC8qKjNE5qih5Z6L5bGV56S6ICovXHJcbiAgICBwcm90ZWN0ZWQgc2hvd0dvb2RzTW9kZWwobW9kZWw6IHN0cmluZywgc2tpbjogc3RyaW5nKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmRpc3BsYXlTdGFnZSkgcmV0dXJuO1xyXG4gICAgICAgIGxldCBhbmdsZSA9IGNjLnYzKCk7XHJcbiAgICAgICAgaWYgKCEhdGhpcy5tb2RlbFR3ZWVuKSB7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxUd2Vlbi5zdG9wKCk7XHJcbiAgICAgICAgICAgIHRoaXMubW9kZWxUd2VlbiA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghIXRoaXMuY3VySXRlbU1vZGVsKSB7XHJcbiAgICAgICAgICAgIGFuZ2xlLnNldCh0aGlzLmN1ckl0ZW1Nb2RlbC5ldWxlckFuZ2xlcyk7XHJcbiAgICAgICAgICAgIEdsb2JhbFBvb2wucHV0KHRoaXMuY3VySXRlbU1vZGVsKTtcclxuICAgICAgICAgICAgdGhpcy5jdXJJdGVtTW9kZWwgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmN1ckl0ZW1Nb2RlbCA9IEdsb2JhbFBvb2wuZ2V0KG1vZGVsKTtcclxuXHJcbiAgICAgICAgbGV0IHVybCA9IHNraW47XHJcbiAgICAgICAgTG9hZGVyLmxvYWRCdW5kbGVSZXMoXCJTa2luXCIsIHVybCwgKHJlcykgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMubm9kZS5hY3RpdmUgfHwgIXRoaXMubm9kZS5pc1ZhbGlkKSByZXR1cm47XHJcbiAgICAgICAgICAgIGxldCBtZXNoID0gdGhpcy5jdXJJdGVtTW9kZWwuZ2V0Q29tcG9uZW50SW5DaGlsZHJlbihjYy5NZXNoUmVuZGVyZXIpO1xyXG4gICAgICAgICAgICBsZXQgc2Y7XHJcbiAgICAgICAgICAgIGlmIChyZXMgaW5zdGFuY2VvZiBjYy5TcHJpdGVGcmFtZSkge1xyXG4gICAgICAgICAgICAgICAgc2YgPSByZXM7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAocmVzIGluc3RhbmNlb2YgY2MuVGV4dHVyZTJEKSB7XHJcbiAgICAgICAgICAgICAgICBzZiA9IG5ldyBjYy5TcHJpdGVGcmFtZShyZXMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG1lc2guZ2V0TWF0ZXJpYWwoMCkuc2V0UHJvcGVydHkoXCJkaWZmdXNlVGV4dHVyZVwiLCBzZik7XHJcbiAgICAgICAgfSwgZmFsc2UpO1xyXG5cclxuICAgICAgICB0aGlzLm1vZGVsU3RhZ2UuYWRkQ2hpbGQodGhpcy5jdXJJdGVtTW9kZWwpO1xyXG4gICAgICAgIHRoaXMuY3VySXRlbU1vZGVsLnNldFBvc2l0aW9uKGNjLnYzKDAsIDAsIDApKTtcclxuICAgICAgICB0aGlzLmN1ckl0ZW1Nb2RlbC5ldWxlckFuZ2xlcyA9IGFuZ2xlO1xyXG4gICAgICAgIHRoaXMubW9kZWxUd2VlbiA9IGNjLnR3ZWVuKHRoaXMuY3VySXRlbU1vZGVsKS5yZXBlYXRGb3JldmVyKGNjLnR3ZWVuKHRoaXMuY3VySXRlbU1vZGVsKS5ieSgyLCB7IGV1bGVyQW5nbGVzOiBjYy52MygwLCA5MCwgMCkgfSkpLnVuaW9uKCkuc3RhcnQoKTtcclxuICAgIH1cclxuXHJcbn1cclxuIl19