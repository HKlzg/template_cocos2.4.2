
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LobbyUI/ShopUI/ShopUI.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f1146XD9dZL0oi7dzvFICfT', 'ShopUI');
// LobbyUI/ShopUI/ShopUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var Loader_1 = require("../../Script/Common/Loader");
var GameData_1 = require("../../Script/Common/GameData");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var ShopItem_1 = require("./ShopItem");
var ShopStage_1 = require("./ShopStage");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**皮肤商城UI*/
var ShopUI = /** @class */ (function (_super) {
    __extends(ShopUI, _super);
    function ShopUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**场景/UI类型 */
        _this._uiType = GlobalEnum_1.GlobalEnum.UI.shop;
        _this.goodsTypeToggles = null;
        /**页面滚动视图 */
        _this.pageView = null;
        /**单个商品页面的预制件 */
        _this.storePage = null; //商城页面
        /**当前商品的价格 */
        _this.price = null;
        /**商品项 */
        _this.shopItemPerfab = null;
        /**商品展示台 */
        _this.stage = null;
        /**当前选中的商品项 */
        _this.curItem = null;
        return _this;
    }
    Object.defineProperty(ShopUI.prototype, "uiType", {
        get: function () { return this._uiType; },
        enumerable: false,
        configurable: true
    });
    ShopUI.prototype.initPage = function () {
        GlobalPool_1.default.createPool(this.shopItemPerfab.name, this.shopItemPerfab, this.shopItemPerfab.name);
        GlobalPool_1.default.createPool(this.storePage.name, this.storePage);
    };
    ShopUI.prototype.resetPage = function () {
        var pages = this.pageView.getPages();
        for (var i = pages.length - 1; i >= 0; --i) {
            GlobalPool_1.default.putAllChildren(pages[i]);
        }
        this.pageView.removeAllPages();
    };
    ShopUI.prototype.initDisplayStage = function () {
        this.stage.init();
    };
    ShopUI.prototype.resetDisplayStage = function () {
        this.stage.reset();
    };
    ShopUI.prototype.init = function () {
        this.curItem = null;
        this.curType = null;
        this.initComponents();
        this.initDisplayStage();
        this.initPage();
        this.onEvents();
    };
    ShopUI.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.ShopEvent.chooseItem, this.onChooseItem, this);
    };
    ShopUI.prototype.reset = function () {
        this.curItem = null;
        this.curType = null;
        this.resetDisplayStage();
        this.resetPage();
    };
    ShopUI.prototype.show = function () {
        this.node.active = true;
        this.reset();
        this.setData();
    };
    ShopUI.prototype.setData = function () {
        var _this = this;
        var toggles = this.goodsTypeToggles.toggleItems;
        if (toggles.length > 0) {
            toggles[0].isChecked = true;
            var handler = toggles[0].checkEvents[0];
            if (!handler) {
                console.warn("商品类型分页标签未绑定回调函数");
                return;
            }
            var type_1 = handler.customEventData;
            Loader_1.default.loadBundleDir("Skin", type_1 + "/Item", function () {
                _this.showGoods(type_1);
            }, cc.SpriteFrame, true);
        }
    };
    ShopUI.prototype.hide = function () {
        this.reset();
        this.node.active = false;
    };
    ShopUI.prototype.onChooseType = function (e, type) {
        var _this = this;
        if (this.curType == type)
            return;
        Loader_1.default.loadBundleDir("Skin", type + "/Item", function () {
            _this.showGoods(type);
        }, cc.SpriteFrame, true);
    };
    /**
     * 显示商品
     * 应当新建一个展示台的类，负责根据实际游戏展示对应的商品模型或图片
     */
    ShopUI.prototype.showGoods = function (type) {
        this.resetPage();
        this.curType = type;
        var goodsData = GameData_1.default.getData(type);
        var maxCount = 6;
        var unlockSkins = PlayerData_1.default.getData("gameData." + type + ".owned");
        var curSkin = PlayerData_1.default.getData("gameData." + type + ".cur");
        if (typeof curSkin === "number") {
            curSkin = curSkin.toString();
        }
        var page = cc.instantiate(this.storePage);
        this.pageView.addPage(page);
        var displayPath = this.curType + "/Display/";
        var itemPath = this.curType + "/Item/";
        var pageIndex = 0;
        for (var key in goodsData) {
            if (page.childrenCount >= maxCount) {
                page = cc.instantiate(this.storePage);
                this.pageView.addPage(page);
            }
            var data = JSON.parse(JSON.stringify(goodsData[key]));
            data.itemUrl = itemPath + data.itemUrl;
            data.displayUrl = displayPath + data.displayUrl;
            data.unlock = unlockSkins.indexOf(parseInt(key)) >= 0;
            var node = GlobalPool_1.default.get(this.shopItemPerfab.name, data);
            if (key == curSkin) {
                var item = node.getComponent(ShopItem_1.default);
                item.isChecked = true;
                this.curItem = item;
                pageIndex = this.pageView.getPages().length - 1;
            }
            page.addChild(node);
        }
        this.pageView.scrollToPage(pageIndex, 0);
        if (!!this.curItem) {
            this.showItemData(this.curItem.data);
        }
    };
    ShopUI.prototype.onChooseItem = function (item) {
        if (!!this.curItem) {
            if (this.curItem.Id === item.Id)
                return;
            this.curItem.isChecked = false;
        }
        this.curItem = item;
        if (this.curItem.data.unlock) {
            this.setCurSkin(this.curType, this.curItem.data.id);
        }
        this.showItemData(item.data);
    };
    /**展示商品详情 */
    ShopUI.prototype.showItemData = function (data) {
        this.stage.showItemData(data);
        if (data.unlock) {
            this.showUsing();
        }
        else {
            this.showPrice(data.price);
        }
    };
    ShopUI.prototype.showPrice = function (price) {
        this.price.string = price.toString();
    };
    ShopUI.prototype.showUsing = function () {
        this.price.string = "使用中";
    };
    /**退出商城 */
    ShopUI.prototype.onBtnExit = function () {
        this.emit(GameEventType_1.EventType.UIEvent.exit, this.uiType);
    };
    /**购买 */
    ShopUI.prototype.onBtnBuy = function () {
        if (!this.curItem)
            return;
        if (this.curItem.data.unlock)
            return;
        var price = this.curItem.data.price;
        var gold = PlayerData_1.default.getData("gameData.asset.gold");
        if (gold < price) {
            this.tipGoldUnenough();
        }
        else {
            this.subGold(price);
            this.unlockSkin(this.curType, this.curItem.data.id);
            this.setCurSkin(this.curType, this.curItem.data.id);
            this.curItem.data.unlock = true;
            this.curItem.unlock = true;
            this.showUsing();
        }
    };
    ShopUI.prototype.subGold = function (gold) {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData.asset.gold",
            value: gold,
            mode: "-",
            save: false,
        });
    };
    /**
     * 解锁皮肤
     * @param type 皮肤类型
     * @param id 皮肤id
     */
    ShopUI.prototype.unlockSkin = function (type, id) {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData." + type + ".owned",
            value: parseInt(id),
            mode: "push"
        });
    };
    /**
     * 设置当前使用的皮肤
     * @param type 皮肤类型
     * @param id 皮肤id
     */
    ShopUI.prototype.setCurSkin = function (type, id) {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData." + type + ".cur",
            value: parseInt(id),
            mode: "="
        });
    };
    /** 提示金币不足 */
    ShopUI.prototype.tipGoldUnenough = function () {
        this.emit(GameEventType_1.EventType.UIEvent.showTip, "金币不足");
    };
    /**观看视频 */
    ShopUI.prototype.onBtnVideo = function () {
        var _this = this;
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, function () {
            _this.emit(GameEventType_1.EventType.UIEvent.playGoldAnim, {
                cb: function () {
                    _this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
                        type: "gameData",
                        attribute: "gameData.asset.gold",
                        value: 200,
                        mode: "+"
                    });
                },
                gold: 200,
            });
        });
    };
    __decorate([
        property(cc.ToggleContainer)
    ], ShopUI.prototype, "goodsTypeToggles", void 0);
    __decorate([
        property(cc.PageView)
    ], ShopUI.prototype, "pageView", void 0);
    __decorate([
        property(cc.Prefab)
    ], ShopUI.prototype, "storePage", void 0);
    __decorate([
        property(cc.Label)
    ], ShopUI.prototype, "price", void 0);
    __decorate([
        property(cc.Prefab)
    ], ShopUI.prototype, "shopItemPerfab", void 0);
    __decorate([
        property(ShopStage_1.default)
    ], ShopUI.prototype, "stage", void 0);
    ShopUI = __decorate([
        ccclass
    ], ShopUI);
    return ShopUI;
}(yyComponent_1.default));
exports.default = ShopUI;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTG9iYnlVSVxcU2hvcFVJXFxTaG9wVUkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBQzFELGtFQUFpRTtBQUNqRSw2REFBd0Q7QUFDeEQsd0VBQW1FO0FBQ25FLHFEQUFnRDtBQUNoRCx5REFBb0Q7QUFDcEQsNkRBQXdEO0FBQ3hELHVDQUFrQztBQUNsQyx5Q0FBb0M7QUFFOUIsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFDNUMsV0FBVztBQUVYO0lBQW9DLDBCQUFXO0lBQS9DO1FBQUEscUVBc1BDO1FBcFBHLGFBQWE7UUFDSCxhQUFPLEdBQUcsdUJBQVUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO1FBSTdCLHNCQUFnQixHQUF1QixJQUFJLENBQUM7UUFFdEQsWUFBWTtRQUVGLGNBQVEsR0FBZ0IsSUFBSSxDQUFDO1FBWXZDLGdCQUFnQjtRQUVOLGVBQVMsR0FBYyxJQUFJLENBQUMsQ0FBQyxNQUFNO1FBQzdDLGFBQWE7UUFFSCxXQUFLLEdBQWEsSUFBSSxDQUFDO1FBQ2pDLFNBQVM7UUFFQyxvQkFBYyxHQUFjLElBQUksQ0FBQztRQUMzQyxXQUFXO1FBRUQsV0FBSyxHQUFjLElBQUksQ0FBQztRQXdHbEMsY0FBYztRQUNKLGFBQU8sR0FBYSxJQUFJLENBQUM7O0lBMkd2QyxDQUFDO0lBbFBHLHNCQUFXLDBCQUFNO2FBQWpCLGNBQXNCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBUWxDLHlCQUFRLEdBQWxCO1FBQ0ksb0JBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQy9GLG9CQUFVLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBQ1MsMEJBQVMsR0FBbkI7UUFDSSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3JDLEtBQUssSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN4QyxvQkFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN2QztRQUNELElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDbkMsQ0FBQztJQWFTLGlDQUFnQixHQUExQjtRQUNJLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUNTLGtDQUFpQixHQUEzQjtRQUNJLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDdkIsQ0FBQztJQUdNLHFCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUNwQixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUNwQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBQ1MseUJBQVEsR0FBbEI7UUFDSSxJQUFJLENBQUMsRUFBRSxDQUFDLHlCQUFTLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFDTSxzQkFBSyxHQUFaO1FBQ0ksSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDcEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDcEIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFTSxxQkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRVMsd0JBQU8sR0FBakI7UUFBQSxpQkFjQztRQWJHLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUM7UUFDaEQsSUFBSSxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUNwQixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUM1QixJQUFJLE9BQU8sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3hDLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ1YsT0FBTyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO2dCQUNoQyxPQUFPO2FBQ1Y7WUFDRCxJQUFJLE1BQUksR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDO1lBQ25DLGdCQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxNQUFJLEdBQUcsT0FBTyxFQUFFO2dCQUN6QyxLQUFJLENBQUMsU0FBUyxDQUFDLE1BQUksQ0FBQyxDQUFDO1lBQ3pCLENBQUMsRUFBRSxFQUFFLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzVCO0lBQ0wsQ0FBQztJQUNNLHFCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUlTLDZCQUFZLEdBQXRCLFVBQXVCLENBQUMsRUFBRSxJQUFJO1FBQTlCLGlCQUtDO1FBSkcsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUk7WUFBRSxPQUFPO1FBQ2pDLGdCQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxJQUFJLEdBQUcsT0FBTyxFQUFFO1lBQ3pDLEtBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDekIsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUNEOzs7T0FHRztJQUNPLDBCQUFTLEdBQW5CLFVBQW9CLElBQUk7UUFDcEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3BCLElBQUksU0FBUyxHQUFHLGtCQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztRQUNqQixJQUFJLFdBQVcsR0FBRyxvQkFBVSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDO1FBQ3BFLElBQUksT0FBTyxHQUFHLG9CQUFVLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUM7UUFDOUQsSUFBSSxPQUFPLE9BQU8sS0FBSyxRQUFRLEVBQUU7WUFDN0IsT0FBTyxHQUFHLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNoQztRQUNELElBQUksSUFBSSxHQUFZLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzVCLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDO1FBQzdDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO1FBQ3ZDLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQztRQUNsQixLQUFLLElBQUksR0FBRyxJQUFJLFNBQVMsRUFBRTtZQUN2QixJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksUUFBUSxFQUFFO2dCQUNoQyxJQUFJLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQy9CO1lBQ0QsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEQsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUN2QyxJQUFJLENBQUMsVUFBVSxHQUFHLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ2hELElBQUksQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDdEQsSUFBSSxJQUFJLEdBQUcsb0JBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDMUQsSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFO2dCQUNoQixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLGtCQUFRLENBQUMsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUNwQixTQUFTLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2FBQ25EO1lBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN2QjtRQUNELElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2hCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN4QztJQUNMLENBQUM7SUFJUyw2QkFBWSxHQUF0QixVQUF1QixJQUFjO1FBQ2pDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDaEIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRTtnQkFBRSxPQUFPO1lBQ3hDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztTQUNsQztRQUNELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3BCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUN2RDtRQUNELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFDRCxZQUFZO0lBQ0YsNkJBQVksR0FBdEIsVUFBdUIsSUFBSTtRQUN2QixJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM5QixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDYixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7U0FDcEI7YUFBTTtZQUNILElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzlCO0lBQ0wsQ0FBQztJQUVTLDBCQUFTLEdBQW5CLFVBQW9CLEtBQWE7UUFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3pDLENBQUM7SUFDUywwQkFBUyxHQUFuQjtRQUNJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUM5QixDQUFDO0lBRUQsVUFBVTtJQUNBLDBCQUFTLEdBQW5CO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFDRCxRQUFRO0lBQ0UseUJBQVEsR0FBbEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQzFCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTTtZQUFFLE9BQU87UUFDckMsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3BDLElBQUksSUFBSSxHQUFHLG9CQUFVLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUM7UUFDckQsSUFBSSxJQUFJLEdBQUcsS0FBSyxFQUFFO1lBQ2QsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1NBQzFCO2FBQU07WUFDSCxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNwRCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7WUFDM0IsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1NBQ3BCO0lBQ0wsQ0FBQztJQUNTLHdCQUFPLEdBQWpCLFVBQWtCLElBQVk7UUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRTtZQUNsRCxJQUFJLEVBQUUsVUFBVTtZQUNoQixTQUFTLEVBQUUscUJBQXFCO1lBQ2hDLEtBQUssRUFBRSxJQUFJO1lBQ1gsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsS0FBSztTQUNkLENBQUMsQ0FBQztJQUNQLENBQUM7SUFDRDs7OztPQUlHO0lBQ08sMkJBQVUsR0FBcEIsVUFBcUIsSUFBSSxFQUFFLEVBQUU7UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRTtZQUNsRCxJQUFJLEVBQUUsVUFBVTtZQUNoQixTQUFTLEVBQUUsV0FBVyxHQUFHLElBQUksR0FBRyxRQUFRO1lBQ3hDLEtBQUssRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDO1lBQ25CLElBQUksRUFBRSxNQUFNO1NBQ2YsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNEOzs7O09BSUc7SUFDTywyQkFBVSxHQUFwQixVQUFxQixJQUFJLEVBQUUsRUFBRTtRQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsZUFBZSxDQUFDLGdCQUFnQixFQUFFO1lBQ2xELElBQUksRUFBRSxVQUFVO1lBQ2hCLFNBQVMsRUFBRSxXQUFXLEdBQUcsSUFBSSxHQUFHLE1BQU07WUFDdEMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUM7WUFDbkIsSUFBSSxFQUFFLEdBQUc7U0FDWixDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0QsYUFBYTtJQUNILGdDQUFlLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUNELFVBQVU7SUFDViwyQkFBVSxHQUFWO1FBQUEsaUJBZUM7UUFkRyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFO1lBQ3BDLEtBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFO2dCQUN0QyxFQUFFLEVBQUU7b0JBQ0EsS0FBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRTt3QkFDbEQsSUFBSSxFQUFFLFVBQVU7d0JBQ2hCLFNBQVMsRUFBRSxxQkFBcUI7d0JBQ2hDLEtBQUssRUFBRSxHQUFHO3dCQUNWLElBQUksRUFBRSxHQUFHO3FCQUNaLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUNELElBQUksRUFBRSxHQUFHO2FBQ1osQ0FBQyxDQUFBO1FBQ04sQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBN09EO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxlQUFlLENBQUM7b0RBQ3lCO0lBSXREO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUM7NENBQ2lCO0lBY3ZDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7NkNBQ2tCO0lBR3RDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7eUNBQ2M7SUFHakM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztrREFDdUI7SUFHM0M7UUFEQyxRQUFRLENBQUMsbUJBQVMsQ0FBQzt5Q0FDYztJQWxDakIsTUFBTTtRQUQxQixPQUFPO09BQ2EsTUFBTSxDQXNQMUI7SUFBRCxhQUFDO0NBdFBELEFBc1BDLENBdFBtQyxxQkFBVyxHQXNQOUM7a0JBdFBvQixNQUFNIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHl5Q29tcG9uZW50IGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL3l5Q29tcG9uZW50XCI7XHJcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcclxuaW1wb3J0IEdsb2JhbFBvb2wgZnJvbSBcIi4uLy4uL1NjcmlwdC9Db21tb24vR2xvYmFsUG9vbFwiO1xyXG5pbXBvcnQgeyBFdmVudFR5cGUgfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dhbWVFdmVudFR5cGVcIjtcclxuaW1wb3J0IExvYWRlciBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9Mb2FkZXJcIjtcclxuaW1wb3J0IEdhbWVEYXRhIGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL0dhbWVEYXRhXCI7XHJcbmltcG9ydCBQbGF5ZXJEYXRhIGZyb20gXCIuLi8uLi9TY3JpcHQvQ29tbW9uL1BsYXllckRhdGFcIjtcclxuaW1wb3J0IFNob3BJdGVtIGZyb20gXCIuL1Nob3BJdGVtXCI7XHJcbmltcG9ydCBTaG9wU3RhZ2UgZnJvbSBcIi4vU2hvcFN0YWdlXCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG4vKirnmq7ogqTllYbln45VSSovXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNob3BVSSBleHRlbmRzIHl5Q29tcG9uZW50IHtcclxuXHJcbiAgICAvKirlnLrmma8vVUnnsbvlnosgKi9cclxuICAgIHByb3RlY3RlZCBfdWlUeXBlID0gR2xvYmFsRW51bS5VSS5zaG9wO1xyXG4gICAgcHVibGljIGdldCB1aVR5cGUoKSB7IHJldHVybiB0aGlzLl91aVR5cGU7IH1cclxuXHJcbiAgICBAcHJvcGVydHkoY2MuVG9nZ2xlQ29udGFpbmVyKVxyXG4gICAgcHJvdGVjdGVkIGdvb2RzVHlwZVRvZ2dsZXM6IGNjLlRvZ2dsZUNvbnRhaW5lciA9IG51bGw7XHJcblxyXG4gICAgLyoq6aG16Z2i5rua5Yqo6KeG5Zu+ICovXHJcbiAgICBAcHJvcGVydHkoY2MuUGFnZVZpZXcpXHJcbiAgICBwcm90ZWN0ZWQgcGFnZVZpZXc6IGNjLlBhZ2VWaWV3ID0gbnVsbDtcclxuICAgIHByb3RlY3RlZCBpbml0UGFnZSgpIHtcclxuICAgICAgICBHbG9iYWxQb29sLmNyZWF0ZVBvb2wodGhpcy5zaG9wSXRlbVBlcmZhYi5uYW1lLCB0aGlzLnNob3BJdGVtUGVyZmFiLCB0aGlzLnNob3BJdGVtUGVyZmFiLm5hbWUpO1xyXG4gICAgICAgIEdsb2JhbFBvb2wuY3JlYXRlUG9vbCh0aGlzLnN0b3JlUGFnZS5uYW1lLCB0aGlzLnN0b3JlUGFnZSk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgcmVzZXRQYWdlKCkge1xyXG4gICAgICAgIGxldCBwYWdlcyA9IHRoaXMucGFnZVZpZXcuZ2V0UGFnZXMoKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gcGFnZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcclxuICAgICAgICAgICAgR2xvYmFsUG9vbC5wdXRBbGxDaGlsZHJlbihwYWdlc1tpXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucGFnZVZpZXcucmVtb3ZlQWxsUGFnZXMoKTtcclxuICAgIH1cclxuICAgIC8qKuWNleS4quWVhuWTgemhtemdoueahOmihOWItuS7tiAqL1xyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIHByb3RlY3RlZCBzdG9yZVBhZ2U6IGNjLlByZWZhYiA9IG51bGw7IC8v5ZWG5Z+O6aG16Z2iXHJcbiAgICAvKirlvZPliY3llYblk4HnmoTku7fmoLwgKi9cclxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcclxuICAgIHByb3RlY3RlZCBwcmljZTogY2MuTGFiZWwgPSBudWxsO1xyXG4gICAgLyoq5ZWG5ZOB6aG5ICovXHJcbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxyXG4gICAgcHJvdGVjdGVkIHNob3BJdGVtUGVyZmFiOiBjYy5QcmVmYWIgPSBudWxsO1xyXG4gICAgLyoq5ZWG5ZOB5bGV56S65Y+wICovXHJcbiAgICBAcHJvcGVydHkoU2hvcFN0YWdlKVxyXG4gICAgcHJvdGVjdGVkIHN0YWdlOiBTaG9wU3RhZ2UgPSBudWxsO1xyXG4gICAgcHJvdGVjdGVkIGluaXREaXNwbGF5U3RhZ2UoKSB7XHJcbiAgICAgICAgdGhpcy5zdGFnZS5pbml0KCk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgcmVzZXREaXNwbGF5U3RhZ2UoKSB7XHJcbiAgICAgICAgdGhpcy5zdGFnZS5yZXNldCgpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwdWJsaWMgaW5pdCgpIHtcclxuICAgICAgICB0aGlzLmN1ckl0ZW0gPSBudWxsO1xyXG4gICAgICAgIHRoaXMuY3VyVHlwZSA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5pbml0Q29tcG9uZW50cygpO1xyXG4gICAgICAgIHRoaXMuaW5pdERpc3BsYXlTdGFnZSgpO1xyXG4gICAgICAgIHRoaXMuaW5pdFBhZ2UoKTtcclxuICAgICAgICB0aGlzLm9uRXZlbnRzKCk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgb25FdmVudHMoKSB7XHJcbiAgICAgICAgdGhpcy5vbihFdmVudFR5cGUuU2hvcEV2ZW50LmNob29zZUl0ZW0sIHRoaXMub25DaG9vc2VJdGVtLCB0aGlzKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyByZXNldCgpIHtcclxuICAgICAgICB0aGlzLmN1ckl0ZW0gPSBudWxsO1xyXG4gICAgICAgIHRoaXMuY3VyVHlwZSA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5yZXNldERpc3BsYXlTdGFnZSgpO1xyXG4gICAgICAgIHRoaXMucmVzZXRQYWdlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNob3coKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5yZXNldCgpO1xyXG4gICAgICAgIHRoaXMuc2V0RGF0YSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBzZXREYXRhKCkge1xyXG4gICAgICAgIGxldCB0b2dnbGVzID0gdGhpcy5nb29kc1R5cGVUb2dnbGVzLnRvZ2dsZUl0ZW1zO1xyXG4gICAgICAgIGlmICh0b2dnbGVzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdG9nZ2xlc1swXS5pc0NoZWNrZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICBsZXQgaGFuZGxlciA9IHRvZ2dsZXNbMF0uY2hlY2tFdmVudHNbMF07XHJcbiAgICAgICAgICAgIGlmICghaGFuZGxlcikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKFwi5ZWG5ZOB57G75Z6L5YiG6aG15qCH562+5pyq57uR5a6a5Zue6LCD5Ye95pWwXCIpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCB0eXBlID0gaGFuZGxlci5jdXN0b21FdmVudERhdGE7XHJcbiAgICAgICAgICAgIExvYWRlci5sb2FkQnVuZGxlRGlyKFwiU2tpblwiLCB0eXBlICsgXCIvSXRlbVwiLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dHb29kcyh0eXBlKTtcclxuICAgICAgICAgICAgfSwgY2MuU3ByaXRlRnJhbWUsIHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHB1YmxpYyBoaWRlKCkge1xyXG4gICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgLyoq5b2T5YmN6YCJ5Lit55qE5ZWG5ZOB5YiG6aG155qE57G75Z6LICovXHJcbiAgICBwcm90ZWN0ZWQgY3VyVHlwZTtcclxuICAgIHByb3RlY3RlZCBvbkNob29zZVR5cGUoZSwgdHlwZSkge1xyXG4gICAgICAgIGlmICh0aGlzLmN1clR5cGUgPT0gdHlwZSkgcmV0dXJuO1xyXG4gICAgICAgIExvYWRlci5sb2FkQnVuZGxlRGlyKFwiU2tpblwiLCB0eXBlICsgXCIvSXRlbVwiLCAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd0dvb2RzKHR5cGUpO1xyXG4gICAgICAgIH0sIGNjLlNwcml0ZUZyYW1lLCB0cnVlKTtcclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog5pi+56S65ZWG5ZOBXHJcbiAgICAgKiDlupTlvZPmlrDlu7rkuIDkuKrlsZXnpLrlj7DnmoTnsbvvvIzotJ/otKPmoLnmja7lrp7pmYXmuLjmiI/lsZXnpLrlr7nlupTnmoTllYblk4HmqKHlnovmiJblm77niYdcclxuICAgICAqL1xyXG4gICAgcHJvdGVjdGVkIHNob3dHb29kcyh0eXBlKSB7XHJcbiAgICAgICAgdGhpcy5yZXNldFBhZ2UoKTtcclxuICAgICAgICB0aGlzLmN1clR5cGUgPSB0eXBlO1xyXG4gICAgICAgIGxldCBnb29kc0RhdGEgPSBHYW1lRGF0YS5nZXREYXRhKHR5cGUpO1xyXG4gICAgICAgIGxldCBtYXhDb3VudCA9IDY7XHJcbiAgICAgICAgbGV0IHVubG9ja1NraW5zID0gUGxheWVyRGF0YS5nZXREYXRhKFwiZ2FtZURhdGEuXCIgKyB0eXBlICsgXCIub3duZWRcIik7XHJcbiAgICAgICAgbGV0IGN1clNraW4gPSBQbGF5ZXJEYXRhLmdldERhdGEoXCJnYW1lRGF0YS5cIiArIHR5cGUgKyBcIi5jdXJcIik7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBjdXJTa2luID09PSBcIm51bWJlclwiKSB7XHJcbiAgICAgICAgICAgIGN1clNraW4gPSBjdXJTa2luLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBwYWdlOiBjYy5Ob2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5zdG9yZVBhZ2UpO1xyXG4gICAgICAgIHRoaXMucGFnZVZpZXcuYWRkUGFnZShwYWdlKTtcclxuICAgICAgICBsZXQgZGlzcGxheVBhdGggPSB0aGlzLmN1clR5cGUgKyBcIi9EaXNwbGF5L1wiO1xyXG4gICAgICAgIGxldCBpdGVtUGF0aCA9IHRoaXMuY3VyVHlwZSArIFwiL0l0ZW0vXCI7XHJcbiAgICAgICAgbGV0IHBhZ2VJbmRleCA9IDA7XHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIGdvb2RzRGF0YSkge1xyXG4gICAgICAgICAgICBpZiAocGFnZS5jaGlsZHJlbkNvdW50ID49IG1heENvdW50KSB7XHJcbiAgICAgICAgICAgICAgICBwYWdlID0gY2MuaW5zdGFudGlhdGUodGhpcy5zdG9yZVBhZ2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wYWdlVmlldy5hZGRQYWdlKHBhZ2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCBkYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShnb29kc0RhdGFba2V5XSkpO1xyXG4gICAgICAgICAgICBkYXRhLml0ZW1VcmwgPSBpdGVtUGF0aCArIGRhdGEuaXRlbVVybDtcclxuICAgICAgICAgICAgZGF0YS5kaXNwbGF5VXJsID0gZGlzcGxheVBhdGggKyBkYXRhLmRpc3BsYXlVcmw7XHJcbiAgICAgICAgICAgIGRhdGEudW5sb2NrID0gdW5sb2NrU2tpbnMuaW5kZXhPZihwYXJzZUludChrZXkpKSA+PSAwO1xyXG4gICAgICAgICAgICBsZXQgbm9kZSA9IEdsb2JhbFBvb2wuZ2V0KHRoaXMuc2hvcEl0ZW1QZXJmYWIubmFtZSwgZGF0YSk7XHJcbiAgICAgICAgICAgIGlmIChrZXkgPT0gY3VyU2tpbikge1xyXG4gICAgICAgICAgICAgICAgbGV0IGl0ZW0gPSBub2RlLmdldENvbXBvbmVudChTaG9wSXRlbSk7XHJcbiAgICAgICAgICAgICAgICBpdGVtLmlzQ2hlY2tlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmN1ckl0ZW0gPSBpdGVtO1xyXG4gICAgICAgICAgICAgICAgcGFnZUluZGV4ID0gdGhpcy5wYWdlVmlldy5nZXRQYWdlcygpLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcGFnZS5hZGRDaGlsZChub2RlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wYWdlVmlldy5zY3JvbGxUb1BhZ2UocGFnZUluZGV4LCAwKTtcclxuICAgICAgICBpZiAoISF0aGlzLmN1ckl0ZW0pIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93SXRlbURhdGEodGhpcy5jdXJJdGVtLmRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKirlvZPliY3pgInkuK3nmoTllYblk4HpobkgKi9cclxuICAgIHByb3RlY3RlZCBjdXJJdGVtOiBTaG9wSXRlbSA9IG51bGw7XHJcbiAgICBwcm90ZWN0ZWQgb25DaG9vc2VJdGVtKGl0ZW06IFNob3BJdGVtKSB7XHJcbiAgICAgICAgaWYgKCEhdGhpcy5jdXJJdGVtKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmN1ckl0ZW0uSWQgPT09IGl0ZW0uSWQpIHJldHVybjtcclxuICAgICAgICAgICAgdGhpcy5jdXJJdGVtLmlzQ2hlY2tlZCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmN1ckl0ZW0gPSBpdGVtO1xyXG4gICAgICAgIGlmICh0aGlzLmN1ckl0ZW0uZGF0YS51bmxvY2spIHtcclxuICAgICAgICAgICAgdGhpcy5zZXRDdXJTa2luKHRoaXMuY3VyVHlwZSwgdGhpcy5jdXJJdGVtLmRhdGEuaWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnNob3dJdGVtRGF0YShpdGVtLmRhdGEpO1xyXG4gICAgfVxyXG4gICAgLyoq5bGV56S65ZWG5ZOB6K+m5oOFICovXHJcbiAgICBwcm90ZWN0ZWQgc2hvd0l0ZW1EYXRhKGRhdGEpIHtcclxuICAgICAgICB0aGlzLnN0YWdlLnNob3dJdGVtRGF0YShkYXRhKTtcclxuICAgICAgICBpZiAoZGF0YS51bmxvY2spIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93VXNpbmcoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dQcmljZShkYXRhLnByaWNlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHNob3dQcmljZShwcmljZTogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy5wcmljZS5zdHJpbmcgPSBwcmljZS50b1N0cmluZygpO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHNob3dVc2luZygpIHtcclxuICAgICAgICB0aGlzLnByaWNlLnN0cmluZyA9IFwi5L2/55So5LitXCI7XHJcbiAgICB9XHJcblxyXG4gICAgLyoq6YCA5Ye65ZWG5Z+OICovXHJcbiAgICBwcm90ZWN0ZWQgb25CdG5FeGl0KCkge1xyXG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5leGl0LCB0aGlzLnVpVHlwZSk7XHJcbiAgICB9XHJcbiAgICAvKirotK3kubAgKi9cclxuICAgIHByb3RlY3RlZCBvbkJ0bkJ1eSgpIHtcclxuICAgICAgICBpZiAoIXRoaXMuY3VySXRlbSkgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aGlzLmN1ckl0ZW0uZGF0YS51bmxvY2spIHJldHVybjtcclxuICAgICAgICBsZXQgcHJpY2UgPSB0aGlzLmN1ckl0ZW0uZGF0YS5wcmljZTtcclxuICAgICAgICBsZXQgZ29sZCA9IFBsYXllckRhdGEuZ2V0RGF0YShcImdhbWVEYXRhLmFzc2V0LmdvbGRcIik7XHJcbiAgICAgICAgaWYgKGdvbGQgPCBwcmljZSkge1xyXG4gICAgICAgICAgICB0aGlzLnRpcEdvbGRVbmVub3VnaCgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3ViR29sZChwcmljZSk7XHJcbiAgICAgICAgICAgIHRoaXMudW5sb2NrU2tpbih0aGlzLmN1clR5cGUsIHRoaXMuY3VySXRlbS5kYXRhLmlkKTtcclxuICAgICAgICAgICAgdGhpcy5zZXRDdXJTa2luKHRoaXMuY3VyVHlwZSwgdGhpcy5jdXJJdGVtLmRhdGEuaWQpO1xyXG4gICAgICAgICAgICB0aGlzLmN1ckl0ZW0uZGF0YS51bmxvY2sgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmN1ckl0ZW0udW5sb2NrID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5zaG93VXNpbmcoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc3ViR29sZChnb2xkOiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlBsYXllckRhdGFFdmVudC51cGRhdGVQbGF5ZXJEYXRhLCB7XHJcbiAgICAgICAgICAgIHR5cGU6IFwiZ2FtZURhdGFcIixcclxuICAgICAgICAgICAgYXR0cmlidXRlOiBcImdhbWVEYXRhLmFzc2V0LmdvbGRcIixcclxuICAgICAgICAgICAgdmFsdWU6IGdvbGQsXHJcbiAgICAgICAgICAgIG1vZGU6IFwiLVwiLFxyXG4gICAgICAgICAgICBzYXZlOiBmYWxzZSxcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog6Kej6ZSB55qu6IKkXHJcbiAgICAgKiBAcGFyYW0gdHlwZSDnmq7ogqTnsbvlnotcclxuICAgICAqIEBwYXJhbSBpZCDnmq7ogqRpZFxyXG4gICAgICovXHJcbiAgICBwcm90ZWN0ZWQgdW5sb2NrU2tpbih0eXBlLCBpZCkge1xyXG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuUGxheWVyRGF0YUV2ZW50LnVwZGF0ZVBsYXllckRhdGEsIHtcclxuICAgICAgICAgICAgdHlwZTogXCJnYW1lRGF0YVwiLFxyXG4gICAgICAgICAgICBhdHRyaWJ1dGU6IFwiZ2FtZURhdGEuXCIgKyB0eXBlICsgXCIub3duZWRcIixcclxuICAgICAgICAgICAgdmFsdWU6IHBhcnNlSW50KGlkKSxcclxuICAgICAgICAgICAgbW9kZTogXCJwdXNoXCJcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIC8qKlxyXG4gICAgICog6K6+572u5b2T5YmN5L2/55So55qE55qu6IKkXHJcbiAgICAgKiBAcGFyYW0gdHlwZSDnmq7ogqTnsbvlnotcclxuICAgICAqIEBwYXJhbSBpZCDnmq7ogqRpZFxyXG4gICAgICovXHJcbiAgICBwcm90ZWN0ZWQgc2V0Q3VyU2tpbih0eXBlLCBpZCkge1xyXG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuUGxheWVyRGF0YUV2ZW50LnVwZGF0ZVBsYXllckRhdGEsIHtcclxuICAgICAgICAgICAgdHlwZTogXCJnYW1lRGF0YVwiLFxyXG4gICAgICAgICAgICBhdHRyaWJ1dGU6IFwiZ2FtZURhdGEuXCIgKyB0eXBlICsgXCIuY3VyXCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBwYXJzZUludChpZCksXHJcbiAgICAgICAgICAgIG1vZGU6IFwiPVwiXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICAvKiog5o+Q56S66YeR5biB5LiN6LazICovXHJcbiAgICBwcm90ZWN0ZWQgdGlwR29sZFVuZW5vdWdoKCkge1xyXG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5zaG93VGlwLCBcIumHkeW4geS4jei2s1wiKTtcclxuICAgIH1cclxuICAgIC8qKuingueci+inhumikSAqL1xyXG4gICAgb25CdG5WaWRlbygpIHtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlNES0V2ZW50LnNob3dWaWRlbywgKCkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQucGxheUdvbGRBbmltLCB7XHJcbiAgICAgICAgICAgICAgICBjYjogKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuUGxheWVyRGF0YUV2ZW50LnVwZGF0ZVBsYXllckRhdGEsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJnYW1lRGF0YVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyaWJ1dGU6IFwiZ2FtZURhdGEuYXNzZXQuZ29sZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogMjAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RlOiBcIitcIlxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGdvbGQ6IDIwMCxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbn1cclxuIl19