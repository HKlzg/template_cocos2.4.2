
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LobbyUI/ChooseLevelUI/ChooseLevelUI.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5c5621S2uZBy5v/B3HCjZ1I', 'ChooseLevelUI');
// LobbyUI/ChooseLevelUI/ChooseLevelUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**关卡选择界面 */
var ChooseLevelUI = /** @class */ (function (_super) {
    __extends(ChooseLevelUI, _super);
    function ChooseLevelUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.plane = null;
        /*****************************************************************关卡项*****************************************************************/
        _this.itemLayer = null;
        /**关卡项背景图 */
        _this.levelItemSprites = [];
        /**已过关背景图 */
        _this.passItem = null;
        /**未解锁背景图 */
        _this.clockItem = null;
        _this.levelLayer = null;
        /**关卡序号 */
        _this.levelLabels = [];
        /*****************************************************************关卡页面*****************************************************************/
        /**每页包含的关卡项数量 */
        _this.countPerPage = 16;
        /**当前显示在第几页，从0开始计数 */
        _this.curPage = 0;
        /**可显示的最大页数 */
        _this.maxPage = 62;
        /*****************************************************************翻页按钮*****************************************************************/
        /**上一页按钮 */
        _this.btnPrePage = null;
        /**下一页按钮 */
        _this.btnNextPage = null;
        _this.unlockEffectMask = null;
        _this.unlockGuang = null;
        return _this;
    }
    ChooseLevelUI.prototype.init = function () {
        this.initUnlockEffect();
        this.initComponents();
        this.initItems();
        this.initPage();
    };
    ChooseLevelUI.prototype.reset = function () {
        this.resetUnlockEffect();
    };
    ChooseLevelUI.prototype.show = function () {
        this.node.active = true;
        // this.curPage = 0;
        var curLevel = PlayerData_1.default.getData("gameData.curLevel");
        if (undefined === curLevel) {
            this.curPage = 0;
        }
        else {
            this.curPage = Math.floor((curLevel - 1) / this.countPerPage);
        }
        this.showRecords(this.curPage);
        this.updateBtnState();
        this.playPlane();
    };
    ChooseLevelUI.prototype.playPlane = function () {
        var b = 0;
        var wg = this.plane.getComponent(cc.Widget);
        if (!!wg) {
            b = wg.bottom;
            wg.enabled = false;
        }
        var h = this.plane.height * this.plane.anchorY;
        var y = 0;
        if (!!wg) {
            y = -this.node.height * this.node.anchorY + b + h;
        }
        else {
            y = this.node.height * (1 - this.node.anchorY) - this.plane.height * (1 - this.plane.anchorY);
        }
        this.plane.setPosition(0, h + this.node.height * (1 - this.node.anchorY), 0);
        var move = Action3dManager_1.default.moveTo(1, 0, y, 0);
        move.easing(Action3dManager_1.default.easeElasticOut(0.35));
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).runAction(this.plane, move);
    };
    ChooseLevelUI.prototype.initItems = function () {
        var _this = this;
        this.countPerPage = this.itemLayer.childrenCount;
        this.levelItemSprites = [];
        var _loop_1 = function (i) {
            this_1.itemLayer.children[i].on("touchend", function () {
                _this.onChooseLevel(i);
            }, this_1);
            this_1.levelItemSprites.push(this_1.itemLayer.children[i].getComponent(cc.Sprite));
        };
        var this_1 = this;
        for (var i = 0; i < this.countPerPage; ++i) {
            _loop_1(i);
        }
        this.levelLabels = [];
        for (var i = 0; i < this.countPerPage; ++i) {
            this.levelLabels.push(this.levelLayer.children[i].getComponent(cc.Label));
        }
    };
    /**选择关卡项 */
    ChooseLevelUI.prototype.onChooseLevel = function (index) {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        var level = this.curPage * this.countPerPage + index + 1;
        var curLevel = PlayerData_1.default.getData("gameData.curLevel");
        if (level <= curLevel) {
            this.emit(GameEventType_1.EventType.DirectorEvent.enterChosedLevel, level);
        }
    };
    ChooseLevelUI.prototype.initPage = function () {
        var c = this.itemLayer.childrenCount;
        this.maxPage = Math.floor(1000 / c);
    };
    ChooseLevelUI.prototype.showRecords = function (page) {
        if (undefined === page) {
            page = this.curPage;
        }
        // let data = PlayerData.getData("gameData.levelRecords");
        var curLevel = PlayerData_1.default.getData("gameData.curLevel");
        var startLevel = page * this.countPerPage + 1;
        for (var i = 0; i < this.countPerPage; ++i) {
            var level = startLevel + i;
            // if (level > curLevel) {
            //     this.levelItemSprites[i].spriteFrame = this.clockItem;
            //     this.levelLabels[i].string = "";
            // } else if (level === curLevel) {
            //     this.levelItemSprites[i].spriteFrame = this.passItem;
            //     this.levelLabels[i].string = level.toString();
            // } else {
            //     let star = data[level];
            //     //理论上star绝对大于0
            //     if (!!star) {
            //         this.levelItemSprites[i].spriteFrame = this.passItem;
            //         this.levelLabels[i].string = (startLevel + i).toString();
            //     } else {
            //         this.levelItemSprites[i].spriteFrame = this.clockItem;
            //         this.levelLabels[i].string = "";
            //     }
            // }
            if (level > curLevel) {
                this.levelItemSprites[i].spriteFrame = this.clockItem;
                this.levelLabels[i].string = "";
            }
            else {
                this.levelItemSprites[i].spriteFrame = this.passItem;
                this.levelLabels[i].string = level.toString();
            }
        }
    };
    /**更新按钮的可点击状态 */
    ChooseLevelUI.prototype.updateBtnState = function () {
        this.btnPrePage.interactable = this.curPage > 0;
        this.btnNextPage.interactable = this.curPage < this.maxPage;
    };
    /**上一页 */
    ChooseLevelUI.prototype.onBtnPrePage = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        if (this.curPage <= 0)
            return;
        this.curPage -= 1;
        this.showRecords(this.curPage);
        this.updateBtnState();
    };
    /**下一页 */
    ChooseLevelUI.prototype.onBtnNextPage = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        if (this.curPage >= this.maxPage)
            return;
        this.curPage += 1;
        this.showRecords(this.curPage);
        this.updateBtnState();
    };
    ChooseLevelUI.prototype.onBtnClose = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.chooseLevel);
    };
    /*****************************************************************解锁/进入按钮*****************************************************************/
    ChooseLevelUI.prototype.onBtnUnclock = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, {
            success: this.unlockLevel.bind(this),
        });
    };
    ChooseLevelUI.prototype.unlockLevel = function () {
        var page = this.curPage;
        var curLevel = PlayerData_1.default.getData("gameData.curLevel");
        if (undefined === curLevel) {
            page = 0;
        }
        else {
            page = Math.floor((curLevel) / this.countPerPage);
        }
        if (page != this.curPage) {
            this.curPage = page;
            this.showRecords(this.curPage);
        }
        var index = curLevel % this.countPerPage;
        var p = this.plane.convertToNodeSpaceAR(this.itemLayer.children[index].convertToWorldSpaceAR(cc.v2(0, 38)));
        this.showUnlockEffect(p);
    };
    ChooseLevelUI.prototype.initUnlockEffect = function () {
        this.unlockEffectMask.active = false;
        this.unlockGuang.active = false;
    };
    ChooseLevelUI.prototype.resetUnlockEffect = function () {
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).stopAllActions(this.unlockEffectMask);
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).stopAllActions(this.unlockGuang);
        this.unlockEffectMask.active = false;
        this.unlockGuang.active = false;
    };
    ChooseLevelUI.prototype.showUnlockEffect = function (p) {
        this.emit(GameEventType_1.EventType.UIEvent.showTouchMask);
        if (undefined === p) {
            var curLevel = PlayerData_1.default.getData("gameData.curLevel");
            var index = curLevel % this.countPerPage;
            p = this.plane.convertToNodeSpaceAR(this.itemLayer.children[index].convertToWorldSpaceAR(cc.v2(0, 38)));
        }
        this.unlockEffectMask.active = true;
        this.unlockEffectMask.setPosition(p);
        this.unlockEffectMask.opacity = 50;
        var fadeIn = Action3dManager_1.default.fadeTo(1, 255);
        fadeIn.easing(Action3dManager_1.default.easeSinIn());
        var cb = Action3dManager_1.default.callFun(this.onUnlockEffectFadeIn.bind(this), this);
        var delay = Action3dManager_1.default.delay(0.3);
        var fadeOut = Action3dManager_1.default.fadeTo(0.5, 0);
        var finish = Action3dManager_1.default.callFun(this.onUnlockEffectFadeOut, this);
        var seq = Action3dManager_1.default.sequence(fadeIn, cb, delay, fadeOut, finish);
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).runAction(this.unlockEffectMask, seq);
    };
    ChooseLevelUI.prototype.onUnlockEffectFadeIn = function () {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData.curLevel",
            value: 1,
            mode: "+",
        });
        this.showRecords(this.curPage);
        this.updateBtnState();
    };
    ChooseLevelUI.prototype.onUnlockEffectFadeOut = function () {
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).stopAllActions(this.unlockGuang);
        this.unlockEffectMask.active = false;
        this.unlockGuang.active = false;
        this.emit(GameEventType_1.EventType.UIEvent.hideTouchMask);
    };
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "plane", void 0);
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "itemLayer", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], ChooseLevelUI.prototype, "passItem", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], ChooseLevelUI.prototype, "clockItem", void 0);
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "levelLayer", void 0);
    __decorate([
        property(cc.Button)
    ], ChooseLevelUI.prototype, "btnPrePage", void 0);
    __decorate([
        property(cc.Button)
    ], ChooseLevelUI.prototype, "btnNextPage", void 0);
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "unlockEffectMask", void 0);
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "unlockGuang", void 0);
    ChooseLevelUI = __decorate([
        ccclass
    ], ChooseLevelUI);
    return ChooseLevelUI;
}(yyComponent_1.default));
exports.default = ChooseLevelUI;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTG9iYnlVSVxcQ2hvb3NlTGV2ZWxVSVxcQ2hvb3NlTGV2ZWxVSS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrREFBMEQ7QUFDMUQsNkRBQXdEO0FBQ3hELHdFQUFtRTtBQUNuRSx1RUFBcUY7QUFDckYsa0VBQWlFO0FBRTNELElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBQzVDLFlBQVk7QUFFWjtJQUEyQyxpQ0FBVztJQUF0RDtRQUFBLHFFQTBQQztRQTlOYSxXQUFLLEdBQVksSUFBSSxDQUFDO1FBc0JoQyx1SUFBdUk7UUFFN0gsZUFBUyxHQUFZLElBQUksQ0FBQztRQUNwQyxZQUFZO1FBQ0Ysc0JBQWdCLEdBQWdCLEVBQUUsQ0FBQztRQUU3QyxZQUFZO1FBRUYsY0FBUSxHQUFtQixJQUFJLENBQUM7UUFDMUMsWUFBWTtRQUVGLGVBQVMsR0FBbUIsSUFBSSxDQUFDO1FBR2pDLGdCQUFVLEdBQVksSUFBSSxDQUFDO1FBQ3JDLFVBQVU7UUFDQSxpQkFBVyxHQUFlLEVBQUUsQ0FBQztRQTBCdkMsd0lBQXdJO1FBQ3hJLGdCQUFnQjtRQUNOLGtCQUFZLEdBQVcsRUFBRSxDQUFDO1FBQ3BDLHFCQUFxQjtRQUNYLGFBQU8sR0FBVyxDQUFDLENBQUM7UUFDOUIsY0FBYztRQUNKLGFBQU8sR0FBVyxFQUFFLENBQUM7UUEwQy9CLHdJQUF3STtRQUN4SSxXQUFXO1FBRUQsZ0JBQVUsR0FBYyxJQUFJLENBQUM7UUFDdkMsV0FBVztRQUVELGlCQUFXLEdBQWMsSUFBSSxDQUFDO1FBcUQ5QixzQkFBZ0IsR0FBWSxJQUFJLENBQUM7UUFFakMsaUJBQVcsR0FBWSxJQUFJLENBQUM7O0lBaUQxQyxDQUFDO0lBeFBVLDRCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRU0sNkJBQUssR0FBWjtRQUNJLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0lBQzdCLENBQUM7SUFFTSw0QkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLG9CQUFvQjtRQUNwQixJQUFJLFFBQVEsR0FBRyxvQkFBVSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3ZELElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRTtZQUN4QixJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztTQUNwQjthQUFNO1lBQ0gsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUNqRTtRQUNELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUlTLGlDQUFTLEdBQW5CO1FBQ0ksSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ1YsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNOLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDO1lBQ2QsRUFBRSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7U0FDdEI7UUFDRCxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMvQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDVixJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDTixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3JEO2FBQU07WUFDSCxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ2pHO1FBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzdFLElBQUksSUFBSSxHQUFHLHlCQUFlLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzlDLElBQUksQ0FBQyxNQUFNLENBQUMseUJBQWUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNsRCx5QkFBZSxDQUFDLE1BQU0sQ0FBQywrQkFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFvQlMsaUNBQVMsR0FBbkI7UUFBQSxpQkFhQztRQVpHLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUM7UUFDakQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztnQ0FDbEIsQ0FBQztZQUNOLE9BQUssU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFO2dCQUN0QyxLQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFCLENBQUMsU0FBTyxDQUFDO1lBQ1QsT0FBSyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBSyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzs7O1FBSm5GLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQztvQkFBakMsQ0FBQztTQUtUO1FBQ0QsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDdEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDeEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1NBQzdFO0lBQ0wsQ0FBQztJQUNELFdBQVc7SUFDRCxxQ0FBYSxHQUF2QixVQUF3QixLQUFhO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0MsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDekQsSUFBSSxRQUFRLEdBQUcsb0JBQVUsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUN2RCxJQUFJLEtBQUssSUFBSSxRQUFRLEVBQUU7WUFDbkIsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztTQUM5RDtJQUNMLENBQUM7SUFTUyxnQ0FBUSxHQUFsQjtRQUNJLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNTLG1DQUFXLEdBQXJCLFVBQXNCLElBQWE7UUFDL0IsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO1NBQ3ZCO1FBQ0QsMERBQTBEO1FBQzFELElBQUksUUFBUSxHQUFHLG9CQUFVLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDdkQsSUFBSSxVQUFVLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1FBQzlDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3hDLElBQUksS0FBSyxHQUFHLFVBQVUsR0FBRyxDQUFDLENBQUM7WUFDM0IsMEJBQTBCO1lBQzFCLDZEQUE2RDtZQUM3RCx1Q0FBdUM7WUFDdkMsbUNBQW1DO1lBQ25DLDREQUE0RDtZQUM1RCxxREFBcUQ7WUFDckQsV0FBVztZQUNYLDhCQUE4QjtZQUM5QixxQkFBcUI7WUFDckIsb0JBQW9CO1lBQ3BCLGdFQUFnRTtZQUNoRSxvRUFBb0U7WUFDcEUsZUFBZTtZQUNmLGlFQUFpRTtZQUNqRSwyQ0FBMkM7WUFDM0MsUUFBUTtZQUNSLElBQUk7WUFFSixJQUFJLEtBQUssR0FBRyxRQUFRLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDdEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO2FBQ25DO2lCQUFNO2dCQUNILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDckQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQ2pEO1NBQ0o7SUFDTCxDQUFDO0lBU0QsZ0JBQWdCO0lBQ04sc0NBQWMsR0FBeEI7UUFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDaEUsQ0FBQztJQUNELFNBQVM7SUFDQyxvQ0FBWSxHQUF0QjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0MsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUM7WUFBRSxPQUFPO1FBQzlCLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDO1FBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBQ0QsU0FBUztJQUNDLHFDQUFhLEdBQXZCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM3QyxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ3pDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDO1FBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRVMsa0NBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLHVCQUFVLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCwySUFBMkk7SUFDakksb0NBQVksR0FBdEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFO1lBQ3BDLE9BQU8sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDdkMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNTLG1DQUFXLEdBQXJCO1FBQ0ksSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUN4QixJQUFJLFFBQVEsR0FBRyxvQkFBVSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3ZELElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRTtZQUN4QixJQUFJLEdBQUcsQ0FBQyxDQUFDO1NBQ1o7YUFBTTtZQUNILElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ3JEO1FBQ0QsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUN0QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztZQUNwQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNsQztRQUNELElBQUksS0FBSyxHQUFHLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBTVMsd0NBQWdCLEdBQTFCO1FBQ0ksSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3BDLENBQUM7SUFDUyx5Q0FBaUIsR0FBM0I7UUFDSSx5QkFBZSxDQUFDLE1BQU0sQ0FBQywrQkFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUMvRSx5QkFBZSxDQUFDLE1BQU0sQ0FBQywrQkFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDMUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3BDLENBQUM7SUFDUyx3Q0FBZ0IsR0FBMUIsVUFBMkIsQ0FBVztRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRTNDLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtZQUNqQixJQUFJLFFBQVEsR0FBRyxvQkFBVSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQ3ZELElBQUksS0FBSyxHQUFHLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQ3pDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMzRztRQUVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFFbkMsSUFBSSxNQUFNLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzVDLE1BQU0sQ0FBQyxNQUFNLENBQUMseUJBQWUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQzNDLElBQUksRUFBRSxHQUFHLHlCQUFlLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDN0UsSUFBSSxLQUFLLEdBQUcseUJBQWUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdkMsSUFBSSxPQUFPLEdBQUcseUJBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzdDLElBQUksTUFBTSxHQUFHLHlCQUFlLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN2RSxJQUFJLEdBQUcsR0FBRyx5QkFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUseUJBQWUsQ0FBQyxNQUFNLENBQUMsK0JBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ25GLENBQUM7SUFDUyw0Q0FBb0IsR0FBOUI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsZUFBZSxDQUFDLGdCQUFnQixFQUFFO1lBQ2xELElBQUksRUFBRSxVQUFVO1lBQ2hCLFNBQVMsRUFBRSxtQkFBbUI7WUFDOUIsS0FBSyxFQUFFLENBQUM7WUFDUixJQUFJLEVBQUUsR0FBRztTQUNaLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBQ1MsNkNBQXFCLEdBQS9CO1FBQ0kseUJBQWUsQ0FBQyxNQUFNLENBQUMsK0JBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUE3TkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztnREFDYztJQXdCaEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztvREFDa0I7SUFNcEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQzttREFDaUI7SUFHMUM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQztvREFDa0I7SUFHM0M7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztxREFDbUI7SUErRXJDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7cURBQ21CO0lBR3ZDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7c0RBQ29CO0lBcUR4QztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzJEQUN5QjtJQUUzQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO3NEQUNvQjtJQXpNckIsYUFBYTtRQURqQyxPQUFPO09BQ2EsYUFBYSxDQTBQakM7SUFBRCxvQkFBQztDQTFQRCxBQTBQQyxDQTFQMEMscUJBQVcsR0EwUHJEO2tCQTFQb0IsYUFBYSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB5eUNvbXBvbmVudCBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi95eUNvbXBvbmVudFwiO1xyXG5pbXBvcnQgUGxheWVyRGF0YSBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9QbGF5ZXJEYXRhXCI7XHJcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2FtZUV2ZW50VHlwZVwiO1xyXG5pbXBvcnQgQWN0aW9uM2RNYW5hZ2VyLCB7IEFjdGlvbk1uZ1R5cGUgfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi9BY3Rpb24zZE1hbmFnZXJcIjtcclxuaW1wb3J0IHsgR2xvYmFsRW51bSB9IGZyb20gXCIuLi8uLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2xvYmFsRW51bVwiO1xyXG5cclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuLyoq5YWz5Y2h6YCJ5oup55WM6Z2iICovXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIENob29zZUxldmVsVUkgZXh0ZW5kcyB5eUNvbXBvbmVudCB7XHJcblxyXG4gICAgcHVibGljIGluaXQoKSB7XHJcbiAgICAgICAgdGhpcy5pbml0VW5sb2NrRWZmZWN0KCk7XHJcbiAgICAgICAgdGhpcy5pbml0Q29tcG9uZW50cygpO1xyXG4gICAgICAgIHRoaXMuaW5pdEl0ZW1zKCk7XHJcbiAgICAgICAgdGhpcy5pbml0UGFnZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZXNldCgpIHtcclxuICAgICAgICB0aGlzLnJlc2V0VW5sb2NrRWZmZWN0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNob3coKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgLy8gdGhpcy5jdXJQYWdlID0gMDtcclxuICAgICAgICBsZXQgY3VyTGV2ZWwgPSBQbGF5ZXJEYXRhLmdldERhdGEoXCJnYW1lRGF0YS5jdXJMZXZlbFwiKTtcclxuICAgICAgICBpZiAodW5kZWZpbmVkID09PSBjdXJMZXZlbCkge1xyXG4gICAgICAgICAgICB0aGlzLmN1clBhZ2UgPSAwO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuY3VyUGFnZSA9IE1hdGguZmxvb3IoKGN1ckxldmVsIC0gMSkgLyB0aGlzLmNvdW50UGVyUGFnZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuc2hvd1JlY29yZHModGhpcy5jdXJQYWdlKTtcclxuICAgICAgICB0aGlzLnVwZGF0ZUJ0blN0YXRlKCk7XHJcbiAgICAgICAgdGhpcy5wbGF5UGxhbmUoKTtcclxuICAgIH1cclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHByb3RlY3RlZCBwbGFuZTogY2MuTm9kZSA9IG51bGw7XHJcbiAgICBwcm90ZWN0ZWQgcGxheVBsYW5lKCkge1xyXG4gICAgICAgIGxldCBiID0gMDtcclxuICAgICAgICBsZXQgd2cgPSB0aGlzLnBsYW5lLmdldENvbXBvbmVudChjYy5XaWRnZXQpO1xyXG4gICAgICAgIGlmICghIXdnKSB7XHJcbiAgICAgICAgICAgIGIgPSB3Zy5ib3R0b207XHJcbiAgICAgICAgICAgIHdnLmVuYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGggPSB0aGlzLnBsYW5lLmhlaWdodCAqIHRoaXMucGxhbmUuYW5jaG9yWTtcclxuICAgICAgICBsZXQgeSA9IDA7XHJcbiAgICAgICAgaWYgKCEhd2cpIHtcclxuICAgICAgICAgICAgeSA9IC10aGlzLm5vZGUuaGVpZ2h0ICogdGhpcy5ub2RlLmFuY2hvclkgKyBiICsgaDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB5ID0gdGhpcy5ub2RlLmhlaWdodCAqICgxIC0gdGhpcy5ub2RlLmFuY2hvclkpIC0gdGhpcy5wbGFuZS5oZWlnaHQgKiAoMSAtIHRoaXMucGxhbmUuYW5jaG9yWSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLnBsYW5lLnNldFBvc2l0aW9uKDAsIGggKyB0aGlzLm5vZGUuaGVpZ2h0ICogKDEgLSB0aGlzLm5vZGUuYW5jaG9yWSksIDApO1xyXG4gICAgICAgIGxldCBtb3ZlID0gQWN0aW9uM2RNYW5hZ2VyLm1vdmVUbygxLCAwLCB5LCAwKTtcclxuICAgICAgICBtb3ZlLmVhc2luZyhBY3Rpb24zZE1hbmFnZXIuZWFzZUVsYXN0aWNPdXQoMC4zNSkpO1xyXG4gICAgICAgIEFjdGlvbjNkTWFuYWdlci5nZXRNbmcoQWN0aW9uTW5nVHlwZS5VSSkucnVuQWN0aW9uKHRoaXMucGxhbmUsIG1vdmUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKuWFs+WNoemhuSoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgaXRlbUxheWVyOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIC8qKuWFs+WNoemhueiDjOaZr+WbviAqL1xyXG4gICAgcHJvdGVjdGVkIGxldmVsSXRlbVNwcml0ZXM6IGNjLlNwcml0ZVtdID0gW107XHJcblxyXG4gICAgLyoq5bey6L+H5YWz6IOM5pmv5Zu+ICovXHJcbiAgICBAcHJvcGVydHkoY2MuU3ByaXRlRnJhbWUpXHJcbiAgICBwcm90ZWN0ZWQgcGFzc0l0ZW06IGNjLlNwcml0ZUZyYW1lID0gbnVsbDtcclxuICAgIC8qKuacquino+mUgeiDjOaZr+WbviAqL1xyXG4gICAgQHByb3BlcnR5KGNjLlNwcml0ZUZyYW1lKVxyXG4gICAgcHJvdGVjdGVkIGNsb2NrSXRlbTogY2MuU3ByaXRlRnJhbWUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcHJvdGVjdGVkIGxldmVsTGF5ZXI6IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgLyoq5YWz5Y2h5bqP5Y+3ICovXHJcbiAgICBwcm90ZWN0ZWQgbGV2ZWxMYWJlbHM6IGNjLkxhYmVsW10gPSBbXTtcclxuXHJcbiAgICBwcm90ZWN0ZWQgaW5pdEl0ZW1zKCkge1xyXG4gICAgICAgIHRoaXMuY291bnRQZXJQYWdlID0gdGhpcy5pdGVtTGF5ZXIuY2hpbGRyZW5Db3VudDtcclxuICAgICAgICB0aGlzLmxldmVsSXRlbVNwcml0ZXMgPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY291bnRQZXJQYWdlOyArK2kpIHtcclxuICAgICAgICAgICAgdGhpcy5pdGVtTGF5ZXIuY2hpbGRyZW5baV0ub24oXCJ0b3VjaGVuZFwiLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9uQ2hvb3NlTGV2ZWwoaSk7XHJcbiAgICAgICAgICAgIH0sIHRoaXMpO1xyXG4gICAgICAgICAgICB0aGlzLmxldmVsSXRlbVNwcml0ZXMucHVzaCh0aGlzLml0ZW1MYXllci5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubGV2ZWxMYWJlbHMgPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY291bnRQZXJQYWdlOyArK2kpIHtcclxuICAgICAgICAgICAgdGhpcy5sZXZlbExhYmVscy5wdXNoKHRoaXMubGV2ZWxMYXllci5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuTGFiZWwpKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvKirpgInmi6nlhbPljaHpobkgKi9cclxuICAgIHByb3RlY3RlZCBvbkNob29zZUxldmVsKGluZGV4OiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcclxuICAgICAgICBsZXQgbGV2ZWwgPSB0aGlzLmN1clBhZ2UgKiB0aGlzLmNvdW50UGVyUGFnZSArIGluZGV4ICsgMTtcclxuICAgICAgICBsZXQgY3VyTGV2ZWwgPSBQbGF5ZXJEYXRhLmdldERhdGEoXCJnYW1lRGF0YS5jdXJMZXZlbFwiKTtcclxuICAgICAgICBpZiAobGV2ZWwgPD0gY3VyTGV2ZWwpIHtcclxuICAgICAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LmVudGVyQ2hvc2VkTGV2ZWwsIGxldmVsKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq5YWz5Y2h6aG16Z2iKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKirmr4/pobXljIXlkKvnmoTlhbPljaHpobnmlbDph48gKi9cclxuICAgIHByb3RlY3RlZCBjb3VudFBlclBhZ2U6IG51bWJlciA9IDE2O1xyXG4gICAgLyoq5b2T5YmN5pi+56S65Zyo56ys5Yeg6aG177yM5LuOMOW8gOWni+iuoeaVsCAqL1xyXG4gICAgcHJvdGVjdGVkIGN1clBhZ2U6IG51bWJlciA9IDA7XHJcbiAgICAvKirlj6/mmL7npLrnmoTmnIDlpKfpobXmlbAgKi9cclxuICAgIHByb3RlY3RlZCBtYXhQYWdlOiBudW1iZXIgPSA2MjtcclxuICAgIHByb3RlY3RlZCBpbml0UGFnZSgpIHtcclxuICAgICAgICBsZXQgYyA9IHRoaXMuaXRlbUxheWVyLmNoaWxkcmVuQ291bnQ7XHJcbiAgICAgICAgdGhpcy5tYXhQYWdlID0gTWF0aC5mbG9vcigxMDAwIC8gYyk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc2hvd1JlY29yZHMocGFnZT86IG51bWJlcikge1xyXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IHBhZ2UpIHtcclxuICAgICAgICAgICAgcGFnZSA9IHRoaXMuY3VyUGFnZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gbGV0IGRhdGEgPSBQbGF5ZXJEYXRhLmdldERhdGEoXCJnYW1lRGF0YS5sZXZlbFJlY29yZHNcIik7XHJcbiAgICAgICAgbGV0IGN1ckxldmVsID0gUGxheWVyRGF0YS5nZXREYXRhKFwiZ2FtZURhdGEuY3VyTGV2ZWxcIik7XHJcbiAgICAgICAgbGV0IHN0YXJ0TGV2ZWwgPSBwYWdlICogdGhpcy5jb3VudFBlclBhZ2UgKyAxO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5jb3VudFBlclBhZ2U7ICsraSkge1xyXG4gICAgICAgICAgICBsZXQgbGV2ZWwgPSBzdGFydExldmVsICsgaTtcclxuICAgICAgICAgICAgLy8gaWYgKGxldmVsID4gY3VyTGV2ZWwpIHtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMubGV2ZWxJdGVtU3ByaXRlc1tpXS5zcHJpdGVGcmFtZSA9IHRoaXMuY2xvY2tJdGVtO1xyXG4gICAgICAgICAgICAvLyAgICAgdGhpcy5sZXZlbExhYmVsc1tpXS5zdHJpbmcgPSBcIlwiO1xyXG4gICAgICAgICAgICAvLyB9IGVsc2UgaWYgKGxldmVsID09PSBjdXJMZXZlbCkge1xyXG4gICAgICAgICAgICAvLyAgICAgdGhpcy5sZXZlbEl0ZW1TcHJpdGVzW2ldLnNwcml0ZUZyYW1lID0gdGhpcy5wYXNzSXRlbTtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMubGV2ZWxMYWJlbHNbaV0uc3RyaW5nID0gbGV2ZWwudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgLy8gfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gICAgIGxldCBzdGFyID0gZGF0YVtsZXZlbF07XHJcbiAgICAgICAgICAgIC8vICAgICAvL+eQhuiuuuS4inN0YXLnu53lr7nlpKfkuo4wXHJcbiAgICAgICAgICAgIC8vICAgICBpZiAoISFzdGFyKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgdGhpcy5sZXZlbEl0ZW1TcHJpdGVzW2ldLnNwcml0ZUZyYW1lID0gdGhpcy5wYXNzSXRlbTtcclxuICAgICAgICAgICAgLy8gICAgICAgICB0aGlzLmxldmVsTGFiZWxzW2ldLnN0cmluZyA9IChzdGFydExldmVsICsgaSkudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgLy8gICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgdGhpcy5sZXZlbEl0ZW1TcHJpdGVzW2ldLnNwcml0ZUZyYW1lID0gdGhpcy5jbG9ja0l0ZW07XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgdGhpcy5sZXZlbExhYmVsc1tpXS5zdHJpbmcgPSBcIlwiO1xyXG4gICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICBpZiAobGV2ZWwgPiBjdXJMZXZlbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sZXZlbEl0ZW1TcHJpdGVzW2ldLnNwcml0ZUZyYW1lID0gdGhpcy5jbG9ja0l0ZW07XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxldmVsTGFiZWxzW2ldLnN0cmluZyA9IFwiXCI7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxldmVsSXRlbVNwcml0ZXNbaV0uc3ByaXRlRnJhbWUgPSB0aGlzLnBhc3NJdGVtO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sZXZlbExhYmVsc1tpXS5zdHJpbmcgPSBsZXZlbC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKue/u+mhteaMiemSrioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLyoq5LiK5LiA6aG15oyJ6ZKuICovXHJcbiAgICBAcHJvcGVydHkoY2MuQnV0dG9uKVxyXG4gICAgcHJvdGVjdGVkIGJ0blByZVBhZ2U6IGNjLkJ1dHRvbiA9IG51bGw7XHJcbiAgICAvKirkuIvkuIDpobXmjInpkq4gKi9cclxuICAgIEBwcm9wZXJ0eShjYy5CdXR0b24pXHJcbiAgICBwcm90ZWN0ZWQgYnRuTmV4dFBhZ2U6IGNjLkJ1dHRvbiA9IG51bGw7XHJcbiAgICAvKirmm7TmlrDmjInpkq7nmoTlj6/ngrnlh7vnirbmgIEgKi9cclxuICAgIHByb3RlY3RlZCB1cGRhdGVCdG5TdGF0ZSgpIHtcclxuICAgICAgICB0aGlzLmJ0blByZVBhZ2UuaW50ZXJhY3RhYmxlID0gdGhpcy5jdXJQYWdlID4gMDtcclxuICAgICAgICB0aGlzLmJ0bk5leHRQYWdlLmludGVyYWN0YWJsZSA9IHRoaXMuY3VyUGFnZSA8IHRoaXMubWF4UGFnZTtcclxuICAgIH1cclxuICAgIC8qKuS4iuS4gOmhtSAqL1xyXG4gICAgcHJvdGVjdGVkIG9uQnRuUHJlUGFnZSgpIHtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcclxuICAgICAgICBpZiAodGhpcy5jdXJQYWdlIDw9IDApIHJldHVybjtcclxuICAgICAgICB0aGlzLmN1clBhZ2UgLT0gMTtcclxuICAgICAgICB0aGlzLnNob3dSZWNvcmRzKHRoaXMuY3VyUGFnZSk7XHJcbiAgICAgICAgdGhpcy51cGRhdGVCdG5TdGF0ZSgpO1xyXG4gICAgfVxyXG4gICAgLyoq5LiL5LiA6aG1ICovXHJcbiAgICBwcm90ZWN0ZWQgb25CdG5OZXh0UGFnZSgpIHtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkF1ZGlvRXZlbnQucGxheUNsaWNrQnRuKTtcclxuICAgICAgICBpZiAodGhpcy5jdXJQYWdlID49IHRoaXMubWF4UGFnZSkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuY3VyUGFnZSArPSAxO1xyXG4gICAgICAgIHRoaXMuc2hvd1JlY29yZHModGhpcy5jdXJQYWdlKTtcclxuICAgICAgICB0aGlzLnVwZGF0ZUJ0blN0YXRlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIG9uQnRuQ2xvc2UoKSB7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmV4aXQsIEdsb2JhbEVudW0uVUkuY2hvb3NlTGV2ZWwpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKuino+mUgS/ov5vlhaXmjInpkq4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByb3RlY3RlZCBvbkJ0blVuY2xvY2soKSB7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnBsYXlDbGlja0J0bik7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5TREtFdmVudC5zaG93VmlkZW8sIHtcclxuICAgICAgICAgICAgc3VjY2VzczogdGhpcy51bmxvY2tMZXZlbC5iaW5kKHRoaXMpLFxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgcHJvdGVjdGVkIHVubG9ja0xldmVsKCkge1xyXG4gICAgICAgIGxldCBwYWdlID0gdGhpcy5jdXJQYWdlO1xyXG4gICAgICAgIGxldCBjdXJMZXZlbCA9IFBsYXllckRhdGEuZ2V0RGF0YShcImdhbWVEYXRhLmN1ckxldmVsXCIpO1xyXG4gICAgICAgIGlmICh1bmRlZmluZWQgPT09IGN1ckxldmVsKSB7XHJcbiAgICAgICAgICAgIHBhZ2UgPSAwO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHBhZ2UgPSBNYXRoLmZsb29yKChjdXJMZXZlbCkgLyB0aGlzLmNvdW50UGVyUGFnZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChwYWdlICE9IHRoaXMuY3VyUGFnZSkge1xyXG4gICAgICAgICAgICB0aGlzLmN1clBhZ2UgPSBwYWdlO1xyXG4gICAgICAgICAgICB0aGlzLnNob3dSZWNvcmRzKHRoaXMuY3VyUGFnZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpbmRleCA9IGN1ckxldmVsICUgdGhpcy5jb3VudFBlclBhZ2U7XHJcbiAgICAgICAgbGV0IHAgPSB0aGlzLnBsYW5lLmNvbnZlcnRUb05vZGVTcGFjZUFSKHRoaXMuaXRlbUxheWVyLmNoaWxkcmVuW2luZGV4XS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMzgpKSk7XHJcbiAgICAgICAgdGhpcy5zaG93VW5sb2NrRWZmZWN0KHApO1xyXG4gICAgfVxyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcHJvdGVjdGVkIHVubG9ja0VmZmVjdE1hc2s6IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgdW5sb2NrR3Vhbmc6IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgcHJvdGVjdGVkIGluaXRVbmxvY2tFZmZlY3QoKSB7XHJcbiAgICAgICAgdGhpcy51bmxvY2tFZmZlY3RNYXNrLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMudW5sb2NrR3VhbmcuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgcmVzZXRVbmxvY2tFZmZlY3QoKSB7XHJcbiAgICAgICAgQWN0aW9uM2RNYW5hZ2VyLmdldE1uZyhBY3Rpb25NbmdUeXBlLlVJKS5zdG9wQWxsQWN0aW9ucyh0aGlzLnVubG9ja0VmZmVjdE1hc2spO1xyXG4gICAgICAgIEFjdGlvbjNkTWFuYWdlci5nZXRNbmcoQWN0aW9uTW5nVHlwZS5VSSkuc3RvcEFsbEFjdGlvbnModGhpcy51bmxvY2tHdWFuZyk7XHJcbiAgICAgICAgdGhpcy51bmxvY2tFZmZlY3RNYXNrLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMudW5sb2NrR3VhbmcuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgc2hvd1VubG9ja0VmZmVjdChwPzogY2MuVmVjMikge1xyXG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuVUlFdmVudC5zaG93VG91Y2hNYXNrKTtcclxuXHJcbiAgICAgICAgaWYgKHVuZGVmaW5lZCA9PT0gcCkge1xyXG4gICAgICAgICAgICBsZXQgY3VyTGV2ZWwgPSBQbGF5ZXJEYXRhLmdldERhdGEoXCJnYW1lRGF0YS5jdXJMZXZlbFwiKTtcclxuICAgICAgICAgICAgbGV0IGluZGV4ID0gY3VyTGV2ZWwgJSB0aGlzLmNvdW50UGVyUGFnZTtcclxuICAgICAgICAgICAgcCA9IHRoaXMucGxhbmUuY29udmVydFRvTm9kZVNwYWNlQVIodGhpcy5pdGVtTGF5ZXIuY2hpbGRyZW5baW5kZXhdLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLCAzOCkpKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMudW5sb2NrRWZmZWN0TWFzay5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMudW5sb2NrRWZmZWN0TWFzay5zZXRQb3NpdGlvbihwKTtcclxuICAgICAgICB0aGlzLnVubG9ja0VmZmVjdE1hc2sub3BhY2l0eSA9IDUwO1xyXG5cclxuICAgICAgICBsZXQgZmFkZUluID0gQWN0aW9uM2RNYW5hZ2VyLmZhZGVUbygxLCAyNTUpO1xyXG4gICAgICAgIGZhZGVJbi5lYXNpbmcoQWN0aW9uM2RNYW5hZ2VyLmVhc2VTaW5JbigpKTtcclxuICAgICAgICBsZXQgY2IgPSBBY3Rpb24zZE1hbmFnZXIuY2FsbEZ1bih0aGlzLm9uVW5sb2NrRWZmZWN0RmFkZUluLmJpbmQodGhpcyksIHRoaXMpO1xyXG4gICAgICAgIGxldCBkZWxheSA9IEFjdGlvbjNkTWFuYWdlci5kZWxheSgwLjMpO1xyXG4gICAgICAgIGxldCBmYWRlT3V0ID0gQWN0aW9uM2RNYW5hZ2VyLmZhZGVUbygwLjUsIDApO1xyXG4gICAgICAgIGxldCBmaW5pc2ggPSBBY3Rpb24zZE1hbmFnZXIuY2FsbEZ1bih0aGlzLm9uVW5sb2NrRWZmZWN0RmFkZU91dCwgdGhpcyk7XHJcbiAgICAgICAgbGV0IHNlcSA9IEFjdGlvbjNkTWFuYWdlci5zZXF1ZW5jZShmYWRlSW4sIGNiLCBkZWxheSwgZmFkZU91dCwgZmluaXNoKTtcclxuICAgICAgICBBY3Rpb24zZE1hbmFnZXIuZ2V0TW5nKEFjdGlvbk1uZ1R5cGUuVUkpLnJ1bkFjdGlvbih0aGlzLnVubG9ja0VmZmVjdE1hc2ssIHNlcSk7XHJcbiAgICB9XHJcbiAgICBwcm90ZWN0ZWQgb25VbmxvY2tFZmZlY3RGYWRlSW4oKSB7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5QbGF5ZXJEYXRhRXZlbnQudXBkYXRlUGxheWVyRGF0YSwge1xyXG4gICAgICAgICAgICB0eXBlOiBcImdhbWVEYXRhXCIsXHJcbiAgICAgICAgICAgIGF0dHJpYnV0ZTogXCJnYW1lRGF0YS5jdXJMZXZlbFwiLFxyXG4gICAgICAgICAgICB2YWx1ZTogMSxcclxuICAgICAgICAgICAgbW9kZTogXCIrXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5zaG93UmVjb3Jkcyh0aGlzLmN1clBhZ2UpO1xyXG4gICAgICAgIHRoaXMudXBkYXRlQnRuU3RhdGUoKTtcclxuICAgIH1cclxuICAgIHByb3RlY3RlZCBvblVubG9ja0VmZmVjdEZhZGVPdXQoKSB7XHJcbiAgICAgICAgQWN0aW9uM2RNYW5hZ2VyLmdldE1uZyhBY3Rpb25NbmdUeXBlLlVJKS5zdG9wQWxsQWN0aW9ucyh0aGlzLnVubG9ja0d1YW5nKTtcclxuICAgICAgICB0aGlzLnVubG9ja0VmZmVjdE1hc2suYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy51bmxvY2tHdWFuZy5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLlVJRXZlbnQuaGlkZVRvdWNoTWFzayk7XHJcbiAgICB9XHJcbn1cclxuIl19