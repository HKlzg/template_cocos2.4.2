
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/LobbyUI/ConfigSettingUI/ConfigSettingUI.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5219a61WZBHrLPY3aPlPMyY', 'ConfigSettingUI');
// LobbyUI/ConfigSettingUI/ConfigSettingUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameConfig_1 = require("../../Script/GameSpecial/GameConfig");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ConfigSettingUI = /** @class */ (function (_super) {
    __extends(ConfigSettingUI, _super);
    function ConfigSettingUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.togBGM = null;
        _this.togEffect = null;
        _this.togVibrate = null;
        return _this;
    }
    ConfigSettingUI.prototype.initConfig = function () {
        var audioConfig = GameConfig_1.default.audioConfig;
        this.togBGM.isChecked = audioConfig.bgm;
        this.togEffect.isChecked = audioConfig.effect;
        var driveConfig = GameConfig_1.default.driveConfig;
        this.togVibrate.isChecked = driveConfig.vibrate;
    };
    ConfigSettingUI.prototype.init = function () {
        this.initComponents();
        this.initConfig();
    };
    ConfigSettingUI.prototype.show = function () {
        if (this.node.active)
            return;
        this.node.active = true;
        this.emit(GameEventType_1.EventType.DirectorEvent.pauseLevel);
        this.initConfig();
    };
    ConfigSettingUI.prototype.hide = function () {
        if (!this.node.active)
            return;
        this.node.active = false;
        this.emit(GameEventType_1.EventType.DirectorEvent.resumeLevel);
    };
    ConfigSettingUI.prototype.saveConfig = function () {
        var audioConfig = {
            bgm: this.togBGM.isChecked,
            effect: this.togEffect.isChecked,
        };
        GameConfig_1.default.audioConfig = audioConfig;
        var driveConfig = {
            vibrate: this.togVibrate.isChecked,
        };
        GameConfig_1.default.driveConfig = driveConfig;
    };
    ConfigSettingUI.prototype.onBtnClose = function () {
        this.saveConfig();
        this.emit(GameEventType_1.EventType.DirectorEvent.resumeLevel);
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.configSetting);
    };
    ConfigSettingUI.prototype.onCloseBGM = function () {
        if (!this.togBGM.isChecked) {
            this.emit(GameEventType_1.EventType.AudioEvent.stopBGM);
        }
        else {
            this.emit(GameEventType_1.EventType.AudioEvent.playBGM, GlobalEnum_1.GlobalEnum.AudioClip.BGM);
        }
    };
    __decorate([
        property(cc.Toggle)
    ], ConfigSettingUI.prototype, "togBGM", void 0);
    __decorate([
        property(cc.Toggle)
    ], ConfigSettingUI.prototype, "togEffect", void 0);
    __decorate([
        property(cc.Toggle)
    ], ConfigSettingUI.prototype, "togVibrate", void 0);
    ConfigSettingUI = __decorate([
        ccclass
    ], ConfigSettingUI);
    return ConfigSettingUI;
}(yyComponent_1.default));
exports.default = ConfigSettingUI;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTG9iYnlVSVxcQ29uZmlnU2V0dGluZ1VJXFxDb25maWdTZXR0aW5nVUkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQTBEO0FBQzFELGtFQUE2RDtBQUM3RCx3RUFBbUU7QUFDbkUsa0VBQWlFO0FBRTNELElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQTZDLG1DQUFXO0lBQXhEO1FBQUEscUVBNkRDO1FBM0RhLFlBQU0sR0FBYyxJQUFJLENBQUM7UUFFekIsZUFBUyxHQUFjLElBQUksQ0FBQztRQUU1QixnQkFBVSxHQUFjLElBQUksQ0FBQzs7SUF1RDNDLENBQUM7SUFyRGEsb0NBQVUsR0FBcEI7UUFDSSxJQUFJLFdBQVcsR0FBRyxvQkFBVSxDQUFDLFdBQVcsQ0FBQztRQUN6QyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7UUFFOUMsSUFBSSxXQUFXLEdBQUcsb0JBQVUsQ0FBQyxXQUFXLENBQUM7UUFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQztJQUNwRCxDQUFDO0lBRU0sOEJBQUksR0FBWDtRQUNJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVNLDhCQUFJLEdBQVg7UUFDSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTTtZQUFFLE9BQU87UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDOUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFDTSw4QkFBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTTtZQUFFLE9BQU87UUFDOUIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVTLG9DQUFVLEdBQXBCO1FBQ0ksSUFBSSxXQUFXLEdBQUc7WUFDZCxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTO1lBQzFCLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVM7U0FDbkMsQ0FBQztRQUNGLG9CQUFVLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztRQUVyQyxJQUFJLFdBQVcsR0FBRztZQUNkLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVM7U0FDckMsQ0FBQztRQUNGLG9CQUFVLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztJQUN6QyxDQUFDO0lBRVMsb0NBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSx1QkFBVSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBRVMsb0NBQVUsR0FBcEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7WUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMzQzthQUFNO1lBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsdUJBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDckU7SUFDTCxDQUFDO0lBekREO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7bURBQ2U7SUFFbkM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztzREFDa0I7SUFFdEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzt1REFDbUI7SUFOdEIsZUFBZTtRQURuQyxPQUFPO09BQ2EsZUFBZSxDQTZEbkM7SUFBRCxzQkFBQztDQTdERCxBQTZEQyxDQTdENEMscUJBQVcsR0E2RHZEO2tCQTdEb0IsZUFBZSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB5eUNvbXBvbmVudCBmcm9tIFwiLi4vLi4vU2NyaXB0L0NvbW1vbi95eUNvbXBvbmVudFwiO1xyXG5pbXBvcnQgR2FtZUNvbmZpZyBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dhbWVDb25maWdcIjtcclxuaW1wb3J0IHsgRXZlbnRUeXBlIH0gZnJvbSBcIi4uLy4uL1NjcmlwdC9HYW1lU3BlY2lhbC9HYW1lRXZlbnRUeXBlXCI7XHJcbmltcG9ydCB7IEdsb2JhbEVudW0gfSBmcm9tIFwiLi4vLi4vU2NyaXB0L0dhbWVTcGVjaWFsL0dsb2JhbEVudW1cIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDb25maWdTZXR0aW5nVUkgZXh0ZW5kcyB5eUNvbXBvbmVudCB7XHJcbiAgICBAcHJvcGVydHkoY2MuVG9nZ2xlKVxyXG4gICAgcHJvdGVjdGVkIHRvZ0JHTTogY2MuVG9nZ2xlID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eShjYy5Ub2dnbGUpXHJcbiAgICBwcm90ZWN0ZWQgdG9nRWZmZWN0OiBjYy5Ub2dnbGUgPSBudWxsO1xyXG4gICAgQHByb3BlcnR5KGNjLlRvZ2dsZSlcclxuICAgIHByb3RlY3RlZCB0b2dWaWJyYXRlOiBjYy5Ub2dnbGUgPSBudWxsO1xyXG5cclxuICAgIHByb3RlY3RlZCBpbml0Q29uZmlnKCkge1xyXG4gICAgICAgIGxldCBhdWRpb0NvbmZpZyA9IEdhbWVDb25maWcuYXVkaW9Db25maWc7XHJcbiAgICAgICAgdGhpcy50b2dCR00uaXNDaGVja2VkID0gYXVkaW9Db25maWcuYmdtO1xyXG4gICAgICAgIHRoaXMudG9nRWZmZWN0LmlzQ2hlY2tlZCA9IGF1ZGlvQ29uZmlnLmVmZmVjdDtcclxuXHJcbiAgICAgICAgbGV0IGRyaXZlQ29uZmlnID0gR2FtZUNvbmZpZy5kcml2ZUNvbmZpZztcclxuICAgICAgICB0aGlzLnRvZ1ZpYnJhdGUuaXNDaGVja2VkID0gZHJpdmVDb25maWcudmlicmF0ZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaW5pdCgpIHtcclxuICAgICAgICB0aGlzLmluaXRDb21wb25lbnRzKCk7XHJcbiAgICAgICAgdGhpcy5pbml0Q29uZmlnKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNob3coKSB7XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS5hY3RpdmUpIHJldHVybjtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmVtaXQoRXZlbnRUeXBlLkRpcmVjdG9yRXZlbnQucGF1c2VMZXZlbCk7XHJcbiAgICAgICAgdGhpcy5pbml0Q29uZmlnKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgaGlkZSgpIHtcclxuICAgICAgICBpZiAoIXRoaXMubm9kZS5hY3RpdmUpIHJldHVybjtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5EaXJlY3RvckV2ZW50LnJlc3VtZUxldmVsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2F2ZUNvbmZpZygpIHtcclxuICAgICAgICBsZXQgYXVkaW9Db25maWcgPSB7XHJcbiAgICAgICAgICAgIGJnbTogdGhpcy50b2dCR00uaXNDaGVja2VkLFxyXG4gICAgICAgICAgICBlZmZlY3Q6IHRoaXMudG9nRWZmZWN0LmlzQ2hlY2tlZCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIEdhbWVDb25maWcuYXVkaW9Db25maWcgPSBhdWRpb0NvbmZpZztcclxuXHJcbiAgICAgICAgbGV0IGRyaXZlQ29uZmlnID0ge1xyXG4gICAgICAgICAgICB2aWJyYXRlOiB0aGlzLnRvZ1ZpYnJhdGUuaXNDaGVja2VkLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgR2FtZUNvbmZpZy5kcml2ZUNvbmZpZyA9IGRyaXZlQ29uZmlnO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBvbkJ0bkNsb3NlKCkge1xyXG4gICAgICAgIHRoaXMuc2F2ZUNvbmZpZygpO1xyXG4gICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuRGlyZWN0b3JFdmVudC5yZXN1bWVMZXZlbCk7XHJcbiAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5VSUV2ZW50LmV4aXQsIEdsb2JhbEVudW0uVUkuY29uZmlnU2V0dGluZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIG9uQ2xvc2VCR00oKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLnRvZ0JHTS5pc0NoZWNrZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5lbWl0KEV2ZW50VHlwZS5BdWRpb0V2ZW50LnN0b3BCR00pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZW1pdChFdmVudFR5cGUuQXVkaW9FdmVudC5wbGF5QkdNLCBHbG9iYWxFbnVtLkF1ZGlvQ2xpcC5CR00pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn1cclxuIl19