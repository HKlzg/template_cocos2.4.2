
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/InitScene/Init.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4805ccI48pCd6oESz6VFiBg', 'Init');
// InitScene/Init.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GamePlatformType_1 = require("../Script/Platform/GamePlatformType");
var EventManager_1 = require("../Script/Common/EventManager");
var GameEventType_1 = require("../Script/GameSpecial/GameEventType");
var GamePlatform_1 = require("../Script/Platform/GamePlatform");
var GamePlatformConfig_1 = require("../Script/Platform/GamePlatformConfig");
var Loader_1 = require("../Script/Common/Loader");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Init = /** @class */ (function (_super) {
    __extends(Init, _super);
    function Init() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = GamePlatformType_1.GamePlatformType.PC;
        _this.platformConfig = null;
        _this.bar = null;
        _this.totalLength = 0;
        /**所有资源包都可记录在本数组中，用于预加载，可尽量将更早需要使用的资源包放在更前 */
        _this.preBundleList = [
            "GameData",
            "Audio",
            "LobbyUI",
            "LevelScene",
            "LevelUI",
            "Skin",
        ];
        /**进入主场景前必须加载完成的子包列表 */
        _this.necessaryBundleList = [
            "MainScene"
        ];
        //子包加载状态
        _this.bundleLoadState = {};
        return _this;
    }
    Init.prototype.initProgressBar = function () {
        if (this.totalLength == 0) {
            this.totalLength = this.bar.getComponent(cc.Sprite).spriteFrame.getOriginalSize().width;
        }
        this.bar.setPosition(-0.5 * this.totalLength, this.bar.y);
        this.bar.width = 0;
    };
    Init.prototype.onUpdateProgress = function (rate) {
        this.bar.width = this.totalLength * rate;
    };
    Init.prototype.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.LoadAssetEvent.updateProgress, this.onUpdateProgress, this);
    };
    Init.prototype.offEvents = function () {
        EventManager_1.default.off(GameEventType_1.EventType.LoadAssetEvent.updateProgress, this.onUpdateProgress, this);
    };
    Init.prototype.onLoad = function () {
        cc.game.addPersistRootNode(this.platformConfig);
        var js = this.findConfig();
        GamePlatform_1.default.instance.init(js);
        this.initProgressBar();
        this.onEvents();
    };
    Init.prototype.findConfig = function () {
        var nodes = this.platformConfig.children;
        for (var i = nodes.length - 1; i >= 0; --i) {
            var js = nodes[i].getComponent(GamePlatformConfig_1.default);
            if (js.type == this.type) {
                return js;
            }
            else {
                nodes[i].removeFromParent();
                nodes[i].destroy();
            }
        }
        console.error("没有设置对应平台的配置！");
        return null;
    };
    Init.prototype.start = function () {
        var _this = this;
        var _loop_1 = function (i) {
            Loader_1.default.loadSubpackage(this_1.necessaryBundleList[i], function () {
                _this.loadOneSubpackage(_this.necessaryBundleList[i]);
            }, true);
        };
        var this_1 = this;
        //加载进入主场景前必需的资源包
        for (var i = this.necessaryBundleList.length - 1; i >= 0; --i) {
            _loop_1(i);
        }
        //预加载其他资源包
        for (var i = 0, c = this.preBundleList.length; i < c; ++i) {
            Loader_1.default.loadBundle(this.preBundleList[i], null, false, false);
        }
    };
    Init.prototype.loadOneSubpackage = function (n) {
        this.bundleLoadState[n] = true;
        for (var i = this.necessaryBundleList.length - 1; i >= 0; --i) {
            if (!this.bundleLoadState[this.necessaryBundleList[i]]) {
                return;
            }
        }
        this.loadMainScene();
    };
    Init.prototype.loadMainScene = function () {
        var _this = this;
        Loader_1.default.loadBundleScene("MainScene", "MainScene", function (res) {
            _this.offEvents();
            cc.director.runScene(res);
        }, false);
    };
    __decorate([
        property({ type: cc.Enum(GamePlatformType_1.GamePlatformType) })
    ], Init.prototype, "type", void 0);
    __decorate([
        property(cc.Node)
    ], Init.prototype, "platformConfig", void 0);
    __decorate([
        property(cc.Node)
    ], Init.prototype, "bar", void 0);
    __decorate([
        property
    ], Init.prototype, "totalLength", void 0);
    Init = __decorate([
        ccclass
    ], Init);
    return Init;
}(cc.Component));
exports.default = Init;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcSW5pdFNjZW5lXFxJbml0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHdFQUF1RTtBQUN2RSw4REFBeUQ7QUFDekQscUVBQWdFO0FBQ2hFLGdFQUEyRDtBQUMzRCw0RUFBdUU7QUFDdkUsa0RBQTZDO0FBRXZDLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQWtDLHdCQUFZO0lBQTlDO1FBQUEscUVBa0dDO1FBaEdVLFVBQUksR0FBcUIsbUNBQWdCLENBQUMsRUFBRSxDQUFDO1FBRzdDLG9CQUFjLEdBQVksSUFBSSxDQUFDO1FBRzVCLFNBQUcsR0FBWSxJQUFJLENBQUM7UUFFcEIsaUJBQVcsR0FBVyxDQUFDLENBQUM7UUF1RGxDLDZDQUE2QztRQUNuQyxtQkFBYSxHQUFhO1lBQ2hDLFVBQVU7WUFDVixPQUFPO1lBQ1AsU0FBUztZQUNULFlBQVk7WUFDWixTQUFTO1lBQ1QsTUFBTTtTQUNULENBQUM7UUFFRix1QkFBdUI7UUFDYix5QkFBbUIsR0FBYTtZQUN0QyxXQUFXO1NBQ2QsQ0FBQztRQUNGLFFBQVE7UUFDRSxxQkFBZSxHQUFHLEVBQUUsQ0FBQzs7SUFrQm5DLENBQUM7SUF2RmEsOEJBQWUsR0FBekI7UUFDSSxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxFQUFFO1lBQ3ZCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxLQUFLLENBQUM7U0FDM0Y7UUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFDUywrQkFBZ0IsR0FBMUIsVUFBMkIsSUFBWTtRQUNuQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztJQUM3QyxDQUFDO0lBRVMsdUJBQVEsR0FBbEI7UUFDSSxzQkFBWSxDQUFDLEVBQUUsQ0FBQyx5QkFBUyxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzFGLENBQUM7SUFDUyx3QkFBUyxHQUFuQjtRQUNJLHNCQUFZLENBQUMsR0FBRyxDQUFDLHlCQUFTLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDM0YsQ0FBQztJQUVELHFCQUFNLEdBQU47UUFDSSxFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUVoRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDM0Isc0JBQVksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRS9CLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUNTLHlCQUFVLEdBQXBCO1FBQ0ksSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUM7UUFDekMsS0FBSyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3hDLElBQUksRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsNEJBQWtCLENBQUMsQ0FBQztZQUNuRCxJQUFJLEVBQUUsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksRUFBRTtnQkFDdEIsT0FBTyxFQUFFLENBQUM7YUFDYjtpQkFBTTtnQkFDSCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDNUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQ3RCO1NBQ0o7UUFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQzlCLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCxvQkFBSyxHQUFMO1FBQUEsaUJBV0M7Z0NBVFksQ0FBQztZQUNOLGdCQUFNLENBQUMsY0FBYyxDQUFDLE9BQUssbUJBQW1CLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQy9DLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4RCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7OztRQUpiLGdCQUFnQjtRQUNoQixLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO29CQUFwRCxDQUFDO1NBSVQ7UUFDRCxVQUFVO1FBQ1YsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDdkQsZ0JBQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ2hFO0lBQ0wsQ0FBQztJQWlCRCxnQ0FBaUIsR0FBakIsVUFBa0IsQ0FBUztRQUN2QixJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUMvQixLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BELE9BQU87YUFDVjtTQUNKO1FBQ0QsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRCw0QkFBYSxHQUFiO1FBQUEsaUJBS0M7UUFKRyxnQkFBTSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFFLFVBQUMsR0FBRztZQUNqRCxLQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDakIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDOUIsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2QsQ0FBQztJQTlGRDtRQURDLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1DQUFnQixDQUFDLEVBQUUsQ0FBQztzQ0FDTTtJQUdwRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO2dEQUNvQjtJQUd0QztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO3FDQUNZO0lBRTlCO1FBREMsUUFBUTs2Q0FDeUI7SUFWakIsSUFBSTtRQUR4QixPQUFPO09BQ2EsSUFBSSxDQWtHeEI7SUFBRCxXQUFDO0NBbEdELEFBa0dDLENBbEdpQyxFQUFFLENBQUMsU0FBUyxHQWtHN0M7a0JBbEdvQixJQUFJIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgR2FtZVBsYXRmb3JtVHlwZSB9IGZyb20gXCIuLi9TY3JpcHQvUGxhdGZvcm0vR2FtZVBsYXRmb3JtVHlwZVwiO1xuaW1wb3J0IEV2ZW50TWFuYWdlciBmcm9tIFwiLi4vU2NyaXB0L0NvbW1vbi9FdmVudE1hbmFnZXJcIjtcbmltcG9ydCB7IEV2ZW50VHlwZSB9IGZyb20gXCIuLi9TY3JpcHQvR2FtZVNwZWNpYWwvR2FtZUV2ZW50VHlwZVwiO1xuaW1wb3J0IEdhbWVQbGF0Zm9ybSBmcm9tIFwiLi4vU2NyaXB0L1BsYXRmb3JtL0dhbWVQbGF0Zm9ybVwiO1xuaW1wb3J0IEdhbWVQbGF0Zm9ybUNvbmZpZyBmcm9tIFwiLi4vU2NyaXB0L1BsYXRmb3JtL0dhbWVQbGF0Zm9ybUNvbmZpZ1wiO1xuaW1wb3J0IExvYWRlciBmcm9tIFwiLi4vU2NyaXB0L0NvbW1vbi9Mb2FkZXJcIjtcblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEluaXQgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLkVudW0oR2FtZVBsYXRmb3JtVHlwZSkgfSlcbiAgICBwdWJsaWMgdHlwZTogR2FtZVBsYXRmb3JtVHlwZSA9IEdhbWVQbGF0Zm9ybVR5cGUuUEM7XG5cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBwdWJsaWMgcGxhdGZvcm1Db25maWc6IGNjLk5vZGUgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgcHJvdGVjdGVkIGJhcjogY2MuTm9kZSA9IG51bGw7XG4gICAgQHByb3BlcnR5XG4gICAgcHJvdGVjdGVkIHRvdGFsTGVuZ3RoOiBudW1iZXIgPSAwO1xuICAgIHByb3RlY3RlZCBpbml0UHJvZ3Jlc3NCYXIoKSB7XG4gICAgICAgIGlmICh0aGlzLnRvdGFsTGVuZ3RoID09IDApIHtcbiAgICAgICAgICAgIHRoaXMudG90YWxMZW5ndGggPSB0aGlzLmJhci5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZS5nZXRPcmlnaW5hbFNpemUoKS53aWR0aDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmJhci5zZXRQb3NpdGlvbigtMC41ICogdGhpcy50b3RhbExlbmd0aCwgdGhpcy5iYXIueSk7XG4gICAgICAgIHRoaXMuYmFyLndpZHRoID0gMDtcbiAgICB9XG4gICAgcHJvdGVjdGVkIG9uVXBkYXRlUHJvZ3Jlc3MocmF0ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuYmFyLndpZHRoID0gdGhpcy50b3RhbExlbmd0aCAqIHJhdGU7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIG9uRXZlbnRzKCkge1xuICAgICAgICBFdmVudE1hbmFnZXIub24oRXZlbnRUeXBlLkxvYWRBc3NldEV2ZW50LnVwZGF0ZVByb2dyZXNzLCB0aGlzLm9uVXBkYXRlUHJvZ3Jlc3MsIHRoaXMpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgb2ZmRXZlbnRzKCkge1xuICAgICAgICBFdmVudE1hbmFnZXIub2ZmKEV2ZW50VHlwZS5Mb2FkQXNzZXRFdmVudC51cGRhdGVQcm9ncmVzcywgdGhpcy5vblVwZGF0ZVByb2dyZXNzLCB0aGlzKTtcbiAgICB9XG5cbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIGNjLmdhbWUuYWRkUGVyc2lzdFJvb3ROb2RlKHRoaXMucGxhdGZvcm1Db25maWcpO1xuXG4gICAgICAgIGxldCBqcyA9IHRoaXMuZmluZENvbmZpZygpO1xuICAgICAgICBHYW1lUGxhdGZvcm0uaW5zdGFuY2UuaW5pdChqcyk7XG5cbiAgICAgICAgdGhpcy5pbml0UHJvZ3Jlc3NCYXIoKTtcbiAgICAgICAgdGhpcy5vbkV2ZW50cygpO1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgZmluZENvbmZpZygpIHtcbiAgICAgICAgbGV0IG5vZGVzID0gdGhpcy5wbGF0Zm9ybUNvbmZpZy5jaGlsZHJlbjtcbiAgICAgICAgZm9yIChsZXQgaSA9IG5vZGVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgICAgICBsZXQganMgPSBub2Rlc1tpXS5nZXRDb21wb25lbnQoR2FtZVBsYXRmb3JtQ29uZmlnKTtcbiAgICAgICAgICAgIGlmIChqcy50eXBlID09IHRoaXMudHlwZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBqcztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbm9kZXNbaV0ucmVtb3ZlRnJvbVBhcmVudCgpO1xuICAgICAgICAgICAgICAgIG5vZGVzW2ldLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zb2xlLmVycm9yKFwi5rKh5pyJ6K6+572u5a+55bqU5bmz5Y+w55qE6YWN572u77yBXCIpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgLy/liqDovb3ov5vlhaXkuLvlnLrmma/liY3lv4XpnIDnmoTotYTmupDljIVcbiAgICAgICAgZm9yIChsZXQgaSA9IHRoaXMubmVjZXNzYXJ5QnVuZGxlTGlzdC5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgTG9hZGVyLmxvYWRTdWJwYWNrYWdlKHRoaXMubmVjZXNzYXJ5QnVuZGxlTGlzdFtpXSwgKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZE9uZVN1YnBhY2thZ2UodGhpcy5uZWNlc3NhcnlCdW5kbGVMaXN0W2ldKTtcbiAgICAgICAgICAgIH0sIHRydWUpO1xuICAgICAgICB9XG4gICAgICAgIC8v6aKE5Yqg6L295YW25LuW6LWE5rqQ5YyFXG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBjID0gdGhpcy5wcmVCdW5kbGVMaXN0Lmxlbmd0aDsgaSA8IGM7ICsraSkge1xuICAgICAgICAgICAgTG9hZGVyLmxvYWRCdW5kbGUodGhpcy5wcmVCdW5kbGVMaXN0W2ldLCBudWxsLCBmYWxzZSwgZmFsc2UpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKuaJgOaciei1hOa6kOWMhemDveWPr+iusOW9leWcqOacrOaVsOe7hOS4re+8jOeUqOS6jumihOWKoOi9ve+8jOWPr+WwvemHj+WwhuabtOaXqemcgOimgeS9v+eUqOeahOi1hOa6kOWMheaUvuWcqOabtOWJjSAqL1xuICAgIHByb3RlY3RlZCBwcmVCdW5kbGVMaXN0OiBzdHJpbmdbXSA9IFtcbiAgICAgICAgXCJHYW1lRGF0YVwiLFxuICAgICAgICBcIkF1ZGlvXCIsXG4gICAgICAgIFwiTG9iYnlVSVwiLFxuICAgICAgICBcIkxldmVsU2NlbmVcIiwgICAgLy/oi6XkuLvpobXkuK3ml6Dog4zmma/lm77vvIznm7TmjqXku6XlhbPljaHlnLrmma/kuLrog4zmma/vvIzliJlMZXZlbOS8mOWFiOS6jkxvYmJ5VUnliqDovb3vvIzlkKbliJnlnKjlhbblkI7liqDovb1cbiAgICAgICAgXCJMZXZlbFVJXCIsXG4gICAgICAgIFwiU2tpblwiLFxuICAgIF07XG5cbiAgICAvKirov5vlhaXkuLvlnLrmma/liY3lv4XpobvliqDovb3lrozmiJDnmoTlrZDljIXliJfooaggKi9cbiAgICBwcm90ZWN0ZWQgbmVjZXNzYXJ5QnVuZGxlTGlzdDogc3RyaW5nW10gPSBbXG4gICAgICAgIFwiTWFpblNjZW5lXCJcbiAgICBdO1xuICAgIC8v5a2Q5YyF5Yqg6L2954q25oCBXG4gICAgcHJvdGVjdGVkIGJ1bmRsZUxvYWRTdGF0ZSA9IHt9O1xuICAgIGxvYWRPbmVTdWJwYWNrYWdlKG46IHN0cmluZykge1xuICAgICAgICB0aGlzLmJ1bmRsZUxvYWRTdGF0ZVtuXSA9IHRydWU7XG4gICAgICAgIGZvciAobGV0IGkgPSB0aGlzLm5lY2Vzc2FyeUJ1bmRsZUxpc3QubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5idW5kbGVMb2FkU3RhdGVbdGhpcy5uZWNlc3NhcnlCdW5kbGVMaXN0W2ldXSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLmxvYWRNYWluU2NlbmUoKTtcbiAgICB9XG5cbiAgICBsb2FkTWFpblNjZW5lKCkge1xuICAgICAgICBMb2FkZXIubG9hZEJ1bmRsZVNjZW5lKFwiTWFpblNjZW5lXCIsIFwiTWFpblNjZW5lXCIsIChyZXMpID0+IHtcbiAgICAgICAgICAgIHRoaXMub2ZmRXZlbnRzKCk7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5ydW5TY2VuZShyZXMpO1xuICAgICAgICB9LCBmYWxzZSk7XG4gICAgfVxuXG59Il19