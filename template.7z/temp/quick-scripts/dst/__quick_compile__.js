
(function () {
var scripts = [{"deps":{"./assets/LevelScene/Script/MyLevelManager":64,"./assets/LevelScene/Script/LevelCamera":12,"./assets/LevelScene/Script/LevelManager":52,"./assets/LevelUI/LoseUI/LoseUI":22,"./assets/LevelUI/ResurgenceUI/ResurgenceUI":62,"./assets/LevelUI/PauseLevelUI/PauseLevelUI":60,"./assets/LevelUI/WinUI/WinUI":10,"./assets/LevelUI/WinUI/WinAnim":63,"./assets/LevelUI/LevelInfoUI/LevelInfoUI":61,"./assets/InitScene/Init":5,"./assets/LobbyUI/ConfigSettingUI/ConfigSettingUI":6,"./assets/LobbyUI/ShopUI/ShopUI":54,"./assets/LobbyUI/ShopUI/ShopItem":24,"./assets/LobbyUI/ShopUI/ShopStage":11,"./assets/LobbyUI/ChooseLevelUI/ChooseLevelUI":1,"./assets/MainScene/Script/LevelController":13,"./assets/MainScene/Script/LoadingUI":27,"./assets/MainScene/Script/PlayerAssetBar":25,"./assets/MainScene/Script/TipMessage":28,"./assets/MainScene/Script/GameDirector":7,"./assets/MainScene/Script/GameLobby":30,"./assets/Recommend/Script/RecommendMatrix":26,"./assets/Recommend/Script/RecommendItem":14,"./assets/Recommend/Script/RecommendPrimary":29,"./assets/Recommend/Script/RecommendBanner":55,"./assets/Recommend/Script/RecommendDrawer":2,"./assets/Script/Common/Action3dManager":58,"./assets/Script/Common/CommonEnum":15,"./assets/Script/Common/CommonEventType":57,"./assets/Script/Common/CommonGameConfig":31,"./assets/Script/Common/CryptoJS":66,"./assets/Script/Common/CryptoAes":67,"./assets/Script/Common/EventManager":56,"./assets/Script/Common/GameData":37,"./assets/Script/Common/GlobalPool":33,"./assets/Script/Common/Loader":16,"./assets/Script/Common/PlayerData":3,"./assets/Script/Common/PowerManager":34,"./assets/Script/Common/UIManager":36,"./assets/Script/Common/http_request":65,"./assets/Script/Common/yyComponent":8,"./assets/Script/Common/AudioManager":32,"./assets/Script/GameSpecial/GameEventType":40,"./assets/Script/GameSpecial/GlobalEnum":17,"./assets/Script/GameSpecial/LevelDataTemplate":39,"./assets/Script/GameSpecial/PlayerDataTemplate":46,"./assets/Script/GameSpecial/SkinDataTemplate":42,"./assets/Script/GameSpecial/GameConfig":35,"./assets/Script/Platform/GamePlatformConfig":44,"./assets/Script/Platform/GamePlatformType":41,"./assets/Script/Platform/GamePlatform":45,"./assets/Script/Platform/SDK/PCSDK":20,"./assets/Script/Platform/SDK/QQSDK":59,"./assets/Script/Platform/SDK/SDK":38,"./assets/Script/Platform/SDK/TTSDK":18,"./assets/Script/Platform/SDK/VIVOSDK":4,"./assets/Script/Platform/SDK/WXSDK":9,"./assets/Script/Platform/SDK/OPPOSDK":21,"./assets/Script/Recommend/Recommend":43,"./assets/Script/Recommend/MyAtlasSprite":19,"./assets/Script/Recommend/RecommendConfig":47,"./assets/Script/Recommend/RecommendContainer":48,"./assets/Script/Recommend/RecommendImageManager":50,"./assets/Script/Recommend/RecommendDataManager":49,"./assets/Script/Recommend/RecommendManager":51,"./assets/Script/Recommend/MyAtlas":53,"./assets/Script/ALD/ALDManager":23},"path":"preview-scripts/__qc_index__.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/Common/PlayerData":3,"../../Script/GameSpecial/GameEventType":40,"../../Script/Common/Action3dManager":58,"../../Script/GameSpecial/GlobalEnum":17},"path":"preview-scripts/assets/LobbyUI/ChooseLevelUI/ChooseLevelUI.js"},{"deps":{"../../Script/Recommend/RecommendContainer":48,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/GameSpecial/GameEventType":40,"../../Script/Recommend/RecommendDataManager":49},"path":"preview-scripts/assets/Recommend/Script/RecommendDrawer.js"},{"deps":{"./EventManager":56,"../GameSpecial/PlayerDataTemplate":46,"../GameSpecial/GameConfig":35,"../GameSpecial/GameEventType":40},"path":"preview-scripts/assets/Script/Common/PlayerData.js"},{"deps":{"./SDK":38,"../GamePlatform":45,"../../Common/EventManager":56,"../../GameSpecial/GameEventType":40},"path":"preview-scripts/assets/Script/Platform/SDK/VIVOSDK.js"},{"deps":{"../Script/Common/EventManager":56,"../Script/Platform/GamePlatformType":41,"../Script/GameSpecial/GameEventType":40,"../Script/Platform/GamePlatform":45,"../Script/Common/Loader":16,"../Script/Platform/GamePlatformConfig":44},"path":"preview-scripts/assets/InitScene/Init.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GameConfig":35,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/GameSpecial/GameEventType":40},"path":"preview-scripts/assets/LobbyUI/ConfigSettingUI/ConfigSettingUI.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GameEventType":40,"../../Script/Common/Action3dManager":58,"../../Script/Common/UIManager":36,"../../Script/Recommend/RecommendManager":51,"../../Script/GameSpecial/GameConfig":35,"../../Script/Common/PlayerData":3,"../../Script/Common/GameData":37,"../../Script/Common/AudioManager":32,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/Common/GlobalPool":33,"../../Script/Common/PowerManager":34,"../../Script/Common/Loader":16},"path":"preview-scripts/assets/MainScene/Script/GameDirector.js"},{"deps":{"./EventManager":56},"path":"preview-scripts/assets/Script/Common/yyComponent.js"},{"deps":{"../GamePlatform":45,"./SDK":38,"../../GameSpecial/GameEventType":40,"../../Common/EventManager":56},"path":"preview-scripts/assets/Script/Platform/SDK/WXSDK.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/GameSpecial/GameEventType":40,"../../Script/Common/UIManager":36,"../../Script/Platform/GamePlatform":45,"../../Script/Platform/GamePlatformType":41,"./WinAnim":63},"path":"preview-scripts/assets/LevelUI/WinUI/WinUI.js"},{"deps":{"../../Script/Common/GlobalPool":33,"../../Script/Common/Loader":16,"../../Script/Common/yyComponent":8},"path":"preview-scripts/assets/LobbyUI/ShopUI/ShopStage.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/Common/Action3dManager":58},"path":"preview-scripts/assets/LevelScene/Script/LevelCamera.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GameEventType":40,"../../Script/GameSpecial/GlobalEnum":17},"path":"preview-scripts/assets/MainScene/Script/LevelController.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/Recommend/RecommendDataManager":49,"../../Script/GameSpecial/GameEventType":40,"../../Script/Recommend/MyAtlasSprite":19,"../../Script/Recommend/RecommendImageManager":50},"path":"preview-scripts/assets/Recommend/Script/RecommendItem.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/CommonEnum.js"},{"deps":{"../GameSpecial/GameEventType":40,"./EventManager":56},"path":"preview-scripts/assets/Script/Common/Loader.js"},{"deps":{"../Common/CommonEnum":15},"path":"preview-scripts/assets/Script/GameSpecial/GlobalEnum.js"},{"deps":{"./SDK":38,"../GamePlatform":45,"../../Common/EventManager":56,"../../GameSpecial/GameEventType":40},"path":"preview-scripts/assets/Script/Platform/SDK/TTSDK.js"},{"deps":{},"path":"preview-scripts/assets/Script/Recommend/MyAtlasSprite.js"},{"deps":{"./SDK":38},"path":"preview-scripts/assets/Script/Platform/SDK/PCSDK.js"},{"deps":{"../GamePlatform":45,"./SDK":38,"../../GameSpecial/GameEventType":40,"../../Common/EventManager":56},"path":"preview-scripts/assets/Script/Platform/SDK/OPPOSDK.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/GameSpecial/GameEventType":40,"../../Script/Common/UIManager":36,"../../Script/Platform/GamePlatform":45,"../../Script/Platform/GamePlatformType":41},"path":"preview-scripts/assets/LevelUI/LoseUI/LoseUI.js"},{"deps":{"../Common/yyComponent":8,"../GameSpecial/GameEventType":40},"path":"preview-scripts/assets/Script/ALD/ALDManager.js"},{"deps":{"../../Script/Common/Loader":16,"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GameEventType":40},"path":"preview-scripts/assets/LobbyUI/ShopUI/ShopItem.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GameEventType":40,"../../Script/Common/PlayerData":3,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/Common/GlobalPool":33,"../../Script/Common/Action3dManager":58},"path":"preview-scripts/assets/MainScene/Script/PlayerAssetBar.js"},{"deps":{"../../Script/Recommend/RecommendContainer":48,"../../Script/Recommend/RecommendDataManager":49},"path":"preview-scripts/assets/Recommend/Script/RecommendMatrix.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GameEventType":40},"path":"preview-scripts/assets/MainScene/Script/LoadingUI.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/Common/Action3dManager":58,"../../Script/GameSpecial/GameEventType":40},"path":"preview-scripts/assets/MainScene/Script/TipMessage.js"},{"deps":{"../../Script/Recommend/RecommendContainer":48,"../../Script/Recommend/RecommendDataManager":49,"../../Script/GameSpecial/GlobalEnum":17,"./RecommendItem":14},"path":"preview-scripts/assets/Recommend/Script/RecommendPrimary.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/GameSpecial/GameEventType":40,"../../Script/Common/PlayerData":3},"path":"preview-scripts/assets/MainScene/Script/GameLobby.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/CommonGameConfig.js"},{"deps":{"../GameSpecial/GlobalEnum":17,"./EventManager":56,"../GameSpecial/GameEventType":40,"../GameSpecial/GameConfig":35,"./Loader":16},"path":"preview-scripts/assets/Script/Common/AudioManager.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/GlobalPool.js"},{"deps":{"../GameSpecial/GameEventType":40,"./EventManager":56,"../GameSpecial/GameConfig":35},"path":"preview-scripts/assets/Script/Common/PowerManager.js"},{"deps":{"../Common/CommonGameConfig":31},"path":"preview-scripts/assets/Script/GameSpecial/GameConfig.js"},{"deps":{"../GameSpecial/GameEventType":40,"./Loader":16,"./EventManager":56},"path":"preview-scripts/assets/Script/Common/UIManager.js"},{"deps":{"../GameSpecial/LevelDataTemplate":39,"../GameSpecial/GlobalEnum":17},"path":"preview-scripts/assets/Script/Common/GameData.js"},{"deps":{"../../Common/EventManager":56,"../../GameSpecial/GameEventType":40,"../../GameSpecial/GameConfig":35,"../GamePlatform":45,"../../GameSpecial/GlobalEnum":17},"path":"preview-scripts/assets/Script/Platform/SDK/SDK.js"},{"deps":{},"path":"preview-scripts/assets/Script/GameSpecial/LevelDataTemplate.js"},{"deps":{"../Common/CommonEventType":57},"path":"preview-scripts/assets/Script/GameSpecial/GameEventType.js"},{"deps":{},"path":"preview-scripts/assets/Script/Platform/GamePlatformType.js"},{"deps":{},"path":"preview-scripts/assets/Script/GameSpecial/SkinDataTemplate.js"},{"deps":{"../Common/yyComponent":8,"../Common/GlobalPool":33,"../GameSpecial/GameEventType":40,"./RecommendDataManager":49},"path":"preview-scripts/assets/Script/Recommend/Recommend.js"},{"deps":{"./GamePlatformType":41},"path":"preview-scripts/assets/Script/Platform/GamePlatformConfig.js"},{"deps":{"./GamePlatformConfig":44,"./GamePlatformType":41,"./SDK/SDK":38,"./SDK/OPPOSDK":21,"./SDK/VIVOSDK":4,"./SDK/WXSDK":9,"./SDK/TTSDK":18,"./SDK/QQSDK":59,"./SDK/PCSDK":20},"path":"preview-scripts/assets/Script/Platform/GamePlatform.js"},{"deps":{},"path":"preview-scripts/assets/Script/GameSpecial/PlayerDataTemplate.js"},{"deps":{},"path":"preview-scripts/assets/Script/Recommend/RecommendConfig.js"},{"deps":{"../Common/yyComponent":8,"./RecommendDataManager":49,"../Common/GlobalPool":33,"../GameSpecial/GlobalEnum":17},"path":"preview-scripts/assets/Script/Recommend/RecommendContainer.js"},{"deps":{"../Common/EventManager":56,"./RecommendConfig":47,"../GameSpecial/GameEventType":40,"../Platform/GamePlatform":45,"../Platform/GamePlatformType":41,"../Common/GlobalPool":33,"../Common/Loader":16},"path":"preview-scripts/assets/Script/Recommend/RecommendDataManager.js"},{"deps":{"./MyAtlas":53},"path":"preview-scripts/assets/Script/Recommend/RecommendImageManager.js"},{"deps":{"./RecommendDataManager":49,"./Recommend":43,"./RecommendConfig":47,"../Platform/GamePlatform":45,"../Platform/GamePlatformType":41},"path":"preview-scripts/assets/Script/Recommend/RecommendManager.js"},{"deps":{"../../Script/GameSpecial/GameEventType":40,"../../Script/Common/yyComponent":8,"../../Script/Common/Action3dManager":58,"../../Script/GameSpecial/GlobalEnum":17},"path":"preview-scripts/assets/LevelScene/Script/LevelManager.js"},{"deps":{},"path":"preview-scripts/assets/Script/Recommend/MyAtlas.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/Common/GlobalPool":33,"../../Script/GameSpecial/GameEventType":40,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/Common/Loader":16,"../../Script/Common/PlayerData":3,"./ShopItem":24,"../../Script/Common/GameData":37,"./ShopStage":11},"path":"preview-scripts/assets/LobbyUI/ShopUI/ShopUI.js"},{"deps":{"../../Script/Recommend/RecommendContainer":48,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/Common/GlobalPool":33,"../../Script/Recommend/RecommendDataManager":49},"path":"preview-scripts/assets/Recommend/Script/RecommendBanner.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/EventManager.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/CommonEventType.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/Action3dManager.js"},{"deps":{"./SDK":38,"../GamePlatform":45},"path":"preview-scripts/assets/Script/Platform/SDK/QQSDK.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GameEventType":40,"../../Script/GameSpecial/GlobalEnum":17},"path":"preview-scripts/assets/LevelUI/PauseLevelUI/PauseLevelUI.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GlobalEnum":17,"../../Script/GameSpecial/GameEventType":40},"path":"preview-scripts/assets/LevelUI/LevelInfoUI/LevelInfoUI.js"},{"deps":{"../../Script/Common/yyComponent":8,"../../Script/GameSpecial/GameEventType":40,"../../Script/GameSpecial/GlobalEnum":17},"path":"preview-scripts/assets/LevelUI/ResurgenceUI/ResurgenceUI.js"},{"deps":{"../../Script/Common/GlobalPool":33,"../../Script/Common/Action3dManager":58},"path":"preview-scripts/assets/LevelUI/WinUI/WinAnim.js"},{"deps":{"../../Script/GameSpecial/GlobalEnum":17,"./LevelManager":52,"../../Script/GameSpecial/GameEventType":40,"./LevelCamera":12},"path":"preview-scripts/assets/LevelScene/Script/MyLevelManager.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/http_request.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/CryptoJS.js"},{"deps":{},"path":"preview-scripts/assets/Script/Common/CryptoAes.js"}];
var entries = ["preview-scripts/__qc_index__.js"];
var bundleScript = 'preview-scripts/__qc_bundle__.js';

/**
 * Notice: This file can not use ES6 (for IE 11)
 */
var modules = {};
var name2path = {};

// Will generated by module.js plugin
// var scripts = ${scripts};
// var entries = ${entries};
// var bundleScript = ${bundleScript};

if (typeof global === 'undefined') {
    window.global = window;
}

var isJSB = typeof jsb !== 'undefined';

function getXMLHttpRequest () {
    return window.XMLHttpRequest ? new window.XMLHttpRequest() : new ActiveXObject('MSXML2.XMLHTTP');
}

function downloadText(url, callback) {
    if (isJSB) {
        var result = jsb.fileUtils.getStringFromFile(url);
        callback(null, result);
        return;
    }

    var xhr = getXMLHttpRequest(),
        errInfo = 'Load text file failed: ' + url;
    xhr.open('GET', url, true);
    if (xhr.overrideMimeType) xhr.overrideMimeType('text\/plain; charset=utf-8');
    xhr.onload = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status === 0) {
                callback(null, xhr.responseText);
            }
            else {
                callback({status:xhr.status, errorMessage:errInfo + ', status: ' + xhr.status});
            }
        }
        else {
            callback({status:xhr.status, errorMessage:errInfo + '(wrong readyState)'});
        }
    };
    xhr.onerror = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(error)'});
    };
    xhr.ontimeout = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(time out)'});
    };
    xhr.send(null);
};

function loadScript (src, cb) {
    if (typeof require !== 'undefined') {
        require(src);
        return cb();
    }

    // var timer = 'load ' + src;
    // console.time(timer);

    var scriptElement = document.createElement('script');

    function done() {
        // console.timeEnd(timer);
        // deallocation immediate whatever
        scriptElement.remove();
    }

    scriptElement.onload = function () {
        done();
        cb();
    };
    scriptElement.onerror = function () {
        done();
        var error = 'Failed to load ' + src;
        console.error(error);
        cb(new Error(error));
    };
    scriptElement.setAttribute('type','text/javascript');
    scriptElement.setAttribute('charset', 'utf-8');
    scriptElement.setAttribute('src', src);

    document.head.appendChild(scriptElement);
}

function loadScripts (srcs, cb) {
    var n = srcs.length;

    srcs.forEach(function (src) {
        loadScript(src, function () {
            n--;
            if (n === 0) {
                cb();
            }
        });
    })
}

function formatPath (path) {
    let destPath = window.__quick_compile_project__.destPath;
    if (destPath) {
        let prefix = 'preview-scripts';
        if (destPath[destPath.length - 1] === '/') {
            prefix += '/';
        }
        path = path.replace(prefix, destPath);
    }
    return path;
}

window.__quick_compile_project__ = {
    destPath: '',

    registerModule: function (path, module) {
        path = formatPath(path);
        modules[path].module = module;
    },

    registerModuleFunc: function (path, func) {
        path = formatPath(path);
        modules[path].func = func;

        var sections = path.split('/');
        var name = sections[sections.length - 1];
        name = name.replace(/\.(?:js|ts|json)$/i, '');
        name2path[name] = path;
    },

    require: function (request, path) {
        var m, requestScript;

        path = formatPath(path);
        if (path) {
            m = modules[path];
            if (!m) {
                console.warn('Can not find module for path : ' + path);
                return null;
            }
        }

        if (m) {
            let depIndex = m.deps[request];
            // dependence script was excluded
            if (depIndex === -1) {
                return null;
            }
            else {
                requestScript = scripts[ m.deps[request] ];
            }
        }
        
        let requestPath = '';
        if (!requestScript) {
            // search from name2path when request is a dynamic module name
            if (/^[\w- .]*$/.test(request)) {
                requestPath = name2path[request];
            }

            if (!requestPath) {
                if (CC_JSB) {
                    return require(request);
                }
                else {
                    console.warn('Can not find deps [' + request + '] for path : ' + path);
                    return null;
                }
            }
        }
        else {
            requestPath = formatPath(requestScript.path);
        }

        let requestModule = modules[requestPath];
        if (!requestModule) {
            console.warn('Can not find request module for path : ' + requestPath);
            return null;
        }

        if (!requestModule.module && requestModule.func) {
            requestModule.func();
        }

        if (!requestModule.module) {
            console.warn('Can not find requestModule.module for path : ' + path);
            return null;
        }

        return requestModule.module.exports;
    },

    run: function () {
        entries.forEach(function (entry) {
            entry = formatPath(entry);
            var module = modules[entry];
            if (!module.module) {
                module.func();
            }
        });
    },

    load: function (cb) {
        var self = this;

        var srcs = scripts.map(function (script) {
            var path = formatPath(script.path);
            modules[path] = script;

            if (script.mtime) {
                path += ("?mtime=" + script.mtime);
            }
            return path;
        });

        console.time && console.time('load __quick_compile_project__');
        // jsb can not analysis sourcemap, so keep separate files.
        if (bundleScript && !isJSB) {
            downloadText(formatPath(bundleScript), function (err, bundleSource) {
                console.timeEnd && console.timeEnd('load __quick_compile_project__');
                if (err) {
                    console.error(err);
                    return;
                }

                let evalTime = 'eval __quick_compile_project__ : ' + srcs.length + ' files';
                console.time && console.time(evalTime);
                var sources = bundleSource.split('\n//------QC-SOURCE-SPLIT------\n');
                for (var i = 0; i < sources.length; i++) {
                    if (sources[i]) {
                        window.eval(sources[i]);
                        // not sure why new Function cannot set breakpoints precisely
                        // new Function(sources[i])()
                    }
                }
                self.run();
                console.timeEnd && console.timeEnd(evalTime);
                cb();
            })
        }
        else {
            loadScripts(srcs, function () {
                self.run();
                console.timeEnd && console.timeEnd('load __quick_compile_project__');
                cb();
            });
        }
    }
};

// Polyfill for IE 11
if (!('remove' in Element.prototype)) {
    Element.prototype.remove = function () {
        if (this.parentNode) {
            this.parentNode.removeChild(this);
        }
    };
}
})();
    