"use strict";
cc._RF.push(module, '13584udb5ZFfKHNpwzpXjg2', 'RecommendDrawer');
// Recommend/Script/RecommendDrawer.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendContainer_1 = require("../../Script/Recommend/RecommendContainer");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**抽屉状态 */
var DrawerState;
(function (DrawerState) {
    DrawerState[DrawerState["close"] = 0] = "close";
    DrawerState[DrawerState["open"] = 1] = "open";
    DrawerState[DrawerState["moving"] = 2] = "moving";
})(DrawerState || (DrawerState = {}));
var RecommendDrawer = /** @class */ (function (_super) {
    __extends(RecommendDrawer, _super);
    function RecommendDrawer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.drawer = null; //抽屉
        _this.btnDrawer = null; //抽屉开关按钮
        _this.btnClose = null;
        return _this;
    }
    RecommendDrawer.prototype.init = function (data) {
        this.state = DrawerState.close;
        this.btnClose.active = false;
        // this.openTargetX = 0;//暂设为打开抽屉时移动到屏幕正中间
        var cvs = cc.find("Canvas");
        this.openTargetX = this.drawer.width * this.drawer.anchorX - cvs.width * 0.5;
        this.openDuration = 0.5;
        this.closeDuration = 0.5;
        this.initType();
        this.onEvents();
        if (!!data) {
            this.setData(data);
        }
    };
    RecommendDrawer.prototype.initType = function () {
        this.type = GlobalEnum_1.GlobalEnum.RecommendDrawerType.left;
        this.drawer.x = -0.5 * (this.node.width + this.drawer.width);
        this.closeDis = this.drawer.x - this.openTargetX;
    };
    RecommendDrawer.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.RecommendEvent.openDrawer, this.onBtnDrawer, this);
        this.on(GameEventType_1.EventType.RecommendEvent.closeDrawer, this.onBtnDrawer, this);
    };
    RecommendDrawer.prototype.reset = function () {
        this.state = DrawerState.close;
        this.btnClose.active = false;
    };
    /**
     * 设置抽屉的数据
     * 只记录数据，打开抽屉的时候再添加节点
     * @param data
     * @param [data.type]       抽屉类型,GlobalEnum.RecommendDrawerType枚举值
     * @param [data.itemType]   节点类型，GlobalEnum.RecommendItemType枚举值
     * @param [data.items]      互推游戏的数据数组，包含游戏id，名字，图标文件名等信息
     */
    RecommendDrawer.prototype.setData = function (data) {
        this.data = data;
        this.setType(data.type);
        if (undefined != this.data.scale) {
            this.drawer.setScale(this.data.scale);
        }
        if (undefined != this.data.pos) {
            this.drawer.setPosition(this.data.pos);
        }
        if (!!data.widget) {
            this.setWidget(this.drawer, data.widget);
        }
        if (!!data.btnWidget) {
            this.setWidget(this.btnDrawer, data.btnWidget);
        }
    };
    /**设置抽屉类型 */
    RecommendDrawer.prototype.setType = function (type) {
        this.type = type;
        switch (type) {
            case GlobalEnum_1.GlobalEnum.RecommendDrawerType.left: {
                this.drawer.x = -0.5 * (this.node.width + this.drawer.width);
                break;
            }
            case GlobalEnum_1.GlobalEnum.RecommendDrawerType.right: {
                this.drawer.x = 0.5 * (this.node.width + this.drawer.width);
                break;
            }
            default: {
                this.type = GlobalEnum_1.GlobalEnum.RecommendDrawerType.left;
                this.drawer.x = -0.5 * (this.node.width + this.drawer.width);
                break;
            }
        }
        this.closeDis = this.drawer.x - this.openTargetX;
    };
    RecommendDrawer.prototype.onBtnDrawer = function () {
        switch (this.state) {
            case DrawerState.close: {
                this.openDrawer();
                break;
            }
            case DrawerState.open: {
                this.closeDrawer();
                break;
            }
        }
    };
    /**打开抽屉 */
    RecommendDrawer.prototype.openDrawer = function () {
        this.showMask();
        this.state = DrawerState.moving;
        this.drawer.stopAllActions();
        var items = this.data.items;
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        this.addItems(items, this.data.itemType);
        var action = cc.moveTo(this.openDuration, this.openTargetX, this.drawer.y);
        action.easing(cc.easeOut(2));
        this.drawer.runAction(cc.sequence(action, cc.callFunc(this.onOpenDrawerFinish, this)));
        this.emit(GameEventType_1.EventType.RecommendEvent.drawerStartOpen);
    };
    RecommendDrawer.prototype.onOpenDrawerFinish = function () {
        this.hideMask();
        this.state = DrawerState.open;
        this.btnClose.active = true;
        this.emit(GameEventType_1.EventType.RecommendEvent.drawerOpened);
    };
    /**关闭抽屉 */
    RecommendDrawer.prototype.closeDrawer = function () {
        this.showMask();
        this.state = DrawerState.moving;
        this.drawer.stopAllActions();
        this.drawer.x = this.openTargetX;
        var action = cc.moveBy(this.closeDuration, this.closeDis, 0);
        action.easing(cc.easeIn(2));
        this.drawer.runAction(cc.sequence(action, cc.callFunc(this.onCloseDrawerFinish, this)));
        this.emit(GameEventType_1.EventType.RecommendEvent.drawerStartClose);
    };
    RecommendDrawer.prototype.onCloseDrawerFinish = function () {
        this.resetItems();
        this.hideMask();
        this.state = DrawerState.close;
        this.btnClose.active = false;
        this.emit(GameEventType_1.EventType.RecommendEvent.drawerClosed);
    };
    RecommendDrawer.prototype.showMask = function () {
        this.emit(GameEventType_1.EventType.UIEvent.showTouchMask);
    };
    RecommendDrawer.prototype.hideMask = function () {
        this.emit(GameEventType_1.EventType.UIEvent.hideTouchMask);
    };
    __decorate([
        property(cc.Node)
    ], RecommendDrawer.prototype, "drawer", void 0);
    __decorate([
        property(cc.Node)
    ], RecommendDrawer.prototype, "btnDrawer", void 0);
    __decorate([
        property(cc.Node)
    ], RecommendDrawer.prototype, "btnClose", void 0);
    RecommendDrawer = __decorate([
        ccclass
    ], RecommendDrawer);
    return RecommendDrawer;
}(RecommendContainer_1.default));
exports.default = RecommendDrawer;

cc._RF.pop();