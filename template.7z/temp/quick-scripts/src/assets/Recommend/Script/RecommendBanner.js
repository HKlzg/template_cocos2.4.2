"use strict";
cc._RF.push(module, '69bd8zPrktOy6RlO57J+sx7', 'RecommendBanner');
// Recommend/Script/RecommendBanner.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendContainer_1 = require("../../Script/Recommend/RecommendContainer");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
//水平滚动显示的互推列表
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecommendBanner = /** @class */ (function (_super) {
    __extends(RecommendBanner, _super);
    function RecommendBanner() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**容器节点 */
        _this.banner = null;
        /**显示互推列表的容器的布局组件 */
        _this.bannerWidget = null;
        /**列表的父节点，带cc.Mask组件 */
        _this.maskNode = null;
        /**朝一个方向循环滚动时需要的列表节点的副本 */
        _this.content_copy = null;
        return _this;
    }
    RecommendBanner.prototype.init = function (data) {
        this.scrollSpd = 50;
        this.onEvents();
        if (!!data) {
            this.setData(data);
            this.startScroll();
        }
    };
    RecommendBanner.prototype.reset = function () {
        this.clearContent_copy();
        this.content.stopAllActions();
        this.resetItems();
    };
    RecommendBanner.prototype.reuse = function (data) {
        this.node.active = true;
        this.reset();
        this.setData(data);
        this.startScroll();
    };
    RecommendBanner.prototype.unuse = function () {
        this.reset();
        this.unschedule(this.startScroll);
    };
    /**
   * 设置组件数据
   * @param data
   * @param [data.type]       组件类型枚举值
   * @param [data.itemType]   互推节点类型枚举值
   * @param [data.items]      互推节点数据数组
   */
    RecommendBanner.prototype.setData = function (data) {
        this.data = data;
        var items = data.items;
        //默认使用全部互推数据
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        this.addItems(items, data.itemType);
        this.content.getComponent(cc.Layout).updateLayout();
        this.setType(data.type);
        this.setBannerPos();
    };
    /**设置坐标 */
    RecommendBanner.prototype.setBannerPos = function () {
        if (undefined != this.data.scale) {
            this.banner.setScale(this.data.scale);
        }
        if (undefined != this.data.pos) {
            this.banner.setPosition(this.data.pos);
        }
        if (undefined != this.data.widget) {
            this.setWidget(this.banner, this.data.widget);
        }
    };
    /**设置banner类型 */
    RecommendBanner.prototype.setType = function (type) {
        this.type = type;
        switch (type) {
            case GlobalEnum_1.GlobalEnum.RecommendBannerType.pingpong: {
                this.clearContent_copy();
                break;
            }
            case GlobalEnum_1.GlobalEnum.RecommendBannerType.left: {
                this.setContent_copy();
                break;
            }
        }
    };
    /**开始自动滚动显示列表 */
    RecommendBanner.prototype.startScroll = function () {
        this.scheduleOnce(this.autoScroll, 0);
    };
    RecommendBanner.prototype.autoScroll = function () {
        switch (this.type) {
            case GlobalEnum_1.GlobalEnum.RecommendBannerType.pingpong: {
                this.scrollPingPongReverse();
                break;
            }
            case GlobalEnum_1.GlobalEnum.RecommendBannerType.left: {
                this.scheduleOnce(this.scrollLeft, 0);
                break;
            }
        }
    };
    /**来回循环滚动 */
    RecommendBanner.prototype.scrollPingPongReverse = function () {
        this.content.stopAllActions();
        this.content.x = 0;
        var len = this.content.width;
        var width = this.maskNode.width;
        var dis = len - width;
        if (dis <= 0)
            return;
        var duration = dis / this.scrollSpd;
        var ping = cc.moveBy(duration, -dis, 0);
        var pong = cc.moveBy(duration, dis, 0);
        this.content.runAction(cc.repeatForever(cc.sequence(ping, pong)));
    };
    /**永远向左滚动 */
    RecommendBanner.prototype.scrollLeft = function () {
        this.content.stopAllActions();
        this.content.x = 0;
        this.moveToLeftHalf(this.content);
        this.content_copy.stopAllActions();
        this.content_copy.x = this.content.width;
        this.moveToLeftRepeat(this.content_copy);
    };
    RecommendBanner.prototype.moveToLeftRepeat = function (node) {
        var dis = node.width;
        var duration = 2 * dis / this.scrollSpd;
        var move = cc.moveBy(duration, -dis * 2, 0);
        var recover = cc.moveTo(0, dis, 0);
        node.runAction(cc.repeatForever(cc.sequence(move, recover)));
    };
    RecommendBanner.prototype.moveToLeftHalf = function (node) {
        var dis = node.width;
        var duration = dis / this.scrollSpd;
        var move = cc.moveBy(duration, -dis, 0);
        node.runAction(cc.sequence(move, cc.callFunc(this.onMoveToLeftHalfFinish, this, node)));
    };
    RecommendBanner.prototype.onMoveToLeftHalfFinish = function (node) {
        node.x = node.width;
        this.moveToLeftRepeat(node);
    };
    /**创建列表节点的副本 */
    RecommendBanner.prototype.setContent_copy = function () {
        this.clearContent_copy();
        var items = this.data.items;
        //默认使用全部互推数据
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        for (var i = 0, count = items.length; i < count; ++i) {
            var item = this.getItem(this.data.itemType, items[i]);
            this.content_copy.addChild(item);
        }
        this.content_copy.getComponent(cc.Layout).updateLayout();
    };
    /**移除列表节点的副本 */
    RecommendBanner.prototype.clearContent_copy = function () {
        this.content_copy.stopAllActions();
        GlobalPool_1.default.putAllChildren(this.content_copy);
    };
    //关闭节点
    RecommendBanner.prototype.onBtnClose = function () {
        this.node.active = false;
    };
    __decorate([
        property(cc.Node)
    ], RecommendBanner.prototype, "banner", void 0);
    __decorate([
        property(cc.Widget)
    ], RecommendBanner.prototype, "bannerWidget", void 0);
    __decorate([
        property(cc.Node)
    ], RecommendBanner.prototype, "maskNode", void 0);
    __decorate([
        property(cc.Node)
    ], RecommendBanner.prototype, "content_copy", void 0);
    RecommendBanner = __decorate([
        ccclass
    ], RecommendBanner);
    return RecommendBanner;
}(RecommendContainer_1.default));
exports.default = RecommendBanner;

cc._RF.pop();