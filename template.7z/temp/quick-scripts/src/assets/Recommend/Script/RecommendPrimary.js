"use strict";
cc._RF.push(module, '9bb1cZVwklInqSmpbVoh3e6', 'RecommendPrimary');
// Recommend/Script/RecommendPrimary.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendItem_1 = require("./RecommendItem");
var RecommendContainer_1 = require("../../Script/Recommend/RecommendContainer");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
//互推-主推，单个的互推节点分散在界面四周显示的互推组件
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecommendPrimary = /** @class */ (function (_super) {
    __extends(RecommendPrimary, _super);
    function RecommendPrimary() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    //添加互推游戏节点
    RecommendPrimary.prototype.addItems = function (data, type) {
        if (type === void 0) { type = GlobalEnum_1.GlobalEnum.RecommendItemType.normal; }
        var ids = [].concat(RecommendDataManager_1.default.getAllRecommendData());
        var needScale = data.length > 2;
        for (var i = 0, count = data.length; i < count; ++i) {
            // let id = data[i].id;
            var id = i;
            if (id >= ids.length) {
                var index = Math.round(Math.random() * (ids.length - 1));
                id = ids[index].id;
                ids.splice(index, 1);
            }
            var item = this.getItem(type, id);
            this.content.addChild(item);
            if (needScale) {
                item.setScale(0.7, 0.7);
            }
            if (!!data[i].scale) {
                item.setScale(data[i].scale);
            }
            if (!!data[i].pos) {
                item.setPosition(data[i].pos);
            }
            this.setWidget(item, data[i].widget);
        }
    };
    RecommendPrimary.prototype.setData = function (data) {
        var items = data.items;
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        this.addItems(items);
        //自动轮播
        if (undefined === data.autoUpdate || !!data.autoUpdate) {
            this.autoUpdateItem();
        }
    };
    RecommendPrimary.prototype.unuse = function () {
        this.reset();
        this.stopUpdateItem();
    };
    /**启动自动轮播 */
    RecommendPrimary.prototype.autoUpdateItem = function () {
        this.schedule(this.updateItems, 3);
    };
    RecommendPrimary.prototype.stopUpdateItem = function () {
        this.unschedule(this.updateItems);
    };
    /**更新主推内容(轮播) */
    RecommendPrimary.prototype.updateItems = function () {
        var count = this.content.childrenCount;
        var ids = RecommendDataManager_1.default.getAllRecommendData();
        var index = this.content.children[count - 1].getComponent(RecommendItem_1.default).getRecommendId();
        for (var i = 0; i < count; ++i) {
            index += 1;
            if (index >= ids.length) {
                index = 0;
            }
            this.content.children[i].getComponent(RecommendItem_1.default).setData(ids[index]);
        }
    };
    RecommendPrimary = __decorate([
        ccclass
    ], RecommendPrimary);
    return RecommendPrimary;
}(RecommendContainer_1.default));
exports.default = RecommendPrimary;

cc._RF.pop();