"use strict";
cc._RF.push(module, '0f711Q689tAopW3Al+kx54X', 'RecommendMatrix');
// Recommend/Script/RecommendMatrix.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendContainer_1 = require("../../Script/Recommend/RecommendContainer");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
//互推矩阵
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecommendMatrix = /** @class */ (function (_super) {
    __extends(RecommendMatrix, _super);
    function RecommendMatrix() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.matrix = null;
        return _this;
    }
    RecommendMatrix.prototype.setData = function (data) {
        if (!!data.scale) {
            this.matrix.setScale(data.scale);
        }
        if (!!data.pos) {
            this.matrix.setPosition(data.pos);
        }
        if (!!data.widget) {
            this.setWidget(this.matrix, data.widget);
        }
        var items = data.items;
        //默认使用全部互推数据
        if (!items) {
            items = [].concat(RecommendDataManager_1.default.getAllRecommendData());
            if (items.length > 8) {
                items.length = 8;
            }
        }
        this.addItems(items, data.itemType);
    };
    __decorate([
        property(cc.Node)
    ], RecommendMatrix.prototype, "matrix", void 0);
    RecommendMatrix = __decorate([
        ccclass
    ], RecommendMatrix);
    return RecommendMatrix;
}(RecommendContainer_1.default));
exports.default = RecommendMatrix;

cc._RF.pop();