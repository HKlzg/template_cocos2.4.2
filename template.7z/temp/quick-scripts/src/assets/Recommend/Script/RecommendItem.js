"use strict";
cc._RF.push(module, 'd1ce16euR1GAq5K0MAlolRv', 'RecommendItem');
// Recommend/Script/RecommendItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var RecommendDataManager_1 = require("../../Script/Recommend/RecommendDataManager");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var RecommendImageManager_1 = require("../../Script/Recommend/RecommendImageManager");
var MyAtlasSprite_1 = require("../../Script/Recommend/MyAtlasSprite");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * 推荐游戏节点
 */
var RecommendItem = /** @class */ (function (_super) {
    __extends(RecommendItem, _super);
    function RecommendItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.gameIcon = null; //游戏图标
        _this.gameName = null; //游戏名称
        return _this;
    }
    /**互推数据id */
    RecommendItem.prototype.getRecommendId = function () { return this.recommendId; };
    RecommendItem.prototype.init = function (data) {
        this.node.setPosition(0, 0);
        this.node.setScale(1, 1);
        this.onEvents();
        if (undefined !== data) {
            this.setData(data);
        }
    };
    RecommendItem.prototype.onEvents = function () {
        this.node.on("touchend", this.onClick, this);
    };
    RecommendItem.prototype.reset = function () {
        this.node.setPosition(0, 0);
        this.node.setScale(1, 1);
        var wg = this.node.getComponent(cc.Widget);
        if (!!wg) {
            wg.isAbsoluteBottom = false;
            wg.isAbsoluteLeft = false;
            wg.isAbsoluteRight = false;
            wg.isAbsoluteTop = false;
        }
    };
    RecommendItem.prototype.reuse = function (data) {
        this.reset();
        this.setData(data);
    };
    RecommendItem.prototype.unuse = function () {
    };
    RecommendItem.prototype.setData = function (data) {
        var recommendData;
        if (typeof data === "number") {
            if (this.recommendId === data)
                return;
            recommendData = RecommendDataManager_1.default.getRecommendData(data);
        }
        else {
            if (this.recommendId === data.id)
                return;
            recommendData = data;
        }
        this.recommendId = recommendData.id;
        //与已有数据相同时不需要再次设置
        //图标
        this.setGameIcon(recommendData.gameIcon);
        //名字
        this.setGameName(recommendData.gameName);
    };
    RecommendItem.prototype.setGameIcon = function (gameIcon) {
        //本地图片：
        // this.gameIcon.getComponent(cc.Sprite).spriteFrame = RecommendDataManager.getGameIcon(gameIcon);
        var _this = this;
        //远程地址图片
        RecommendImageManager_1.default.load(gameIcon, function (data) {
            data.width = _this.node.width;
            data.height = _this.node.height;
            _this.gameIcon.getComponent(MyAtlasSprite_1.default).setAtlasData(data);
        });
    };
    RecommendItem.prototype.setGameName = function (n) {
        this.gameName.string = n;
    };
    //点击节点
    RecommendItem.prototype.onClick = function () {
        this.emit(GameEventType_1.EventType.RecommendEvent.clickRecommendItem, this.recommendId);
    };
    __decorate([
        property(cc.Node)
    ], RecommendItem.prototype, "gameIcon", void 0);
    __decorate([
        property(cc.Label)
    ], RecommendItem.prototype, "gameName", void 0);
    RecommendItem = __decorate([
        ccclass
    ], RecommendItem);
    return RecommendItem;
}(yyComponent_1.default));
exports.default = RecommendItem;

cc._RF.pop();