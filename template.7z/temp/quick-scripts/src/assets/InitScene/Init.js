"use strict";
cc._RF.push(module, '4805ccI48pCd6oESz6VFiBg', 'Init');
// InitScene/Init.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GamePlatformType_1 = require("../Script/Platform/GamePlatformType");
var EventManager_1 = require("../Script/Common/EventManager");
var GameEventType_1 = require("../Script/GameSpecial/GameEventType");
var GamePlatform_1 = require("../Script/Platform/GamePlatform");
var GamePlatformConfig_1 = require("../Script/Platform/GamePlatformConfig");
var Loader_1 = require("../Script/Common/Loader");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Init = /** @class */ (function (_super) {
    __extends(Init, _super);
    function Init() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = GamePlatformType_1.GamePlatformType.PC;
        _this.platformConfig = null;
        _this.bar = null;
        _this.totalLength = 0;
        /**所有资源包都可记录在本数组中，用于预加载，可尽量将更早需要使用的资源包放在更前 */
        _this.preBundleList = [
            "GameData",
            "Audio",
            "LobbyUI",
            "LevelScene",
            "LevelUI",
            "Skin",
        ];
        /**进入主场景前必须加载完成的子包列表 */
        _this.necessaryBundleList = [
            "MainScene"
        ];
        //子包加载状态
        _this.bundleLoadState = {};
        return _this;
    }
    Init.prototype.initProgressBar = function () {
        if (this.totalLength == 0) {
            this.totalLength = this.bar.getComponent(cc.Sprite).spriteFrame.getOriginalSize().width;
        }
        this.bar.setPosition(-0.5 * this.totalLength, this.bar.y);
        this.bar.width = 0;
    };
    Init.prototype.onUpdateProgress = function (rate) {
        this.bar.width = this.totalLength * rate;
    };
    Init.prototype.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.LoadAssetEvent.updateProgress, this.onUpdateProgress, this);
    };
    Init.prototype.offEvents = function () {
        EventManager_1.default.off(GameEventType_1.EventType.LoadAssetEvent.updateProgress, this.onUpdateProgress, this);
    };
    Init.prototype.onLoad = function () {
        cc.game.addPersistRootNode(this.platformConfig);
        var js = this.findConfig();
        GamePlatform_1.default.instance.init(js);
        this.initProgressBar();
        this.onEvents();
    };
    Init.prototype.findConfig = function () {
        var nodes = this.platformConfig.children;
        for (var i = nodes.length - 1; i >= 0; --i) {
            var js = nodes[i].getComponent(GamePlatformConfig_1.default);
            if (js.type == this.type) {
                return js;
            }
            else {
                nodes[i].removeFromParent();
                nodes[i].destroy();
            }
        }
        console.error("没有设置对应平台的配置！");
        return null;
    };
    Init.prototype.start = function () {
        var _this = this;
        var _loop_1 = function (i) {
            Loader_1.default.loadSubpackage(this_1.necessaryBundleList[i], function () {
                _this.loadOneSubpackage(_this.necessaryBundleList[i]);
            }, true);
        };
        var this_1 = this;
        //加载进入主场景前必需的资源包
        for (var i = this.necessaryBundleList.length - 1; i >= 0; --i) {
            _loop_1(i);
        }
        //预加载其他资源包
        for (var i = 0, c = this.preBundleList.length; i < c; ++i) {
            Loader_1.default.loadBundle(this.preBundleList[i], null, false, false);
        }
    };
    Init.prototype.loadOneSubpackage = function (n) {
        this.bundleLoadState[n] = true;
        for (var i = this.necessaryBundleList.length - 1; i >= 0; --i) {
            if (!this.bundleLoadState[this.necessaryBundleList[i]]) {
                return;
            }
        }
        this.loadMainScene();
    };
    Init.prototype.loadMainScene = function () {
        var _this = this;
        Loader_1.default.loadBundleScene("MainScene", "MainScene", function (res) {
            _this.offEvents();
            cc.director.runScene(res);
        }, false);
    };
    __decorate([
        property({ type: cc.Enum(GamePlatformType_1.GamePlatformType) })
    ], Init.prototype, "type", void 0);
    __decorate([
        property(cc.Node)
    ], Init.prototype, "platformConfig", void 0);
    __decorate([
        property(cc.Node)
    ], Init.prototype, "bar", void 0);
    __decorate([
        property
    ], Init.prototype, "totalLength", void 0);
    Init = __decorate([
        ccclass
    ], Init);
    return Init;
}(cc.Component));
exports.default = Init;

cc._RF.pop();