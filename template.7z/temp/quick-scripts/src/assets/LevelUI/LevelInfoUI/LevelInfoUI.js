"use strict";
cc._RF.push(module, '4393ap5mKNKOIGdbWF8MM3a', 'LevelInfoUI');
// LevelUI/LevelInfoUI/LevelInfoUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
//关卡进度分数等信息UI
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LevelInfoUI = /** @class */ (function (_super) {
    __extends(LevelInfoUI, _super);
    function LevelInfoUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /****************************************管理对象****************************************/
        //#region 关卡进度
        _this.curLevelLabel = null;
        _this.nextLevelLabel = null;
        //关卡进度
        _this.levelProgressBar = null;
        //#endregion
        //#region 金币
        _this.curGoldLabel = null;
        _this.curGold = 0;
        return _this;
    }
    Object.defineProperty(LevelInfoUI.prototype, "uiType", {
        get: function () { return GlobalEnum_1.GlobalEnum.UI.levelInfo; },
        enumerable: false,
        configurable: true
    });
    LevelInfoUI.prototype.init = function () {
        this.initCurGold();
        this.initComponents();
        this.initProgress();
        this.onEvents();
    };
    LevelInfoUI.prototype.onEvents = function () {
    };
    LevelInfoUI.prototype.reset = function () {
        this.resetCurGold();
        this.resetProgress();
    };
    LevelInfoUI.prototype.show = function (levelData) {
        this.node.active = true;
        this.reset();
        this.setData(levelData);
    };
    LevelInfoUI.prototype.hide = function () {
        this.reset();
        this.node.active = false;
    };
    LevelInfoUI.prototype.getData = function () {
        return {
            speGold: 0,
            gold: this.curGold,
        };
    };
    LevelInfoUI.prototype.setData = function (data) {
        if (!!this.curLevelLabel)
            this.curLevelLabel.string = data.lv.toString();
        if (!!this.nextLevelLabel)
            this.nextLevelLabel.string = (data.lv + 1).toString();
    };
    LevelInfoUI.prototype.convertToString = function (v) {
        if (v < 1100)
            return v.toString();
        if (v < 1100000)
            return (v * 0.001).toFixed(1) + "K";
        return (v * 0.000001).toFixed(1) + "M";
    };
    LevelInfoUI.prototype.initProgress = function () {
        if (!!this.levelProgressBar)
            this.levelProgressBar.progress = 0;
    };
    LevelInfoUI.prototype.resetProgress = function () {
        if (!!this.levelProgressBar)
            this.levelProgressBar.progress = 0;
    };
    LevelInfoUI.prototype.setProgress = function (r) {
        if (!!this.levelProgressBar)
            this.levelProgressBar.progress = r;
    };
    LevelInfoUI.prototype.initCurGold = function () {
        this.curGold = 0;
        this.curGoldLabel.string = this.curGold.toString();
    };
    LevelInfoUI.prototype.resetCurGold = function () {
        this.curGold = 0;
        this.curGoldLabel.string = this.curGold.toString();
    };
    LevelInfoUI.prototype.addCurGold = function (v) {
        this.curGold += v;
        this.curGoldLabel.string = this.curGold.toString();
    };
    LevelInfoUI.prototype.onPlayerCollGold = function (count) {
        this.addCurGold(1);
    };
    //#endregion
    /**设置按钮 */
    LevelInfoUI.prototype.onBtnConfigSetting = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.UIEvent.enter, GlobalEnum_1.GlobalEnum.UI.configSetting);
    };
    /**暂停按钮 */
    LevelInfoUI.prototype.onBtnPause = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.UIEvent.enter, GlobalEnum_1.GlobalEnum.UI.pauseLevel);
    };
    //测试用：重置关卡
    LevelInfoUI.prototype.onBtnReplay = function () {
        this.emit(GameEventType_1.EventType.DirectorEvent.replayCurLevel);
    };
    //测试用：返回首页
    LevelInfoUI.prototype.onBtnLobby = function () {
        this.emit(GameEventType_1.EventType.DirectorEvent.enterLobby);
    };
    LevelInfoUI.prototype.onBtnWin = function () {
        this.emit(GameEventType_1.EventType.LevelEvent.testWin);
    };
    LevelInfoUI.prototype.onBtnLose = function () {
        this.emit(GameEventType_1.EventType.LevelEvent.testLose);
    };
    __decorate([
        property(cc.Label)
    ], LevelInfoUI.prototype, "curLevelLabel", void 0);
    __decorate([
        property(cc.Label)
    ], LevelInfoUI.prototype, "nextLevelLabel", void 0);
    __decorate([
        property(cc.ProgressBar)
    ], LevelInfoUI.prototype, "levelProgressBar", void 0);
    __decorate([
        property(cc.Label)
    ], LevelInfoUI.prototype, "curGoldLabel", void 0);
    LevelInfoUI = __decorate([
        ccclass
    ], LevelInfoUI);
    return LevelInfoUI;
}(yyComponent_1.default));
exports.default = LevelInfoUI;

cc._RF.pop();