"use strict";
cc._RF.push(module, 'd8843No3IJGf4jWUiXUAgX3', 'WinUI');
// LevelUI/WinUI/WinUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var UIManager_1 = require("../../Script/Common/UIManager");
var GamePlatform_1 = require("../../Script/Platform/GamePlatform");
var GamePlatformType_1 = require("../../Script/Platform/GamePlatformType");
var WinAnim_1 = require("./WinAnim");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WinUI = /** @class */ (function (_super) {
    __extends(WinUI, _super);
    function WinUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bg = null;
        _this.winAnim = null;
        //关卡奖励的金币    
        /**显示关卡奖励的金币的节点层 */
        _this.levelGoldLayer = null;
        _this.goldLabel = null;
        _this.baseGold = 0;
        _this.speGold = 0;
        //视频与普通领取分开的方案：
        /**单倍领取 */
        _this.btnGetAwardSingle = null;
        /**视频领取 */
        _this.btnVideo = null;
        /**下一关按钮 */
        _this.btnNextLevel = null;
        _this.btnLobby = null;
        //头条分享录屏
        _this.btnShareVideo = null;
        _this.shareGold = null;
        /**分享录屏奖励的金币量 */
        _this.shareVideoAwardGold = 100;
        return _this;
    }
    Object.defineProperty(WinUI.prototype, "uiType", {
        /**场景/UI类型 */
        get: function () { return GlobalEnum_1.GlobalEnum.UI.winUI; },
        enumerable: false,
        configurable: true
    });
    WinUI.prototype.reset = function () {
        this.hideBtnGetAward();
        this.hideBtnLobby();
        this.hideBtnShareVideo();
        this.hideLevelGold();
    };
    /**
     * 显示UI
     * @param data 关卡成绩
     */
    WinUI.prototype.show = function (data) {
        this.reset();
        if (undefined === data) {
            var ui = UIManager_1.default.getUI(GlobalEnum_1.GlobalEnum.UI.levelInfo);
            data = ui.getData();
        }
        this.node.active = true;
        this.setData(data);
        this.winAnim.play(this.onWinAnimFinished.bind(this));
    };
    WinUI.prototype.onWinAnimFinished = function () {
        this.emit(GameEventType_1.EventType.SDKEvent.stopRecord);
        this.stepShowBtnGetAward();
    };
    WinUI.prototype.stepShowBtnGetAward = function () {
        this.showBtnShareVideo();
        this.showBtnGetAward();
        this.showLevelGold();
    };
    WinUI.prototype.stepShowBtnLobby = function () {
        this.showBtnLobby();
    };
    /**显示分享录屏按钮 */
    WinUI.prototype.showBtnShareVideo = function () {
        if (!this.btnShareVideo)
            return false;
        if (GamePlatform_1.default.instance.Config.type != GamePlatformType_1.GamePlatformType.TT)
            return false;
        if (!!this.shareGold) {
            this.shareGold.node.parent.active = true;
            this.shareGold.string = "+" + this.shareVideoAwardGold;
        }
        this.btnShareVideo.active = true;
        return true;
    };
    /**隐藏分享录屏按钮 */
    WinUI.prototype.hideBtnShareVideo = function () {
        if (!!this.shareGold)
            this.shareGold.node.parent.active = false;
        if (!!this.btnShareVideo) {
            // this.btnShareVideo.stopAllActions();
            this.btnShareVideo.active = false;
        }
    };
    /**显示领取奖励按钮 */
    WinUI.prototype.showBtnGetAward = function () {
        if (!!this.btnGetAwardSingle)
            this.btnGetAwardSingle.active = true;
        if (!!this.btnVideo)
            this.btnVideo.active = true;
    };
    /**隐藏领取奖励按钮 */
    WinUI.prototype.hideBtnGetAward = function () {
        if (!!this.btnGetAwardSingle)
            this.btnGetAwardSingle.active = false;
        if (!!this.btnVideo)
            this.btnVideo.active = false;
    };
    /**显示关卡金币奖励 */
    WinUI.prototype.showLevelGold = function () {
        if (!!this.levelGoldLayer)
            this.levelGoldLayer.active = true;
    };
    /**隐藏关卡金币奖励 */
    WinUI.prototype.hideLevelGold = function () {
        if (!!this.levelGoldLayer)
            this.levelGoldLayer.active = false;
    };
    //返回、下一关等按钮
    WinUI.prototype.showBtnLobby = function () {
        if (!!this.btnNextLevel)
            this.btnNextLevel.active = true;
        if (!!this.btnLobby)
            this.btnLobby.active = true;
    };
    WinUI.prototype.hideBtnLobby = function () {
        if (!!this.btnNextLevel)
            this.btnNextLevel.active = false;
        if (!!this.btnLobby)
            this.btnLobby.active = false;
    };
    WinUI.prototype.hide = function () {
        this.node.active = false;
    };
    WinUI.prototype.setData = function (data) {
        this.data = data;
        this.baseGold = data.gold;
        this.goldLabel.string = (this.baseGold + this.speGold).toString();
    };
    WinUI.prototype.getTotalGold = function () {
        return this.baseGold + this.speGold;
    };
    //视频三倍
    WinUI.prototype.onBtnVideo = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, this.onVideoFinish.bind(this));
    };
    WinUI.prototype.onVideoFinish = function () {
        this.hideLevelGold();
        this.addGold(this.getTotalGold() * 3, this.onGetGoldFinish.bind(this));
    };
    //普通领取
    WinUI.prototype.onBtnGetGold = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.hideLevelGold();
        this.addGold(this.getTotalGold(), this.onGetGoldFinish.bind(this));
    };
    //返回首页
    WinUI.prototype.onBtnLobby = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.DirectorEvent.enterLobby);
    };
    /**下一关 */
    WinUI.prototype.onBtnNextLevel = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.DirectorEvent.playNextLevel);
        // this.emit(EventType.DirectorEvent.enterLobby);
    };
    //金币领取完成后显示下一关和返回首页按钮
    WinUI.prototype.onGetGoldFinish = function () {
        this.hideLevelGold();
        this.hideBtnGetAward();
        this.stepShowBtnLobby();
    };
    /**设置按钮坐标为常规状态 */
    WinUI.prototype.setBtnsPosNormal = function () {
        // this.btnNextLevel.y = 310 + this.btnNextLevel.height * this.btnNextLevel.anchorY - this.node.height * this.node.anchorY;
    };
    /**播放金币动画获得金币 */
    WinUI.prototype.addGold = function (gold, cb) {
        var _this = this;
        var pos = this.levelGoldLayer.convertToWorldSpaceAR(cc.v2());
        var cvs = cc.find("Canvas");
        pos.x -= cvs.width * 0.5;
        pos.y -= cvs.height * 0.5;
        this.emit(GameEventType_1.EventType.UIEvent.playGoldAnim, {
            startPos: pos,
            cb: function () {
                _this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
                    attribute: "gameData.asset.gold",
                    value: gold,
                    mode: "+"
                });
                !!cb && cb();
            },
            gold: gold,
        });
    };
    //头条平台录屏分享
    WinUI.prototype.onBtnShareVideo = function () {
        this.emit(GameEventType_1.EventType.SDKEvent.shareRecord, this.onShareVideoFinish.bind(this), this.onShareVideoFail.bind(this));
    };
    WinUI.prototype.onShareVideoFinish = function () {
        this.hideBtnShareVideo();
        // this.addGold(this.shareVideoAwardGold);
        this.emit(GameEventType_1.EventType.AssetEvent.getPower, 2);
        this.emit(GameEventType_1.EventType.UIEvent.showTip, "分享成功，获得体力奖励！");
    };
    WinUI.prototype.onShareVideoFail = function () {
    };
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "bg", void 0);
    __decorate([
        property(WinAnim_1.default)
    ], WinUI.prototype, "winAnim", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "levelGoldLayer", void 0);
    __decorate([
        property(cc.Label)
    ], WinUI.prototype, "goldLabel", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnGetAwardSingle", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnVideo", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnNextLevel", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnLobby", void 0);
    __decorate([
        property(cc.Node)
    ], WinUI.prototype, "btnShareVideo", void 0);
    __decorate([
        property(cc.Label)
    ], WinUI.prototype, "shareGold", void 0);
    WinUI = __decorate([
        ccclass
    ], WinUI);
    return WinUI;
}(yyComponent_1.default));
exports.default = WinUI;

cc._RF.pop();