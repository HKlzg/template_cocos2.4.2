"use strict";
cc._RF.push(module, '2c9f1wU97FCOJH/XExKCKoF', 'WinAnim');
// LevelUI/WinUI/WinAnim.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WinAnim = /** @class */ (function (_super) {
    __extends(WinAnim, _super);
    function WinAnim() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.prefab = null;
        _this.imgs = [];
        _this.minScale = 0.5;
        _this.maxScale = 2;
        _this.minAngle = 0;
        _this.maxAngle = 180;
        _this.minSkew = 0;
        _this.maxSkew = 5;
        _this.duration = 1;
        _this.minSpd = 1500;
        _this.maxSpd = 2500;
        _this.gravity = -3000;
        _this.count = 100;
        _this.particles = [];
        _this.index = 0;
        _this.finishCallFun = null;
        return _this;
    }
    WinAnim.prototype.addItem = function () {
        this.index++;
        if (this.index >= this.imgs.length) {
            this.index = 0;
        }
        var node = GlobalPool_1.default.get(this.prefab.name);
        node.getComponent(cc.Sprite).spriteFrame = this.imgs[this.index];
        var scale = this.randomScope(this.minScale, this.maxScale);
        var angle = this.randomScope(this.minAngle, this.maxAngle);
        node.setScale(scale);
        node.angle = angle;
        var duration = this.duration;
        var scale1 = Action3dManager_1.default.scaleTo(duration, this.randomScope(this.minScale, this.maxScale), this.randomScope(this.minScale, this.maxScale), 1);
        var rotate1 = Action3dManager_1.default.rotateTo2d(duration, this.randomScope(this.minAngle, this.maxAngle));
        var spawn = Action3dManager_1.default.spawn(scale1, rotate1);
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).runAction(node, spawn);
        var v = cc.v2();
        var spd = this.minSpd + Math.random() * (this.maxSpd - this.minSpd);
        var radian = (Math.random() * 0.5 + 0.25) * 3.14;
        v.x = spd * Math.cos(radian);
        v.y = spd * Math.sin(radian);
        this.particles.push(new Particle(node, v, this.gravity));
        node.setPosition(0, 0);
        this.node.addChild(node);
    };
    WinAnim.prototype.randomScope = function (min, max) {
        return min + Math.random() * (max - min);
    };
    WinAnim.prototype.play = function (cb) {
        if (!!cb)
            this.finishCallFun = cb;
        var c = this.count;
        GlobalPool_1.default.createPool(this.prefab.name, this.prefab);
        GlobalPool_1.default.preCreate(this.prefab.name, c);
        for (var i = 0; i < this.count; ++i) {
            this.addItem();
        }
        this.schedule(this.step, 0.016);
    };
    WinAnim.prototype.step = function () {
        var dt = 0.016;
        for (var i = this.particles.length - 1; i >= 0; --i) {
            this.particles[i].update(dt);
            if (this.particles[i].finished) {
                GlobalPool_1.default.put(this.particles[i].node);
                this.particles.splice(i, 1);
            }
        }
        if (this.particles.length == 0) {
            this.onFinish();
        }
    };
    WinAnim.prototype.onFinish = function () {
        this.unscheduleAllCallbacks();
        if (!!this.finishCallFun) {
            var cb = this.finishCallFun;
            this.finishCallFun = null;
            cb();
        }
    };
    __decorate([
        property(cc.Prefab)
    ], WinAnim.prototype, "prefab", void 0);
    __decorate([
        property([cc.SpriteFrame])
    ], WinAnim.prototype, "imgs", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "minScale", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "maxScale", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "minAngle", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "maxAngle", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "minSkew", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "maxSkew", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "duration", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "minSpd", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "maxSpd", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "gravity", void 0);
    __decorate([
        property(cc.Integer)
    ], WinAnim.prototype, "count", void 0);
    WinAnim = __decorate([
        ccclass
    ], WinAnim);
    return WinAnim;
}(cc.Component));
exports.default = WinAnim;
var Particle = /** @class */ (function () {
    function Particle(node, spd, g) {
        this.node = node;
        this.spd = spd;
        this.gravity = g;
    }
    Particle.prototype.update = function (dt) {
        this.spd.y += this.gravity * dt;
        this.node.setPosition(this.node.x + this.spd.x * dt, this.node.y + this.spd.y * dt);
    };
    Object.defineProperty(Particle.prototype, "finished", {
        get: function () {
            return this.node.y < -667;
        },
        enumerable: false,
        configurable: true
    });
    return Particle;
}());

cc._RF.pop();