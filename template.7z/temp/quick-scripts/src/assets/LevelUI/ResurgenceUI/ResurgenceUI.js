"use strict";
cc._RF.push(module, '537ef5L6LZFSoQ2QezJLHX7', 'ResurgenceUI');
// LevelUI/ResurgenceUI/ResurgenceUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ResurgenceUI = /** @class */ (function (_super) {
    __extends(ResurgenceUI, _super);
    function ResurgenceUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btnCancel = null;
        _this.curScore = null;
        _this.maxScore = null;
        _this.timer = null;
        _this.t = 0;
        return _this;
    }
    ResurgenceUI.prototype.init = function () {
        this.initComponents();
        this.initTimer();
        this.hideBtnCancel();
    };
    ResurgenceUI.prototype.reset = function () {
        this.resetTimer();
        this.hideBtnCancel();
        this.unschedule(this.showBtnCancel);
    };
    ResurgenceUI.prototype.hideBtnCancel = function () {
        this.btnCancel.active = false;
    };
    ResurgenceUI.prototype.showBtnCancel = function () {
        this.btnCancel.active = true;
    };
    ResurgenceUI.prototype.initTimer = function () {
    };
    ResurgenceUI.prototype.resetTimer = function () {
        this.t = 10;
        this.timer.string = this.t.toString();
        this.stopTimer();
    };
    ResurgenceUI.prototype.updateTimer = function () {
        this.t -= 1;
        if (this.t <= 0) {
            this.t = 0;
            this.waitingTimeOver();
        }
        this.timer.string = this.t.toString();
    };
    ResurgenceUI.prototype.waitingTimeOver = function () {
        this.stopTimer();
        this.cancelFuHuo();
    };
    ResurgenceUI.prototype.startTimer = function () {
        this.schedule(this.updateTimer, 1);
    };
    ResurgenceUI.prototype.stopTimer = function () {
        this.unschedule(this.updateTimer);
    };
    ResurgenceUI.prototype.show = function () {
        this.node.active = true;
        this.reset();
        this.scheduleOnce(this.showBtnCancel, 2);
        this.startTimer();
        // let v = PlayerData.getData("gameData.maxScore");
        // this.maxScore.string = v.toString();
        // let ui = UIManager.getUI(GlobalEnum.UI.levelInfo);
        // let data = ui.getData();
        // this.curScore.string = data.gold.toString();
    };
    ResurgenceUI.prototype.onBtnFuHuo = function () {
        this.stopTimer();
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, {
            success: this.fuHuo.bind(this),
            fail: this.startTimer.bind(this),
            quit: this.startTimer.bind(this),
        });
    };
    ResurgenceUI.prototype.onBtnCancel = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.cancelFuHuo();
    };
    ResurgenceUI.prototype.cancelFuHuo = function () {
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.resurgence);
        this.emit(GameEventType_1.EventType.LevelEvent.cancelResurgence);
    };
    ResurgenceUI.prototype.fuHuo = function () {
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.resurgence);
        this.emit(GameEventType_1.EventType.LevelEvent.resurgence);
    };
    __decorate([
        property(cc.Node)
    ], ResurgenceUI.prototype, "btnCancel", void 0);
    __decorate([
        property(cc.Label)
    ], ResurgenceUI.prototype, "curScore", void 0);
    __decorate([
        property(cc.Label)
    ], ResurgenceUI.prototype, "maxScore", void 0);
    __decorate([
        property(cc.Label)
    ], ResurgenceUI.prototype, "timer", void 0);
    ResurgenceUI = __decorate([
        ccclass
    ], ResurgenceUI);
    return ResurgenceUI;
}(yyComponent_1.default));
exports.default = ResurgenceUI;

cc._RF.pop();