"use strict";
cc._RF.push(module, '5c5621S2uZBy5v/B3HCjZ1I', 'ChooseLevelUI');
// LobbyUI/ChooseLevelUI/ChooseLevelUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**关卡选择界面 */
var ChooseLevelUI = /** @class */ (function (_super) {
    __extends(ChooseLevelUI, _super);
    function ChooseLevelUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.plane = null;
        /*****************************************************************关卡项*****************************************************************/
        _this.itemLayer = null;
        /**关卡项背景图 */
        _this.levelItemSprites = [];
        /**已过关背景图 */
        _this.passItem = null;
        /**未解锁背景图 */
        _this.clockItem = null;
        _this.levelLayer = null;
        /**关卡序号 */
        _this.levelLabels = [];
        /*****************************************************************关卡页面*****************************************************************/
        /**每页包含的关卡项数量 */
        _this.countPerPage = 16;
        /**当前显示在第几页，从0开始计数 */
        _this.curPage = 0;
        /**可显示的最大页数 */
        _this.maxPage = 62;
        /*****************************************************************翻页按钮*****************************************************************/
        /**上一页按钮 */
        _this.btnPrePage = null;
        /**下一页按钮 */
        _this.btnNextPage = null;
        _this.unlockEffectMask = null;
        _this.unlockGuang = null;
        return _this;
    }
    ChooseLevelUI.prototype.init = function () {
        this.initUnlockEffect();
        this.initComponents();
        this.initItems();
        this.initPage();
    };
    ChooseLevelUI.prototype.reset = function () {
        this.resetUnlockEffect();
    };
    ChooseLevelUI.prototype.show = function () {
        this.node.active = true;
        // this.curPage = 0;
        var curLevel = PlayerData_1.default.getData("gameData.curLevel");
        if (undefined === curLevel) {
            this.curPage = 0;
        }
        else {
            this.curPage = Math.floor((curLevel - 1) / this.countPerPage);
        }
        this.showRecords(this.curPage);
        this.updateBtnState();
        this.playPlane();
    };
    ChooseLevelUI.prototype.playPlane = function () {
        var b = 0;
        var wg = this.plane.getComponent(cc.Widget);
        if (!!wg) {
            b = wg.bottom;
            wg.enabled = false;
        }
        var h = this.plane.height * this.plane.anchorY;
        var y = 0;
        if (!!wg) {
            y = -this.node.height * this.node.anchorY + b + h;
        }
        else {
            y = this.node.height * (1 - this.node.anchorY) - this.plane.height * (1 - this.plane.anchorY);
        }
        this.plane.setPosition(0, h + this.node.height * (1 - this.node.anchorY), 0);
        var move = Action3dManager_1.default.moveTo(1, 0, y, 0);
        move.easing(Action3dManager_1.default.easeElasticOut(0.35));
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).runAction(this.plane, move);
    };
    ChooseLevelUI.prototype.initItems = function () {
        var _this = this;
        this.countPerPage = this.itemLayer.childrenCount;
        this.levelItemSprites = [];
        var _loop_1 = function (i) {
            this_1.itemLayer.children[i].on("touchend", function () {
                _this.onChooseLevel(i);
            }, this_1);
            this_1.levelItemSprites.push(this_1.itemLayer.children[i].getComponent(cc.Sprite));
        };
        var this_1 = this;
        for (var i = 0; i < this.countPerPage; ++i) {
            _loop_1(i);
        }
        this.levelLabels = [];
        for (var i = 0; i < this.countPerPage; ++i) {
            this.levelLabels.push(this.levelLayer.children[i].getComponent(cc.Label));
        }
    };
    /**选择关卡项 */
    ChooseLevelUI.prototype.onChooseLevel = function (index) {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        var level = this.curPage * this.countPerPage + index + 1;
        var curLevel = PlayerData_1.default.getData("gameData.curLevel");
        if (level <= curLevel) {
            this.emit(GameEventType_1.EventType.DirectorEvent.enterChosedLevel, level);
        }
    };
    ChooseLevelUI.prototype.initPage = function () {
        var c = this.itemLayer.childrenCount;
        this.maxPage = Math.floor(1000 / c);
    };
    ChooseLevelUI.prototype.showRecords = function (page) {
        if (undefined === page) {
            page = this.curPage;
        }
        // let data = PlayerData.getData("gameData.levelRecords");
        var curLevel = PlayerData_1.default.getData("gameData.curLevel");
        var startLevel = page * this.countPerPage + 1;
        for (var i = 0; i < this.countPerPage; ++i) {
            var level = startLevel + i;
            // if (level > curLevel) {
            //     this.levelItemSprites[i].spriteFrame = this.clockItem;
            //     this.levelLabels[i].string = "";
            // } else if (level === curLevel) {
            //     this.levelItemSprites[i].spriteFrame = this.passItem;
            //     this.levelLabels[i].string = level.toString();
            // } else {
            //     let star = data[level];
            //     //理论上star绝对大于0
            //     if (!!star) {
            //         this.levelItemSprites[i].spriteFrame = this.passItem;
            //         this.levelLabels[i].string = (startLevel + i).toString();
            //     } else {
            //         this.levelItemSprites[i].spriteFrame = this.clockItem;
            //         this.levelLabels[i].string = "";
            //     }
            // }
            if (level > curLevel) {
                this.levelItemSprites[i].spriteFrame = this.clockItem;
                this.levelLabels[i].string = "";
            }
            else {
                this.levelItemSprites[i].spriteFrame = this.passItem;
                this.levelLabels[i].string = level.toString();
            }
        }
    };
    /**更新按钮的可点击状态 */
    ChooseLevelUI.prototype.updateBtnState = function () {
        this.btnPrePage.interactable = this.curPage > 0;
        this.btnNextPage.interactable = this.curPage < this.maxPage;
    };
    /**上一页 */
    ChooseLevelUI.prototype.onBtnPrePage = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        if (this.curPage <= 0)
            return;
        this.curPage -= 1;
        this.showRecords(this.curPage);
        this.updateBtnState();
    };
    /**下一页 */
    ChooseLevelUI.prototype.onBtnNextPage = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        if (this.curPage >= this.maxPage)
            return;
        this.curPage += 1;
        this.showRecords(this.curPage);
        this.updateBtnState();
    };
    ChooseLevelUI.prototype.onBtnClose = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.chooseLevel);
    };
    /*****************************************************************解锁/进入按钮*****************************************************************/
    ChooseLevelUI.prototype.onBtnUnclock = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, {
            success: this.unlockLevel.bind(this),
        });
    };
    ChooseLevelUI.prototype.unlockLevel = function () {
        var page = this.curPage;
        var curLevel = PlayerData_1.default.getData("gameData.curLevel");
        if (undefined === curLevel) {
            page = 0;
        }
        else {
            page = Math.floor((curLevel) / this.countPerPage);
        }
        if (page != this.curPage) {
            this.curPage = page;
            this.showRecords(this.curPage);
        }
        var index = curLevel % this.countPerPage;
        var p = this.plane.convertToNodeSpaceAR(this.itemLayer.children[index].convertToWorldSpaceAR(cc.v2(0, 38)));
        this.showUnlockEffect(p);
    };
    ChooseLevelUI.prototype.initUnlockEffect = function () {
        this.unlockEffectMask.active = false;
        this.unlockGuang.active = false;
    };
    ChooseLevelUI.prototype.resetUnlockEffect = function () {
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).stopAllActions(this.unlockEffectMask);
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).stopAllActions(this.unlockGuang);
        this.unlockEffectMask.active = false;
        this.unlockGuang.active = false;
    };
    ChooseLevelUI.prototype.showUnlockEffect = function (p) {
        this.emit(GameEventType_1.EventType.UIEvent.showTouchMask);
        if (undefined === p) {
            var curLevel = PlayerData_1.default.getData("gameData.curLevel");
            var index = curLevel % this.countPerPage;
            p = this.plane.convertToNodeSpaceAR(this.itemLayer.children[index].convertToWorldSpaceAR(cc.v2(0, 38)));
        }
        this.unlockEffectMask.active = true;
        this.unlockEffectMask.setPosition(p);
        this.unlockEffectMask.opacity = 50;
        var fadeIn = Action3dManager_1.default.fadeTo(1, 255);
        fadeIn.easing(Action3dManager_1.default.easeSinIn());
        var cb = Action3dManager_1.default.callFun(this.onUnlockEffectFadeIn.bind(this), this);
        var delay = Action3dManager_1.default.delay(0.3);
        var fadeOut = Action3dManager_1.default.fadeTo(0.5, 0);
        var finish = Action3dManager_1.default.callFun(this.onUnlockEffectFadeOut, this);
        var seq = Action3dManager_1.default.sequence(fadeIn, cb, delay, fadeOut, finish);
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).runAction(this.unlockEffectMask, seq);
    };
    ChooseLevelUI.prototype.onUnlockEffectFadeIn = function () {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData.curLevel",
            value: 1,
            mode: "+",
        });
        this.showRecords(this.curPage);
        this.updateBtnState();
    };
    ChooseLevelUI.prototype.onUnlockEffectFadeOut = function () {
        Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI).stopAllActions(this.unlockGuang);
        this.unlockEffectMask.active = false;
        this.unlockGuang.active = false;
        this.emit(GameEventType_1.EventType.UIEvent.hideTouchMask);
    };
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "plane", void 0);
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "itemLayer", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], ChooseLevelUI.prototype, "passItem", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], ChooseLevelUI.prototype, "clockItem", void 0);
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "levelLayer", void 0);
    __decorate([
        property(cc.Button)
    ], ChooseLevelUI.prototype, "btnPrePage", void 0);
    __decorate([
        property(cc.Button)
    ], ChooseLevelUI.prototype, "btnNextPage", void 0);
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "unlockEffectMask", void 0);
    __decorate([
        property(cc.Node)
    ], ChooseLevelUI.prototype, "unlockGuang", void 0);
    ChooseLevelUI = __decorate([
        ccclass
    ], ChooseLevelUI);
    return ChooseLevelUI;
}(yyComponent_1.default));
exports.default = ChooseLevelUI;

cc._RF.pop();