"use strict";
cc._RF.push(module, '5219a61WZBHrLPY3aPlPMyY', 'ConfigSettingUI');
// LobbyUI/ConfigSettingUI/ConfigSettingUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameConfig_1 = require("../../Script/GameSpecial/GameConfig");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ConfigSettingUI = /** @class */ (function (_super) {
    __extends(ConfigSettingUI, _super);
    function ConfigSettingUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.togBGM = null;
        _this.togEffect = null;
        _this.togVibrate = null;
        return _this;
    }
    ConfigSettingUI.prototype.initConfig = function () {
        var audioConfig = GameConfig_1.default.audioConfig;
        this.togBGM.isChecked = audioConfig.bgm;
        this.togEffect.isChecked = audioConfig.effect;
        var driveConfig = GameConfig_1.default.driveConfig;
        this.togVibrate.isChecked = driveConfig.vibrate;
    };
    ConfigSettingUI.prototype.init = function () {
        this.initComponents();
        this.initConfig();
    };
    ConfigSettingUI.prototype.show = function () {
        if (this.node.active)
            return;
        this.node.active = true;
        this.emit(GameEventType_1.EventType.DirectorEvent.pauseLevel);
        this.initConfig();
    };
    ConfigSettingUI.prototype.hide = function () {
        if (!this.node.active)
            return;
        this.node.active = false;
        this.emit(GameEventType_1.EventType.DirectorEvent.resumeLevel);
    };
    ConfigSettingUI.prototype.saveConfig = function () {
        var audioConfig = {
            bgm: this.togBGM.isChecked,
            effect: this.togEffect.isChecked,
        };
        GameConfig_1.default.audioConfig = audioConfig;
        var driveConfig = {
            vibrate: this.togVibrate.isChecked,
        };
        GameConfig_1.default.driveConfig = driveConfig;
    };
    ConfigSettingUI.prototype.onBtnClose = function () {
        this.saveConfig();
        this.emit(GameEventType_1.EventType.DirectorEvent.resumeLevel);
        this.emit(GameEventType_1.EventType.UIEvent.exit, GlobalEnum_1.GlobalEnum.UI.configSetting);
    };
    ConfigSettingUI.prototype.onCloseBGM = function () {
        if (!this.togBGM.isChecked) {
            this.emit(GameEventType_1.EventType.AudioEvent.stopBGM);
        }
        else {
            this.emit(GameEventType_1.EventType.AudioEvent.playBGM, GlobalEnum_1.GlobalEnum.AudioClip.BGM);
        }
    };
    __decorate([
        property(cc.Toggle)
    ], ConfigSettingUI.prototype, "togBGM", void 0);
    __decorate([
        property(cc.Toggle)
    ], ConfigSettingUI.prototype, "togEffect", void 0);
    __decorate([
        property(cc.Toggle)
    ], ConfigSettingUI.prototype, "togVibrate", void 0);
    ConfigSettingUI = __decorate([
        ccclass
    ], ConfigSettingUI);
    return ConfigSettingUI;
}(yyComponent_1.default));
exports.default = ConfigSettingUI;

cc._RF.pop();