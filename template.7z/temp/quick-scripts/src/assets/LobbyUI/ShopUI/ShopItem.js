"use strict";
cc._RF.push(module, '5a631MrW1ZFcYMlXrLofj5W', 'ShopItem');
// LobbyUI/ShopUI/ShopItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var Loader_1 = require("../../Script/Common/Loader");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * 单个商品
 */
var ShopItem = /** @class */ (function (_super) {
    __extends(ShopItem, _super);
    function ShopItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.itemSprite = null;
        _this.LockMask = null;
        _this._unclock = false;
        _this.chooseMask = null;
        _this._isChecked = false;
        _this.itemName = null;
        _this.price = null;
        return _this;
    }
    Object.defineProperty(ShopItem.prototype, "unlock", {
        /**商品项是否已解锁 */
        get: function () { return this._unclock; },
        set: function (v) {
            this._unclock = !!v;
            this.LockMask.active = !this._unclock;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ShopItem.prototype, "isChecked", {
        /**商品项是否被选中 */
        get: function () { return this._isChecked; },
        set: function (v) {
            this._isChecked = !!v;
            this.chooseMask.active = this._isChecked;
        },
        enumerable: false,
        configurable: true
    });
    ShopItem.prototype.init = function (data) {
        this.isChecked = false;
        this.onEvents();
        if (!!data)
            this.setData(data);
    };
    ShopItem.prototype.onEvents = function () {
        this.node.on("touchend", this.onTouchEnd, this);
    };
    ShopItem.prototype.reset = function () {
        this.data = null;
        this.isChecked = false;
    };
    ShopItem.prototype.reuse = function (data) {
        this.reset();
        this.setData(data);
    };
    ShopItem.prototype.unuse = function () {
        this.reset();
    };
    ShopItem.prototype.setData = function (data) {
        //数据
        this.data = data;
        //图片
        this.setImg(data.itemUrl);
        //名称
        if (!!this.itemName)
            this.itemName.string = data.name;
        //价格
        if (!!this.price)
            this.price.string = data.price.toString();
        //状态
        this.unlock = data.unlock;
    };
    ShopItem.prototype.setImg = function (url) {
        var _this = this;
        Loader_1.default.loadBundleRes("Skin", url, function (res) {
            if (!res)
                return;
            if (res instanceof cc.Texture2D) {
                _this.itemSprite.spriteFrame = new cc.SpriteFrame(res);
            }
            else if (res instanceof cc.SpriteFrame) {
                _this.itemSprite.spriteFrame = res;
            }
        }, false);
    };
    ShopItem.prototype.onTouchEnd = function () {
        if (this.isChecked)
            return;
        this.isChecked = true;
        this.emit(GameEventType_1.EventType.ShopEvent.chooseItem, this);
    };
    __decorate([
        property(cc.Sprite)
    ], ShopItem.prototype, "itemSprite", void 0);
    __decorate([
        property(cc.Node)
    ], ShopItem.prototype, "LockMask", void 0);
    __decorate([
        property(cc.Node)
    ], ShopItem.prototype, "chooseMask", void 0);
    __decorate([
        property(cc.Label)
    ], ShopItem.prototype, "itemName", void 0);
    __decorate([
        property(cc.Label)
    ], ShopItem.prototype, "price", void 0);
    ShopItem = __decorate([
        ccclass
    ], ShopItem);
    return ShopItem;
}(yyComponent_1.default));
exports.default = ShopItem;

cc._RF.pop();