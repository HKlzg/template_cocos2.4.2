"use strict";
cc._RF.push(module, '2aa0dpyd3VCraGsx3pxEXt6', 'ShopStage');
// LobbyUI/ShopUI/ShopStage.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
var Loader_1 = require("../../Script/Common/Loader");
var yyComponent_1 = require("../../Script/Common/yyComponent");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**商城的商品展示台 */
var ShopStage = /** @class */ (function (_super) {
    __extends(ShopStage, _super);
    function ShopStage() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //2D展示方式：
        /**展示商品详情的图片精灵 */
        _this.displaySprite = null;
        //3D展示方式：
        /**商品展示台 */
        _this.displayStage = null;
        /**展示3D模型节点的父节点 */
        _this.modelStage = null;
        /**商品展示台相机 */
        _this.camera = null;
        /**当前用来展示的3D模型节点 */
        _this.curItemModel = null;
        /**3D模型动作 */
        _this.modelTween = null;
        return _this;
    }
    ShopStage.prototype.init = function () {
        this.initComponents();
        this.initDisplayStage();
        this.initSprite();
    };
    ShopStage.prototype.reset = function () {
        this.resetDisplayStage();
        this.resetSprite();
    };
    ShopStage.prototype.initSprite = function () {
        if (!this.displaySprite)
            return;
        this.displaySprite.spriteFrame = null;
    };
    ShopStage.prototype.resetSprite = function () {
        if (!this.displaySprite)
            return;
        this.displaySprite.spriteFrame = null;
    };
    ShopStage.prototype.showGoodsImg = function (img) {
        var _this = this;
        if (!this.displaySprite)
            return;
        Loader_1.default.loadBundleRes("Skin", img, function (res) {
            if (_this.displaySprite.isValid) {
                _this.displaySprite.spriteFrame = res;
            }
        }, cc.SpriteFrame, false);
    };
    ShopStage.prototype.initDisplayStage = function () {
        if (!this.displayStage)
            return;
        var wg = this.displayStage.getComponent(cc.Widget);
        if (!!wg) {
            wg.updateAlignment();
        }
        var y = this.displayStage.y;
        var rate = y / cc.find("Canvas").height;
        this.camera.rect = cc.rect(0, rate, 1, 1);
    };
    ShopStage.prototype.resetDisplayStage = function () {
        if (!this.displayStage)
            return;
        if (!!this.modelTween) {
            this.modelTween.stop();
            this.modelTween = null;
        }
        if (!!this.curItemModel) {
            GlobalPool_1.default.put(this.curItemModel);
            this.curItemModel = null;
        }
    };
    /**展示商品详情 */
    ShopStage.prototype.showItemData = function (data) {
        //图片展示方式：
        this.showGoodsImg(data.displayUrl);
        //3D模型展示方式：
        // this.showGoodsModel(data.model, data.skin);
    };
    /**3D模型展示 */
    ShopStage.prototype.showGoodsModel = function (model, skin) {
        var _this = this;
        if (!this.displayStage)
            return;
        var angle = cc.v3();
        if (!!this.modelTween) {
            this.modelTween.stop();
            this.modelTween = null;
        }
        if (!!this.curItemModel) {
            angle.set(this.curItemModel.eulerAngles);
            GlobalPool_1.default.put(this.curItemModel);
            this.curItemModel = null;
        }
        this.curItemModel = GlobalPool_1.default.get(model);
        var url = skin;
        Loader_1.default.loadBundleRes("Skin", url, function (res) {
            if (!_this.node.active || !_this.node.isValid)
                return;
            var mesh = _this.curItemModel.getComponentInChildren(cc.MeshRenderer);
            var sf;
            if (res instanceof cc.SpriteFrame) {
                sf = res;
            }
            else if (res instanceof cc.Texture2D) {
                sf = new cc.SpriteFrame(res);
            }
            mesh.getMaterial(0).setProperty("diffuseTexture", sf);
        }, false);
        this.modelStage.addChild(this.curItemModel);
        this.curItemModel.setPosition(cc.v3(0, 0, 0));
        this.curItemModel.eulerAngles = angle;
        this.modelTween = cc.tween(this.curItemModel).repeatForever(cc.tween(this.curItemModel).by(2, { eulerAngles: cc.v3(0, 90, 0) })).union().start();
    };
    __decorate([
        property(cc.Sprite)
    ], ShopStage.prototype, "displaySprite", void 0);
    __decorate([
        property(cc.Node)
    ], ShopStage.prototype, "displayStage", void 0);
    __decorate([
        property(cc.Node)
    ], ShopStage.prototype, "modelStage", void 0);
    __decorate([
        property(cc.Camera)
    ], ShopStage.prototype, "camera", void 0);
    ShopStage = __decorate([
        ccclass
    ], ShopStage);
    return ShopStage;
}(yyComponent_1.default));
exports.default = ShopStage;

cc._RF.pop();