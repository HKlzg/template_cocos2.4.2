"use strict";
cc._RF.push(module, 'f1146XD9dZL0oi7dzvFICfT', 'ShopUI');
// LobbyUI/ShopUI/ShopUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var Loader_1 = require("../../Script/Common/Loader");
var GameData_1 = require("../../Script/Common/GameData");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var ShopItem_1 = require("./ShopItem");
var ShopStage_1 = require("./ShopStage");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**皮肤商城UI*/
var ShopUI = /** @class */ (function (_super) {
    __extends(ShopUI, _super);
    function ShopUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**场景/UI类型 */
        _this._uiType = GlobalEnum_1.GlobalEnum.UI.shop;
        _this.goodsTypeToggles = null;
        /**页面滚动视图 */
        _this.pageView = null;
        /**单个商品页面的预制件 */
        _this.storePage = null; //商城页面
        /**当前商品的价格 */
        _this.price = null;
        /**商品项 */
        _this.shopItemPerfab = null;
        /**商品展示台 */
        _this.stage = null;
        /**当前选中的商品项 */
        _this.curItem = null;
        return _this;
    }
    Object.defineProperty(ShopUI.prototype, "uiType", {
        get: function () { return this._uiType; },
        enumerable: false,
        configurable: true
    });
    ShopUI.prototype.initPage = function () {
        GlobalPool_1.default.createPool(this.shopItemPerfab.name, this.shopItemPerfab, this.shopItemPerfab.name);
        GlobalPool_1.default.createPool(this.storePage.name, this.storePage);
    };
    ShopUI.prototype.resetPage = function () {
        var pages = this.pageView.getPages();
        for (var i = pages.length - 1; i >= 0; --i) {
            GlobalPool_1.default.putAllChildren(pages[i]);
        }
        this.pageView.removeAllPages();
    };
    ShopUI.prototype.initDisplayStage = function () {
        this.stage.init();
    };
    ShopUI.prototype.resetDisplayStage = function () {
        this.stage.reset();
    };
    ShopUI.prototype.init = function () {
        this.curItem = null;
        this.curType = null;
        this.initComponents();
        this.initDisplayStage();
        this.initPage();
        this.onEvents();
    };
    ShopUI.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.ShopEvent.chooseItem, this.onChooseItem, this);
    };
    ShopUI.prototype.reset = function () {
        this.curItem = null;
        this.curType = null;
        this.resetDisplayStage();
        this.resetPage();
    };
    ShopUI.prototype.show = function () {
        this.node.active = true;
        this.reset();
        this.setData();
    };
    ShopUI.prototype.setData = function () {
        var _this = this;
        var toggles = this.goodsTypeToggles.toggleItems;
        if (toggles.length > 0) {
            toggles[0].isChecked = true;
            var handler = toggles[0].checkEvents[0];
            if (!handler) {
                console.warn("商品类型分页标签未绑定回调函数");
                return;
            }
            var type_1 = handler.customEventData;
            Loader_1.default.loadBundleDir("Skin", type_1 + "/Item", function () {
                _this.showGoods(type_1);
            }, cc.SpriteFrame, true);
        }
    };
    ShopUI.prototype.hide = function () {
        this.reset();
        this.node.active = false;
    };
    ShopUI.prototype.onChooseType = function (e, type) {
        var _this = this;
        if (this.curType == type)
            return;
        Loader_1.default.loadBundleDir("Skin", type + "/Item", function () {
            _this.showGoods(type);
        }, cc.SpriteFrame, true);
    };
    /**
     * 显示商品
     * 应当新建一个展示台的类，负责根据实际游戏展示对应的商品模型或图片
     */
    ShopUI.prototype.showGoods = function (type) {
        this.resetPage();
        this.curType = type;
        var goodsData = GameData_1.default.getData(type);
        var maxCount = 6;
        var unlockSkins = PlayerData_1.default.getData("gameData." + type + ".owned");
        var curSkin = PlayerData_1.default.getData("gameData." + type + ".cur");
        if (typeof curSkin === "number") {
            curSkin = curSkin.toString();
        }
        var page = cc.instantiate(this.storePage);
        this.pageView.addPage(page);
        var displayPath = this.curType + "/Display/";
        var itemPath = this.curType + "/Item/";
        var pageIndex = 0;
        for (var key in goodsData) {
            if (page.childrenCount >= maxCount) {
                page = cc.instantiate(this.storePage);
                this.pageView.addPage(page);
            }
            var data = JSON.parse(JSON.stringify(goodsData[key]));
            data.itemUrl = itemPath + data.itemUrl;
            data.displayUrl = displayPath + data.displayUrl;
            data.unlock = unlockSkins.indexOf(parseInt(key)) >= 0;
            var node = GlobalPool_1.default.get(this.shopItemPerfab.name, data);
            if (key == curSkin) {
                var item = node.getComponent(ShopItem_1.default);
                item.isChecked = true;
                this.curItem = item;
                pageIndex = this.pageView.getPages().length - 1;
            }
            page.addChild(node);
        }
        this.pageView.scrollToPage(pageIndex, 0);
        if (!!this.curItem) {
            this.showItemData(this.curItem.data);
        }
    };
    ShopUI.prototype.onChooseItem = function (item) {
        if (!!this.curItem) {
            if (this.curItem.Id === item.Id)
                return;
            this.curItem.isChecked = false;
        }
        this.curItem = item;
        if (this.curItem.data.unlock) {
            this.setCurSkin(this.curType, this.curItem.data.id);
        }
        this.showItemData(item.data);
    };
    /**展示商品详情 */
    ShopUI.prototype.showItemData = function (data) {
        this.stage.showItemData(data);
        if (data.unlock) {
            this.showUsing();
        }
        else {
            this.showPrice(data.price);
        }
    };
    ShopUI.prototype.showPrice = function (price) {
        this.price.string = price.toString();
    };
    ShopUI.prototype.showUsing = function () {
        this.price.string = "使用中";
    };
    /**退出商城 */
    ShopUI.prototype.onBtnExit = function () {
        this.emit(GameEventType_1.EventType.UIEvent.exit, this.uiType);
    };
    /**购买 */
    ShopUI.prototype.onBtnBuy = function () {
        if (!this.curItem)
            return;
        if (this.curItem.data.unlock)
            return;
        var price = this.curItem.data.price;
        var gold = PlayerData_1.default.getData("gameData.asset.gold");
        if (gold < price) {
            this.tipGoldUnenough();
        }
        else {
            this.subGold(price);
            this.unlockSkin(this.curType, this.curItem.data.id);
            this.setCurSkin(this.curType, this.curItem.data.id);
            this.curItem.data.unlock = true;
            this.curItem.unlock = true;
            this.showUsing();
        }
    };
    ShopUI.prototype.subGold = function (gold) {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData.asset.gold",
            value: gold,
            mode: "-",
            save: false,
        });
    };
    /**
     * 解锁皮肤
     * @param type 皮肤类型
     * @param id 皮肤id
     */
    ShopUI.prototype.unlockSkin = function (type, id) {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData." + type + ".owned",
            value: parseInt(id),
            mode: "push"
        });
    };
    /**
     * 设置当前使用的皮肤
     * @param type 皮肤类型
     * @param id 皮肤id
     */
    ShopUI.prototype.setCurSkin = function (type, id) {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData." + type + ".cur",
            value: parseInt(id),
            mode: "="
        });
    };
    /** 提示金币不足 */
    ShopUI.prototype.tipGoldUnenough = function () {
        this.emit(GameEventType_1.EventType.UIEvent.showTip, "金币不足");
    };
    /**观看视频 */
    ShopUI.prototype.onBtnVideo = function () {
        var _this = this;
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.SDKEvent.showVideo, function () {
            _this.emit(GameEventType_1.EventType.UIEvent.playGoldAnim, {
                cb: function () {
                    _this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
                        type: "gameData",
                        attribute: "gameData.asset.gold",
                        value: 200,
                        mode: "+"
                    });
                },
                gold: 200,
            });
        });
    };
    __decorate([
        property(cc.ToggleContainer)
    ], ShopUI.prototype, "goodsTypeToggles", void 0);
    __decorate([
        property(cc.PageView)
    ], ShopUI.prototype, "pageView", void 0);
    __decorate([
        property(cc.Prefab)
    ], ShopUI.prototype, "storePage", void 0);
    __decorate([
        property(cc.Label)
    ], ShopUI.prototype, "price", void 0);
    __decorate([
        property(cc.Prefab)
    ], ShopUI.prototype, "shopItemPerfab", void 0);
    __decorate([
        property(ShopStage_1.default)
    ], ShopUI.prototype, "stage", void 0);
    ShopUI = __decorate([
        ccclass
    ], ShopUI);
    return ShopUI;
}(yyComponent_1.default));
exports.default = ShopUI;

cc._RF.pop();