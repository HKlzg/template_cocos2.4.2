"use strict";
cc._RF.push(module, '40bcc/o5rtGMK5aKqyYxbY2', 'LevelController');
// Level/LevelController/LevelController.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//关卡中的控制器，接收玩家操作
var LevelController = /** @class */ (function (_super) {
    __extends(LevelController, _super);
    function LevelController() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LevelController.prototype.onLoad = function () {
        this.init();
        this.setDisable();
    };
    LevelController.prototype.init = function () {
        this.initComponents();
        this.initTouchState();
        this.initCustomUpdateState();
        this.registAllCustomUpdate();
        this.onEvents();
    };
    LevelController.prototype.onEvents = function () {
        this.node.on("touchstart", this.onTouchStart, this);
        this.node.on("touchmove", this.onTouchMove, this);
        this.node.on("touchend", this.onTouchEnd, this);
        this.on(GameEventType_1.EventType.CtrlEvent.ctrlStart, this.setEnable, this);
        this.on(GameEventType_1.EventType.CtrlEvent.ctrlEnd, this.setDisable, this);
    };
    LevelController.prototype.registAllCustomUpdate = function () {
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.CtrlState.touched, this.stepTouchStay);
    };
    LevelController.prototype.reset = function () {
        this.resetTouchState();
    };
    //启用触摸操作层
    LevelController.prototype.setEnable = function () {
        this.reset();
        this.node.active = true;
    };
    //禁用触摸操作层
    LevelController.prototype.setDisable = function () {
        this.reset();
        this.node.active = false;
    };
    LevelController.prototype.getTouchData = function (e) {
        return {
            startTime: this.touchStartTime,
            stayTime: this.touchStayTime,
            path: this.touchPath,
            e: e
        };
    };
    LevelController.prototype.initTouchState = function () {
        this.touched = false;
        this.touchId = -1;
        this.touchStartTime = -1;
        this.touchStayTime = 0;
        this.touchPath = [];
    };
    LevelController.prototype.resetTouchState = function () {
        this.touched = false;
        this.touchId = -1;
        this.touchStartTime = -1;
        this.touchStayTime = 0;
        this.touchPath = [];
    };
    //触摸开始
    LevelController.prototype.onTouchStart = function (e) {
        //屏蔽多点触摸
        if (this.isMultipleTouch(e))
            return;
        //记录触摸状态
        this.touched = true;
        this.touchId = e.getID();
        this.touchStartTime = Date.now();
        this.touchStayTime = 0;
        var p = e.getLocation();
        // this.touchPath.push(p);
        this.touchPath[0] = p; //不需要记录触摸路径时用此方式
        this.emit(GameEventType_1.EventType.CtrlEvent.touchStart, this.getTouchData(e));
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.CtrlState.touched);
    };
    //触摸移动
    LevelController.prototype.onTouchMove = function (e) {
        if (!this.isCurTouchEvent(e))
            return;
        var p = e.getLocation();
        // let p2 = this.touchPath[this.touchPath.length - 1];
        // if (Math.abs(p.x - p2.x) < 5 && Math.abs(p.y - p2.y) < 5) return;
        this.touchPath[1] = p; //不需要记录触摸路径时用此方式
        // this.touchPath.push(p);
        this.emit(GameEventType_1.EventType.CtrlEvent.touchMove, this.getTouchData(e));
    };
    //触摸结束
    LevelController.prototype.onTouchEnd = function (e) {
        if (!this.isCurTouchEvent(e))
            return;
        var p = e.getLocation();
        // this.touchPath.push(p);
        this.touchPath[1] = p; //不需要记录触摸路径时用此方式
        this.emit(GameEventType_1.EventType.CtrlEvent.touchEnd, this.getTouchData(e));
        this.resetTouchState();
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.CtrlState.none);
    };
    /**
     * 是否多重触摸
     * @param e 触摸事件
     */
    LevelController.prototype.isMultipleTouch = function (e) {
        return e.getTouches().length > 1;
    };
    //是否当前已记录的有效的触摸事件
    LevelController.prototype.isCurTouchEvent = function (e) {
        return e.getID() == this.touchId;
    };
    LevelController.prototype.stepTouchStay = function (dt) {
        if (this.touched) {
            this.touchStayTime += dt;
            this.emit(GameEventType_1.EventType.CtrlEvent.touchStay, this.getTouchData(null));
        }
    };
    LevelController = __decorate([
        ccclass
    ], LevelController);
    return LevelController;
}(yyComponent_1.default));
exports.default = LevelController;

cc._RF.pop();