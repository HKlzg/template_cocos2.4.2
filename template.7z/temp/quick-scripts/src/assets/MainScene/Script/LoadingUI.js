"use strict";
cc._RF.push(module, '326d3l9GUNNN6sC8bQK7+Ik', 'LoadingUI');
// MainScene/Script/LoadingUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**加载进度条UI */
var LoadingUI = /** @class */ (function (_super) {
    __extends(LoadingUI, _super);
    function LoadingUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bar = null;
        _this.totalLength = 0;
        return _this;
    }
    LoadingUI.prototype.init = function () {
        if (this.totalLength == 0) {
            this.totalLength = this.bar.getComponent(cc.Sprite).spriteFrame.getOriginalSize().width;
        }
        this.bar.setPosition(-0.5 * this.totalLength, this.bar.y);
        this.onEvents();
    };
    LoadingUI.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.LoadAssetEvent.showProgress, this.onShowProgress, this);
        this.on(GameEventType_1.EventType.LoadAssetEvent.updateProgress, this.onUpdateProgress, this);
        this.on(GameEventType_1.EventType.LoadAssetEvent.hideProgress, this.onHideProgress, this);
    };
    LoadingUI.prototype.onShowProgress = function (rate) {
        this.node.active = true;
        this.bar.width = this.totalLength * rate;
    };
    LoadingUI.prototype.onUpdateProgress = function (rate) {
        this.bar.width = this.totalLength * rate;
    };
    LoadingUI.prototype.onHideProgress = function () {
        this.node.active = false;
    };
    __decorate([
        property(cc.Node)
    ], LoadingUI.prototype, "bar", void 0);
    __decorate([
        property
    ], LoadingUI.prototype, "totalLength", void 0);
    LoadingUI = __decorate([
        ccclass
    ], LoadingUI);
    return LoadingUI;
}(yyComponent_1.default));
exports.default = LoadingUI;

cc._RF.pop();