"use strict";
cc._RF.push(module, '08b7fQRKfNDVZa5QgqRT/Gw', 'PlayerAssetBar');
// MainScene/Script/PlayerAssetBar.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
//玩家的金币体力等资产信息条
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var PlayerAssetBar = /** @class */ (function (_super) {
    __extends(PlayerAssetBar, _super);
    function PlayerAssetBar() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //#region 金币信息
        _this.goldLabel = null;
        //#endregion
        //#region 金币动画
        _this.goldLayer = null;
        _this.goldIconPrefab = null;
        return _this;
        //#endregion
        //#region 体力信息
        //#endregion
        //#region 体力动画
        //#endregion
    }
    PlayerAssetBar.prototype.init = function () {
        this.initComponents();
        this.initGoldIcon();
        this.onEvents();
        this.setData();
    };
    PlayerAssetBar.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, this.onPlayerDataChanged, this);
        this.on(GameEventType_1.EventType.UIEvent.playGoldAnim, this.playGoldAnim, this);
    };
    PlayerAssetBar.prototype.reset = function () {
        this.resetGoldIcon();
    };
    PlayerAssetBar.prototype.show = function () {
        this.node.active = true;
        this.setData();
        this.onEvents();
    };
    PlayerAssetBar.prototype.hide = function () {
        this.offEvents();
        this.node.active = false;
    };
    PlayerAssetBar.prototype.setData = function () {
        var data = PlayerData_1.default.getData("gameData.asset");
        this.setGold(data.gold);
    };
    PlayerAssetBar.prototype.convertToString = function (v) {
        if (v < 1100)
            return v.toString();
        if (v < 1000000)
            return (v * 0.001).toFixed(1) + "K";
        return (v * 0.000001).toFixed(1) + "M";
    };
    PlayerAssetBar.prototype.onPlayerDataChanged = function (data) {
        switch (data.attribute) {
            case "gameData.asset.gold": {
                this.setGold(data.value);
                break;
            }
        }
    };
    PlayerAssetBar.prototype.setGold = function (gold) {
        this.goldLabel.string = this.convertToString(gold);
    };
    PlayerAssetBar.prototype.initGoldIcon = function () {
        var p = this.goldLabel.node.convertToWorldSpaceAR(cc.v2(0, 0));
        p = this.node.convertToNodeSpaceAR(p);
        this.targetPos = cc.v3(p.x, p.y, 0);
        this.cb = null;
        GlobalPool_1.default.createPool(GlobalEnum_1.GlobalEnum.LevelPrefab.goldIcon, this.goldIconPrefab);
    };
    PlayerAssetBar.prototype.resetGoldIcon = function () {
        this.cb = null;
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI);
        for (var i = this.goldLayer.childrenCount - 1; i >= 0; --i) {
            actMng.stopAllActions(this.goldLayer.children[i]);
        }
        GlobalPool_1.default.putAllChildren(this.goldLayer, true);
    };
    PlayerAssetBar.prototype.playGoldAnim = function (data) {
        this.resetGoldIcon();
        this.emit(GameEventType_1.EventType.UIEvent.showTouchMask);
        this.cb = data.cb;
        var center = cc.v2();
        if (!!data.startPos) {
            center.set(data.startPos);
        }
        var duration = 0.2;
        var count = Math.round(Math.random() * 10) + 20;
        var scope = 250;
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI);
        for (var i = 0; i < count; i++) {
            var item = GlobalPool_1.default.get(GlobalEnum_1.GlobalEnum.LevelPrefab.goldIcon);
            this.goldLayer.addChild(item);
            item.setPosition(center);
            item.setScale(1, 1);
            var move = Action3dManager_1.default.moveTo(duration, (Math.random() - 0.5) * scope, (Math.random() - 0.5) * scope, 0);
            move.easing(Action3dManager_1.default.easeOut(2));
            actMng.runAction(item, move);
        }
        this.scheduleOnce(this.toTarget, duration);
    };
    PlayerAssetBar.prototype.toTarget = function () {
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI);
        var duration = 0.8;
        var delay = 0.005;
        var totalDelay = this.goldLayer.childrenCount * delay;
        for (var i = this.goldLayer.childrenCount - 1; i >= 0; --i) {
            var move = Action3dManager_1.default.moveTo(duration, this.targetPos);
            var scale = Action3dManager_1.default.scaleTo(duration, 0.5, 0.5, 1);
            var spawn = Action3dManager_1.default.spawn(move, scale);
            var d = Action3dManager_1.default.delay(delay + i * delay);
            var seq = Action3dManager_1.default.sequence(d, spawn);
            actMng.runAction(this.goldLayer.children[i], seq);
        }
        this.scheduleOnce(this.playFinish, duration + totalDelay);
    };
    PlayerAssetBar.prototype.playFinish = function () {
        this.emit(GameEventType_1.EventType.UIEvent.hideTouchMask);
        if (!!this.cb) {
            this.cb();
        }
        else {
            this.emit(GameEventType_1.EventType.UIEvent.goldAnimPlayFinish);
        }
        this.resetGoldIcon();
    };
    __decorate([
        property(cc.Label)
    ], PlayerAssetBar.prototype, "goldLabel", void 0);
    __decorate([
        property(cc.Node)
    ], PlayerAssetBar.prototype, "goldLayer", void 0);
    __decorate([
        property(cc.Prefab)
    ], PlayerAssetBar.prototype, "goldIconPrefab", void 0);
    PlayerAssetBar = __decorate([
        ccclass
    ], PlayerAssetBar);
    return PlayerAssetBar;
}(yyComponent_1.default));
exports.default = PlayerAssetBar;

cc._RF.pop();