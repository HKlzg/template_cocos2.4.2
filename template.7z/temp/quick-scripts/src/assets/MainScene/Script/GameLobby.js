"use strict";
cc._RF.push(module, '69ef72xiQlAL4AzHd4vX34+', 'GameLobby');
// MainScene/Script/GameLobby.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameLobby = /** @class */ (function (_super) {
    __extends(GameLobby, _super);
    function GameLobby() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._uiType = GlobalEnum_1.GlobalEnum.UI.lobby;
        /**当前关卡 */
        _this.curLevel = null;
        return _this;
    }
    Object.defineProperty(GameLobby.prototype, "uiType", {
        /**场景/UI类型 */
        get: function () { return this._uiType; },
        enumerable: false,
        configurable: true
    });
    GameLobby.prototype.init = function () {
        this.updateCurLevel();
        this.onEvents();
    };
    GameLobby.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, this.onPlayerDataChanged, this);
    };
    GameLobby.prototype.reset = function () {
    };
    GameLobby.prototype.show = function () {
        this.node.active = true;
        this.emit(GameEventType_1.EventType.AudioEvent.playBGM, GlobalEnum_1.GlobalEnum.AudioClip.BGM, true);
    };
    GameLobby.prototype.hide = function () {
        this.node.active = false;
    };
    GameLobby.prototype.onPlayerDataChanged = function (data) {
        if (data.attribute == "gameData.curLevel") {
            this.curLevel.string = data.value.toString();
        }
    };
    GameLobby.prototype.updateCurLevel = function () {
        var lv = PlayerData_1.default.getData("gameData.curLevel");
        this.curLevel.string = lv.toString();
    };
    GameLobby.prototype.onBtnStartGame = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.DirectorEvent.startGame);
    };
    GameLobby.prototype.onBtnShop = function () {
        this.emit(GameEventType_1.EventType.AudioEvent.playClickBtn);
        this.emit(GameEventType_1.EventType.UIEvent.enter, GlobalEnum_1.GlobalEnum.UI.shop);
    };
    __decorate([
        property(cc.Label)
    ], GameLobby.prototype, "curLevel", void 0);
    GameLobby = __decorate([
        ccclass
    ], GameLobby);
    return GameLobby;
}(yyComponent_1.default));
exports.default = GameLobby;

cc._RF.pop();