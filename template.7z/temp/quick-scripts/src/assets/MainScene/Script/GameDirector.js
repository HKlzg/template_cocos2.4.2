"use strict";
cc._RF.push(module, '6d088A7nYNLd6wJkhsMlfmq', 'GameDirector');
// MainScene/Script/GameDirector.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var RecommendManager_1 = require("../../Script/Recommend/RecommendManager");
var UIManager_1 = require("../../Script/Common/UIManager");
var GameConfig_1 = require("../../Script/GameSpecial/GameConfig");
var PlayerData_1 = require("../../Script/Common/PlayerData");
var AudioManager_1 = require("../../Script/Common/AudioManager");
var GameData_1 = require("../../Script/Common/GameData");
var PowerManager_1 = require("../../Script/Common/PowerManager");
var Loader_1 = require("../../Script/Common/Loader");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GlobalPool_1 = require("../../Script/Common/GlobalPool");
//游戏流程管理器
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * 游戏流程总管理器
 *
 * 游戏流程：
 *
 * 登录:
 * 登录账号
 * 获取玩家数据
 *
 * 进入首页：
 * 加载首页资源
 * 显示首页UI
 *
 * 开始游戏：
 * 加载关卡数据
 * 加载关卡资源
 * 进入关卡
 * 隐藏首页UI
 *
 * 关卡结束：
 * 加载结算UI资源
 * 显示结算UI
 *
 * 继续下一关：
 * 退出当前关卡
 * 回收当前关卡资源
 * 加载关卡数据
 * 加载关卡资源
 * 进入关卡
 *
 * 重玩当前关：
 * 重置关卡状态
 * 进入关卡
 *
 * 返回首页：
 * 退出关卡
 * 回收关卡资源
 * 显示首页UI
 */
var GameDirector = /** @class */ (function (_super) {
    __extends(GameDirector, _super);
    function GameDirector() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bg = null;
        /************************************快捷方法************************************/
        //#region 触摸遮罩
        /**出没遮罩层，阻挡玩家触摸操作 */
        _this.touchMask = null;
        //#endregion
        /************************************管理的对象************************************/
        //#region 已经存在的UI
        _this.defaultUIs = [];
        //#endregion
        //只能在首页中时才显示的UI
        _this.lobbyUIs = [];
        //只能在关卡中时才显示的UI
        _this.levelUIs = [];
        //可在任意情况下显示的UI
        _this.persistUIs = [];
        /**关卡管理器 */
        _this.levelMng = null;
        //#region UI动作管理器
        _this.uiActMng = null;
        return _this;
        //#endregion
    }
    GameDirector.prototype.start = function () {
        this.init();
        this.loadGameData();
    };
    GameDirector.prototype.update = function (dt) {
        this.uiActMng.update(dt);
        if (!!this.levelMng) {
            this.levelMng.running(dt);
        }
    };
    GameDirector.prototype.initTouchMask = function () {
        this.touchMask.active = false;
        this.touchMaskCount = 0;
    };
    GameDirector.prototype.resetTouchMask = function () {
        this.touchMask.active = false;
        this.touchMaskCount = 0;
    };
    /**显示一层遮罩，阻挡玩家操作 */
    GameDirector.prototype.showTouchMask = function (count) {
        if (count === void 0) { count = 1; }
        this.touchMaskCount += count;
        this.touchMask.active = true;
    };
    /**移除一层遮罩，遮罩层数为0时玩家才能进行操作 */
    GameDirector.prototype.hideTouchMask = function (count) {
        if (count === void 0) { count = 1; }
        this.touchMaskCount -= count;
        if (this.touchMaskCount <= 0) {
            this.touchMaskCount = 0;
            this.touchMask.active = false;
        }
    };
    //#endregion
    //#region 关卡暂停/继续快捷方法
    /**暂停关卡 */
    GameDirector.prototype.pauseLevel = function () {
        this.emit(GameEventType_1.EventType.DirectorEvent.pauseLevel);
    };
    /**恢复关卡 */
    GameDirector.prototype.resumeLevel = function () {
        this.emit(GameEventType_1.EventType.DirectorEvent.resumeLevel);
    };
    //#endregion
    //#region UI显隐快捷方法
    GameDirector.prototype.showUI = function (ui, data) {
        this.emit(GameEventType_1.EventType.UIEvent.enter, ui, data);
    };
    GameDirector.prototype.showUIs = function (uis) {
        for (var i = uis.length - 1; i >= 0; --i) {
            this.emit(GameEventType_1.EventType.UIEvent.enter, uis[i]);
        }
    };
    GameDirector.prototype.hideUI = function (ui) {
        this.emit(GameEventType_1.EventType.UIEvent.exit, ui);
    };
    GameDirector.prototype.hideUIs = function (uis) {
        for (var i = uis.length - 1; i >= 0; --i) {
            this.emit(GameEventType_1.EventType.UIEvent.exit, uis[i]);
        }
    };
    GameDirector.prototype.initDefaultUIs = function () {
        for (var i = this.defaultUIs.length - 1; i >= 0; --i) {
            this.defaultUIs[i].init();
            this.defaultUIs[i].hide();
        }
    };
    GameDirector.prototype.initUIConfig = function () {
        this.lobbyUIs = [];
        this.lobbyUIs.push(GlobalEnum_1.GlobalEnum.UI.lobby);
        this.lobbyUIs.push(GlobalEnum_1.GlobalEnum.UI.shop);
        this.lobbyUIs.push(GlobalEnum_1.GlobalEnum.UI.chooseLevel);
        this.levelUIs = [];
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.levelInfo);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.levelTeach);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.winUI);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.loseUI);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.trySkin);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.pauseLevel);
        this.levelUIs.push(GlobalEnum_1.GlobalEnum.UI.resurgence);
        this.persistUIs = [];
        this.persistUIs.push(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
        this.persistUIs.push(GlobalEnum_1.GlobalEnum.UI.tipPower);
        this.persistUIs.push(GlobalEnum_1.GlobalEnum.UI.getPower);
        this.persistUIs.push(GlobalEnum_1.GlobalEnum.UI.configSetting);
    };
    GameDirector.prototype.initActMng = function () {
        this.uiActMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.UI);
    };
    //#endregion
    /************************************游戏流程************************************/
    //#region 脚本通用流程
    GameDirector.prototype.init = function () {
        this.initUIConfig();
        this.initActMng();
        this.initTouchMask();
        this.initModels();
        this.initDefaultUIs();
        this.onEvents();
    };
    GameDirector.prototype.initModels = function () {
        //互推
        var node = this.node.getChildByName("Recommend");
        if (!!node && node.active) {
            RecommendManager_1.default.init(node);
        }
        //广告
        // AdvertManager.init();
        //UI
        UIManager_1.default.init(this.node.getChildByName("UI"));
        //todo:测试：重置玩家数据，需要再次重置时，将needResetPlayerData字符串最后一位数字加1
        var resetPlayerData = cc.sys.localStorage.getItem(GameConfig_1.default.gameName + "needResetPlayerData1");
        if (!resetPlayerData) {
            cc.sys.localStorage.setItem(GameConfig_1.default.gameName + "needResetPlayerData1", JSON.stringify(true));
        }
        PlayerData_1.default.init();
        AudioManager_1.default.init();
        GameData_1.default.init();
        PowerManager_1.default.init();
    };
    GameDirector.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.DirectorEvent.startGame, this.onStartGame, this);
        this.on(GameEventType_1.EventType.DirectorEvent.enterLobby, this.enterGameLobby, this);
        this.on(GameEventType_1.EventType.DirectorEvent.playNextLevel, this.onPlayNextLevel, this);
        this.on(GameEventType_1.EventType.DirectorEvent.replayCurLevel, this.onReplayCurLevel, this);
        this.on(GameEventType_1.EventType.DirectorEvent.playerWin, this.onLevelWin, this);
        this.on(GameEventType_1.EventType.DirectorEvent.playerLose, this.onLevelLose, this);
        this.on(GameEventType_1.EventType.DirectorEvent.hideGameLobby, this.hideGameLobbyUI, this);
        this.on(GameEventType_1.EventType.DirectorEvent.chooseTrySkinFinish, this.onChooseTrySkinFinish, this);
        this.on(GameEventType_1.EventType.UIEvent.showTouchMask, this.showTouchMask, this);
        this.on(GameEventType_1.EventType.UIEvent.hideTouchMask, this.hideTouchMask, this);
    };
    GameDirector.prototype.reset = function () {
        this.exitLevel();
        this.resetTouchMask();
    };
    //#endregion
    //#region 游戏数据加载
    /**加载全部游戏数据（json文件） */
    GameDirector.prototype.loadGameData = function () {
        var _this = this;
        Loader_1.default.loadBundle("GameData", function () {
            Loader_1.default.loadBundleDir("GameData", "JSONData", function (res) {
                var urls = [];
                for (var i = 0, c = res.length; i < c; ++i) {
                    urls.push(res[i].name);
                }
                GameData_1.default.setData(res, urls);
                _this.enterGameLobby();
            }, cc.JsonAsset, true);
        }, true, true);
    };
    //#endregion
    //#region 游戏流程：进入/退出首页
    //进入首页
    GameDirector.prototype.enterGameLobby = function () {
        if (!!this.levelMng) {
            this.levelMng.exit();
        }
        this.showGameLobbyUI();
    };
    //显示首页UI
    GameDirector.prototype.showGameLobbyUI = function () {
        this.hideUIs(this.levelUIs);
        this.hideUIs(this.persistUIs);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.lobby);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
    };
    //隐藏首页UI 
    GameDirector.prototype.hideGameLobbyUI = function () {
        this.hideUIs(this.lobbyUIs);
        this.hideUIs(this.persistUIs);
        this.hideUI(GlobalEnum_1.GlobalEnum.UI.lobby);
    };
    //#endregion
    //#region 游戏流程：进入关卡
    //开始游戏：
    GameDirector.prototype.onStartGame = function () {
        if (!this.levelMng) {
            Loader_1.default.loadBundle("LevelScene", this.loadLevelCommonAsset.bind(this), true, true);
        }
        else {
            this.enterLevel();
        }
    };
    //加载关卡场景所需的通用资源并创建对象池
    GameDirector.prototype.loadLevelCommonAsset = function () {
        var _this = this;
        Loader_1.default.loadBundleDir("LevelScene", "MultiplePrefab", function (assets) {
            for (var i = assets.length - 1; i >= 0; --i) {
                var prefab = assets[i];
                GlobalPool_1.default.createPool(prefab.name, prefab, prefab.name);
            }
            _this.loadLevelManager();
        });
    };
    //加载关卡场景管理器
    GameDirector.prototype.loadLevelManager = function () {
        var _this = this;
        Loader_1.default.loadBundleRes("LevelScene", "SinglePrefab/LevelManager", function (res) {
            var node = cc.instantiate(res);
            _this.node.getChildByName("LevelManager").addChild(node);
            _this.levelMng = node.getComponent("LevelManager");
            _this.levelMng.init();
            _this.enterLevel();
        });
    };
    //进入关卡
    GameDirector.prototype.enterLevel = function (level) {
        if (!level) {
            level = this.getCurLevel();
        }
        //进入关卡:
        this.hideGameLobbyUI();
        this.hideUIs(this.levelUIs);
        var levelData = this.getLevelData(level);
        this.levelMng.enterLevel(levelData);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.levelInfo, levelData);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
        // this.showTeachAnim();
        // this.showTrySkin();
    };
    //获取玩家当前能进入的关卡
    GameDirector.prototype.getCurLevel = function () {
        return PlayerData_1.default.getData("gameData.curLevel");
    };
    //获取关卡数据
    GameDirector.prototype.getLevelData = function (level) {
        // level = 2;
        var data = GameData_1.default.getLevelData(level);
        // let data = GameData.getLevelData(14);
        data.id = level;
        data.lv = level;
        return data;
    };
    //皮肤试用界面
    GameDirector.prototype.showTrySkin = function () {
        this.pauseLevel();
        this.showUI(GlobalEnum_1.GlobalEnum.UI.trySkin, GlobalEnum_1.GlobalEnum.GoodsType.playerSkin);
    };
    //试用皮肤流程结束(不论玩家是否选择了试用皮肤)
    GameDirector.prototype.onChooseTrySkinFinish = function () {
        this.hideUI(GlobalEnum_1.GlobalEnum.UI.trySkin);
        this.showTeachAnim();
    };
    //显示教学动画
    GameDirector.prototype.showTeachAnim = function () {
        // let teached = cc.sys.localStorage.getItem(GameConfig.gameName + "teached");
        // if (!!teached && !!JSON.parse(teached)) return;
        this.pauseLevel();
        this.showUI(GlobalEnum_1.GlobalEnum.UI.levelTeach);
    };
    //#endregion
    //#region 游戏流程：关卡胜利
    //关卡胜利
    GameDirector.prototype.onLevelWin = function () {
        this.addCurLevel();
        this.showUI(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.winUI);
    };
    //关卡进度+1
    GameDirector.prototype.addCurLevel = function () {
        this.emit(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, {
            type: "gameData",
            attribute: "gameData.curLevel",
            value: 1,
            mode: "+",
        });
    };
    //#endregion
    //#region 游戏流程：胜利后继续下一关
    //继续下一关
    GameDirector.prototype.onPlayNextLevel = function () {
        this.exitCurLevel();
        this.putBackCurLevelAsset();
        this.enterLevel();
    };
    //退出当前关卡
    GameDirector.prototype.exitCurLevel = function () {
        this.levelMng.exit();
    };
    //回收当前关卡使用的资源
    GameDirector.prototype.putBackCurLevelAsset = function () {
    };
    //#endregion
    //#region 游戏流程：关卡失败
    //关卡失败
    GameDirector.prototype.onLevelLose = function () {
        this.showUI(GlobalEnum_1.GlobalEnum.UI.playerAssetBar);
        this.showUI(GlobalEnum_1.GlobalEnum.UI.loseUI);
    };
    //#endregion
    //#region 游戏流程：失败后重玩
    //重玩当前关卡
    GameDirector.prototype.onReplayCurLevel = function () {
        this.resetCurLevel();
        this.putBackCurLevelAsset();
        this.enterLevel();
    };
    //重置当前关卡状态
    GameDirector.prototype.resetCurLevel = function () {
        this.levelMng.reset();
    };
    //#endregion
    //#region 游戏流程：返回首页
    //返回首页
    GameDirector.prototype.onComeBackGameLobby = function () {
        this.exitLevel();
        this.putBackLevelAsset();
        this.showGameLobbyUI();
    };
    //彻底退出关卡场景
    GameDirector.prototype.exitLevel = function () {
        if (!!this.levelMng)
            this.levelMng.exit();
    };
    //回收关卡场景的全部资源
    GameDirector.prototype.putBackLevelAsset = function () {
    };
    __decorate([
        property(cc.Node)
    ], GameDirector.prototype, "bg", void 0);
    __decorate([
        property(cc.Node)
    ], GameDirector.prototype, "touchMask", void 0);
    __decorate([
        property([yyComponent_1.default])
    ], GameDirector.prototype, "defaultUIs", void 0);
    GameDirector = __decorate([
        ccclass
    ], GameDirector);
    return GameDirector;
}(yyComponent_1.default));
exports.default = GameDirector;

cc._RF.pop();