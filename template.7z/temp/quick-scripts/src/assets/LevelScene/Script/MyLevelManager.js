"use strict";
cc._RF.push(module, '96965tMQ3pGBpQf/2vNsU/8', 'MyLevelManager');
// LevelScene/Script/MyLevelManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var LevelManager_1 = require("./LevelManager");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var LevelCamera_1 = require("./LevelCamera");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MyLevelManager = /** @class */ (function (_super) {
    __extends(MyLevelManager, _super);
    function MyLevelManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //#endregion
        //#region 相机
        _this.camera = null;
        return _this;
    }
    /**************************************************通用流程**************************************************/
    //#region 初始化
    MyLevelManager.prototype.init = function () {
        this.initCamera();
        this.initCustomUpdateState();
        this.initLevelTimer();
        this.initActMng();
        this.initEnterLobbyState();
        this.loadLobbyItems();
        this.registAllCustomUpdate();
        this.onEvents();
    };
    MyLevelManager.prototype.registAllCustomUpdate = function () {
        //通用状态
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.playing, this.stepLevelPlaying);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.win, this.stepLevelWin);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.lose, this.stepLevelLose);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.lobby, this.stepLobby);
        //其他状态
    };
    MyLevelManager.prototype.onEvents = function () {
        //游戏总流程相关
        this.on(GameEventType_1.EventType.DirectorEvent.pauseLevel, this.pause, this);
        this.on(GameEventType_1.EventType.DirectorEvent.resumeLevel, this.resume, this);
        //游戏玩法相关
        this.on(GameEventType_1.EventType.LevelEvent.testLose, this.onTestLose, this);
        this.on(GameEventType_1.EventType.LevelEvent.testWin, this.onTestWin, this);
    };
    /**加载进入首页时必须显示的内容 */
    MyLevelManager.prototype.loadLobbyItems = function () {
    };
    //#endregion
    //#region 重置
    MyLevelManager.prototype.reset = function () {
        this.resetCamera();
        this.resetCustomUpdateState();
        this.resetLevelTimer();
    };
    //#endregion
    /**************************************************对外功能**************************************************/
    //#region 进入关卡
    //进入关卡，设置关卡数据，启动关卡控制器，开始游戏
    MyLevelManager.prototype.enterLevel = function (levelData) {
        this.node.active = true;
        if (this.needLoadCount <= 0) {
            this.reset();
            this.levelData = levelData;
            this._enterLevel();
        }
        else {
            this.levelData = levelData;
            this.nextState = GlobalEnum_1.GlobalEnum.LevelState.playing;
        }
    };
    MyLevelManager.prototype._enterLevel = function () {
        this.setData();
        this.startLevel();
    };
    MyLevelManager.prototype.setData = function () {
        //关卡内容
        //玩家
        //相机
    };
    //#endregion
    //#region 教学脚本
    MyLevelManager.prototype.setTeachCmp = function (js) {
    };
    //#endregion
    //#region 进入首页
    /**设置在首页中作为背景时需要显示的内容 */
    MyLevelManager.prototype.setEnterLobbyData = function () {
    };
    //#endregion
    /**************************************************管理对象**************************************************/
    //#region  玩家
    // protected player:Player = null;
    MyLevelManager.prototype.initPlayer = function () {
    };
    MyLevelManager.prototype.resetPlayer = function () {
    };
    MyLevelManager.prototype.setPlayer = function () {
    };
    MyLevelManager.prototype.updatePlayer = function (dt) {
    };
    MyLevelManager.prototype.initCamera = function () {
        this.camera.init();
    };
    MyLevelManager.prototype.resetCamera = function () {
        this.camera.reset();
    };
    MyLevelManager.prototype.updateCamera = function (dt) {
        this.camera.customUpdate(dt);
    };
    //#endregion
    /**************************************************流程**************************************************/
    //#region 游戏中
    MyLevelManager.prototype.stepLevelPlaying = function (dt) {
        this.updateCamera(dt);
        this.updatePlayer(dt);
    };
    //#endregion
    //#region 胜利
    MyLevelManager.prototype.stepLevelWin = function (dt) {
    };
    /**关卡胜利的成绩 */
    MyLevelManager.prototype.getWinData = function () {
        var data = {};
        data.lv = this.levelData.lv;
        return data;
    };
    //#endregion
    //#region 失败
    MyLevelManager.prototype.stepLevelLose = function (dt) {
    };
    //#endregion
    //#region 状态：首页中
    MyLevelManager.prototype.stepLobby = function (dt) {
        // this.updateCamera(dt);
    };
    //#endregion
    /**************************************************事件**************************************************/
    MyLevelManager.prototype.onTestWin = function () {
        this.win();
    };
    MyLevelManager.prototype.onTestLose = function () {
        this.lose();
    };
    __decorate([
        property(LevelCamera_1.default)
    ], MyLevelManager.prototype, "camera", void 0);
    MyLevelManager = __decorate([
        ccclass
    ], MyLevelManager);
    return MyLevelManager;
}(LevelManager_1.default));
exports.default = MyLevelManager;

cc._RF.pop();