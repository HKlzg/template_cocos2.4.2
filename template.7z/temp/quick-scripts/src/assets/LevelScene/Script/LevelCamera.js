"use strict";
cc._RF.push(module, 'ade43+9RZtE46LoF1vdxOuA', 'LevelCamera');
// Level/Script/LevelCamera.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**关卡中使用的3D相机 */
var LevelCamera = /** @class */ (function (_super) {
    __extends(LevelCamera, _super);
    function LevelCamera() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**相机组件 */
        _this.camera = null;
        /**相机组件所在节点 */
        _this.cameraNode = null;
        /**相机朝向的节点 */
        _this.anchorNode = null;
        return _this;
    }
    LevelCamera.prototype.initOriginalTransform = function () {
        this._originalPos = cc.v3();
        this.cameraNode.getPosition(this._originalPos);
        this._originalEulerAngles = cc.v3();
        this._originalEulerAngles.set(this.cameraNode.eulerAngles);
    };
    /**恢复到原始视角 */
    LevelCamera.prototype.resumeOriginalTransform = function (duration, cb) {
        if (duration === void 0) { duration = 0; }
        if (!duration) {
            this.cameraNode.setPosition(this._originalPos);
            this.cameraNode.eulerAngles = this._originalEulerAngles;
            return;
        }
        this.changeCamera({
            duration: duration,
            pos: this._originalPos,
            angle: this._originalEulerAngles,
            cb: cb
        });
    };
    /**视角切换 */
    LevelCamera.prototype.changeCamera = function (data) {
        if (!data.duration) {
            if (!!data.pos)
                this.cameraNode.setPosition(data.pos);
            if (!!data.angle)
                this.cameraNode.eulerAngles = data.angle;
            if (!!data.cb)
                data.cb();
            return;
        }
        var move = null;
        var rotate = null;
        if (!!data.pos) {
            move = Action3dManager_1.default.moveTo(data.duration, data.pos);
        }
        if (!!data.angle) {
            rotate = Action3dManager_1.default.rotateTo(data.duration, data.angle);
        }
        var spawn = null;
        if (!!move && !!rotate) {
            spawn = Action3dManager_1.default.spawn(move, rotate);
        }
        else if (!!move) {
            spawn = Action3dManager_1.default.spawn(move);
        }
        else if (!!rotate) {
            spawn = Action3dManager_1.default.spawn(rotate);
        }
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.Level);
        if (!!spawn && !!data.cb) {
            var callFun = Action3dManager_1.default.callFun(data.cb);
            var sequence = Action3dManager_1.default.sequence(spawn, callFun);
            actMng.runAction(this.cameraNode, sequence);
        }
        else if (!!spawn) {
            actMng.runAction(this.cameraNode, spawn);
        }
        else if (!!data.cb) {
            data.cb();
        }
    };
    LevelCamera.prototype.init = function () {
        this.anchorNode = this.node;
        this.camera = this.node.getComponentInChildren(cc.Camera);
        this.cameraNode = this.camera.node;
        this.customStep = this.stepSlowFollow;
        this.adaptViewForWidth();
        this.initOriginalTransform();
    };
    //按宽度适配，保持水平方向的视野范围不变
    LevelCamera.prototype.adaptViewForWidth = function () {
        var p = cc.v3();
        this.cameraNode.getPosition(p);
        var L1 = Math.sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
        var H2 = cc.find("Canvas").height;
        var fov = this.camera.fov;
        var h = L1 * Math.tan(fov * 0.5 * 0.017453);
        h = h * H2 / 1334; //1334：设计分辨率
        var f2 = Math.atan2(h, L1) * 2 * 57.3;
        this.camera.fov = f2;
    };
    LevelCamera.prototype.reset = function () {
        this.followTarget = null;
        this.resumeOriginalTransform();
    };
    LevelCamera.prototype.setTarget = function (followTarget) {
        this.followTarget = followTarget;
        // let pos = cc.v3();
        // this.followTarget.getPosition(pos);
        // this.anchorNode.setPosition(pos);
        this.anchorNode.setPosition(this.followTarget.x, 0, this.followTarget.z);
    };
    LevelCamera.prototype.stepSlowFollow = function (dt) {
        if (!this.followTarget)
            return;
        //无缓动跟随：
        // this.anchorNode.setPosition(this.followTarget.x, this.followTarget.y, this.followTarget.z);
        this.anchorNode.setPosition(this.followTarget.x, 0, this.followTarget.z);
        // let pos = cc.v3();
        // this.followTarget.getPosition(pos);
        // this.convertWorldToScreen(pos);
        //缓动跟随：
        // let p1 = cc.v3();
        // this.followTarget.getPosition(p1);
        // let p2 = cc.v3();
        // this.anchorNode.getPosition(p2);
        // let offset = p1.subtract(p2);
        // // offset.multiplyScalar(dt);//todo:是否缓动跟随
        // this.anchorNode.setPosition(p2.addSelf(offset));
    };
    /**移动到指定位置 */
    LevelCamera.prototype.moveTo = function (duration, pos, cb) {
        var actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.Level);
        var action = Action3dManager_1.default.moveTo(duration, pos);
        action.easing(Action3dManager_1.default.easeOut(3));
        if (!!cb) {
            var callFun = Action3dManager_1.default.callFun(cb);
            actMng.runAction(this.node, Action3dManager_1.default.sequence(action, callFun));
        }
        else {
            actMng.runAction(this.node, action);
        }
    };
    /****************************************坐标转换****************************************/
    /**世界坐标转屏幕坐标 */
    LevelCamera.prototype.convertWorldToScreen = function (pos) {
        var p = this.convertWorldToCanvas(pos);
        var cvs = cc.find("Canvas");
        p.x + cvs.width * 0.5;
        p.y += cvs.height * 0.5;
        return p;
    };
    /**世界坐标转换到Canvas节点坐标 */
    LevelCamera.prototype.convertWorldToCanvas = function (pos) {
        var p = this.convertWorldToCamera(pos);
        var angle = this.camera.fov;
        var z = p.z;
        var tan = Math.tan(angle * 0.5 * 0.017453);
        var h = Math.abs(z * tan);
        var x = p.x / h;
        var y = p.y / h;
        var cvs = cc.find("Canvas");
        y = cvs.height * 0.5 * y;
        x = cvs.height * 0.5 * x;
        return cc.v2(x, y);
    };
    /**世界坐标转换到相机坐标系 */
    LevelCamera.prototype.convertWorldToCamera = function (pos) {
        var center = this.getCameraPos();
        var eulerAngler = this.getCameraEulerAngles();
        var angle = eulerAngler.y;
        var p1 = cc.v2(pos.x - center.x, pos.z - center.z);
        p1 = this.rotatePos(p1, angle);
        angle = eulerAngler.x;
        var p2 = cc.v2(p1.y, pos.y - center.y);
        p2 = this.rotatePos(p2, angle);
        // return cc.v3(p1.x + center.x, p2.x + center.y, p2.y + center.z);
        return cc.v3(p1.x, p2.y, p2.x);
    };
    /**相机的世界坐标 */
    LevelCamera.prototype.getCameraPos = function () {
        var angle = this.node.eulerAngles.y;
        var p = this.rotatePos(cc.v2(this.cameraNode.x, this.cameraNode.z), -angle);
        return cc.v3(p.x + this.node.x, this.cameraNode.y + this.node.y, p.y + this.node.z);
    };
    /**相机在世界坐标系下的旋转角度 */
    LevelCamera.prototype.getCameraEulerAngles = function () {
        return cc.v3(this.cameraNode.eulerAngles.x, this.node.eulerAngles.y, 0);
    };
    /**
     * 旋转坐标点
     * @param p 坐标点
     * @param angle 旋转角度，负数表示顺时针旋转，正数表示逆时针旋转
     */
    LevelCamera.prototype.rotatePos = function (p, angle) {
        var radian = angle * 0.017453;
        var sin = Math.sin(radian);
        var cos = Math.cos(radian);
        var x = p.x * cos - p.y * sin;
        var y = p.x * sin + p.y * cos;
        return cc.v2(x, y);
    };
    /**
     * 将节点坐标系下的坐标点转换为其父节点坐标系下的坐标
     * @param node 节点
     * @param pos 坐标点
     */
    LevelCamera.prototype.convertToParent = function (node, pos) {
        var p = cc.v3(pos.x * node.scaleX, pos.y * node.scaleY, pos.z * node.scaleZ);
        var p1 = cc.v2(p.x, p.z);
        p1 = this.rotatePos(p1, node.eulerAngles.y);
        var p2 = cc.v2(p1.y, p.y);
        p2 = this.rotatePos(p2, node.eulerAngles.x);
        p.x = p1.x + node.x;
        p.y = p2.y + node.y;
        p.z = p2.x + node.z;
        return p;
    };
    /**
     * 将子节点坐标系下的坐标点转换到根节点坐标系
     * @param root 根节点
     * @param node 子节点
     * @param pos 要转换的坐标点
     */
    LevelCamera.prototype.convertToNodePos = function (root, node, pos) {
        var p = cc.v3();
        p.set(pos);
        while (!!node && node.is3DNode && node != root) {
            p = this.convertToParent(node, p);
            node = node.parent;
        }
        return p;
    };
    __decorate([
        property(cc.Camera)
    ], LevelCamera.prototype, "camera", void 0);
    __decorate([
        property(cc.Node)
    ], LevelCamera.prototype, "cameraNode", void 0);
    __decorate([
        property(cc.Node)
    ], LevelCamera.prototype, "anchorNode", void 0);
    LevelCamera = __decorate([
        ccclass
    ], LevelCamera);
    return LevelCamera;
}(yyComponent_1.default));
exports.default = LevelCamera;

cc._RF.pop();