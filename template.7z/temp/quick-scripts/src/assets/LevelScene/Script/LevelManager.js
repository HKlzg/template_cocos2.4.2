"use strict";
cc._RF.push(module, '8a3a1r8py9NEZq3f4jOfVcp', 'LevelManager');
// LevelScene/Script/LevelManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../../Script/Common/yyComponent");
var GameEventType_1 = require("../../Script/GameSpecial/GameEventType");
var Action3dManager_1 = require("../../Script/Common/Action3dManager");
var GlobalEnum_1 = require("../../Script/GameSpecial/GlobalEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//关卡管理器
var LevelManager = /** @class */ (function (_super) {
    __extends(LevelManager, _super);
    function LevelManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.pauseCount = 0;
        //#endregion
        //#region 对象
        /**关卡中动态添加的模型节点存放层 */
        _this.levelLayer = null;
        //#endregion
        //#region 动作管理器
        _this.actMng = null;
        //#endregion
        //#region 游戏进入首页，关卡场景作为背景
        _this.nextState = null;
        _this.needLoadCount = 0;
        return _this;
        //#endregion
    }
    /**************************************************************通用流程**************************************************************/
    //#region 初始化
    LevelManager.prototype.init = function () {
        this.initComponents();
        this.initCustomUpdateState();
        this.initLevelTimer();
        this.initActMng();
        this.initEnterLobbyState();
        this.loadLobbyItems();
        this.registAllCustomUpdate();
        this.onEvents();
        cc.warn("关卡管理器的init需由子类实现");
    };
    LevelManager.prototype.registAllCustomUpdate = function () {
        cc.warn("关卡管理器的registAllCustomUpdate需由子类实现");
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.lobby, this.stepLobby);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.win, this.stepLevelWin);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.lose, this.stepLevelLose);
        this.registCustomUpdate(GlobalEnum_1.GlobalEnum.LevelState.playing, this.stepLevelPlaying);
    };
    LevelManager.prototype.onEvents = function () {
        cc.warn("关卡管理器的onEvents需由子类实现");
        this.on(GameEventType_1.EventType.DirectorEvent.pauseLevel, this.pause, this);
        this.on(GameEventType_1.EventType.DirectorEvent.resumeLevel, this.resume, this);
    };
    /**加载进入首页时必须显示的内容 */
    LevelManager.prototype.loadLobbyItems = function () {
    };
    //#endregion
    //#region 重置
    LevelManager.prototype.reset = function () {
        //回收关卡中的对象
        this.resetCustomUpdateState();
        this.resetLevelTimer();
    };
    Object.defineProperty(LevelManager.prototype, "paused", {
        get: function () { return this.isPaused; },
        enumerable: false,
        configurable: true
    });
    /**暂停关卡运行 */
    LevelManager.prototype.pause = function (count) {
        if (count === void 0) { count = 1; }
        this.pauseCount += count;
        this.isPaused = true;
    };
    /**
     * 继续关卡运行
     * @param count 值为-1时强制恢复关卡运行
     */
    LevelManager.prototype.resume = function (count) {
        if (count === void 0) { count = 1; }
        if (count === -1) {
            this.pauseCount = 0;
            this.isPaused = false;
        }
        else {
            this.pauseCount -= count;
            if (this.pauseCount <= 0) {
                this.pauseCount = 0;
                this.isPaused = false;
            }
        }
    };
    LevelManager.prototype.initLevelTimer = function () {
        this.elapseTimer = 0;
        this.isPaused = false;
        this.pauseCount = 0;
    };
    LevelManager.prototype.resetLevelTimer = function () {
        this.elapseTimer = 0;
        this.isPaused = false;
        this.pauseCount = 0;
    };
    //自定义的每帧更新函数，由计时器执行
    LevelManager.prototype.customUpdate = function () {
        if (this.isPaused)
            return;
        var d = Date.now();
        var dt = d - this.lastFrameTime;
        this.lastFrameTime = d;
        if (dt > 34)
            dt = 34; //避免苹果手机打开下拉菜单再回来，dt值过大
        dt *= 0.001; //单位转换为秒
        this.elapseTimer += dt;
        if (!!this.customStep) {
            this.customStep(dt);
        }
    };
    LevelManager.prototype.running = function (dt) {
        if (!this.isPaused) {
            this.updateAction(dt);
            if (!!this.customStep)
                this.customStep(dt);
        }
    };
    LevelManager.prototype.getLevelData = function () {
        return this.levelData;
    };
    LevelManager.prototype.initActMng = function () {
        this.actMng = Action3dManager_1.default.getMng(Action3dManager_1.ActionMngType.Level);
    };
    LevelManager.prototype.updateAction = function (dt) {
        this.actMng.update(dt);
    };
    //#endregion
    /**************************************************************对外功能**************************************************************/
    //#region 进入关卡
    //进入关卡，设置关卡数据，启动关卡控制器，开始游戏
    LevelManager.prototype.enterLevel = function (levelData) {
        this.node.active = true;
        if (this.needLoadCount <= 0) {
            this.reset();
            this.levelData = levelData;
            this._enterLevel();
        }
        else {
            this.levelData = levelData;
            this.nextState = GlobalEnum_1.GlobalEnum.LevelState.playing;
        }
    };
    LevelManager.prototype._enterLevel = function () {
        this.setData();
        this.startLevel();
    };
    //关卡数据设置完毕，开始运行关卡进行游戏
    LevelManager.prototype.startLevel = function () {
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.playing);
        this.lastFrameTime = Date.now();
        // this.schedule(this.customUpdate, 0.016);
        this.emit(GameEventType_1.EventType.CtrlEvent.ctrlStart);
        this.emit(GameEventType_1.EventType.AudioEvent.playBGM, GlobalEnum_1.GlobalEnum.AudioClip.BGM, true);
        // this.emit(EventType.SDKEvent.startRecord);
        var lv = this.levelData.lv;
        if (undefined === lv) {
            lv = this.levelData.id;
        }
        this.emit(GameEventType_1.EventType.ALDEvent.levelStart, lv);
        this.emit(GameEventType_1.EventType.UIEvent.showTip, "关卡开始！"); //todo:测试用
    };
    //#endregion
    //#region 教学脚本
    LevelManager.prototype.setTeachCmp = function (js) { };
    //#endregion
    //#region 退出关卡
    //退出关卡
    LevelManager.prototype.exit = function () {
        this.reset();
        // this.node.active = false;
        // this.unschedule(this.customUpdate);
    };
    LevelManager.prototype.initEnterLobbyState = function () {
        this.nextState = null;
        this.needLoadCount = 0;
        console.warn("进入首页必须加载的预制件数量为：", this.needLoadCount);
    };
    LevelManager.prototype.enterLobby = function () {
        if (this.needLoadCount <= 0) {
            this.reset();
            this.setEnterLobbyData();
            this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.lobby);
        }
        else {
            this.nextState = GlobalEnum_1.GlobalEnum.LevelState.lobby;
        }
    };
    LevelManager.prototype.setEnterLobbyData = function () {
        console.log("设置关卡场景作为首页背景时的数据，由子类实现");
    };
    LevelManager.prototype.loadLobbyItemFinish = function () {
        this.needLoadCount--;
        if (this.needLoadCount <= 0) {
            switch (this.nextState) {
                case GlobalEnum_1.GlobalEnum.LevelState.lobby: {
                    this.setEnterLobbyData();
                    this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.lobby);
                    break;
                }
                case GlobalEnum_1.GlobalEnum.LevelState.playing: {
                    this._enterLevel();
                    break;
                }
            }
            this.emit(GameEventType_1.EventType.LevelEvent.levelSceneLoadFinish);
        }
    };
    //#endregion
    /**************************************************************流程**************************************************************/
    //#region 基础流程，子类实现
    //关卡进行中
    LevelManager.prototype.stepLevelPlaying = function (dt) {
        // console.log("关卡管理器子类未实现方法stepLevelPlaying");
    };
    //关卡胜利
    LevelManager.prototype.stepLevelWin = function (dt) {
        // console.log("关卡管理器子类未实现方法stepLevelWin");
    };
    //关卡失败
    LevelManager.prototype.stepLevelLose = function (dt) {
        // console.log("关卡管理器子类未实现方法stepLevelLose");
    };
    //游戏流程为显示首页，关卡场景作为背景
    LevelManager.prototype.stepLobby = function (dt) {
        // console.log("关卡管理器子类未实现方法stepLobby");
    };
    //#endregion
    /**************************************************************功能**************************************************************/
    //#region 结算
    /**玩家胜利 */
    LevelManager.prototype.win = function (data) {
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.win);
        this.emit(GameEventType_1.EventType.CtrlEvent.ctrlEnd);
        this.emit(GameEventType_1.EventType.DirectorEvent.playerWin, data);
        this.emit(GameEventType_1.EventType.AudioEvent.stopBGM);
        this.emit(GameEventType_1.EventType.AudioEvent.playEffect, GlobalEnum_1.GlobalEnum.AudioClip.win);
        // this.emit(EventType.SDKEvent.stopRecord);
        var lv = this.levelData.lv;
        if (undefined === lv) {
            lv = this.levelData.id;
        }
        this.emit(GameEventType_1.EventType.ALDEvent.levelWin, lv);
        this.emit(GameEventType_1.EventType.PlayerDataEvent.trySkinEnd, GlobalEnum_1.GlobalEnum.GoodsType.playerSkin);
    };
    /**玩家失败 */
    LevelManager.prototype.lose = function (data) {
        this.enterCustomUpdateState(GlobalEnum_1.GlobalEnum.LevelState.lose);
        this.emit(GameEventType_1.EventType.CtrlEvent.ctrlEnd);
        this.emit(GameEventType_1.EventType.DirectorEvent.playerLose, data);
        this.emit(GameEventType_1.EventType.AudioEvent.stopBGM);
        this.emit(GameEventType_1.EventType.AudioEvent.playEffect, GlobalEnum_1.GlobalEnum.AudioClip.lose);
        // this.emit(EventType.SDKEvent.stopRecord);
        var lv = this.levelData.lv;
        if (undefined === lv) {
            lv = this.levelData.id;
        }
        this.emit(GameEventType_1.EventType.ALDEvent.levelLose, lv);
        this.emit(GameEventType_1.EventType.PlayerDataEvent.trySkinEnd, GlobalEnum_1.GlobalEnum.GoodsType.playerSkin);
    };
    __decorate([
        property(cc.Node)
    ], LevelManager.prototype, "levelLayer", void 0);
    LevelManager = __decorate([
        ccclass
    ], LevelManager);
    return LevelManager;
}(yyComponent_1.default));
exports.default = LevelManager;

cc._RF.pop();