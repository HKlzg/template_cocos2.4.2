"use strict";
cc._RF.push(module, 'da1cfQrGnNAE4bDQ9RN6h+7', 'GamePlatform');
// Script/Platform/GamePlatform.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GamePlatformConfig_1 = require("./GamePlatformConfig");
var GamePlatformType_1 = require("./GamePlatformType");
var SDK_1 = require("./SDK/SDK");
var WXSDK_1 = require("./SDK/WXSDK");
var TTSDK_1 = require("./SDK/TTSDK");
var OPPOSDK_1 = require("./SDK/OPPOSDK");
var VIVOSDK_1 = require("./SDK/VIVOSDK");
var QQSDK_1 = require("./SDK/QQSDK");
var PCSDK_1 = require("./SDK/PCSDK");
var GamePlatform = /** @class */ (function () {
    function GamePlatform() {
        this._config = null;
        this._sdk = null;
    }
    Object.defineProperty(GamePlatform, "instance", {
        get: function () {
            if (!GamePlatform._instance) {
                GamePlatform._instance = new GamePlatform();
            }
            return GamePlatform._instance;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GamePlatform.prototype, "Config", {
        /**
         * 平台设置参数
         */
        get: function () {
            return this._config;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GamePlatform, "SDK", {
        /**
         * SDK
         */
        get: function () {
            if (!GamePlatform.instance._sdk) {
                GamePlatform.instance.setDefaultSdk();
            }
            return GamePlatform.instance._sdk;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 初始化SDK
     */
    GamePlatform.prototype.init = function (param) {
        console.log(param);
        this._config = param;
        switch (param.type) {
            case GamePlatformType_1.GamePlatformType.PC:
                this._sdk = new SDK_1.default(); //默认不继承。
                break;
            case GamePlatformType_1.GamePlatformType.WX:
                this._sdk = new WXSDK_1.default();
                break;
            case GamePlatformType_1.GamePlatformType.TT:
                this._sdk = new TTSDK_1.default();
                break;
            case GamePlatformType_1.GamePlatformType.QQ:
                this._sdk = new QQSDK_1.default();
                break;
            case GamePlatformType_1.GamePlatformType.OPPO:
                this._sdk = new OPPOSDK_1.default();
                break;
            case GamePlatformType_1.GamePlatformType.VIVO:
                this._sdk = new VIVOSDK_1.default();
                break;
            default: {
                this._sdk = new PCSDK_1.default();
                break;
            }
        }
        this._sdk.init();
        this._sdk.onEvents();
        this._sdk.loadRecord();
    };
    /**
     * 设置默认sdk[PC];
     */
    GamePlatform.prototype.setDefaultSdk = function () {
        var param = new GamePlatformConfig_1.default();
        param.type = GamePlatformType_1.GamePlatformType.PC;
        param.appId = "";
        param.secret = "";
        param.share = true;
        param.video = true;
        param.banner = false;
        param.interstitial = false;
        param.vibrate = true;
        param.videoAdUnitId = [""];
        param.BannerAdUnitId = [""];
        param.InterstitialAdUnitId = [""];
        param.appBoxUnitId = [""];
        param.blockAdUnitId = [""];
        this.init(param);
    };
    return GamePlatform;
}());
exports.default = GamePlatform;

cc._RF.pop();