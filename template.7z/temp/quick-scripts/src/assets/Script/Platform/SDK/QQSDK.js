"use strict";
cc._RF.push(module, 'b3854A5MblBFaGgmx+n2v1Y', 'QQSDK');
// Script/Platform/SDK/QQSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var QQSDK = /** @class */ (function (_super) {
    __extends(QQSDK, _super);
    function QQSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'qq';
        //盒子广告
        _this.appBox = null;
        return _this;
    }
    QQSDK.prototype.init = function () {
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        console.log("QQ小游戏系统信息：");
        console.log(this.systemInfo);
        this.api.showShareMenu({ withShareTicket: false });
    };
    /**
     * 视频广告
     */
    QQSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        if (!this.canApiUseVideo()) {
            this.onVideoSuccess();
            return;
        }
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("获取视频id失败");
            return;
        }
        var rewardedVideoAd = this.api.createRewardedVideoAd({
            adUnitId: id,
        });
        rewardedVideoAd.onLoad(this.onVideoShow.bind(this));
        rewardedVideoAd.onError(this.onVideoFail.bind(this));
        var closefun = (function (res) {
            rewardedVideoAd.offLoad(_this.onVideoShow.bind(_this));
            rewardedVideoAd.offError(_this.onVideoFail.bind(_this));
            rewardedVideoAd.offClose(closefun);
            rewardedVideoAd = null;
            if (res && res.isEnded) {
                _this.onVideoSuccess();
            }
            else {
                _this.onVideoQuit();
                _this.onVideoHide();
            }
        });
        rewardedVideoAd.onClose(closefun);
        //开始加载视频广告
        rewardedVideoAd.load().then(function () {
            rewardedVideoAd.show().catch(function (err) {
                _this.onVideoFail(err);
                rewardedVideoAd.offLoad(_this.onVideoShow.bind(_this));
                rewardedVideoAd.offError(_this.onVideoFail.bind(_this));
                rewardedVideoAd.offClose(closefun);
                rewardedVideoAd = null;
            });
        });
    };
    /**能否使用api：video */
    QQSDK.prototype.canApiUseVideo = function () {
        return true;
    };
    /**
     * 打开banner
     */
    QQSDK.prototype.showBanner = function () {
        if (!this.canApiUseBanner()) {
            return;
        }
        // if (this.insertAdRecord.isShowing) {
        //     console.log("有插屏显示，不再显示banner");
        //     this.removeBanner();
        //     return;
        // }
        if (!!this._bannerAd) {
            this._bannerAd.show().then(this.onBannerShow.bind(this));
            return;
        }
        var id = this.getBannerId();
        if (!id)
            return;
        // this.removeBanner();
        var banner = this.createBanner(id);
        banner.show().then(this.onBannerShow.bind(this));
    };
    /**能否使用api：banner */
    QQSDK.prototype.canApiUseBanner = function () {
        return true;
    };
    QQSDK.prototype.createBanner = function (id) {
        var _this = this;
        this._bannerAd = this.api.createBannerAd({
            adUnitId: id,
            style: {
                left: 0,
                top: this.systemInfo.screenHeight - 130,
                width: this.systemInfo.screenWidth + 50,
            }
        });
        this._bannerAd.onError(this.onBannerErr.bind(this));
        // this._bannerAd.show().then(this.onBannerShow.bind(this));
        this._bannerAd.onResize(function (res) {
            if (_this.systemInfo.platform == "ios" && cc.visibleRect["height"] / cc.visibleRect["width"] >= 2) {
                console.log("苹果刘海屏手机调用banner");
                _this._bannerAd.style.top = _this.systemInfo.screenHeight - res.height - 20;
            }
            else {
                _this._bannerAd.style.top = _this.systemInfo.screenHeight - res.height;
            }
        });
        return this._bannerAd;
    };
    /**
     * 关闭广告
     */
    QQSDK.prototype.removeBanner = function () {
        if (this._bannerAd) {
            this._bannerAd.offError(this.onBannerErr.bind(this));
            this._bannerAd.offResize();
            this._bannerAd.destroy(); //要先把旧的广告给销毁，不然会导致其监听的事件无法释放，影响性能
            this._bannerAd = null;
        }
        //销毁当前banner后，立即创建新的banner，但不显示出来
        var id = this.getBannerId();
        if (!id)
            return;
        this.createBanner(id);
    };
    /**
     * 插屏广告
     */
    QQSDK.prototype.showInterstitialAd = function (banner) {
        var _this = this;
        if (banner === void 0) { banner = false; }
        this.showBanner();
        return;
        this.useBannerInsteadInsert = banner;
        if (!this.canApiUseInsert()) {
            this.showBannerInsteadInsert();
            return;
        }
        var id = this.getInsertAdUnitId();
        if (!id) {
            this.showBannerInsteadInsert();
            return;
        }
        var ad = this.api.createInterstitialAd({ adUnitId: id });
        // ad.show().then(() => {
        //     this.removeBanner();
        //     this.onInsertShow();
        // });
        try {
            ad.show().then(function () {
                _this.removeBanner();
                _this.onInsertShow();
            }).catch(function (err) {
                _this.onInsertErr(err);
                _this.showBannerInsteadInsert();
            });
        }
        catch (err) {
            this.onInsertErr(err);
            this.showBannerInsteadInsert();
        }
        ad.onClose(function () {
            _this.onInsertHide();
            ad.destroy();
        });
        ad.onError(function (err) {
            _this.onInsertErr(err);
            _this.showBannerInsteadInsert();
        });
    };
    /**能否使用api：insert */
    QQSDK.prototype.canApiUseInsert = function () {
        var version = this.systemInfo.SDKVersion;
        if (this.lessThan(version, '1.12.0')) {
            console.log('基础库版本低于1.12.0，插屏无法显示');
            return false;
        }
        return true;
    };
    /**
     * 短震动
     */
    QQSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    QQSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    QQSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ""; }
        var index = Math.floor((Math.random() * this.shareTitleArr.length));
        var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
        this.api.shareAppMessage({
            title: "" + this.shareTitleArr[index],
            imageUrl: "" + this.shareImgArr[indeximg],
            query: "" + query,
        });
    };
    /**
     * 激励分享&&带参分享
     */
    QQSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
        if (!GamePlatform_1.default.instance.Config.share) {
            // success();
            return;
        }
        this.shareAppMessage(query);
        success();
    };
    //订阅
    QQSDK.prototype.subscribeMsg = function (data) {
        if (undefined === data) {
            data = {
                subscribe: true,
                success: function (res) {
                    console.log("订阅成功");
                },
                fail: function (res) {
                    console.log("订阅失败");
                },
            };
        }
        this.api.subscribeAppMsg(data);
    };
    //彩签
    QQSDK.prototype.addColorSign = function (data) {
        if (this.lessThan(this.systemInfo.SDKVersion, "1.10.0")) {
            console.log("基础库版本低于1.10.0，无法使用彩签功能");
            return;
        }
        if (undefined === data) {
            data = {
                success: function (res) {
                    console.log("彩签添加成功,", res);
                },
                fail: function (res) {
                    console.log("彩签添加失败,", res);
                },
                complete: function (res) {
                    console.log("彩签接口调用完成，", res);
                }
            };
        }
        this.api.addColorSign(data);
    };
    QQSDK.prototype.showAppBox = function () {
        var _this = this;
        if (this.lessThan(this.systemInfo.SDKVersion, "1.7.1")) {
            console.log("基础库版本低于1.7.1，盒子广告无法显示");
            return;
        }
        if (!!this.appBox) {
            this.appBox.show();
            return;
        }
        var id = this.getAppBoxId();
        var appBox = this.api.createAppBox({
            adUnitId: id,
        });
        appBox.load().then(function () {
            console.log("盒子广告加载完成");
            appBox.show();
            console.log("盒子广告显示成功");
        }).catch(function (err) {
            console.log("盒子广告加载失败：", err);
            appBox.destroy();
            _this.appBox = null;
        });
        this.appBox = appBox;
    };
    //积木广告
    QQSDK.prototype.showBlockAd = function () {
    };
    return QQSDK;
}(SDK_1.default));
exports.default = QQSDK;

cc._RF.pop();