"use strict";
cc._RF.push(module, 'c40cdLxs1FA0ZE1thrryygV', 'WXSDK');
// Script/Platform/SDK/WXSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var EventManager_1 = require("../../Common/EventManager");
var WXSDK = /** @class */ (function (_super) {
    __extends(WXSDK, _super);
    function WXSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'wx';
        /**创建新的banner的时间 */
        _this.createBannerTime = 0;
        /**banner加载成功后是否需要立即显示 */
        _this.needShowBanner = false;
        /**banner是否已加载完毕 */
        _this.bannerLoaded = false;
        return _this;
    }
    WXSDK.prototype.init = function () {
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        console.log("系统信息：");
        console.log(JSON.stringify(this.systemInfo));
        // this.api.onShareAppMessage(() => ({}));
        this.api.showShareMenu({ withShareTicket: false });
        this.preCreateBanner();
    };
    WXSDK.prototype.triggerGC = function () {
        this.api.triggerGC();
    };
    //video
    WXSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("视频id获取失败");
            return;
        }
        if (!this.videoAd) {
            this.videoAd = this.api.createRewardedVideoAd({ adUnitId: id });
            this.videoAd.onLoad(function () {
                console.log("视频广告加载完毕");
            });
            this.videoAd.onError(function (err) {
                console.log("视频广告错误：", JSON.stringify(err));
            });
            this.videoAd.onClose(function (res) {
                // 小于 2.1.0 的基础库版本，res 是一个 undefined
                if (res && res.isEnded || res === undefined) {
                    _this.onVideoSuccess();
                }
                else {
                    _this.onVideoQuit();
                    _this.onVideoHide();
                }
            });
        }
        this.videoAd.show().then(this.onVideoShow.bind(this))
            .catch(function (err) {
            _this.videoAd.load()
                .then(function () {
                _this.videoAd.show().then(_this.onVideoShow.bind(_this));
            })
                .catch(_this.onVideoFail.bind(_this));
        });
    };
    /**
     * 打开banner
     */
    WXSDK.prototype.showBanner = function (cb) {
        var _this = this;
        // if (this.insertAdRecord.isShowing) {
        //     console.log("插屏广告正在显示，无法同时显示banner");
        //     this.removeBanner();
        //     return;
        // }
        if (this.bannerShowing)
            return;
        //已经创建了banner：
        if (!!this._bannerAd) {
            //创建的banner已经加载成功，直接显示：
            if (this.bannerLoaded) {
                this._bannerAd.show().then(function () {
                    _this.onBannerShow();
                    _this.bannerShowing = true;
                    if (!!cb) {
                        cb();
                    }
                });
            }
            else {
                //创建的banner还没加载完成时，设置标记，使其在加载完成后显示
                this.needShowBanner = true;
            }
        }
        else {
            //尚未创建banner，则设置标记，创建banner，并使其在加载完成后显示
            this.needShowBanner = true;
            this.preCreateBanner();
        }
    };
    /**预先创建banner，创建的banner在加载完成时，会根据 needShowBanner 确定是否需要立即显示 */
    WXSDK.prototype.preCreateBanner = function () {
        var _this = this;
        var id = this.getBannerId();
        if (!id)
            return null;
        this._bannerAd = this.api.createBannerAd({
            adUnitId: id,
            style: {
                left: 0,
                top: this.systemInfo.screenHeight - 130,
                width: this.systemInfo.screenWidth + 50,
            }
        });
        this._bannerAd.onError(function (err) {
            _this.onBannerErr(err);
            _this.destroyBanner();
        });
        this._bannerAd.onResize(function (res) {
            if (_this.systemInfo.platform == "ios" && !!_this.systemInfo.statusBarHeight && _this.systemInfo.statusBarHeight > 20) {
                _this._bannerAd.style.top = _this.systemInfo.screenHeight - res.height - 20;
            }
            else {
                _this._bannerAd.style.top = _this.systemInfo.screenHeight - res.height;
            }
        });
        this._bannerAd.onLoad(function () {
            _this.bannerLoaded = true;
            if (_this.needShowBanner) {
                _this.showBanner();
                _this.needShowBanner = false;
            }
        });
        this.createBannerTime = Date.now();
        return this._bannerAd;
    };
    /**
     * 关闭广告
     */
    WXSDK.prototype.removeBanner = function () {
        if (this._bannerAd) {
            var t = Date.now();
            if (t - this.createBannerTime > 60000) {
                console.log("距上次显示banner已超过60秒，创建新的banner");
                this.destroyBanner();
                this.preCreateBanner();
            }
            else {
                this._bannerAd.hide();
            }
        }
        this.bannerShowing = false;
        this.needShowBanner = false;
    };
    /**销毁已经创建的banner */
    WXSDK.prototype.destroyBanner = function () {
        if (!!this._bannerAd) {
            this._bannerAd.offLoad();
            this._bannerAd.offError();
            this._bannerAd.offResize();
            this._bannerAd.destroy(); //要先把旧的广告给销毁，不然会导致其监听的事件无法释放，影响性能
            this._bannerAd = null;
        }
        this.bannerLoaded = false;
    };
    //插屏广告
    WXSDK.prototype.showInterstitialAd = function (banner) {
        var _this = this;
        if (banner === void 0) { banner = false; }
        this.useBannerInsteadInsert = banner;
        this.showBannerInsteadInsert();
        var id = this.getInsertAdUnitId();
        if (!id) {
            // this.showBannerInsteadInsert();
            return;
        }
        var version = this.systemInfo.SDKVersion;
        if (this.compareVersion(version, '2.6.0') < 0) {
            console.log('基础库版本过低');
            // this.showBannerInsteadInsert();
            //   // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
            //   wx.showModal({
            //     title: '提示',
            //     content: '当前微信版本过低，无法使用插屏广告，请升级到最新微信版本后重试。'
            //   })
            return;
        }
        var ad = this.api.createInterstitialAd({ adUnitId: id });
        ad.show().then(this.onInsertShow.bind(this));
        ad.onClose(this.onInsertHide.bind(this));
        ad.onError(function (err) {
            _this.onInsertErr(err);
            // this.showBannerInsteadInsert();
        });
    };
    /**
     * 短震动
     */
    WXSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    WXSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    WXSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ""; }
        var index = Math.floor((Math.random() * this.shareTitleArr.length));
        var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
        this.api.shareAppMessage({
            title: "" + this.shareTitleArr[index],
            imageUrl: "" + this.shareImgArr[indeximg],
            query: "" + query,
        });
    };
    /**
     * 激励分享&&带参分享
     */
    WXSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
        if (!GamePlatform_1.default.instance.Config.share) {
            success();
            return;
        }
        this.shareAppMessage(query);
        success();
    };
    /**
     * 消息提示
     */
    WXSDK.prototype.showMessage = function (msg, icon) {
        if (icon === void 0) { icon = 'none'; }
        // this.api.showToast({
        //     title: msg,
        //     duration: 2000,
        //     icon: icon,
        //     success: (res) => { }
        // });
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTip, msg);
    };
    WXSDK.prototype.navigateToMiniProgram = function (data) {
        this.api.navigateToMiniProgram({
            appId: data.gameId,
        });
    };
    return WXSDK;
}(SDK_1.default));
exports.default = WXSDK;

cc._RF.pop();