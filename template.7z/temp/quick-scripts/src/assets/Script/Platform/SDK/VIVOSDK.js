"use strict";
cc._RF.push(module, 'b09a0FKoPRKd5JE74TASulT', 'VIVOSDK');
// Script/Platform/SDK/VIVOSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var EventManager_1 = require("../../Common/EventManager");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var VIVOSDK = /** @class */ (function (_super) {
    __extends(VIVOSDK, _super);
    function VIVOSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'qg';
        //视频广告
        _this.rewardedAd = null;
        return _this;
    }
    /**
     * 初始化
     */
    VIVOSDK.prototype.init = function () {
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        console.log("系统信息：");
        console.log(JSON.stringify(this.systemInfo));
    };
    VIVOSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        if (this.systemInfo.platformVersionCode < 1041) {
            this.onVideoFail('基础库版本过低，不能使用视频功能');
            return;
        }
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("视频id获取失败");
            return;
        }
        if (!this.rewardedAd) {
            var rewardedAd_1 = this.api.createRewardedVideoAd({
                posId: id,
                style: {}
            });
            rewardedAd_1.onClose(function (res) {
                if (res && res.isEnded) {
                    _this.onVideoSuccess();
                }
                else {
                    _this.onVideoQuit();
                    _this.onVideoHide();
                }
            });
            rewardedAd_1.onError(function (err) {
                switch (err.errCode) {
                    case -3: {
                        console.log("激励广告加载失败---调用太频繁", JSON.stringify(err));
                        break;
                    }
                    case -4: {
                        console.log("激励广告加载失败--- 一分钟内不能重复加载", JSON.stringify(err));
                        break;
                    }
                    case 30008: {
                        // 当前启动来源不支持激励视频广告，请选择其他激励策略
                        break;
                    }
                    default: {
                        // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                        console.log("激励广告展示失败");
                        console.log(JSON.stringify(err));
                        break;
                    }
                }
                _this.onVideoFail(err);
            });
            rewardedAd_1.onLoad(function () {
                var adshow = rewardedAd_1.show();
                _this.onVideoShow();
                // 捕捉show失败的错误
                adshow && adshow.catch(function (err) {
                    _this.onVideoFail(err);
                });
            });
            this.rewardedAd = rewardedAd_1;
        }
        var adLoad = this.rewardedAd.load(); //第一次调用 可能会报-3  广告能正常展示就可以忽略
        // 捕捉load失败的错误
        !!adLoad && adLoad.catch(function (err) {
            _this.onVideoFail(err);
        });
    };
    /**
     * 打开banner广告
     */
    VIVOSDK.prototype.showBanner = function () {
        var _this = this;
        if (this.systemInfo.platformVersionCode < 1031) {
            console.log("基础库版本过低，不能使用广告功能");
            return;
        }
        // if (this.insertAdRecord.isShowing) {
        //     console.log("插屏广告正在显示，无法同时显示banner");
        //     return;
        // }
        if (this.bannerRecord.getShowSpaceTime() < 12) {
            console.log("距离上一次展示banner的时间间隔小于12秒，不进行展示");
            return;
        }
        if (!!this._bannerAd) {
            console.log("上一次创建的banner未销毁，直接显示");
            this._bannerAd.show().then(function () {
                console.log("再次显示已创建的banner成功");
                _this.onBannerShow();
            }).catch(function (err) {
                _this.onBannerErr(err);
                _this.removeBanner();
                _this.createBanner();
            });
        }
        else {
            this.removeBanner();
            this.createBanner();
        }
    };
    VIVOSDK.prototype.createBanner = function () {
        var _this = this;
        var id = this.getBannerId();
        if (!id)
            return;
        //style内无需设置任何字段，banner会在屏幕底部居中显示，
        // 没有style字段，banner会在上边显示
        var bannerAd = this.api.createBannerAd({
            posId: id,
            style: {}
        });
        this._bannerAd = bannerAd;
        var adshow = bannerAd.show();
        // 调用then和catch之前需要对show的结果做下判空处理，防止出错（如果没有判空，在平台版本为1052以及以下的手机上将会出现错误）
        if (!adshow) {
            console.log("banner show fail");
        }
        adshow && adshow.then(function () {
            console.log("banner广告展示成功");
            _this.onBannerShow();
        }).catch(function (err) {
            switch (err.code) {
                case 30003: {
                    console.log("新用户7天内不能曝光Banner，请将手机时间调整为7天后，退出游戏重新进入");
                    break;
                }
                case 30009: {
                    console.log("10秒内调用广告次数超过1次，10秒后再调用");
                    break;
                }
                case 30002: {
                    console.log("加载广告失败，重新加载广告");
                    break;
                }
                default: {
                    // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                    console.log("banner广告展示失败");
                    console.log(JSON.stringify(err));
                    break;
                }
            }
        });
    };
    /**
     * 关闭banner广告
     */
    VIVOSDK.prototype.removeBanner = function () {
        var _this = this;
        if (this._bannerAd) {
            //距离上一次创建时间少于12秒时，隐藏banner，下次需要显示时不再创建新的banner
            if (this.bannerRecord.getShowSpaceTime() < 12) {
                console.log("距离上一次创建时间少于12秒，不销毁banner，只隐藏");
                this._bannerAd.hide();
            }
            else {
                var addestroy = this._bannerAd.destroy();
                addestroy && addestroy.then(function () {
                    console.log("banner广告销毁成功");
                    _this._bannerAd = null;
                }).catch(function (err) {
                    console.log("banner广告销毁失败", err);
                    _this._bannerAd.hide();
                });
            }
            this.onBannerHide();
        }
    };
    /**
     * 插屏广告
     */
    VIVOSDK.prototype.showInterstitialAd = function (banner) {
        var _this = this;
        if (banner === void 0) { banner = false; }
        this.useBannerInsteadInsert = banner;
        if (this.systemInfo.platformVersionCode < 1031) {
            console.log("基础库版本过低，不能使用插屏广告功能");
            this.showBannerInsteadInsert();
            return;
        }
        var id = this.getInsertAdUnitId();
        if (!id) {
            this.showBannerInsteadInsert();
            return;
        }
        var interstitialAd = this.api.createInterstitialAd({
            posId: id,
            style: {}
        });
        interstitialAd.onClose(this.onInsertHide.bind(this));
        var adshow = interstitialAd.show();
        if (!adshow) {
            console.log("insertAd show fail");
            this.showBannerInsteadInsert();
            return;
        }
        // 调用then和catch之前需要对show的结果做下判空处理，防止出错（如果没有判空，在平台版本为1052以及以下的手机上将会出现错误）
        !!adshow && adshow.then(function () {
            // this.removeBanner();
            _this.onInsertShow();
            _this.showBannerInsteadInsert();
        }).catch(function (err) {
            switch (err.code) {
                case 30003: {
                    console.log("新用户7天内不能曝光Banner，请将手机时间调整为7天后，退出游戏重新进入");
                    break;
                }
                case 30009: {
                    console.log("10秒内调用广告次数超过1次，10秒后再调用");
                    break;
                }
                case 30002: {
                    console.log("load广告失败，重新加载广告");
                    break;
                }
                default: {
                    // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                    console.log("插屏广告展示失败");
                    console.log(JSON.stringify(err));
                    break;
                }
            }
            _this.onInsertErr(err);
            _this.showBannerInsteadInsert();
        });
    };
    /**
     * 短震动
     */
    VIVOSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    VIVOSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    VIVOSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ''; }
    };
    /**
     * 激励分享&&带参分享
     */
    VIVOSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
    };
    /**
     * 消息提示
     */
    VIVOSDK.prototype.showMessage = function (msg, icon) {
        if (icon === void 0) { icon = 'none'; }
        // this.api.showToast({
        //     title: msg,
        //     duration: 2000,
        //     icon: icon,
        //     success: (res) => { }
        // });
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTip, msg);
    };
    return VIVOSDK;
}(SDK_1.default));
exports.default = VIVOSDK;

cc._RF.pop();