"use strict";
cc._RF.push(module, '58947sP21dHI6brMjcbkNmW', 'SDK');
// Script/Platform/SDK/SDK.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Platform = void 0;
var EventManager_1 = require("../../Common/EventManager");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var GamePlatform_1 = require("../GamePlatform");
var GameConfig_1 = require("../../GameSpecial/GameConfig");
var GlobalEnum_1 = require("../../GameSpecial/GlobalEnum");
var SDK = /** @class */ (function () {
    function SDK() {
        /**
         * 分享游戏时的描述
         */
        this.shareTitleArr = [
            '',
            ''
        ];
        /**
         * 分享游戏时的图片
         */
        this.shareImgArr = [
            '',
            ''
        ];
        /**手机操作系统类型 */
        this.platform = null;
        this.videoRecord = null;
        /**数据分析工具使用的数据 */
        this.videoTongJi = null;
        /*******************************************banner*******************************************/
        this.bannerRecord = null;
        /**当前是否显示了banner(部分平台关闭banner无回调) */
        this.bannerShowing = false;
        /*******************************************插屏*******************************************/
        this.insertAdRecord = null;
        /**插屏显示失败时，是否使用banner代替 */
        this.useBannerInsteadInsert = false;
        this.recordVideoData = null;
    }
    /**
     * 记录SDK与系统信息
     *
     * 将不同平台的系统信息中通用的内容用统一的字段存储
     * @param platform      SDK获取的系统信息中的操作系统
     * @param version       SDK获取的系统信息中的操作系统版本号
     * @param sdkVersion    SDK获取的系统信息中的SDK版本号
     */
    SDK.prototype.setSystemInfo = function (platform, systemVersion, sdkVersion) {
        this.systemVersion = systemVersion;
        this.sdkVersion = sdkVersion;
        var str = platform.toUpperCase();
        switch (str) {
            case Platform.ios: {
                this.platform = Platform.ios;
                break;
            }
            case Platform.android: {
                this.platform = Platform.android;
                break;
            }
            default: {
                this.platform = Platform.pc;
                break;
            }
        }
    };
    /**手机操作系统是否低于指定版本 */
    SDK.prototype.systemLessThan = function (v) {
        return this.lessThan(this.systemVersion, v);
    };
    /**平台sdk是否低于指定版本 */
    SDK.prototype.sdkLessThan = function (v) {
        return this.lessThan(this.sdkVersion, v);
    };
    /**比较版本号v1是否低于v2 */
    SDK.prototype.lessThan = function (v1, v2) {
        var arr1 = v1.split('.');
        var arr2 = v2.split('.');
        var len = Math.max(arr2.length, arr2.length);
        while (arr1.length < len) {
            arr1.push('0');
        }
        while (arr2.length < len) {
            arr2.push('0');
        }
        for (var i = 0; i < len; i++) {
            var num1 = parseInt(arr1[i]);
            var num2 = parseInt(arr2[i]);
            if (num1 < num2) {
                return true;
            }
            else if (num1 > num2) {
                return false;
            }
        }
        return false;
    };
    /**判断基础库版本号 */
    SDK.prototype.compareVersion = function (v1, v2) {
        v1 = v1.split('.');
        v2 = v2.split('.');
        var len = Math.max(v1.length, v2.length);
        while (v1.length < len) {
            v1.push('0');
        }
        while (v2.length < len) {
            v2.push('0');
        }
        for (var i = 0; i < len; i++) {
            var num1 = parseInt(v1[i]);
            var num2 = parseInt(v2[i]);
            if (num1 > num2) {
                return 1;
            }
            else if (num1 < num2) {
                return -1;
            }
        }
        return 0;
    };
    /**
     * 初始化
     */
    SDK.prototype.init = function () { };
    SDK.prototype.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showBanner, this.showBanner, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.hideBanner, this.removeBanner, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showVideo, this.showVideo, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.startRecord, this.startRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.pauseRecord, this.pauseRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.resumeRecord, this.resumeRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.stopRecord, this.stopRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.shareRecord, this.shareRecord, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showMsg, this.showMessage, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showInsertAd, this.showInterstitialAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.navigateToMiniProgram, this.navigateToMiniProgram, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.vibrateLong, this.onVibrateLong, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.vibrateShort, this.onVibrateShort, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.show, this.onShow, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.hide, this.onHide, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showInsertByPauseLevel, this.showInsertAdByPauseLevel, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.triggerGC, this.triggerGC, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showNativeAd, this.showNativeAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.hideNativeAd, this.hideNativeAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.hideAllNativeAd, this.hideAllNativeAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.quickShowNativeAd, this.quickShowNativeAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.quickHideNativeAd, this.quickHideNativeAd, this);
        //qq平台功能：
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showAppBox, this.showAppBox, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.showBlockAd, this.showBlockAd, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.addColorSign, this.addColorSign, this);
        EventManager_1.default.on(GameEventType_1.EventType.SDKEvent.subscribeMsg, this.subscribeMsg, this);
    };
    SDK.prototype.triggerGC = function () { };
    /**暂停游戏时显示插屏，插屏显示失败时不显示banner */
    SDK.prototype.showInsertAdByPauseLevel = function () {
        this.showInterstitialAd(false);
    };
    //广告记录
    SDK.prototype.loadRecord = function () {
        var data = {
            video: null,
            banner: null,
            insert: null,
            recordVideoData: null,
            time: 0,
        };
        var record = cc.sys.localStorage.getItem("AdRecord");
        if (!!record) {
            var d = JSON.parse(record);
            var now = new Date();
            var old = new Date(d.time);
            if (now.getMonth() == old.getMonth() && now.getDate() == old.getDate()) {
                data = d;
            }
        }
        this.bannerRecord = new AdRecord(data.banner);
        this.videoRecord = new AdRecord(data.video);
        this.insertAdRecord = new AdRecord(data.insert);
        this.recordVideoData = new RecordVideoData(data.recordVideoData);
    };
    SDK.prototype.saveRecord = function () {
        var data = {
            video: this.videoRecord,
            banner: this.bannerRecord,
            insert: this.insertAdRecord,
            recordVideoData: this.recordVideoData,
            time: Date.now(),
        };
        cc.sys.localStorage.setItem("AdRecord", JSON.stringify(data));
    };
    /*******************************************录屏*******************************************/
    //开始录屏（头条）
    SDK.prototype.startRecord = function () {
        this.recordVideo("start");
        this.recordVideoData.onStart();
    };
    SDK.prototype.pauseRecord = function () {
        this.recordVideo("pause");
    };
    SDK.prototype.resumeRecord = function () {
        this.recordVideo("resume");
    };
    //停止录屏（头条）
    SDK.prototype.stopRecord = function () {
        this.recordVideoData.onEnd();
        this.recordVideo("stop");
    };
    //分享录屏（头条）
    SDK.prototype.shareRecord = function (success, fail) {
        if (fail === void 0) { fail = null; }
        this.shareRecordVideo(success, fail);
    };
    /**
     * 视频广告
     * @param success   广告观看完毕的回调
     * @param quit      中途退出广告观看的回调
     * @param fail      广告加载失败的回调
     */
    SDK.prototype.showVideo = function (success, quit, fail, videoName) {
        this.videoTongJi = null;
        if (!this.canApiUseVideo()) {
            if (typeof success === "object") {
                if (!!success.page) {
                    EventManager_1.default.emit(GameEventType_1.EventType.TongJi.video, {
                        type: success.page,
                        subType: GlobalEnum_1.GlobalEnum.VideoSubType.videoFail,
                        battle: success.battle
                    });
                }
                if (!!success.fail) {
                    success.fail();
                }
            }
            else if (!!fail) {
                fail();
            }
            return;
        }
        this.resetVideoCb();
        if (typeof success === "object") {
            this.videoSuccess = success.success;
            this.videoQuit = success.quit;
            this.videoFail = success.fail;
            if (undefined !== success.page) {
                this.videoTongJi = {
                    type: success.page,
                    battle: success.battle,
                };
            }
            videoName = success.videoName;
        }
        else {
            this.videoSuccess = success;
            this.videoQuit = quit;
            this.videoFail = fail;
        }
        if (!this.videoFail) {
            this.videoFail = this.tipVideoFail.bind(this);
        }
        this.sendVideoTongJi(GlobalEnum_1.GlobalEnum.VideoSubType.clickBtnVideo);
        this.onVideoStart();
        if (!this.getVideoAdUnitId()) {
            setTimeout(this.onVideoSuccess.bind(this), 0);
        }
        else {
            this.showVideoAd(videoName);
        }
    };
    /**视频广告开始播放时，处理与游戏逻辑相关的事件 */
    SDK.prototype.onVideoStart = function () {
        EventManager_1.default.emit(GameEventType_1.EventType.AudioEvent.pause);
        EventManager_1.default.emit(GameEventType_1.EventType.DirectorEvent.pauseLevel);
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTouchMask);
    };
    /**视频广告播放结束或加载失败后，处理与游戏逻辑相关的事件 */
    SDK.prototype.onVideoEnd = function () {
        EventManager_1.default.emit(GameEventType_1.EventType.AudioEvent.resume);
        EventManager_1.default.emit(GameEventType_1.EventType.DirectorEvent.resumeLevel);
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.hideTouchMask);
    };
    /**能否使用api：video ，子类实现 */
    SDK.prototype.canApiUseVideo = function () { return true; };
    SDK.prototype.tipVideoFail = function () {
        this.showMessage("视频加载失败，请稍后再试~");
    };
    SDK.prototype.showVideoAd = function (videoName) {
        this.onVideoSuccess();
    };
    /**获取视频广告id */
    SDK.prototype.getVideoAdUnitId = function (videoName) {
        if (!GamePlatform_1.default.instance.Config.video) {
            console.log("广告开关未打开");
            return null;
        }
        if (!GamePlatform_1.default.instance.Config.videoAdUnitId || !GamePlatform_1.default.instance.Config.videoAdUnitId[0]) {
            console.log("广告参数未填写");
            return null;
        }
        if (undefined === videoName) {
            return GamePlatform_1.default.instance.Config.videoAdUnitId[0];
        }
        if (videoName >= GamePlatform_1.default.instance.Config.videoAdUnitId.length) {
            return GamePlatform_1.default.instance.Config.videoAdUnitId[0];
        }
        return GamePlatform_1.default.instance.Config.videoAdUnitId[videoName];
    };
    SDK.prototype.onVideoShow = function () {
        console.log("视频广告展示成功");
        this.videoRecord.onShow();
    };
    SDK.prototype.onVideoHide = function () {
        console.log("视频广告未播放完即被关闭");
        this.videoRecord.onHide();
    };
    SDK.prototype.onVideoSuccess = function () {
        console.log("视频广告观看成功！");
        this.sendVideoTongJi(GlobalEnum_1.GlobalEnum.VideoSubType.videoSuc);
        this.onVideoEnd();
        var cb = this.videoSuccess;
        this.resetVideoCb();
        if (!!cb) {
            cb();
        }
    };
    SDK.prototype.onVideoFail = function (err) {
        console.log("视频广告加载出错  ", err);
        this.sendVideoTongJi(GlobalEnum_1.GlobalEnum.VideoSubType.videoFail);
        this.onVideoEnd();
        var cb = this.videoFail;
        this.resetVideoCb();
        if (!!cb) {
            cb();
        }
    };
    SDK.prototype.onVideoQuit = function () {
        console.log("视频广告观看未完成");
        this.sendVideoTongJi(GlobalEnum_1.GlobalEnum.VideoSubType.videoQuit);
        this.onVideoEnd();
        var cb = this.videoQuit;
        this.resetVideoCb();
        if (!!cb) {
            cb();
        }
    };
    /**发送视频数据进行统计 */
    SDK.prototype.sendVideoTongJi = function (subType) {
        if (!!this.videoTongJi) {
            EventManager_1.default.emit(GameEventType_1.EventType.TongJi.video, {
                type: this.videoTongJi.type,
                subType: subType,
                battle: this.videoTongJi.battle,
            });
        }
    };
    SDK.prototype.resetVideoCb = function () {
        this.videoSuccess = null;
        this.videoQuit = null;
        this.videoFail = null;
    };
    SDK.prototype.showBanner = function () { };
    /**能否使用api：banner ，子类实现 */
    SDK.prototype.canApiUseBanner = function () { return true; };
    SDK.prototype.removeBanner = function () { };
    SDK.prototype.getBannerId = function () {
        if (!GamePlatform_1.default.instance.Config.banner) {
            console.log("banner开关未打开");
            return null;
        }
        if (!GamePlatform_1.default.instance.Config.BannerAdUnitId || !GamePlatform_1.default.instance.Config.BannerAdUnitId[0]) {
            console.log("banner ID 未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.BannerAdUnitId[0];
    };
    SDK.prototype.onBannerShow = function () {
        console.log("banner 显示成功");
        this.bannerRecord.onShow();
        this.bannerShowing = true;
        EventManager_1.default.emit(GameEventType_1.EventType.SDKEvent.showBannerFinish);
    };
    SDK.prototype.onBannerHide = function () {
        console.log("banner 广告隐藏");
        this.bannerRecord.onHide();
        this.bannerShowing = false;
    };
    SDK.prototype.onBannerErr = function (err) {
        console.log('banner 显示失败:', JSON.stringify(err));
        this.bannerRecord.isShowing = false;
    };
    /**
     * 插屏广告
     * @param banner    插屏显示失败时是否显示banner
     */
    SDK.prototype.showInterstitialAd = function (banner) { };
    /**能否使用api：insert ，子类实现 */
    SDK.prototype.canApiUseInsert = function () { return true; };
    /**获取插屏广告id */
    SDK.prototype.getInsertAdUnitId = function () {
        if (!GamePlatform_1.default.instance.Config.interstitial) {
            console.log("插屏广告开关未打开");
            return null;
        }
        if (!GamePlatform_1.default.instance.Config.InterstitialAdUnitId || !GamePlatform_1.default.instance.Config.InterstitialAdUnitId[0]) {
            console.log("插屏广告参数未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.InterstitialAdUnitId[0];
    };
    SDK.prototype.onInsertShow = function () {
        console.log("插屏显示成功");
        this.insertAdRecord.onShow();
    };
    SDK.prototype.onInsertHide = function () {
        console.log("关闭插屏");
        this.insertAdRecord.onHide();
    };
    SDK.prototype.onInsertErr = function (err) {
        console.log("插屏广告加载失败：" + JSON.stringify(err));
        this.insertAdRecord.isShowing = false;
    };
    SDK.prototype.showBannerInsteadInsert = function () {
        if (this.useBannerInsteadInsert) {
            console.log("显示banner代替插屏");
            this.showBanner();
        }
        this.useBannerInsteadInsert = false;
    };
    /*******************************************震动*******************************************/
    /**短震动 */
    SDK.prototype.onVibrateShort = function () {
        if (!GameConfig_1.default.driveConfig.vibrate)
            return;
        this.vibrateShort();
    };
    SDK.prototype.vibrateShort = function () { };
    /**长震动 */
    SDK.prototype.onVibrateLong = function () {
        if (!GameConfig_1.default.driveConfig.vibrate)
            return;
        this.vibrateLong();
    };
    SDK.prototype.vibrateLong = function () { };
    /*******************************************分享*******************************************/
    /**无激励分享&&带参分享 */
    SDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ''; }
    };
    /**激励分享&&带参分享 */
    SDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
        success();
    };
    /**弹出消息 */
    SDK.prototype.showMessage = function (msg, icon) {
        if (icon === void 0) { icon = 'none'; }
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTip, msg);
    };
    /**录屏功能 */
    SDK.prototype.recordVideo = function (type) {
        if (type === void 0) { type = 'start'; }
    };
    /**录屏分享 */
    SDK.prototype.shareRecordVideo = function (success, fail) { };
    /*******************************************跳转*******************************************/
    /**跳转到其他小游戏 */
    SDK.prototype.navigateToMiniProgram = function (data) {
        console.log("跳转小游戏，子类实现，data:", data);
    };
    /**游戏切到后台 */
    SDK.prototype.onHide = function () { };
    /**从后台回到游戏 */
    SDK.prototype.onShow = function () { };
    //QQ平台功能：
    /*******************************************盒子广告*******************************************/
    SDK.prototype.showAppBox = function () { };
    SDK.prototype.getAppBoxId = function () {
        if (!GamePlatform_1.default.instance.Config.appBoxUnitId || !GamePlatform_1.default.instance.Config.appBoxUnitId[0]) {
            console.log("盒子广告参数未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.appBoxUnitId[0];
    };
    /*******************************************积木广告*******************************************/
    SDK.prototype.showBlockAd = function () { };
    SDK.prototype.getBlockAdId = function () {
        if (!GamePlatform_1.default.instance.Config.blockAdUnitId || !GamePlatform_1.default.instance.Config.blockAdUnitId[0]) {
            console.log("积木广告参数未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.blockAdUnitId[0];
    };
    /*******************************************彩签*******************************************/
    SDK.prototype.addColorSign = function (data) { };
    SDK.prototype.subscribeMsg = function (data) { };
    /*******************************************原生广告*******************************************/
    /**原生广告id */
    SDK.prototype.getNativeAdId = function () {
        if (!GamePlatform_1.default.instance.Config.nativeAdUnitId[0]) {
            console.log("原生广告参数未填写");
            return null;
        }
        return GamePlatform_1.default.instance.Config.nativeAdUnitId[0];
    };
    SDK.prototype.getAllNativeAdIds = function () {
        if (!GamePlatform_1.default.instance.Config.nativeAdUnitId[0]) {
            console.log("原生广告参数未填写");
            return [];
        }
        return GamePlatform_1.default.instance.Config.nativeAdUnitId;
    };
    /**显示原生广告 */
    SDK.prototype.showNativeAd = function (data) { };
    SDK.prototype.hideNativeAd = function (data) { };
    SDK.prototype.hideAllNativeAd = function (data) { };
    SDK.prototype.quickShowNativeAd = function (data) { };
    SDK.prototype.quickHideNativeAd = function (data) { };
    return SDK;
}());
exports.default = SDK;
var AdRecord = /** @class */ (function () {
    function AdRecord(data) {
        this.isShowing = false;
        this.gameShowCount = 0;
        this.gameHideCount = 0;
        if (!data) {
            this.dayShowCount = 0;
            this.dayHideCount = 0;
            this.preShowTime = 0;
            this.preHideTime = 0;
        }
        else {
            this.dayShowCount = data.dayShowCount;
            this.dayHideCount = data.dayHideCount;
            this.preShowTime = data.preShowTime;
            this.preHideTime = data.preHideTime;
        }
    }
    AdRecord.prototype.onShow = function () {
        this.isShowing = true;
        this.dayShowCount++;
        this.gameShowCount++;
        this.preShowTime = Date.now();
    };
    AdRecord.prototype.onHide = function () {
        this.isShowing = false;
        this.dayHideCount++;
        this.gameHideCount++;
        this.preHideTime = Date.now();
    };
    /**当前时间距离上一次展示的时间间隔，单位：秒 */
    AdRecord.prototype.getShowSpaceTime = function () {
        var d = Date.now() - this.preShowTime;
        return d * 0.001;
    };
    /**当前时间距离上一次关闭的时间间隔，单位：秒 */
    AdRecord.prototype.getHideSpaceTime = function () {
        var d = Date.now() - this.preHideTime;
        return d * 0.001;
    };
    return AdRecord;
}());
/**录屏数据记录 */
var RecordVideoData = /** @class */ (function () {
    function RecordVideoData(data) {
        this.startTime = 0;
        this.endTime = 0;
        this.gameShareCount = 0;
        if (!!data) {
            this.dayShareCount = data.dayShareCount;
        }
        else {
            this.dayShareCount = 0;
        }
    }
    /**录屏开始 */
    RecordVideoData.prototype.onStart = function () {
        this.startTime = Date.now();
        this.endTime = Date.now();
    };
    /**录屏结束 */
    RecordVideoData.prototype.onEnd = function () {
        this.endTime = Date.now();
    };
    Object.defineProperty(RecordVideoData.prototype, "totalTime", {
        /**录屏时长，单位：秒 */
        get: function () {
            return (this.endTime - this.startTime) * 0.001;
        },
        enumerable: false,
        configurable: true
    });
    /**分享成功 */
    RecordVideoData.prototype.onShare = function () {
        this.gameShareCount++;
        this.dayShareCount++;
    };
    return RecordVideoData;
}());
/**
 * 手机平台类型
 */
var Platform;
(function (Platform) {
    /**电脑上调试时使用 */
    Platform["pc"] = "PC";
    /**苹果 */
    Platform["ios"] = "IOS";
    /**安卓 */
    Platform["android"] = "ANDROID";
})(Platform = exports.Platform || (exports.Platform = {}));

cc._RF.pop();