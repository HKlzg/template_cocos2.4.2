"use strict";
cc._RF.push(module, 'ce8bdT8m8hNvbQVO6NcG6Ss', 'TTSDK');
// Script/Platform/SDK/TTSDK.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDK_1 = require("./SDK");
var GamePlatform_1 = require("../GamePlatform");
var EventManager_1 = require("../../Common/EventManager");
var GameEventType_1 = require("../../GameSpecial/GameEventType");
var TTSDK = /** @class */ (function (_super) {
    __extends(TTSDK, _super);
    function TTSDK() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'tt';
        _this.appName = null;
        /**创建新的banner的时间 */
        _this.createBannerTime = 0;
        /**banner加载成功后是否需要立即显示 */
        _this.needShowBanner = false;
        /**banner是否已加载完毕 */
        _this.bannerLoaded = false;
        //插屏
        _this.insertAd = null;
        //当前录屏是否已成功发布过一次
        _this.isShared = false;
        //录屏错误。
        _this.IsRecordError = false;
        //视频地址
        _this.videoPath = '';
        _this.recordMng = null;
        return _this;
    }
    /**
     * 记录字节跳动平台下的应用程序的类型，
     * 参考文档：https://microapp.bytedance.com/dev/cn/mini-app/develop/basic-library/compatibility-description
     */
    TTSDK.prototype.initAppType = function () {
        var appName = this.systemInfo.appName.toUpperCase();
        switch (appName) {
            case "TOUTIAO": {
                this.appName = AppName.touTiao;
                break;
            }
            case "DOUYIN": {
                this.appName = AppName.douYin;
                break;
            }
            case "XIGUA": {
                this.appName = AppName.xiGua;
                break;
            }
            case "NEWS_ARTICLE_LITE": {
                this.appName = AppName.jiSuTT;
                break;
            }
            default: {
                this.appName = AppName.devtools;
                break;
            }
        }
    };
    TTSDK.prototype.init = function () {
        this.api = window[this.apiName];
        this.systemInfo = this.api.getSystemInfoSync();
        this.initAppType();
        this.setSystemInfo(this.systemInfo.platform, this.systemInfo.version, this.systemInfo.SDKVersion);
        console.log("系统信息：");
        console.log(JSON.stringify(this.systemInfo));
        this.api.showShareMenu({ withShareTicket: false });
        this.preCreateBanner();
    };
    //video
    TTSDK.prototype.showVideoAd = function (videoName) {
        var _this = this;
        if (!this.canApiUseVideo()) {
            this.onVideoSuccess();
            return;
        }
        var id = this.getVideoAdUnitId(videoName);
        if (!id) {
            this.onVideoFail("获取视频id失败");
            return;
        }
        //不支持在开发工具运行，只能在真机运行 返回值是个单例
        var rewardedVideoAd = this.api.createRewardedVideoAd({ adUnitId: id });
        var load = (function () {
            _this.onVideoShow();
        });
        rewardedVideoAd.onLoad(load);
        var error = (function (err) {
            _this.onVideoFail(err);
        });
        rewardedVideoAd.onError(error);
        var closefun = (function (res) {
            rewardedVideoAd.offLoad(load);
            rewardedVideoAd.offError(error);
            rewardedVideoAd.offClose(closefun);
            rewardedVideoAd = null;
            if (res && res.isEnded || res === undefined) {
                _this.onVideoSuccess();
            }
            else {
                _this.onVideoQuit();
                _this.onVideoHide();
            }
        });
        rewardedVideoAd.onClose(closefun);
        //开始加载视频广告
        rewardedVideoAd.load().then(function () {
            rewardedVideoAd.show().catch(function (err) {
                _this.onVideoFail(err);
                rewardedVideoAd.offLoad(load);
                rewardedVideoAd.offError(error);
                rewardedVideoAd.offClose(closefun);
                rewardedVideoAd = null;
            });
        });
    };
    /**能否使用api：video */
    TTSDK.prototype.canApiUseVideo = function () {
        if (this.appName == AppName.devtools) {
            console.log("开发者工具上无法显示视频广告");
            return false;
        }
        return true;
    };
    /**
     * 打开banner广告
     */
    TTSDK.prototype.showBanner = function (cb) {
        var _this = this;
        if (!this.canApiUseBanner()) {
            return;
        }
        if (this.insertAdRecord.isShowing) {
            console.log("有插屏显示，不再显示banner");
            this.removeBanner();
            return;
        }
        if (this.bannerRecord.getShowSpaceTime() < 1) {
            console.log("距离上次显示banner时间小于1s，不再创建");
            return;
        }
        if (this.bannerShowing)
            return;
        //已经创建了banner：
        if (!!this._bannerAd) {
            //创建的banner已经加载成功，直接显示：
            if (this.bannerLoaded) {
                this._bannerAd.show().then(function () {
                    _this.onBannerShow();
                    _this.bannerShowing = true;
                    if (!!cb) {
                        cb();
                    }
                });
            }
            else {
                //创建的banner还没加载完成时，设置标记，使其在加载完成后显示
                this.needShowBanner = true;
            }
        }
        else {
            //尚未创建banner，则设置标记，创建banner，并使其在加载完成后显示
            this.needShowBanner = true;
            this.preCreateBanner();
        }
    };
    /**能否使用api：banner */
    TTSDK.prototype.canApiUseBanner = function () {
        if (this.appName == AppName.douYin) {
            console.log("抖音平台无banner");
            return false;
        }
        return true;
    };
    /**预先创建banner，创建的banner在加载完成时，会根据 needShowBanner 确定是否需要立即显示 */
    TTSDK.prototype.preCreateBanner = function () {
        var _this = this;
        var id = this.getBannerId();
        if (!id)
            return null;
        var targetBannerAdWidth = 200;
        this._bannerAd = this.api.createBannerAd({
            adUnitId: id,
            style: {
                width: targetBannerAdWidth,
                top: this.systemInfo.windowHeight - (targetBannerAdWidth / 16 * 9),
            }
        });
        this._bannerAd.onError(function (err) {
            _this.onBannerErr(err);
            _this.destroyBanner();
        });
        // 尺寸调整时会触发回调，通过回调拿到的广告真实宽高再进行定位适配处理
        // 注意：如果在回调里再次调整尺寸，要确保不要触发死循环！！！
        this._bannerAd.onResize(function (size) {
            // good
            _this._bannerAd.style.top = _this.systemInfo.windowHeight - size.height;
            _this._bannerAd.style.left = (_this.systemInfo.windowWidth - size.width) / 2;
            // bad，会触发死循环
            // bannerAd.style.width++;
        });
        this._bannerAd.onLoad(function () {
            _this.bannerLoaded = true;
            if (_this.needShowBanner) {
                _this.showBanner();
                _this.needShowBanner = false;
            }
        });
        this.createBannerTime = Date.now();
        return this._bannerAd;
    };
    /**
     * 关闭banner广告
     */
    TTSDK.prototype.removeBanner = function () {
        if (this._bannerAd) {
            var t = Date.now();
            if (t - this.createBannerTime > 60000) {
                console.log("距上次显示banner已超过60秒，创建新的banner");
                this.destroyBanner();
                this.preCreateBanner();
            }
            else {
                this._bannerAd.hide();
            }
        }
        this.bannerShowing = false;
        this.needShowBanner = false;
    };
    /**销毁banner */
    TTSDK.prototype.destroyBanner = function () {
        if (this._bannerAd) {
            // this._bannerAd.offLoad();
            // this._bannerAd.offError();
            // this._bannerAd.offResize();
            this._bannerAd.destroy(); //要先把旧的广告给销毁，不然会导致其监听的事件无法释放，影响性能
            this._bannerAd = null;
        }
        this.bannerLoaded = false;
    };
    TTSDK.prototype.showInterstitialAd = function (banner) {
        var _this = this;
        this.useBannerInsteadInsert = banner;
        if (!this.canApiUseInsert()) {
            this.showBannerInsteadInsert();
            return;
        }
        var id = this.getInsertAdUnitId();
        if (!id) {
            this.showBannerInsteadInsert();
            return;
        }
        if (!!this.insertAd) {
            this.insertAd.destroy();
            this.insertAd = null;
        }
        var interstitialAd = this.api.createInterstitialAd({ adUnitId: id });
        if (!interstitialAd) {
            this.onInsertErr("插屏创建失败");
            this.showBannerInsteadInsert();
            return;
        }
        this.insertAd = interstitialAd;
        interstitialAd.onClose(this.onInsertHide.bind(this));
        interstitialAd.onError(function (err) {
            _this.onInsertErr(err);
            _this.showBannerInsteadInsert();
        });
        interstitialAd.load().then(function () {
            try {
                interstitialAd.show().then(function () {
                    _this.removeBanner();
                    _this.onInsertShow();
                }).catch(function (err) {
                    _this.onInsertErr(err);
                    _this.showBannerInsteadInsert();
                });
            }
            catch (err) {
                _this.onInsertErr(err);
                _this.showBannerInsteadInsert();
            }
        });
    };
    /**能否是否api：insert */
    TTSDK.prototype.canApiUseInsert = function () {
        //插屏只支持安卓头条客户端
        if (this.appName !== AppName.touTiao
            || this.platform == SDK_1.Platform.ios) {
            return false;
        }
        return true;
    };
    /**
     * 短震动
     */
    TTSDK.prototype.vibrateShort = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateShort({});
        }
    };
    /**
     * 长震动
     */
    TTSDK.prototype.vibrateLong = function () {
        if (GamePlatform_1.default.instance.Config.vibrate) {
            this.api.vibrateLong({});
        }
    };
    /**
     * 无激励分享&&带参分享
     */
    TTSDK.prototype.shareAppMessage = function (query) {
        if (query === void 0) { query = ''; }
        var index = Math.floor((Math.random() * this.shareTitleArr.length));
        var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
        var self = this;
        this.api.shareAppMessage({
            title: "" + this.shareTitleArr[index],
            imageUrl: "" + this.shareImgArr[indeximg],
            query: query,
            success: function (res) {
                self.showMessage('分享成功');
            },
            fail: function (res) {
                self.showMessage('分享失败');
            },
        });
    };
    /**
     * 激励分享&&带参分享
     */
    TTSDK.prototype.shareToAnyOne = function (success, fail, query) {
        if (query === void 0) { query = ''; }
        var index = Math.floor((Math.random() * this.shareTitleArr.length));
        var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
        var self = this;
        this.api.shareAppMessage({
            title: "" + this.shareTitleArr[index],
            imageUrl: "" + this.shareImgArr[indeximg],
            query: query,
            success: function (res) {
                self.showMessage('分享成功');
                success();
            },
            fail: function (res) {
                self.showMessage('分享失败');
                fail && fail();
            },
        });
    };
    /**
     * 录屏
     */
    TTSDK.prototype.recordVideo = function (type) {
        if (type === void 0) { type = 'start'; }
        var self = this;
        if (null === this.recordMng) {
            this.recordMng = this.api.getGameRecorderManager();
            this.recordMng.onStart(function (res) {
                console.log('录屏开始', res);
            });
            this.recordMng.onPause(function (res) {
                console.log("暂停录屏，", res);
            });
            this.recordMng.onResume(function (res) {
                console.log("继续录屏", res);
            });
            this.recordMng.onStop(function (res) {
                console.log('监听录屏结束', res);
                self.videoPath = res.videoPath + "";
                EventManager_1.default.emit(GameEventType_1.EventType.SDKEvent.recordSaved);
            });
            this.recordMng.onError(function (errMsg) {
                console.log('录屏错误：', JSON.stringify(errMsg));
                self.IsRecordError = true;
                EventManager_1.default.emit(GameEventType_1.EventType.SDKEvent.recordError);
            });
        }
        var recorder = this.recordMng;
        switch (type) {
            case "start": {
                this.IsRecordError = false;
                this.isShared = false;
                recorder.start({
                    duration: 120,
                });
                break;
            }
            case "pause": {
                recorder.pause();
                break;
            }
            case "resume": {
                recorder.resume();
                break;
            }
            case "stop": {
                recorder.stop();
                break;
            }
        }
    };
    /**分享录屏 */
    TTSDK.prototype.shareRecordVideo = function (success, fail) {
        var _this = this;
        var time = this.recordVideoData.totalTime;
        if (time <= 3) {
            this.showMessage("录屏时间短于3s不能分享哦~~");
            if (!!fail)
                fail();
            return;
        }
        console.log('视频地址', this.videoPath, this.IsRecordError);
        var self = this;
        if (this.videoPath && this.IsRecordError == false) {
            var index = Math.floor((Math.random() * this.shareTitleArr.length));
            var indeximg = Math.floor((Math.random() * this.shareImgArr.length));
            this.api.shareAppMessage({
                channel: 'video',
                title: "" + this.shareTitleArr[index],
                imageUrl: "" + this.shareImgArr[indeximg],
                extra: {
                    videoPath: this.videoPath,
                },
                success: function (res) {
                    console.log('录屏发布成功:', JSON.stringify(res));
                    self.showMessage("发布成功");
                    if (!self.isShared) {
                        self.recordVideoData.onShare();
                        self.isShared = true;
                        success();
                    }
                },
                fail: function (res) {
                    console.log('录屏发布失败', JSON.stringify(res));
                    if (res.errMsg.indexOf("short") >= 0) {
                        self.showMessage("录屏时间短于3秒不能分享哦~~");
                    }
                    else if (res.errMsg.indexOf("cancel") >= 0) {
                        self.showMessage("发布取消");
                    }
                    if (!!fail)
                        fail();
                    return;
                    if (_this.appName == AppName.touTiao) { //头条版
                        if (self.systemInfo.platform == "ios") { //苹果手机 安卓手机为 android
                            if (res.errMsg == 'shareAppMessage:fail video duration is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('分享取消');
                            }
                        }
                        else {
                            var msg = res.errMsg.split(',')[0];
                            console.log('msg', msg);
                            if (msg == 'shareAppMessage:fail video file is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                    }
                    else if (_this.appName == AppName.jiSuTT) { //头条极速版
                        if (self.systemInfo.platform == "ios") { //苹果手机 安卓手机为 android
                            if (res.errMsg == 'shareAppMessage:fail video duration is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                        else {
                            var msg = res.errMsg.split(',')[0];
                            console.log('msg', msg);
                            if (msg == 'shareAppMessage:fail video file is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                    }
                    else if (_this.appName == AppName.douYin) { //抖音
                        if (self.systemInfo.platform == "ios") { //苹果手机 安卓手机为 android
                            if (res.errMsg == 'shareAppMessage:fail video duration is too short') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                        else {
                            var msg = res.errMsg.split(',')[0];
                            console.log('msg', msg);
                            if (msg == 'shareAppMessageDirectly:fail') {
                                self.showMessage('录屏时间短于3s不能分享哦~~');
                            }
                            else {
                                self.showMessage('发布取消');
                            }
                        }
                    }
                    else {
                        self.showMessage('发布取消');
                    }
                }
            });
        }
        else {
            self.showMessage('录屏错误');
            if (!!fail)
                fail();
        }
    };
    // /**
    //  * 消息提示
    //  */
    // public showMessage(msg: string, icon: string = 'none') {
    //     this.api.showToast({
    //         title: msg,
    //         duration: 2000,
    //         icon: icon,
    //         success: (res) => { }
    //     });
    // }
    TTSDK.prototype.navigateToMiniProgram = function (data) {
        this.api.navigateToMiniProgram({
            appId: data.gameId,
        });
    };
    return TTSDK;
}(SDK_1.default));
exports.default = TTSDK;
/**字节跳动平台的应用名称 */
var AppName;
(function (AppName) {
    /**开发者工具 */
    AppName[AppName["devtools"] = 0] = "devtools";
    /**今日头条 */
    AppName[AppName["touTiao"] = 1] = "touTiao";
    /**今日头条极速版 */
    AppName[AppName["jiSuTT"] = 2] = "jiSuTT";
    /**抖音 */
    AppName[AppName["douYin"] = 3] = "douYin";
    /**西瓜 */
    AppName[AppName["xiGua"] = 4] = "xiGua";
})(AppName || (AppName = {}));

cc._RF.pop();