"use strict";
cc._RF.push(module, 'dcc1fC1BMVGYoDaYaaesjp4', 'GamePlatformConfig');
// Script/Platform/GamePlatformConfig.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GamePlatformType_1 = require("./GamePlatformType");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GamePlatformConfig = /** @class */ (function (_super) {
    __extends(GamePlatformConfig, _super);
    function GamePlatformConfig() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //平台。
        _this.type = GamePlatformType_1.GamePlatformType.PC;
        _this.version = "";
        _this.appId = "";
        _this.secret = "";
        _this.ServiceAdress = "";
        _this.videoAdUnitId = [];
        _this.BannerAdUnitId = [];
        _this.InterstitialAdUnitId = [];
        _this.appBoxUnitId = [];
        _this.blockAdUnitId = [];
        _this.nativeAdUnitId = [];
        _this.share = true;
        _this.video = true;
        _this.banner = true;
        _this.interstitial = true;
        _this.vibrate = true;
        return _this;
    }
    __decorate([
        property({ type: cc.Enum(GamePlatformType_1.GamePlatformType) })
    ], GamePlatformConfig.prototype, "type", void 0);
    __decorate([
        property
    ], GamePlatformConfig.prototype, "version", void 0);
    __decorate([
        property({
            displayName: "项目appId",
        })
    ], GamePlatformConfig.prototype, "appId", void 0);
    __decorate([
        property({
            displayName: "项目secret",
        })
    ], GamePlatformConfig.prototype, "secret", void 0);
    __decorate([
        property({
            displayName: "项目远程服务器地址",
        })
    ], GamePlatformConfig.prototype, "ServiceAdress", void 0);
    __decorate([
        property({
            displayName: "视频广告Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "videoAdUnitId", void 0);
    __decorate([
        property({
            displayName: "BannerId",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "BannerAdUnitId", void 0);
    __decorate([
        property({
            displayName: "插屏Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "InterstitialAdUnitId", void 0);
    __decorate([
        property({
            displayName: "盒子广告Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "appBoxUnitId", void 0);
    __decorate([
        property({
            displayName: "积木广告Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "blockAdUnitId", void 0);
    __decorate([
        property({
            displayName: "原生广告Id",
            type: [cc.String],
        })
    ], GamePlatformConfig.prototype, "nativeAdUnitId", void 0);
    __decorate([
        property({
            displayName: "开启激励分享",
            tooltip: "是否关闭激励分享，图标也会隐藏"
        })
    ], GamePlatformConfig.prototype, "share", void 0);
    __decorate([
        property({
            displayName: "开启视频广告",
            tooltip: "是否关闭视频广告，图标也会隐藏"
        })
    ], GamePlatformConfig.prototype, "video", void 0);
    __decorate([
        property({
            displayName: "开启Banner",
            tooltip: "是否关闭Banner"
        })
    ], GamePlatformConfig.prototype, "banner", void 0);
    __decorate([
        property({
            displayName: "开启插屏",
            tooltip: "是否关闭插屏"
        })
    ], GamePlatformConfig.prototype, "interstitial", void 0);
    __decorate([
        property({
            displayName: "开启震动",
            tooltip: "是否开启震动"
        })
    ], GamePlatformConfig.prototype, "vibrate", void 0);
    GamePlatformConfig = __decorate([
        ccclass
    ], GamePlatformConfig);
    return GamePlatformConfig;
}(cc.Component));
exports.default = GamePlatformConfig;

cc._RF.pop();