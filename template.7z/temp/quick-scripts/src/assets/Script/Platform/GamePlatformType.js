"use strict";
cc._RF.push(module, 'a0a33dEZ9RBsqUmmWr+YJ9q', 'GamePlatformType');
// Script/Platform/GamePlatformType.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GamePlatformType = void 0;
var GamePlatformType;
(function (GamePlatformType) {
    GamePlatformType[GamePlatformType["PC"] = 0] = "PC";
    GamePlatformType[GamePlatformType["WX"] = 1] = "WX";
    GamePlatformType[GamePlatformType["TT"] = 2] = "TT";
    GamePlatformType[GamePlatformType["QQ"] = 3] = "QQ";
    GamePlatformType[GamePlatformType["OPPO"] = 4] = "OPPO";
    GamePlatformType[GamePlatformType["VIVO"] = 5] = "VIVO";
    GamePlatformType[GamePlatformType["XiaoMi"] = 6] = "XiaoMi";
    GamePlatformType[GamePlatformType["LeYou"] = 7] = "LeYou";
    GamePlatformType[GamePlatformType["DYB_QQ"] = 8] = "DYB_QQ";
    GamePlatformType[GamePlatformType["Blue_Android"] = 9] = "Blue_Android";
    GamePlatformType[GamePlatformType["Blue_IOS"] = 10] = "Blue_IOS";
})(GamePlatformType = exports.GamePlatformType || (exports.GamePlatformType = {}));

cc._RF.pop();