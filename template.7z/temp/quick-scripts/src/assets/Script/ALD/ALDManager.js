"use strict";
cc._RF.push(module, '5aa10EHgGJFXK2ZloCqjYEv', 'ALDManager');
// Script/ALD/ALDManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../Common/yyComponent");
var GameEventType_1 = require("../GameSpecial/GameEventType");
//微信小游戏阿拉丁数据统计管理器
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ALDManager = /** @class */ (function (_super) {
    __extends(ALDManager, _super);
    function ALDManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.apiName = 'wx';
        return _this;
    }
    ALDManager.prototype.init = function () {
        this.api = window[this.apiName];
        if (!!this.api.aldStage) {
            this.onEvents();
        }
    };
    ALDManager.prototype.onEvents = function () {
        this.on(GameEventType_1.EventType.ALDEvent.levelStart, this.onStart, this);
        this.on(GameEventType_1.EventType.ALDEvent.levelWin, this.onLevelWin, this);
        this.on(GameEventType_1.EventType.ALDEvent.levelLose, this.onLevelLose, this);
    };
    /**
     * 关卡开始
     * @param lv    关卡编号
     */
    ALDManager.prototype.onStart = function (lv) {
        var data = {
            stageId: lv.toString(),
            stageName: "第" + lv + "关",
            userId: "" //玩家id
        };
        this.api.aldStage.onStart(data);
    };
    /**
     * 关卡中事件
     * @param data
     * @param data.stageId      关卡id
     * @param data.stageName    关卡名称
     * @param data.userId       用户id
     * @param data.event        事件名称
     * @param data.params       事件参数
     * @param data.params.itemName  道具名称
     * @param data.params.itemCount 道具数量
     * @param data.params.desc      描述
     * @param data.params.itemMoney 道具价格
     */
    ALDManager.prototype.onRunning = function (data) {
        this.api.aldStage.onRunning(data);
    };
    /**
     * 关卡完成
     * @param data
     * @param data.stageId      关卡id
     * @param data.stageName    关卡名称
     * @param data.userId       用户id，可选
     * @param data.event        关卡完成  关卡进行中，用户触发的操作    该字段必传
     * @param data.params
     * @param data.params.desc  描述
     */
    ALDManager.prototype.onEnd = function (data) {
        if (null == data) {
            data = {
                stageId: "1",
                stageName: "第一关",
                event: "complete",
                params: {
                    desc: "关卡完成"
                }
            };
        }
        this.api.aldStage.onEnd(data);
    };
    /**
     * 关卡胜利
     * @param lv 关卡编号
     */
    ALDManager.prototype.onLevelWin = function (lv) {
        var data = this.convertData(lv);
        data.event = "complete";
        data.params = {
            desc: "关卡胜利",
        };
        this.api.aldStage.onEnd(data);
    };
    /**
     * 关卡失败
     * @param lv 关卡编号
     */
    ALDManager.prototype.onLevelLose = function (lv) {
        var data = this.convertData(lv);
        data.event = "fail";
        data.params = {
            desc: "关卡失败",
        };
        this.api.aldStage.onEnd(data);
    };
    /**
     * 通过关卡编号生成阿拉丁统计需要的基础数据
     * @param lv
     */
    ALDManager.prototype.convertData = function (lv) {
        return {
            stageId: lv.toString(),
            stageName: "第" + lv + "关",
            userId: "" //玩家id
        };
    };
    ALDManager = __decorate([
        ccclass
    ], ALDManager);
    return ALDManager;
}(yyComponent_1.default));
exports.default = ALDManager;

cc._RF.pop();