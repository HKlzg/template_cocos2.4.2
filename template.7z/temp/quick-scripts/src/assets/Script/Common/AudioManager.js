"use strict";
cc._RF.push(module, 'c3ffd4uKblBBKHFHlRW8W83', 'AudioManager');
// Script/Common/AudioManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameEventType_1 = require("../GameSpecial/GameEventType");
var EventManager_1 = require("./EventManager");
var GlobalEnum_1 = require("../GameSpecial/GlobalEnum");
var GameConfig_1 = require("../GameSpecial/GameConfig");
var Loader_1 = require("./Loader");
//音效管理器
var AudioManager = /** @class */ (function () {
    function AudioManager() {
    }
    AudioManager.init = function () {
        this.playingEffectCount = 0;
        cc.audioEngine.setMusicVolume(1);
        cc.audioEngine.setEffectsVolume(1);
        this.onEvents();
    };
    AudioManager.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.playBGM, this.playBGM, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.playClickBtn, this.playClickBtn, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.playEffect, this.playEffect, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.stopBGM, this.stop, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.pause, this.pauseBGM, this);
        EventManager_1.default.on(GameEventType_1.EventType.AudioEvent.resume, this.resumeBGM, this);
    };
    AudioManager.playClickBtn = function () {
        this.playEffect(GlobalEnum_1.GlobalEnum.AudioClip.clickBtn);
    };
    AudioManager.playEffect = function (clip) {
        var _this = this;
        if (undefined === this.allClips[clip]) {
            Loader_1.default.loadBundle("Audio", function () {
                Loader_1.default.loadBundleRes("Audio", clip, function (res) {
                    if (!res) {
                        _this.allClips[clip] = null;
                        cc.warn("要播放的音效资源未找到：", clip);
                        return;
                    }
                    _this.allClips[clip] = res;
                    _this._playEffect(clip);
                }, false);
            }, false);
        }
        else {
            this._playEffect(clip);
        }
    };
    AudioManager._playEffect = function (clip) {
        if (!GameConfig_1.default.audioConfig.effect)
            return;
        if (null === this.allClips[clip])
            return;
        if (this.playingEffectCount < this.maxEffectCount) {
            this.playingEffectCount++;
            var id = cc.audioEngine.play(this.allClips[clip], false, 1);
            cc.audioEngine.setFinishCallback(id, this._effectFinish.bind(this));
        }
    };
    AudioManager._effectFinish = function () {
        this.playingEffectCount--;
        if (this.playingEffectCount < 0)
            this.playingEffectCount = 0;
    };
    AudioManager.playBGM = function (clip, loop) {
        var _this = this;
        if (loop === void 0) { loop = true; }
        if (this.curBGM == clip) {
            return;
        }
        if (undefined === this.allClips[clip]) {
            Loader_1.default.loadBundle("Audio", function () {
                Loader_1.default.loadBundleRes("Audio", clip, function (res) {
                    if (!res) {
                        _this.allClips[clip] = null;
                        cc.warn("要播放的音效资源未找到：", clip);
                        return;
                    }
                    _this.allClips[clip] = res;
                    _this._playBGM(clip, loop);
                }, false);
            }, false);
        }
        else {
            this._playBGM(clip, loop);
        }
    };
    AudioManager._playBGM = function (clip, loop) {
        if (!GameConfig_1.default.audioConfig.bgm)
            return;
        if (null === this.allClips[clip])
            return;
        cc.audioEngine.stopMusic();
        cc.audioEngine.playMusic(this.allClips[clip], loop);
        this.curBGM = clip;
    };
    AudioManager.stop = function () {
        this.curBGM = null;
        cc.audioEngine.stopMusic();
    };
    AudioManager.pauseBGM = function () {
        cc.audioEngine.pauseMusic();
        console.log("暂停背景音乐");
    };
    AudioManager.resumeBGM = function () {
        cc.audioEngine.resumeMusic();
        console.log("继续播放背景音乐");
    };
    /**音效资源 */
    AudioManager.allClips = {};
    AudioManager.playingEffectCount = 0;
    /**可同时播放的最大音效数量 */
    AudioManager.maxEffectCount = 3;
    AudioManager.curBGM = null;
    return AudioManager;
}());
exports.default = AudioManager;

cc._RF.pop();