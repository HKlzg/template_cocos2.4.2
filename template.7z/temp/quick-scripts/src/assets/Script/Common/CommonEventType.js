"use strict";
cc._RF.push(module, 'f58a07RCU5EcZ3PXgKStiAX', 'CommonEventType');
// Script/Common/CommonEventType.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**游戏流程相关的事件,从 1000 开始 */
var DirectorEvent;
(function (DirectorEvent) {
    DirectorEvent[DirectorEvent["startIndex"] = 1000] = "startIndex";
    DirectorEvent[DirectorEvent["enterLobby"] = 1001] = "enterLobby";
    DirectorEvent[DirectorEvent["hideGameLobby"] = 1002] = "hideGameLobby";
    DirectorEvent[DirectorEvent["startGame"] = 1003] = "startGame";
    DirectorEvent[DirectorEvent["startLevel"] = 1004] = "startLevel";
    DirectorEvent[DirectorEvent["enterChosedLevel"] = 1005] = "enterChosedLevel";
    DirectorEvent[DirectorEvent["exitLevel"] = 1006] = "exitLevel";
    DirectorEvent[DirectorEvent["playNextLevel"] = 1007] = "playNextLevel";
    DirectorEvent[DirectorEvent["replayCurLevel"] = 1008] = "replayCurLevel";
    DirectorEvent[DirectorEvent["playerWin"] = 1009] = "playerWin";
    DirectorEvent[DirectorEvent["playerLose"] = 1010] = "playerLose";
    DirectorEvent[DirectorEvent["pauseLevel"] = 1011] = "pauseLevel";
    DirectorEvent[DirectorEvent["resumeLevel"] = 1012] = "resumeLevel";
    DirectorEvent[DirectorEvent["matchPlayerFinish"] = 1013] = "matchPlayerFinish";
    DirectorEvent[DirectorEvent["chooseTrySkinFinish"] = 1014] = "chooseTrySkinFinish";
})(DirectorEvent || (DirectorEvent = {}));
/**资源加载相关事件，从 2000 开始 */
var LoadAssetEvent;
(function (LoadAssetEvent) {
    LoadAssetEvent[LoadAssetEvent["startIndex"] = 2000] = "startIndex";
    LoadAssetEvent[LoadAssetEvent["showProgress"] = 2001] = "showProgress";
    LoadAssetEvent[LoadAssetEvent["hideProgress"] = 2002] = "hideProgress";
    LoadAssetEvent[LoadAssetEvent["updateProgress"] = 2003] = "updateProgress";
})(LoadAssetEvent || (LoadAssetEvent = {}));
/**游戏数据相关事件，从 3000 开始 */
var PlayerDataEvent;
(function (PlayerDataEvent) {
    PlayerDataEvent[PlayerDataEvent["startIndex"] = 3000] = "startIndex";
    PlayerDataEvent[PlayerDataEvent["updatePlayerData"] = 3001] = "updatePlayerData";
    PlayerDataEvent[PlayerDataEvent["playerDataChanged"] = 3002] = "playerDataChanged";
    PlayerDataEvent[PlayerDataEvent["trySkinEnd"] = 3003] = "trySkinEnd";
})(PlayerDataEvent || (PlayerDataEvent = {}));
/**SDK相关事件 */
var SDKEvent;
(function (SDKEvent) {
    SDKEvent[SDKEvent["startIndex"] = 4000] = "startIndex";
    SDKEvent[SDKEvent["showMsg"] = 4001] = "showMsg";
    SDKEvent[SDKEvent["showVideo"] = 4002] = "showVideo";
    SDKEvent[SDKEvent["showBanner"] = 4003] = "showBanner";
    SDKEvent[SDKEvent["hideBanner"] = 4004] = "hideBanner";
    SDKEvent[SDKEvent["showBannerFinish"] = 4005] = "showBannerFinish";
    SDKEvent[SDKEvent["showInsertAd"] = 4006] = "showInsertAd";
    SDKEvent[SDKEvent["startRecord"] = 4007] = "startRecord";
    SDKEvent[SDKEvent["pauseRecord"] = 4008] = "pauseRecord";
    SDKEvent[SDKEvent["resumeRecord"] = 4009] = "resumeRecord";
    SDKEvent[SDKEvent["stopRecord"] = 4010] = "stopRecord";
    SDKEvent[SDKEvent["recordSaved"] = 4011] = "recordSaved";
    SDKEvent[SDKEvent["recordError"] = 4012] = "recordError";
    SDKEvent[SDKEvent["shareRecord"] = 4013] = "shareRecord";
    SDKEvent[SDKEvent["bannerResize"] = 4014] = "bannerResize";
    SDKEvent[SDKEvent["navigateToMiniProgram"] = 4015] = "navigateToMiniProgram";
    SDKEvent[SDKEvent["vibrateShort"] = 4016] = "vibrateShort";
    SDKEvent[SDKEvent["vibrateLong"] = 4017] = "vibrateLong";
    SDKEvent[SDKEvent["hide"] = 4018] = "hide";
    SDKEvent[SDKEvent["show"] = 4019] = "show";
    SDKEvent[SDKEvent["showInsertByPauseLevel"] = 4020] = "showInsertByPauseLevel";
    SDKEvent[SDKEvent["triggerGC"] = 4021] = "triggerGC";
    SDKEvent[SDKEvent["showNativeAd"] = 4022] = "showNativeAd";
    SDKEvent[SDKEvent["hideNativeAd"] = 4023] = "hideNativeAd";
    SDKEvent[SDKEvent["hideAllNativeAd"] = 4024] = "hideAllNativeAd";
    SDKEvent[SDKEvent["quickShowNativeAd"] = 4025] = "quickShowNativeAd";
    SDKEvent[SDKEvent["quickHideNativeAd"] = 4026] = "quickHideNativeAd";
    //安卓/苹果端原生包SDK事件：
    SDKEvent[SDKEvent["callJSVideoSuccess"] = 4027] = "callJSVideoSuccess";
    SDKEvent[SDKEvent["callJSVideoFail"] = 4028] = "callJSVideoFail";
    SDKEvent[SDKEvent["callJSVideoError"] = 4029] = "callJSVideoError";
    SDKEvent[SDKEvent["callJSFullVideoSuccess"] = 4030] = "callJSFullVideoSuccess";
    SDKEvent[SDKEvent["callJSFullVideoFail"] = 4031] = "callJSFullVideoFail";
    SDKEvent[SDKEvent["callJSFullVideoError"] = 4032] = "callJSFullVideoError";
    //QQ平台：
    SDKEvent[SDKEvent["showAppBox"] = 4033] = "showAppBox";
    SDKEvent[SDKEvent["showBlockAd"] = 4034] = "showBlockAd";
    SDKEvent[SDKEvent["subscribeMsg"] = 4035] = "subscribeMsg";
    SDKEvent[SDKEvent["addColorSign"] = 4036] = "addColorSign";
})(SDKEvent || (SDKEvent = {}));
/**UI相关事件 */
var UIEvent;
(function (UIEvent) {
    UIEvent[UIEvent["startIndex"] = 5000] = "startIndex";
    UIEvent[UIEvent["playGoldAnim"] = 5001] = "playGoldAnim";
    UIEvent[UIEvent["goldAnimPlayFinish"] = 5002] = "goldAnimPlayFinish";
    UIEvent[UIEvent["showTip"] = 5003] = "showTip";
    UIEvent[UIEvent["showTouchMask"] = 5004] = "showTouchMask";
    UIEvent[UIEvent["hideTouchMask"] = 5005] = "hideTouchMask";
    UIEvent[UIEvent["enter"] = 5006] = "enter";
    UIEvent[UIEvent["entered"] = 5007] = "entered";
    UIEvent[UIEvent["exit"] = 5008] = "exit";
    UIEvent[UIEvent["exited"] = 5009] = "exited";
})(UIEvent || (UIEvent = {}));
/**音效事件 */
var AudioEvent;
(function (AudioEvent) {
    AudioEvent[AudioEvent["startIndex"] = 6000] = "startIndex";
    AudioEvent[AudioEvent["playBGM"] = 6001] = "playBGM";
    AudioEvent[AudioEvent["playEffect"] = 6002] = "playEffect";
    AudioEvent[AudioEvent["playClickBtn"] = 6003] = "playClickBtn";
    AudioEvent[AudioEvent["stopBGM"] = 6004] = "stopBGM";
    AudioEvent[AudioEvent["changeConfig"] = 6005] = "changeConfig";
    AudioEvent[AudioEvent["pause"] = 6006] = "pause";
    AudioEvent[AudioEvent["resume"] = 6007] = "resume";
})(AudioEvent || (AudioEvent = {}));
/**阿拉丁数据统计事件 */
var ALDEvent;
(function (ALDEvent) {
    ALDEvent[ALDEvent["startIndex"] = 7000] = "startIndex";
    ALDEvent[ALDEvent["levelStart"] = 7001] = "levelStart";
    ALDEvent[ALDEvent["levelWin"] = 7002] = "levelWin";
    ALDEvent[ALDEvent["levelLose"] = 7003] = "levelLose";
    ALDEvent[ALDEvent["levelExit"] = 7004] = "levelExit";
})(ALDEvent || (ALDEvent = {}));
/**互推相关事件 */
var RecommendEvent;
(function (RecommendEvent) {
    RecommendEvent[RecommendEvent["startIndex"] = 8000] = "startIndex";
    RecommendEvent[RecommendEvent["assetLoadFinish"] = 8001] = "assetLoadFinish";
    RecommendEvent[RecommendEvent["clickRecommendItem"] = 8002] = "clickRecommendItem";
    RecommendEvent[RecommendEvent["clickBtnRecommend_TT"] = 8003] = "clickBtnRecommend_TT";
    RecommendEvent[RecommendEvent["hideRecommend"] = 8004] = "hideRecommend";
    RecommendEvent[RecommendEvent["openDrawer"] = 8005] = "openDrawer";
    RecommendEvent[RecommendEvent["drawerStartOpen"] = 8006] = "drawerStartOpen";
    RecommendEvent[RecommendEvent["drawerOpened"] = 8007] = "drawerOpened";
    RecommendEvent[RecommendEvent["closeDrawer"] = 8008] = "closeDrawer";
    RecommendEvent[RecommendEvent["drawerStartClose"] = 8009] = "drawerStartClose";
    RecommendEvent[RecommendEvent["drawerClosed"] = 8010] = "drawerClosed";
})(RecommendEvent || (RecommendEvent = {}));
/**玩家资产事件 */
var AssetEvent;
(function (AssetEvent) {
    AssetEvent[AssetEvent["startIndex"] = 9000] = "startIndex";
    AssetEvent[AssetEvent["powerChanged"] = 9001] = "powerChanged";
    AssetEvent[AssetEvent["powerUnEnough"] = 9002] = "powerUnEnough";
    AssetEvent[AssetEvent["consumePower"] = 9003] = "consumePower";
    AssetEvent[AssetEvent["getPower"] = 9004] = "getPower";
})(AssetEvent || (AssetEvent = {}));
/**后台开关事件，从10000开始 */
var AdvertSwitchEvent;
(function (AdvertSwitchEvent) {
    AdvertSwitchEvent[AdvertSwitchEvent["startIndex"] = 10000] = "startIndex";
    AdvertSwitchEvent[AdvertSwitchEvent["loadConfigSuccess"] = 10001] = "loadConfigSuccess";
    AdvertSwitchEvent[AdvertSwitchEvent["changeScene"] = 10002] = "changeScene";
    AdvertSwitchEvent[AdvertSwitchEvent["closeFullRecommend"] = 10003] = "closeFullRecommend";
    AdvertSwitchEvent[AdvertSwitchEvent["onBtnFadeExit"] = 10004] = "onBtnFadeExit";
})(AdvertSwitchEvent || (AdvertSwitchEvent = {}));
/**触摸控制器事件，适用于只有一个节点接收触摸操作的场景，从11000开始 */
var CtrlEvent;
(function (CtrlEvent) {
    CtrlEvent[CtrlEvent["startIndex"] = 11000] = "startIndex";
    CtrlEvent[CtrlEvent["ctrlStart"] = 11001] = "ctrlStart";
    CtrlEvent[CtrlEvent["ctrlEnd"] = 11002] = "ctrlEnd";
    CtrlEvent[CtrlEvent["touchStart"] = 11003] = "touchStart";
    CtrlEvent[CtrlEvent["touchMove"] = 11004] = "touchMove";
    CtrlEvent[CtrlEvent["touchEnd"] = 11005] = "touchEnd";
    CtrlEvent[CtrlEvent["touchStay"] = 11006] = "touchStay";
})(CtrlEvent || (CtrlEvent = {}));
/**商城相关事件，从12000开始 */
var ShopEvent;
(function (ShopEvent) {
    ShopEvent[ShopEvent["startIndex"] = 12000] = "startIndex";
    ShopEvent[ShopEvent["chooseItem"] = 12001] = "chooseItem";
    ShopEvent[ShopEvent["changeDisplayItem"] = 12002] = "changeDisplayItem";
})(ShopEvent || (ShopEvent = {}));
/**乐游SDK专属事件，从13000开始 */
var LeYouRecommend;
(function (LeYouRecommend) {
    LeYouRecommend[LeYouRecommend["startIndex"] = 13000] = "startIndex";
    /**底部猜你喜欢互推 */
    LeYouRecommend[LeYouRecommend["showMoreGameByBanner"] = 13001] = "showMoreGameByBanner";
    /**单个图标的互推 */
    LeYouRecommend[LeYouRecommend["showMoreGameByIcon"] = 13002] = "showMoreGameByIcon";
    /**更多游戏互推 */
    LeYouRecommend[LeYouRecommend["showMoreGame"] = 13003] = "showMoreGame";
    /**侧边栏互推 */
    LeYouRecommend[LeYouRecommend["showMoreGameSide"] = 13004] = "showMoreGameSide";
    /**中间水平滚动的互推 */
    LeYouRecommend[LeYouRecommend["showMoreGameMiddle"] = 13005] = "showMoreGameMiddle";
})(LeYouRecommend || (LeYouRecommend = {}));
/**数据统计事件，从14000开始 */
var TongJi;
(function (TongJi) {
    TongJi[TongJi["startIndex"] = 14000] = "startIndex";
    /**用户事件漏斗（进区服事件） */
    TongJi[TongJi["appOnce"] = 14001] = "appOnce";
    /**分享出日志 */
    TongJi[TongJi["sharedOut"] = 14002] = "sharedOut";
    /**通过分享进入 */
    TongJi[TongJi["sharedIn"] = 14003] = "sharedIn";
    /**视频广告事件 */
    TongJi[TongJi["video"] = 14004] = "video";
    /**升级 */
    TongJi[TongJi["levelUp"] = 14005] = "levelUp";
    /**完成任务 */
    TongJi[TongJi["task"] = 14006] = "task";
    /**自定义行为 */
    TongJi[TongJi["action"] = 14007] = "action";
    /**充值 */
    TongJi[TongJi["pay"] = 14008] = "pay";
    /**money日志 */
    TongJi[TongJi["money"] = 14009] = "money";
    /**道具 */
    TongJi[TongJi["item"] = 14010] = "item";
    /**闯关 */
    TongJi[TongJi["battle"] = 14011] = "battle";
    /**装备日志 */
    TongJi[TongJi["equip"] = 14012] = "equip";
    /**装备升级 */
    TongJi[TongJi["equipLevel"] = 14013] = "equipLevel";
    /**装备升阶 */
    TongJi[TongJi["equipDegree"] = 14014] = "equipDegree";
    /**装备玩法 */
    TongJi[TongJi["equipPlayWay"] = 14015] = "equipPlayWay";
    /**自定义事件 */
    TongJi[TongJi["event"] = 14016] = "event";
    /**清除云存储数据 */
    TongJi[TongJi["clear"] = 14017] = "clear";
    /**广告错误日志 */
    TongJi[TongJi["error"] = 14018] = "error";
    /**解锁皮肤事件 */
    TongJi[TongJi["unlockSkin"] = 14019] = "unlockSkin";
})(TongJi || (TongJi = {}));
/**柚子互推专属事件，从15000开始 */
var YouZiRecommend;
(function (YouZiRecommend) {
    YouZiRecommend[YouZiRecommend["startIndex"] = 15000] = "startIndex";
    /**显示全屏落地推广页 */
    YouZiRecommend[YouZiRecommend["showFullScreenIcon"] = 15001] = "showFullScreenIcon";
    /**显示游戏合集 */
    YouZiRecommend[YouZiRecommend["showYouziGameCollectionPage"] = 15002] = "showYouziGameCollectionPage";
})(YouZiRecommend || (YouZiRecommend = {}));
/**
 * 适用于框架的通用事件类型
 *
 * 在子类中添加游戏专属的事件时， startIndex 从 100000 开始
 */
var CommonEventType = /** @class */ (function () {
    function CommonEventType() {
    }
    CommonEventType.DirectorEvent = DirectorEvent;
    CommonEventType.LoadAssetEvent = LoadAssetEvent;
    CommonEventType.PlayerDataEvent = PlayerDataEvent;
    CommonEventType.SDKEvent = SDKEvent;
    CommonEventType.UIEvent = UIEvent;
    CommonEventType.AudioEvent = AudioEvent;
    CommonEventType.ALDEvent = ALDEvent;
    CommonEventType.RecommendEvent = RecommendEvent;
    CommonEventType.AssetEvent = AssetEvent;
    CommonEventType.AdvertSwitchEvent = AdvertSwitchEvent;
    CommonEventType.CtrlEvent = CtrlEvent;
    CommonEventType.ShopEvent = ShopEvent;
    CommonEventType.LeYouRecommend = LeYouRecommend;
    CommonEventType.TongJi = TongJi;
    CommonEventType.YouZiRecommend = YouZiRecommend;
    return CommonEventType;
}());
exports.default = CommonEventType;

cc._RF.pop();