"use strict";
cc._RF.push(module, 'adf24pKBfVFoZ3UCJW+E7Fs', 'CommonGameConfig');
// Script/Common/CommonGameConfig.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 全局使用的游戏配置，只包含静态数据
 *
 * 基类中包含了适用于框架的游戏通用的配置，可在子类中根据实际游戏自定义新的属性
 */
var CommonGameConfig = /** @class */ (function () {
    function CommonGameConfig() {
    }
    CommonGameConfig.initAudioConfig = function () {
        if (!this._audioConfig) {
            var config = cc.sys.localStorage.getItem("audioConfig");
            if (!!config) {
                this._audioConfig = JSON.parse(config);
            }
            else {
                this._audioConfig = new AudioConfig();
            }
        }
    };
    Object.defineProperty(CommonGameConfig, "audioConfig", {
        get: function () {
            this.initAudioConfig();
            return this._audioConfig;
        },
        set: function (config) {
            this.initAudioConfig();
            this._audioConfig.bgm = !!config.bgm;
            this._audioConfig.effect = !!config.effect;
            cc.sys.localStorage.setItem("audioConfig", JSON.stringify(this._audioConfig));
        },
        enumerable: false,
        configurable: true
    });
    CommonGameConfig.initDriveConfig = function () {
        if (!this._driveConfig) {
            var config = cc.sys.localStorage.getItem("driveConfig");
            if (!!config) {
                this._driveConfig = JSON.parse(config);
            }
            else {
                this._driveConfig = new DriveConfig();
            }
        }
    };
    Object.defineProperty(CommonGameConfig, "driveConfig", {
        get: function () {
            this.initDriveConfig();
            return this._driveConfig;
        },
        set: function (config) {
            this.initDriveConfig();
            this._driveConfig.vibrate = !!config.vibrate;
            cc.sys.localStorage.setItem("driveConfig", JSON.stringify(this._driveConfig));
        },
        enumerable: false,
        configurable: true
    });
    /**游戏名称字符串 */
    CommonGameConfig.gameName = "myGame";
    //音效设置
    //#region 音效设置
    CommonGameConfig._audioConfig = null;
    //#endregion
    //#region 与设备相关的设置
    CommonGameConfig._driveConfig = null;
    return CommonGameConfig;
}());
exports.default = CommonGameConfig;
/**音效配置 */
var AudioConfig = /** @class */ (function () {
    function AudioConfig() {
        /**是否可播放背景音乐 */
        this.bgm = true;
        /**是否可播放特效 */
        this.effect = true;
    }
    return AudioConfig;
}());
var DriveConfig = /** @class */ (function () {
    function DriveConfig() {
        this.vibrate = true;
    }
    return DriveConfig;
}());

cc._RF.pop();