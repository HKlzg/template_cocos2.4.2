"use strict";
cc._RF.push(module, 'bc9d8TfjwRC0J+4t02oPAHq', 'PlayerData');
// Script/Common/PlayerData.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventManager_1 = require("./EventManager");
var PlayerDataTemplate_1 = require("../GameSpecial/PlayerDataTemplate");
var GameConfig_1 = require("../GameSpecial/GameConfig");
var GameEventType_1 = require("../GameSpecial/GameEventType");
//玩家数据管理器
var PlayerData = /** @class */ (function () {
    function PlayerData() {
    }
    PlayerData.init = function () {
        this.Data = PlayerDataTemplate_1.default.getData();
        var resetPlayerData = cc.sys.localStorage.getItem(GameConfig_1.default.gameName + "needResetPlayerData7");
        if (!resetPlayerData || !JSON.parse(resetPlayerData)) {
            var v = cc.sys.localStorage.getItem(GameConfig_1.default.gameName + "PlayerData");
            if (!!v) {
                v = JSON.parse(v);
                this.copyObject(this.Data, v);
            }
        }
        cc.sys.localStorage.setItem(GameConfig_1.default.gameName + "needResetPlayerData7", JSON.stringify(false));
        this.resetTrySkin();
        this.onEvents();
    };
    PlayerData.copyObject = function (target, src) {
        for (var key in src) {
            switch (typeof src[key]) {
                case "number":
                case "boolean":
                case "string": {
                    target[key] = src[key];
                    break;
                }
                case "object": {
                    if (Array.isArray(src[key])) {
                        target[key] = [].concat(src[key]);
                    }
                    else {
                        if (undefined == target[key])
                            target[key] = {};
                        this.copyObject(target[key], src[key]);
                    }
                    break;
                }
                default: {
                    break;
                }
            }
        }
    };
    PlayerData.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.PlayerDataEvent.updatePlayerData, this.onUpdatePlayerData, this);
    };
    /**
     * 更新玩家数据
     * @param data
     * @param {string} [data.attribute] 要修改的数据的字段名称，用“.”号分割多级子属性，例如“gameData.curLevel”
     * @param {number|string} [data.value] 属性改变的量
     * @param {string} [data.mode] 数据修改方式
     * @param {boolean} [data.save] 是否需要及时保存数据，默认为true
     * @param {boolean} [data.emit] 是否需要及时通知外界玩家数据已变化，默认为true
     */
    PlayerData.onUpdatePlayerData = function (data) {
        if (data.attribute.indexOf(".") < 0) {
            this.updateData(this.Data, data.attribute, data.value, data.mode);
        }
        else {
            var str = data.attribute.split(".");
            var playerData = this.Data;
            for (var i = 0; i < str.length - 1; ++i) {
                if (undefined != playerData[str[i]]) {
                    playerData = playerData[str[i]];
                }
                else {
                    cc.log("修改玩家数据失败，玩家数据未定义对应属性：" + str[i]);
                    cc.log(data);
                    return;
                }
            }
            this.updateData(playerData, str[str.length - 1], data.value, data.mode);
        }
        if (undefined === data.save || true === data.save) {
            this.saveData();
        }
        if (undefined === data.emit || true === data.emit) {
            //数据更新后发送事件，UI组件自动处理
            EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
                attribute: data.attribute,
                value: this.getData(data.attribute),
            });
        }
    };
    /**
     * 更新对象的字段值
     * @param data      字段所属对象
     * @param attribute 字段名称
     * @param value     要改变的值
     * @param mode      改变方式
     */
    PlayerData.updateData = function (data, attribute, value, mode) {
        switch (mode) {
            case "+": {
                data[attribute] += parseFloat(value);
                break;
            }
            case "-": {
                data[attribute] -= parseFloat(value);
                break;
            }
            case "*": {
                data[attribute] *= parseFloat(value);
                break;
            }
            case "=": {
                data[attribute] = parseFloat(value);
                break;
            }
            case "push": {
                data[attribute].push(value);
                break;
            }
            default: {
                cc.log("数据修改失败，未定义的数据修改方式：" + mode);
                break;
            }
        }
    };
    /**
     * 获取玩家数据
     * @param attribute 字段名称，用“.”号分割多级子属性，例如“gameData.curLevel”
     */
    PlayerData.getData = function (attribute) {
        if (!attribute) {
            return this.Data;
        }
        if (attribute.indexOf(".") < 0) {
            return this.Data[attribute];
        }
        var str = attribute.split(".");
        var playerData = this.Data;
        for (var i = 0; i < str.length; ++i) {
            if (undefined != playerData[str[i]]) {
                playerData = playerData[str[i]];
            }
            else {
                return playerData;
            }
        }
        return playerData;
    };
    //存储数据，将在本地存储，并发送给服务端
    PlayerData.saveData = function () {
        cc.sys.localStorage.setItem(GameConfig_1.default.gameName + "PlayerData", JSON.stringify(this.Data));
        //todo: 发送给服务端
    };
    //一些通用的快捷方法：
    //金币
    /**增加金币 */
    PlayerData.addGold = function (gold) {
        this.Data.gameData.asset.gold += gold;
        EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
            type: "gameData",
            attribute: "gameData.asset.gold",
            value: this.Data.gameData.asset.gold,
        });
    };
    /**
     * 快捷方法：减少金币
     * @param gold  减少的金币数量
     */
    PlayerData.subGold = function (gold) {
        if (gold <= this.Data.gameData.asset.gold) {
            this.Data.gameData.asset.gold -= gold;
        }
        else {
            this.Data.gameData.asset.gold = 0;
        }
        EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
            type: "gameData",
            attribute: "gameData.asset.gold",
            value: this.Data.gameData.asset.gold,
        });
    };
    //皮肤
    /**
     * 获取当前使用的皮肤，激活了试用皮肤时，将返回试用皮肤
     * @param type 皮肤类型
     */
    PlayerData.getCurSkinId = function (type) {
        var data = this.Data.gameData[type];
        var id = data.try;
        if (id == -1) {
            id = data.cur;
        }
        return id;
    };
    /**
     * 解锁皮肤
     * @param type  皮肤类型
     * @param id    皮肤id
     */
    PlayerData.unlockSkin = function (type, id) {
        var data = this.Data.gameData[type];
        if (data.owned.indexOf(id) >= 0) {
            return;
        }
        data.owned.push(id);
        EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
            type: "gameData",
            attribute: "gameData." + type + ".owned",
            value: data.owned,
        });
    };
    /**
     * 设置指定皮肤为当前使用的皮肤
     * @param type  皮肤类型
     * @param id    皮肤id
     */
    PlayerData.setCurSkin = function (type, id) {
        var data = this.Data.gameData[type];
        if (data.cur == id)
            return;
        data.cur = id;
        EventManager_1.default.emit(GameEventType_1.EventType.PlayerDataEvent.playerDataChanged, {
            type: "gameData",
            attribute: "gameData." + type + ".cur",
            value: data.cur,
        });
    };
    /**
     * 试用皮肤
     * @param type  皮肤类型
     * @param id    皮肤id
     */
    PlayerData.onTrySkin = function (type, id) {
        this.Data.gameData[type].try = id;
    };
    /**
     * 皮肤试用结束
     * @param type  皮肤类型
     */
    PlayerData.onTrySkinEnd = function (type) {
        this.Data.gameData[type].try = -1;
    };
    PlayerData.resetTrySkin = function () {
        var data = this.Data.gameData;
        for (var key in data) {
            if (typeof data[key] == "object" && !!data[key].try) {
                data[key].try = -1;
            }
        }
    };
    PlayerData.Data = {};
    return PlayerData;
}());
exports.default = PlayerData;

cc._RF.pop();