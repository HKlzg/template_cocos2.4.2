"use strict";
cc._RF.push(module, 'dadc8E+D51OzpDph59yTsyO', 'PowerManager');
// CommonScript/PowerManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameEventType_1 = require("../GameSpecial/GameEventType");
var EventManager_1 = require("./EventManager");
var GameConfig_1 = require("../GameSpecial/GameConfig");
//体力管理器
var PowerManager = /** @class */ (function () {
    function PowerManager() {
    }
    PowerManager.init = function () {
        this.data = this.loadOldData();
        this.startAutoRecoverPower();
        this.onEvents();
    };
    PowerManager.loadOldData = function () {
        var data = new PowerData();
        var oldData = cc.sys.localStorage.getItem(GameConfig_1.default.gameName + "PowerData");
        if (!!oldData) {
            oldData = JSON.parse(oldData);
            data.curPower = oldData.curPower;
            data.lastSaveTime = oldData.lastSaveTime;
        }
        return data;
    };
    PowerManager.startAutoRecoverPower = function () {
        var _this = this;
        var lastTime = this.data.lastSaveTime;
        var now = Date.now();
        var d1 = new Date(lastTime).getDate();
        var d2 = new Date(now).getDate();
        if (d2 > d1) {
            //隔天恢复满体力
            this.data.lastSaveTime = now;
            this.addPower(this.data.maxPower);
            setInterval(this.recoverPower.bind(this), this.data.recoverPowerInterval, this.data.recoverPowerValue);
        }
        else {
            //补充离线时间恢复的体力
            var passTime = now - lastTime;
            var power = Math.floor(passTime / this.data.recoverPowerInterval) * this.data.recoverPowerValue;
            var delay = passTime % this.data.recoverPowerInterval;
            if (power > 0) {
                this.data.lastSaveTime = now - delay;
                this.addPower(power);
            }
            setTimeout(function () {
                setInterval(_this.recoverPower.bind(_this), _this.data.recoverPowerInterval, _this.data.recoverPowerValue);
            }, this.data.recoverPowerInterval - delay);
        }
    };
    PowerManager.recoverPower = function () {
        this.data.addPower(this.data.recoverPowerValue);
        this.data.updateLastSaveTime();
        this.saveData();
        this.emit(GameEventType_1.EventType.AssetEvent.powerChanged, this.data.curPower);
    };
    PowerManager.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.AssetEvent.consumePower, this.onConsumePower, this);
        EventManager_1.default.on(GameEventType_1.EventType.AssetEvent.getPower, this.addPower, this);
    };
    /**
     * 获取体力数据
     */
    PowerManager.getData = function () {
        return {
            //能够拥有的最大体力值
            maxPower: this.data.maxPower,
            //当前体力值
            curPower: this.data.curPower,
            //恢复体力需要的总时间，单位：秒
            totalTime: Math.floor(this.data.recoverPowerInterval * 0.001),
            //当前已经过的时间，单位：秒
            curTime: Math.floor((Date.now() - this.data.lastSaveTime) * 0.001),
        };
    };
    PowerManager.saveData = function () {
        cc.sys.localStorage.setItem(GameConfig_1.default.gameName + "powerData", JSON.stringify(this.data));
    };
    PowerManager.addPower = function (v) {
        if (v === void 0) { v = 1; }
        this.data.addPower(v);
        this.saveData();
        this.emit(GameEventType_1.EventType.AssetEvent.powerChanged, this.data.curPower);
    };
    PowerManager.subPower = function (v) {
        if (this.data.subPower(v)) {
            this.saveData();
            this.emit(GameEventType_1.EventType.AssetEvent.powerChanged, this.data.curPower);
        }
    };
    /**
     * 扣除体力，执行回调
     * @param data
     * @param [data.cb]     回调函数
     * @param [data.power]  需要扣除的体力，默认为1
     */
    PowerManager.onConsumePower = function (data) {
        var power = data.power;
        if (undefined == data.power) {
            power = 1;
        }
        if (this.data.subPower(power)) {
            !!data.cb && data.cb();
        }
        else {
            this.tipPowerUnEnough();
        }
    };
    PowerManager.tipPowerUnEnough = function () {
        this.emit(GameEventType_1.EventType.AssetEvent.powerUnEnough, this.data.curPower);
    };
    PowerManager.emit = function (eventType, data) {
        EventManager_1.default.emit(eventType, data);
    };
    PowerManager.data = null;
    return PowerManager;
}());
exports.default = PowerManager;
var PowerData = /** @class */ (function () {
    function PowerData() {
        /**最大体力值 */
        this.maxPower = 10;
        /**体力自动恢复的时间间隔，单位：毫秒 */
        this.recoverPowerInterval = 300000;
        /**体力自动恢复的量 */
        this.recoverPowerValue = 1;
        /**当前体力值 */
        this.curPower = 10;
        /**最后一次恢复体力的时间 */
        this.lastSaveTime = 0;
        this.curPower = 10;
        this.lastSaveTime = Date.now();
    }
    PowerData.prototype.addPower = function (v) {
        if (v === void 0) { v = 1; }
        this.curPower += v;
        if (this.curPower > this.maxPower) {
            this.curPower = this.maxPower;
        }
    };
    PowerData.prototype.subPower = function (v) {
        if (this.curPower < v)
            return false;
        this.curPower -= v;
        return true;
    };
    PowerData.prototype.updateLastSaveTime = function () {
        this.lastSaveTime = Date.now();
    };
    return PowerData;
}());

cc._RF.pop();