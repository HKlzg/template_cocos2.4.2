"use strict";
cc._RF.push(module, '8b8f7V7UqZE24WpKssNCDL7', 'GameData');
// Script/Common/GameData.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GlobalEnum_1 = require("../GameSpecial/GlobalEnum");
var LevelDataTemplate_1 = require("../GameSpecial/LevelDataTemplate");
/**游戏JSON数据管理器 */
var GameData = /** @class */ (function () {
    function GameData() {
    }
    GameData.init = function () {
        this.data = {};
        //一些常见的数据类型，使用默认数据进行初始化
        //关卡：
        this.data[GlobalEnum_1.GlobalEnum.GameDataType.levelData] = LevelDataTemplate_1.default.getData();
    };
    GameData.setData = function (res, urls) {
        for (var key in GlobalEnum_1.GlobalEnum.GameDataType) {
            var index = this.getUrlsIndex(GlobalEnum_1.GlobalEnum.GameDataType[key], urls);
            if (index >= 0) {
                this.data[GlobalEnum_1.GlobalEnum.GameDataType[key]] = res[index].json;
            }
            else {
                console.warn("数据类型不存在：", GlobalEnum_1.GlobalEnum.GameDataType[key]);
            }
        }
        //数据从数组转换为对象
        for (var key in GlobalEnum_1.GlobalEnum.GameDataType) {
            var type = GlobalEnum_1.GlobalEnum.GameDataType[key];
            if (!!this.data[type] && Array.isArray(this.data[type])) {
                var arr = this.data[type];
                var d = {};
                for (var i = arr.length - 1; i >= 0; --i) {
                    d[arr[i].id] = arr[i];
                }
                this.data[type] = d;
            }
        }
    };
    /**获取数据类型字符串在资源url数组中的索引 */
    GameData.getUrlsIndex = function (name, urls) {
        for (var i = urls.length - 1; i >= 0; --i) {
            if (urls[i].indexOf(name) >= 0) {
                return i;
            }
        }
        return -1;
    };
    /**添加记录数据 */
    GameData.addData = function (type, data) {
        if (!!this.data[type]) {
            console.warn("对应类型的数据已经存在，请检查类型是否重名:", type);
            return;
        }
        this.data[type] = data;
    };
    /**
     * 获取游戏数据
     * @param type  数据类型枚举值
     * @param key   需要的具体数据
     */
    GameData.getData = function (type, key) {
        if (undefined === this.data[type]) {
            console.warn("不存在对应类型的数据：", type);
            return null;
        }
        if (undefined === key) {
            return this.data[type];
        }
        else {
            return this.data[type][key];
        }
    };
    //一些常见的数据的快捷获取方法
    /**关卡数据 */
    GameData.getLevelData = function (lv) {
        var data = this.data[GlobalEnum_1.GlobalEnum.GameDataType.levelData];
        if (!data) {
            cc.log("不存在关卡数据，使用示例数据");
            return LevelDataTemplate_1.default.getData(); //不存在关卡数据时，使用示例关卡数据
        }
        //超出关卡数时随机
        if (!data[lv]) {
            var keys = Object.keys(data);
            var index = Math.round(Math.random() * (keys.length - 1));
            if (parseInt(keys[index]) <= 3) {
                cc.log("关卡" + lv + "不存在数据，使用随机关卡数据：" + keys[keys.length - 1]);
                return data[keys[keys.length - 1]];
            }
            else {
                cc.log("关卡" + lv + "不存在数据，使用随机关卡数据：" + keys[index]);
                return data[keys[index]];
            }
        }
        else {
            return data[lv];
        }
    };
    /**
     * 记录所有游戏数据，
     * key:数据类型枚举值；
     * value:数据
     */
    GameData.data = {};
    return GameData;
}());
exports.default = GameData;

cc._RF.pop();