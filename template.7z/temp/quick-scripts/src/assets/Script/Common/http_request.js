"use strict";
cc._RF.push(module, '2c29csX5rhKb490tgYRKTP0', 'http_request');
// Script/Common/http_request.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Button_manager_1 = require("../mananer/Button_manager");
var http_request = /** @class */ (function () {
    function http_request() {
        this.objFunc = {};
    }
    http_request.getInstance = function () {
        if (!http_request._instance) {
            http_request._instance = new http_request();
        }
        return http_request._instance;
    };
    http_request.prototype.postRequest = function (url, _data, _callback) {
        Button_manager_1.default.getInstance().setIsClick(false);
        console.log('postRequest --->', url);
        var http = new XMLHttpRequest();
        http.addEventListener("error", this.onRequestError);
        http.open("POST", url, true); //初始化请求
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        // httpRequest.setRequestHeader("Content-type","application/json");
        var str = '';
        for (var a in _data) {
            str += a + "=" + encodeURIComponent(_data[a]) + '&';
        }
        str = str.substr(0, str.length - 1);
        http.send(str); //JSON.stringify(_data)
        http.onreadystatechange = function () {
            var state = http.readyState; //返回服务器的状态
            var status = http.status;
            if (state == 4 && status == 200) {
                var response = http.responseText; //返回的信息是一个字符串
                var data = JSON.parse(response); //解析字符串
                Button_manager_1.default.getInstance().setIsClick(true);
                _callback && _callback(data);
            }
        };
    };
    http_request.prototype.get = function (url, _data, _callback) {
        Button_manager_1.default.getInstance().setIsClick(false);
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.timeout = 10 * 1000;
        xhr.open("GET", url, true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (this.readyState === 4 && (this.status >= 200 && this.status < 300)) {
                var respone = xhr.responseText;
                if (!respone)
                    console.log("httperror", respone);
                var resp = JSON.parse(respone);
                _callback(resp);
                Button_manager_1.default.getInstance().setIsClick(true);
            }
        };
        var str = '';
        for (var a in _data) {
            str += a + "=" + _data[a] + '&';
        }
        str = str.substr(0, str.length - 1);
        xhr.send(str);
    };
    http_request.prototype.setRequestErrorFunc = function (cb, target) {
        this.objFunc['error'] = { 'cb': cb, 'target': target };
    };
    http_request.prototype.onRequestError = function () {
        //请求失败
        if (this.objFunc['error']) {
            var obj = this.objFunc['error'];
            obj['cb'].call(obj['target'], "游戏维护中");
        }
    };
    http_request.url_ad = 'https://ad.geyian.ink/';
    http_request.url_login = 'https://tjqh.youdongxi.cn/';
    http_request.url_gamelevel = 'https://img.youdongxi.cn/';
    http_request.url_buy = "https://tj.geyian.ink/";
    http_request._instance = null;
    return http_request;
}());
exports.default = http_request;

cc._RF.pop();