"use strict";
cc._RF.push(module, '1b75e2LoNBL/qFnvI/JpByU', 'CryptoAes');
// Script/Common/CryptoAes.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var CryptoJS = require("../3rd/CryptoJS");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var key = CryptoJS.enc.Utf8.parse('d2ba0a0acd99b1a8d1ded721d86d128d');
var iv = CryptoJS.enc.Utf8.parse('632323c6ee97597f');
var CryptoAes = /** @class */ (function (_super) {
    __extends(CryptoAes, _super);
    function CryptoAes() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CryptoAes.aesEncrypt = function (data) {
        var encrypted = CryptoJS.AES.encrypt(data, key, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
        return encrypted.toString();
    };
    CryptoAes.aesDecrypt = function (data) {
        return CryptoJS.AES.decrypt(data, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.ZeroPadding
            // padding:CryptoJS.pad.Pkcs7
        }).toString(CryptoJS.enc.Utf8);
    };
    CryptoAes = __decorate([
        ccclass
    ], CryptoAes);
    return CryptoAes;
}(cc.Component));
exports.default = CryptoAes;

cc._RF.pop();