"use strict";
cc._RF.push(module, 'cf28fdbEPpGfbpydjMQvpU4', 'CommonEnum');
// Script/Common/CommonEnum.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommonEnum = void 0;
/******************************框架通用枚举，不需要改动******************************/
//互推预制件
var RecommendPrefab;
(function (RecommendPrefab) {
    RecommendPrefab["item"] = "RecommendItem";
    RecommendPrefab["drawer"] = "RecommendDrawer";
    RecommendPrefab["banner"] = "RecommendBanner";
    RecommendPrefab["matrix"] = "RecommendMatrix";
    RecommendPrefab["primary"] = "RecommendPrimary";
    RecommendPrefab["primary_tt"] = "RecommendPrimary_TT";
    RecommendPrefab["btnCenter_tt"] = "RecommendBtnCenter_TT";
    RecommendPrefab["btnSide_tt"] = "RecommendBtnSide_TT";
})(RecommendPrefab || (RecommendPrefab = {}));
//互推游戏节点类型
var RecommendItemType;
(function (RecommendItemType) {
    RecommendItemType["normal"] = "RecommendItem";
})(RecommendItemType || (RecommendItemType = {}));
//互推矩阵抽屉类型
var RecommendDrawerType;
(function (RecommendDrawerType) {
    RecommendDrawerType[RecommendDrawerType["left"] = 1] = "left";
    RecommendDrawerType[RecommendDrawerType["right"] = 2] = "right";
})(RecommendDrawerType || (RecommendDrawerType = {}));
//互推banner类型
var RecommendBannerType;
(function (RecommendBannerType) {
    RecommendBannerType[RecommendBannerType["pingpong"] = 1] = "pingpong";
    RecommendBannerType[RecommendBannerType["left"] = 2] = "left";
    RecommendBannerType[RecommendBannerType["right"] = 3] = "right";
})(RecommendBannerType || (RecommendBannerType = {}));
/**触摸控制器状态 */
var CtrlState;
(function (CtrlState) {
    CtrlState[CtrlState["none"] = 1] = "none";
    CtrlState[CtrlState["touched"] = 2] = "touched";
})(CtrlState || (CtrlState = {}));
/**用于数据统计的视频事件 */
var VideoSubType;
(function (VideoSubType) {
    VideoSubType[VideoSubType["showVideoBtn"] = 7] = "showVideoBtn";
    VideoSubType[VideoSubType["openVideoWindow"] = 0] = "openVideoWindow";
    VideoSubType[VideoSubType["closeVideoWindow"] = 1] = "closeVideoWindow";
    VideoSubType[VideoSubType["clickBtnVideo"] = 2] = "clickBtnVideo";
    VideoSubType[VideoSubType["videoQuit"] = 3] = "videoQuit";
    VideoSubType[VideoSubType["videoSuc"] = 4] = "videoSuc";
    VideoSubType[VideoSubType["getAward"] = 5] = "getAward";
    VideoSubType[VideoSubType["videoFail"] = 6] = "videoFail";
})(VideoSubType || (VideoSubType = {}));
/*****************框架通用枚举，可能需要根据实际游戏添加枚举值，添加后放到其他游戏中照样能正常运行*****************/
/**资源路径，可为本地路径或远程路径 */
var UrlPath;
(function (UrlPath) {
    //皮肤资源：
    /**皮肤资源根路径 */
    UrlPath["skinRootUrl"] = "myGame/Img/Skin/";
    /**皮肤贴图文件夹名 */
    UrlPath["skinTextureDir"] = "Textures";
    /**皮肤在商城的商品项显示图片的文件夹名 */
    UrlPath["skinItemDir"] = "Item";
    /**皮肤商品选中时在展示台显示的图片的文件夹名 */
    UrlPath["skinDisplayDir"] = "Display";
})(UrlPath || (UrlPath = {}));
/**UI类型，枚举值与对应UI预制件、脚本名称相同 */
var UI;
(function (UI) {
    UI["lobby"] = "GameLobby";
    UI["configSetting"] = "ConfigSettingUI";
    UI["playerAssetBar"] = "PlayerAssetBar";
    UI["getPower"] = "GetPowerUI";
    UI["tipPower"] = "TipPowerUI";
    UI["shop"] = "ShopUI";
    UI["chooseLevel"] = "ChooseLevelUI";
    UI["levelInfo"] = "LevelInfoUI";
    UI["pauseLevel"] = "PauseLevelUI";
    UI["trySkin"] = "TrySkinUI";
    UI["levelTeach"] = "TeachAnim";
    UI["winUI"] = "WinUI";
    UI["loseUI"] = "LoseUI";
    UI["resurgence"] = "ResurgenceUI";
})(UI || (UI = {}));
/**游戏数据类型 */
var GameDataType;
(function (GameDataType) {
    /**关卡数据 */
    GameDataType["levelData"] = "LevelData";
    //皮肤
    GameDataType["playerSkin"] = "PlayerSkin";
})(GameDataType || (GameDataType = {}));
/**商店中商品项的类型 */
var GoodsType;
(function (GoodsType) {
    /**主角皮肤 */
    GoodsType["playerSkin"] = "PlayerSkin";
})(GoodsType || (GoodsType = {}));
//音效文件
var AudioClip;
(function (AudioClip) {
    AudioClip["clickBtn"] = "Common/Audio/clickBtn";
    AudioClip["win"] = "Common/Audio/win";
    AudioClip["lose"] = "Common/Audio/lose";
    AudioClip["BGM"] = "myGame/Audio/BGM1";
})(AudioClip || (AudioClip = {}));
/**关卡状态 */
var LevelState;
(function (LevelState) {
    LevelState[LevelState["inited"] = 1] = "inited";
    LevelState[LevelState["playing"] = 2] = "playing";
    LevelState[LevelState["win"] = 3] = "win";
    LevelState[LevelState["lose"] = 4] = "lose";
    LevelState[LevelState["lobby"] = 5] = "lobby";
})(LevelState || (LevelState = {}));
/**********************根据实际游戏设置的枚举值，由子类定义，这里仅作示例，不会包含到导出的类中**********************/
/**通过全局对象池管理的预制件名称与对应的脚本名称，这里仅作示例，不会包含到导出的类中，需在子类中定义 */
var LevelPrefab;
(function (LevelPrefab) {
    LevelPrefab["goldIcon"] = "GoldIcon";
})(LevelPrefab || (LevelPrefab = {}));
/**
 * 定义全部通用的枚举值
 *
 * 注：LevelPrefab 枚举类型必须在子类中定义
 */
var CommonEnum = /** @class */ (function () {
    function CommonEnum() {
    }
    CommonEnum.RecommendPrefab = RecommendPrefab;
    CommonEnum.RecommendItemType = RecommendItemType;
    CommonEnum.RecommendDrawerType = RecommendDrawerType;
    CommonEnum.RecommendBannerType = RecommendBannerType;
    CommonEnum.CtrlState = CtrlState;
    CommonEnum.VideoSubType = VideoSubType;
    CommonEnum.UrlPath = UrlPath;
    CommonEnum.UI = UI;
    CommonEnum.GameDataType = GameDataType;
    CommonEnum.GoodsType = GoodsType;
    CommonEnum.AudioClip = AudioClip;
    CommonEnum.LevelState = LevelState;
    return CommonEnum;
}());
exports.CommonEnum = CommonEnum;

cc._RF.pop();