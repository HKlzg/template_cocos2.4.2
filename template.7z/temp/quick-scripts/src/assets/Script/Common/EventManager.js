"use strict";
cc._RF.push(module, '923b3ZTA9BPFb6bNUNyeF3N', 'EventManager');
// CommonScript/EventManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Handler = void 0;
/**
 * 自定义的事件管理器
 */
var EventManager = /** @class */ (function () {
    function EventManager() {
    }
    /**
     * 注册事件
     * @param {number} type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     * @returns {Handler} 若注册成功，返回回调对象
     */
    EventManager.on = function (type, cb, target) {
        if (!this.events.hasOwnProperty(type)) {
            this.events[type] = [];
        }
        for (var i = this.events[type].length - 1; i >= 0; --i) {
            if (this.events[type][i].equal(cb, target)) {
                return null;
            }
        }
        var h = new Handler(cb, target);
        this.events[type].push(h);
        return h;
    };
    /**
     * 注册只触发一次的事件
     * @param {number} type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     * @returns {Handler} 若注册成功，返回回调对象
     */
    EventManager.once = function (type, cb, target) {
        if (!this.onceEvents.hasOwnProperty(type)) {
            this.onceEvents[type] = [];
        }
        for (var i = this.onceEvents[type].length - 1; i >= 0; --i) {
            if (this.onceEvents[type][i].equal(cb, target)) {
                return null;
            }
        }
        var h = new Handler(cb, target);
        this.onceEvents[type].push(h);
        return h;
    };
    /**
     * 注销事件，只传入事件类型枚举值时，将删除该枚举值对应的所有回调函数
     * @param type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     */
    EventManager.off = function (type, h, target) {
        if (!h) {
            this.events[type] = [];
            this.onceEvents[type] = [];
            return;
        }
        if (h instanceof Handler) {
            if (this.events.hasOwnProperty(type)) {
                for (var i = this.events[type].length - 1; i >= 0; --i) {
                    if (this.events[type][i].id == h.id) {
                        this.events[type].splice(i, 1);
                        break;
                    }
                }
            }
            if (this.onceEvents.hasOwnProperty(type)) {
                for (var i = this.onceEvents[type].length - 1; i >= 0; --i) {
                    if (this.onceEvents[type][i].id == h.id) {
                        this.onceEvents[type].splice(i, 1);
                        break;
                    }
                }
            }
        }
        else {
            if (this.events.hasOwnProperty(type)) {
                for (var i = this.events[type].length - 1; i >= 0; --i) {
                    if (this.events[type][i].equal(h, target)) {
                        this.events[type].splice(i, 1);
                        break;
                    }
                }
            }
            if (this.onceEvents.hasOwnProperty(type)) {
                for (var i = this.onceEvents[type].length - 1; i >= 0; --i) {
                    if (this.onceEvents[type][i].equal(h, target)) {
                        this.onceEvents[type].splice(i, 1);
                        break;
                    }
                }
            }
        }
    };
    /**
     * 批量注销事件
     * @param type 事件类型
     * @param h 事件回调数组
     */
    EventManager.offGroup = function (type, h) {
        if (this.events.hasOwnProperty(type)) {
            for (var i = h.length - 1; i >= 0; --i) {
                for (var j = this.events[type].length - 1; j >= 0; --j) {
                    if (this.events[type][j].id == h[i].id) {
                        this.events[type].splice(j, 1);
                        break;
                    }
                }
            }
        }
        if (this.onceEvents.hasOwnProperty(type)) {
            for (var i = h.length - 1; i >= 0; --i) {
                for (var j = this.onceEvents[type].length - 1; j >= 0; --j) {
                    if (this.onceEvents[type][j].id == h[i].id) {
                        this.onceEvents[type].splice(j, 1);
                        break;
                    }
                }
            }
        }
    };
    /**
     * 发送事件
     * @param {number} type 事件类型枚举值
     * @param {any} data 传给回调函数的参数
     */
    EventManager.emit = function (type, d1, d2, d3, d4, d5) {
        if (this.events.hasOwnProperty(type)) {
            var handlers = this.events[type];
            for (var i = 0, count = handlers.length; i < count; ++i) {
                if (undefined === d1) {
                    handlers[i].cb.call(handlers[i].target);
                }
                else if (undefined === d2) {
                    handlers[i].cb.call(handlers[i].target, d1);
                }
                else if (undefined === d3) {
                    handlers[i].cb.call(handlers[i].target, d1, d2);
                }
                else if (undefined === d4) {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3);
                }
                else if (undefined === d5) {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3, d4);
                }
                else {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3, d4, d5);
                }
            }
        }
        if (this.onceEvents.hasOwnProperty(type)) {
            var handlers = this.onceEvents[type];
            for (var i = 0, count = handlers.length; i < count; ++i) {
                if (undefined === d1) {
                    handlers[i].cb.call(handlers[i].target);
                }
                else if (undefined === d2) {
                    handlers[i].cb.call(handlers[i].target, d1);
                }
                else if (undefined === d3) {
                    handlers[i].cb.call(handlers[i].target, d1, d2);
                }
                else if (undefined === d4) {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3);
                }
                else if (undefined === d5) {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3, d4);
                }
                else {
                    handlers[i].cb.call(handlers[i].target, d1, d2, d3, d4, d5);
                }
            }
            delete this.onceEvents[type];
        }
    };
    /**
     * 记录所有事件类型与对应回调函数的字典
     * key:事件类型枚举值
     * value:事件类型对应的回调函数数组
     */
    EventManager.events = {};
    /**
     * 记录所有只触发一次的事件类型与对应回调函数的字典
     * key:事件类型枚举值
     * value:事件类型对应的回调函数数组
     */
    EventManager.onceEvents = {};
    return EventManager;
}());
exports.default = EventManager;
/**
 * 回调函数，包含函数和函数所属的对象
 */
var Handler = /** @class */ (function () {
    /**
     * @param {Function} cb 回调函数
     * @param {Object} target 回调函数所属的对象
     */
    function Handler(cb, target) {
        this._id = Handler.idCount++;
        this.target = target;
        this.cb = cb;
    }
    Object.defineProperty(Handler.prototype, "id", {
        get: function () {
            return this._id;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 比较两个回调是否一样
     * @param {Function} cb
     * @param {Object} target
     */
    Handler.prototype.equal = function (cb, target) {
        return this.target === target && this.cb == cb;
    };
    Handler.idCount = 0; //自增id
    return Handler;
}());
exports.Handler = Handler;

cc._RF.pop();