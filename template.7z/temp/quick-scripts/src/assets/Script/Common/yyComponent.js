"use strict";
cc._RF.push(module, 'd2f58JcttJPP6hHjBNvP5V8', 'yyComponent');
// Script/Common/yyComponent.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var EventManager_1 = require("./EventManager");
//抽象类，自定义脚本基类，包含通用功能
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var yyComponent = /** @class */ (function (_super) {
    __extends(yyComponent, _super);
    function yyComponent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._customId = null;
        //#endregion
        /************************************************************事件管理器************************************************************/
        //#region 事件注册
        /**
         * 记录所有事件类型与对应回调函数的字典，销毁脚本时，根据此字典注销其事件
         * key:事件类型枚举值
         * value:事件类型对应的回调函数数组
         */
        _this.events = {};
        /**
         * 记录所有只触发一次的事件类型与对应回调函数的字典
         * key:事件类型枚举值
         * value:事件类型对应的回调函数数组
         */
        _this.onceEvents = {};
        return _this;
        //#endregion
    }
    yyComponent_1 = yyComponent;
    Object.defineProperty(yyComponent.prototype, "Id", {
        get: function () {
            if (null === this._customId) {
                this._customId = yyComponent_1._autoId++;
            }
            return this._customId;
        },
        enumerable: false,
        configurable: true
    });
    //#endregion
    //#region 数组功能
    /**从数组中移除元素，只限于yyComponent的子类，返回结果是否移除成功 */
    yyComponent.prototype.removeElementInArray = function (ele, arr) {
        var id = ele.Id;
        for (var i = 0, count = arr.length; i < count; ++i) {
            if (arr[i].Id == id) {
                arr.splice(i, 1);
                return true;
            }
        }
        return false;
    };
    //#endregion
    /************************************************************通用流程************************************************************/
    //#region 初始化
    //适用于自动对象池的接口函数，需在子类重写
    /**初始化数据，取代原有的onLoad方法，子类实现 */
    yyComponent.prototype.init = function (data) {
        this.initComponents();
        this.registAllCustomUpdate();
        this.onEvents();
        if (!!data)
            this.setData(data);
    };
    /**初始化脚本以外的其他组件 */
    yyComponent.prototype.initComponents = function () {
        if (!!this.node.parent) {
            var wg = this.node.getComponent(cc.Widget);
            if (!!wg) {
                wg.updateAlignment();
            }
            var ly = this.node.getComponent(cc.Layout);
            if (!!ly) {
                ly.updateLayout();
            }
        }
    };
    /**注册通过自定义事件管理器管理的事件，子类实现 */
    yyComponent.prototype.onEvents = function () { };
    /**注册所有自定义运行状态与函数，子类实现 */
    yyComponent.prototype.registAllCustomUpdate = function () { };
    /**设置状态、数据等，子类实现 */
    yyComponent.prototype.setData = function (data) { };
    //#endregion
    //#region 重置
    /**重置状态、数据等，子类实现 */
    yyComponent.prototype.reset = function () { };
    //#endregion
    //#region 对象池复用
    /**从对象池中取回实例重新使用时将执行的方法，可重置状态、数据，设置新的状态、数据 */
    yyComponent.prototype.reuse = function (data) {
        this.reset();
        this.onEvents();
        if (!!data)
            this.setData(data);
    };
    /**放回对象池时将执行的方法，应当注销事件、计时器等 */
    yyComponent.prototype.unuse = function () {
        this.reset();
        this.offEvents();
    };
    Object.defineProperty(yyComponent.prototype, "customUpdateState", {
        get: function () { return this._customUpdateState; },
        enumerable: false,
        configurable: true
    });
    yyComponent.prototype.stepEmpty = function (dt) { };
    /**初始化运行状态 */
    yyComponent.prototype.initCustomUpdateState = function () {
        this._customUpdateState = null;
        this.customStep = this.stepEmpty;
        this.customUpdateMap = {};
    };
    /**重置运行状态 */
    yyComponent.prototype.resetCustomUpdateState = function () {
        this._customUpdateState = null;
        this.customStep = this.stepEmpty;
    };
    /**注册运行状态与函数，注册后，脚本切换到该状态时，自定义更新函数中将执行该方法 */
    yyComponent.prototype.registCustomUpdate = function (state, step) {
        if (!this.customUpdateMap) {
            this.customUpdateMap = {};
        }
        this.customUpdateMap[state] = step;
    };
    /**切换到指定的运行状态 */
    yyComponent.prototype.enterCustomUpdateState = function (state) {
        if (this._customUpdateState != state) {
            this._customUpdateState = state;
            if (!!this.customUpdateMap[state]) {
                this.customStep = this.customUpdateMap[state];
            }
            else {
                this.customStep = this.stepEmpty;
            }
        }
    };
    /**自定义的每帧更新函数 */
    yyComponent.prototype.customUpdate = function (dt) {
        if (!!this.customStep) {
            this.customStep(dt);
        }
    };
    /**遍历数组执行其自定义的更新函数 */
    yyComponent.prototype.runCustomUpdate = function (cps, dt) {
        for (var i = cps.length - 1; i >= 0; --i) {
            cps[i].customUpdate(dt);
        }
    };
    //#endregion
    /************************************************************节点通用功能************************************************************/
    //#region 基础属性
    /**设置节点的基础属性，包括坐标、角度、缩放 */
    yyComponent.prototype.setTransform = function (data) {
        if (undefined !== data.p) {
            this.setPosition(data.p);
        }
        if (undefined !== data.e) {
            if (typeof data.e === "number") {
                this.setEulerAngles(cc.v3(0, 0, data.e));
            }
            else {
                this.setEulerAngles(data.e);
            }
        }
        if (undefined !== data.s) {
            if (typeof data.s === "number") {
                this.setScale(cc.v3(data.s, data.s, data.s));
            }
            else {
                this.setScale(data.s);
            }
        }
    };
    Object.defineProperty(yyComponent.prototype, "x", {
        //#endregion
        //#region 坐标
        //节点相关属性
        get: function () { return this.node.x; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(yyComponent.prototype, "y", {
        get: function () { return this.node.y; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(yyComponent.prototype, "z", {
        get: function () { return this.node.z; },
        enumerable: false,
        configurable: true
    });
    yyComponent.prototype.setPosition = function (pos) {
        this.node.setPosition(pos);
    };
    yyComponent.prototype.getPosition = function () {
        if (this.node.is3DNode) {
            return cc.v3(this.x, this.y, this.z);
        }
        else {
            return cc.v2(this.x, this.y);
        }
    };
    Object.defineProperty(yyComponent.prototype, "angleX", {
        //#endregion
        //#region 角度
        get: function () { return this.node.eulerAngles.x; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(yyComponent.prototype, "angleY", {
        get: function () { return this.node.eulerAngles.y; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(yyComponent.prototype, "angleZ", {
        get: function () { return this.node.eulerAngles.z; },
        enumerable: false,
        configurable: true
    });
    yyComponent.prototype.setEulerAngles = function (eulerAngles) {
        this.node.eulerAngles = eulerAngles;
    };
    //#endregion
    //#region 缩放
    /**设置节点缩放 */
    yyComponent.prototype.setScale = function (scale) {
        this.node.setScale(scale);
    };
    //#endregion
    /************************************************************UI通用功能************************************************************/
    //#region UI显示/隐藏
    /**适用于UI节点，显示UI并设置UI内容 */
    yyComponent.prototype.show = function (data) {
        this.node.active = true;
        if (undefined !== data)
            this.setData(data);
    };
    /**适用于UI节点，隐藏UI */
    yyComponent.prototype.hide = function () {
        this.node.active = false;
    };
    //#endregion
    //#region 数据
    /**获取数据 */
    yyComponent.prototype.getData = function (data) {
        return null;
    };
    /**
     * 注册事件
     * @param {number} type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     */
    yyComponent.prototype.on = function (type, cb, target) {
        var h = EventManager_1.default.on(type, cb, target);
        if (!!h) {
            if (!this.events.hasOwnProperty(type)) {
                this.events[type] = [];
            }
            this.events[type].push(h);
        }
    };
    /**
     * 注册只触发一次的事件
     * @param {number} type 事件类型枚举值
     * @param {Function} cb 回调函数
     * @param {Object} target 函数所属对象
     */
    yyComponent.prototype.once = function (type, cb, target) {
        var h = EventManager_1.default.once(type, cb, target);
        if (!!h) {
            if (!this.onceEvents.hasOwnProperty(type)) {
                this.onceEvents[type] = [];
            }
            this.onceEvents[type].push(h);
        }
    };
    //#endregion
    //#region 事件发射
    /**
     * 发送事件
     * @param {number} type 事件类型枚举值
     * @param {any} data 传给回调函数的参数
     */
    yyComponent.prototype.emit = function (type, d1, d2, d3, d4, d5) {
        if (undefined === d1) {
            EventManager_1.default.emit(type);
        }
        else if (undefined === d2) {
            EventManager_1.default.emit(type, d1);
        }
        else if (undefined === d3) {
            EventManager_1.default.emit(type, d1, d2);
        }
        else if (undefined === d4) {
            EventManager_1.default.emit(type, d1, d2, d3);
        }
        else if (undefined === d5) {
            EventManager_1.default.emit(type, d1, d2, d3, d4);
        }
        else {
            EventManager_1.default.emit(type, d1, d2, d3, d4, d5);
        }
        if (this.onceEvents.hasOwnProperty(type))
            delete this.onceEvents[type];
    };
    //#endregion
    //#region 事件注销
    yyComponent.prototype.off = function (type, cb, target) {
        var events = this.events[type];
        if (!!events) {
            for (var i = events.length - 1; i >= 0; --i) {
                if (events[i].cb === cb && events[i].target === target) {
                    EventManager_1.default.off(type, events[i]);
                    events.splice(i, 1);
                }
            }
        }
        events = this.onceEvents[type];
        if (!!events) {
            for (var i = events.length - 1; i >= 0; --i) {
                if (events[i].cb === cb && events[i].target === target) {
                    EventManager_1.default.off(type, events[i]);
                    events.splice(i, 1);
                }
            }
        }
    };
    /**
     * 注销脚本中注册的所有事件
     */
    yyComponent.prototype.offEvents = function () {
        for (var key in this.events) {
            EventManager_1.default.offGroup(key, this.events[key]);
        }
        this.events = {};
        for (var key in this.onceEvents) {
            EventManager_1.default.offGroup(key, this.onceEvents[key]);
        }
        this.onceEvents = {};
    };
    /**对象销毁时自动注销所有事件 */
    yyComponent.prototype.onDestroy = function () {
        this.offEvents();
    };
    var yyComponent_1;
    /************************************************************自定义ID************************************************************/
    //#region 自定义ID
    //自动id
    yyComponent._autoId = 1;
    yyComponent = yyComponent_1 = __decorate([
        ccclass
    ], yyComponent);
    return yyComponent;
}(cc.Component));
exports.default = yyComponent;

cc._RF.pop();