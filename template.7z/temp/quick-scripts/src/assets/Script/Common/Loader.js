"use strict";
cc._RF.push(module, '76f22jaHdBP6q6d5du5twvn', 'Loader');
// Script/Common/Loader.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventManager_1 = require("./EventManager");
var GameEventType_1 = require("../GameSpecial/GameEventType");
var Loader = /** @class */ (function () {
    function Loader() {
    }
    //#region 进度条及触摸遮罩
    /**显示进度条：发送事件，通知UI节点显示进度 */
    Loader.showProgressBar = function (rate) {
        if (undefined === rate) {
            rate = 0;
        }
        this.showMask();
        EventManager_1.default.emit(GameEventType_1.EventType.LoadAssetEvent.showProgress, rate);
    };
    /**
     * 根据资源加载进度更新进度条
     * @param completedCount    已加载完成的资源数量
     * @param totalCount        要加载的资源总数量
     * @param item              当前加载完成的资源
     */
    Loader.updateProgress = function (completedCount, totalCount, item) {
        var rate = completedCount / totalCount;
        if (rate > 1)
            rate = 1;
        EventManager_1.default.emit(GameEventType_1.EventType.LoadAssetEvent.updateProgress, rate);
    };
    Loader.hideProgressBar = function (count) {
        if (count === void 0) { count = 1; }
        EventManager_1.default.emit(GameEventType_1.EventType.LoadAssetEvent.hideProgress);
        this.hideMask(count);
    };
    //显示遮罩，只屏蔽触摸事件，不显示进度条，不变暗屏幕
    Loader.showMask = function (count) {
        if (count === void 0) { count = 1; }
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.showTouchMask, count);
    };
    Loader.hideMask = function (count) {
        if (count === void 0) { count = 1; }
        EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.hideTouchMask, count);
    };
    /**
     * 加载资源包（与原加载子包接口用法一致）
     * @param name      资源包名称
     * @param cb        回调函数，只需后台预加载资源时，传入null即可
     * @param mask      加载过程中是否需要显示进度条并阻断玩家触摸操作，当需要加载完成后才能进行下一步操作时，请传入true
     * @param insert    插队加载，为true时，会在当前任务加载完后立即加载该资源包，队列中的其他任务延后加载
     */
    Loader.loadBundle = function (name, cb, mask, insert) {
        if (mask === void 0) { mask = false; }
        if (insert === void 0) { insert = false; }
        this.loadSubpackage(name, cb, mask, insert);
    };
    /**
     * 加载子包资源
     * @param name      子包名称
     * @param cb        回调函数，只需后台预加载资源时，传入null即可
     * @param mask      加载过程中是否需要显示进度条并阻断玩家触摸操作，当需要加载完成后才能进行下一步操作时，请传入true
     * @param insert    插队加载，为true时，会在当前任务加载完后立即加载该资源包，队列中的其他任务延后加载
     */
    Loader.loadSubpackage = function (name, cb, mask, insert) {
        if (undefined === mask) {
            mask = false;
        }
        if (undefined === insert) {
            insert = false;
        }
        var record = this.subpackageRecords[name];
        if (!record) {
            record = new SubpackageRecord(name, cb, mask);
            this.subpackageRecords[name] = record;
        }
        switch (record.state) {
            case LoadState.inited: {
                if (mask)
                    this.showSubpackageProgress();
                if (insert && this.subpackageSequence.length > 0) {
                    this.subpackageSequence.splice(1, 0, name);
                    record.enterSequence();
                }
                else {
                    this.subpackageSequence.push(name);
                    if (this.subpackageSequence.length > 1) {
                        record.enterSequence();
                    }
                    else {
                        this._loadSubpackage(name);
                    }
                }
                break;
            }
            case LoadState.waiting: {
                if (mask)
                    this.showSubpackageProgress();
                record.pushCb(cb, mask);
                break;
            }
            case LoadState.turnTo: {
                if (mask)
                    this.showSubpackageProgress();
                record.pushCb(cb, mask);
                this._loadSubpackage(name);
                break;
            }
            case LoadState.loading: {
                if (mask)
                    this.showSubpackageProgress();
                record.pushCb(cb, mask);
                break;
            }
            case LoadState.finished: {
                setTimeout(function () {
                    if (!!cb)
                        cb();
                }, 0);
                break;
            }
        }
    };
    Loader._loadSubpackage = function (name) {
        var _this = this;
        console.log("开始加载子包：", name);
        console.log("子包加载队列：", this.subpackageSequence.toString());
        this.subpackageRecords[name].loadStart();
        cc.assetManager.loadBundle(name, function (err, bundle) {
            if (err) {
                console.error("子包加载出错：", name);
                console.error(err);
                return;
            }
            console.log("子包加载完成：", name);
            var index = _this.subpackageSequence.indexOf(name);
            _this.subpackageSequence.splice(index, 1);
            console.log("等待加载的子包列表：", _this.subpackageSequence.toString());
            _this.hideSubpackageProgress();
            _this.subpackageRecords[name].loadFinish();
            if (_this.subpackageSequence.length > 0) {
                // setTimeout(() => {
                var str = _this.subpackageSequence[0];
                console.log("加载下一个子包：", str);
                var record = _this.subpackageRecords[str];
                if (!!record) {
                    record.turnToLoad();
                }
                _this.loadSubpackage(str, null, !!_this.subpackageRecords[str].maskCount);
                // }, 0);
            }
        });
    };
    /**显示子包加载进度条 */
    Loader.showSubpackageProgress = function () {
        if (null === this.subpackageProgressTimer) {
            this.showProgressBar();
            this.subpackageProgress = 0;
            this.subpackageProgressTimer = setInterval(this.updateSubpackageProgress.bind(this), 100);
        }
    };
    Loader.updateSubpackageProgress = function () {
        this.subpackageProgress += 0.03;
        if (this.subpackageProgress >= 1) {
            this.subpackageProgress = 0;
        }
        EventManager_1.default.emit(GameEventType_1.EventType.LoadAssetEvent.updateProgress, this.subpackageProgress);
    };
    Loader.hideSubpackageProgress = function () {
        if (null !== this.subpackageProgressTimer) {
            var count = 0;
            for (var i = this.subpackageSequence.length - 1; i >= 0; --i) {
                count += this.subpackageRecords[this.subpackageSequence[i]].maskCount;
            }
            if (count == 0) {
                clearInterval(this.subpackageProgressTimer);
                this.subpackageProgressTimer = null;
                this.subpackageProgress = 0;
                this.hideProgressBar();
            }
        }
    };
    //#endregion
    //#region 资源加载
    /**
    * 加载单个资源
    * @param url    资源完整的路径名称，不包含后缀
    * @param cb     资源加载完成后的回调
    * @param mask   加载过程中是否阻挡玩家触摸操作，默认阻挡
    */
    Loader.loadRes = function (url, cb, mask) {
        var _this = this;
        if (!!this.singleAsset[url]) {
            setTimeout(function () {
                cb(_this.singleAsset[url]);
            }, 0);
        }
        else {
            if (undefined === mask) {
                mask = true;
            }
            if (mask) {
                this.showMask();
            }
            cc.loader.loadRes(url, function (err, res) {
                if (mask) {
                    _this.hideMask();
                }
                if (err) {
                    cc.error(err.message || err);
                    cb(null);
                    return;
                }
                _this.singleAsset[url] = res;
                cb(res);
            });
        }
    };
    /**
     * 加载整个文件夹内的资源
     * @param dir   文件夹路径
     * @param cb    加载完成回调
     * @param type  资源类型
     * @param mask  加载过程中是否显示加载进度并阻挡玩家触摸操作，默认为true
     */
    Loader.loadResDir = function (dir, cb, type, mask) {
        var _this = this;
        if (!!this.dirAsset[dir]) {
            setTimeout(function () {
                cb(_this.dirAsset[dir]);
            }, 0);
            return;
        }
        var assetType = null;
        if (undefined === type) {
            mask = true;
        }
        else if (typeof type === "boolean") {
            mask = !!type;
        }
        else {
            assetType = type;
            if (undefined === mask) {
                mask = true;
            }
        }
        if (mask) {
            this.showProgressBar();
        }
        if (!!assetType) {
            cc.loader.loadResDir(dir, assetType, this.updateProgress.bind(this), function (err, arr, urls) {
                if (mask) {
                    _this.hideProgressBar();
                }
                if (err) {
                    cc.log(err);
                    cb(null);
                    return;
                }
                _this.dirAsset[dir] = arr;
                for (var i = arr.length - 1; i >= 0; --i) {
                    _this.singleAsset[urls[i]] = arr[i];
                }
                cb(_this.dirAsset[dir]);
            });
        }
        else {
            cc.loader.loadResDir(dir, this.updateProgress.bind(this), function (err, arr, urls) {
                if (mask) {
                    _this.hideProgressBar();
                }
                if (err) {
                    cc.log(err);
                    cb(null);
                    return;
                }
                _this.dirAsset[dir] = arr;
                for (var i = arr.length - 1; i >= 0; --i) {
                    _this.singleAsset[urls[i]] = arr[i];
                }
                cb(_this.dirAsset[dir]);
            });
        }
    };
    /**加载资源数组 */
    Loader.loadResArray = function (urls, cb, mask) {
        var _this = this;
        var assets = [];
        var arr = [];
        for (var i = urls.length - 1; i >= 0; --i) {
            var res = this.getAsset(urls[i]);
            if (!!res) {
                assets.push(res);
            }
            else {
                arr.push(urls[i]);
            }
        }
        if (arr.length == 0) {
            setTimeout(function () {
                cb(assets);
            }, 0);
            return;
        }
        if (undefined === mask) {
            mask = true;
        }
        if (mask) {
            this.showProgressBar();
        }
        cc.loader.loadResArray(arr, this.updateProgress.bind(this), function (err, res) {
            if (mask) {
                _this.hideProgressBar();
            }
            if (!!err) {
                console.log(err);
                cb(null);
                return;
            }
            if (Array.isArray(res)) {
                for (var i = arr.length - 1; i >= 0; --i) {
                    _this.singleAsset[arr[i]] = res[i];
                    assets.push(res[i]);
                }
            }
            else {
                _this.singleAsset[arr[0]] = res;
                assets.push(res);
            }
            cb(assets);
        });
    };
    /**
     * 获取已加载的资源
     * @param url 资源路径
     */
    Loader.getAsset = function (url) {
        if (!this.singleAsset[url]) {
            console.warn("尚未加载资源：", url);
            return null;
        }
        return this.singleAsset[url];
    };
    /**
     * 从资源包加载单个资源，调用前请确保该资源包已加载完成
     * @param bundle    资源包名
     * @param url       资源相对路径
     * @param cb        加载回调
     * @param mask      加载过程中是否阻挡玩家触摸操作，默认阻挡
     */
    Loader.loadBundleRes = function (bundle, url, cb, type, mask) {
        var _this = this;
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            console.error("资源包 " + bundle + " 尚未加载，无法获取资源:", url);
            cb(null);
            return;
        }
        var assetType = null;
        if (undefined === type) {
            mask = true;
        }
        else if (typeof type === "boolean") {
            mask = !!type;
        }
        else {
            assetType = type;
            if (undefined === mask) {
                mask = true;
            }
        }
        if (mask) {
            this.showMask();
        }
        if (null !== assetType) {
            b.load(url, assetType, function (err, res) {
                if (mask) {
                    _this.hideMask();
                }
                if (err) {
                    cc.error(err.message || err);
                    cb(null);
                    return;
                }
                cb(res);
            });
        }
        else {
            b.load(url, function (err, res) {
                if (mask) {
                    _this.hideMask();
                }
                if (err) {
                    cc.error(err.message || err);
                    cb(null);
                    return;
                }
                cb(res);
            });
        }
    };
    /**
     * 从资源包加载多个资源，调用前请确保该资源包已加载完成
     * @param bundle    资源包名
     * @param urls      资源相对路径
     * @param cb        加载回调
     * @param mask      加载过程中是否显示加载进度条并阻挡玩家操作，默认为true
     */
    Loader.loadBundleArray = function (bundle, urls, cb, mask) {
        var _this = this;
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            console.error("资源包 " + bundle + " 尚未加载，无法获取资源数组:", urls);
            cb(null);
            return;
        }
        if (undefined === mask) {
            mask = true;
        }
        if (mask) {
            this.showProgressBar();
        }
        b.load(urls, this.updateProgress.bind(this), function (err, res) {
            if (mask) {
                _this.hideProgressBar();
            }
            if (err) {
                cc.error(err.message || err);
                cb(null);
                return;
            }
            cb(res);
        });
    };
    /**
     * 从资源包中加载文件夹，调用前请确保该资源包已加载完成
     * @param bundle    资源包名
     * @param dir       文件夹路径
     * @param cb        加载回调
     * @param type      要加载的文件夹中的资源类型
     * @param mask      加载过程中是否显示加载进度条并阻挡玩家操作，默认为true
     */
    Loader.loadBundleDir = function (bundle, dir, cb, type, mask) {
        var _this = this;
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            console.error("资源包 " + bundle + " 尚未加载，无法获取资源文件夹:", dir);
            cb(null);
            return;
        }
        var assetType = null;
        if (undefined === type) {
            mask = true;
        }
        else if (typeof type === "boolean") {
            mask = !!type;
        }
        else {
            assetType = type;
            if (undefined === mask) {
                mask = true;
            }
        }
        if (mask) {
            this.showProgressBar();
        }
        if (!!assetType) {
            b.loadDir(dir, assetType, this.updateProgress.bind(this), function (err, arr) {
                if (mask) {
                    _this.hideProgressBar();
                }
                if (err) {
                    cc.log(err);
                    cb(null);
                    return;
                }
                cb(arr);
            });
        }
        else {
            b.loadDir(dir, this.updateProgress.bind(this), function (err, arr) {
                if (mask) {
                    _this.hideProgressBar();
                }
                if (err) {
                    cc.log(err);
                    cb(null);
                    return;
                }
                cb(arr);
            });
        }
    };
    Loader.loadBundleScene = function (bundle, scene, cb, mask) {
        var _this = this;
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            console.error("资源包 " + bundle + " 尚未加载，无法加载场景:", scene);
            cb(null);
            return;
        }
        if (undefined === mask) {
            mask = true;
        }
        if (mask) {
            this.showProgressBar();
        }
        b.loadScene(scene, this.updateProgress.bind(this), function (err, res) {
            if (mask) {
                _this.hideProgressBar();
            }
            if (!!err) {
                console.error(err);
                return;
            }
            cb(res);
        });
    };
    //#endregion
    //#region 预加载
    /**
     * 预加载资源包中的单个资源，调用完后，你仍然需要通过 `loadBundleRes` 来完成加载。
     * @param bundle    资源包名称
     * @param url       资源路径
     * @param assetType 资源类型
     */
    Loader.preLoadBundleRes = function (bundle, url, assetType) {
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            return;
        }
        if (undefined === assetType) {
            b.preload(url);
        }
        else {
            b.preload(url, assetType);
        }
    };
    /**
     * 预加载资源包中的资源数组，调用完后，你仍然需要通过 `loadBundleRes` 或'loadBundleArray'来完成加载。
     * @param bundle    资源包名称
     * @param urls      资源路径数组
     * @param assetType 资源类型
     */
    Loader.preLoadBundleArray = function (bundle, urls, assetType) {
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            return;
        }
        if (undefined === assetType) {
            b.preload(urls);
        }
        else {
            b.preload(urls, assetType);
        }
    };
    /**
     * 预加载资源包中的文件夹，调用完后，你仍然需要通过 `loadBundleDir` 来完成加载。
     * @param bundle    资源包名称
     * @param dir       资源文件夹名称
     * @param assetType 资源类型
     */
    Loader.preLoadBundleDir = function (bundle, dir, assetType) {
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            return;
        }
        if (undefined === assetType) {
            b.preloadDir(dir);
        }
        else {
            b.preloadDir(dir, assetType);
        }
    };
    /**
     * 预加载资源包中的场景文件，调用完后，你仍然需要通过 `loadBundleScene` 来完成加载。
     * @param bundle    资源包名称
     * @param scene     场景名
     */
    Loader.preLoadBundleScene = function (bundle, scene) {
        var b = cc.assetManager.getBundle(bundle);
        if (!b) {
            return;
        }
        b.preloadScene(scene);
    };
    /**记录文件夹路径对应的资源数组 */
    Loader.dirAsset = {};
    /**记录所有加载完成的资源，包括通过文件夹加载的资源 */
    Loader.singleAsset = {};
    //#endregion
    //#region 子包、资源包加载
    /**子包加载状态记录 */
    Loader.subpackageRecords = {};
    /**需要加载的子包队伍 */
    Loader.subpackageSequence = [];
    Loader.subpackageProgressTimer = null;
    Loader.subpackageProgress = 0;
    return Loader;
}());
exports.default = Loader;
/**子包加载状态 */
var SubpackageRecord = /** @class */ (function () {
    function SubpackageRecord(name, cb, mask) {
        this.name = name;
        this.state = LoadState.inited;
        this.cbs = [];
        if (!!cb)
            this.pushCb(cb);
        this.maskCount = mask ? 1 : 0;
    }
    SubpackageRecord.prototype.pushCb = function (cb, mask) {
        if (!!cb)
            this.cbs.push(cb);
        if (!!mask)
            this.maskCount++;
    };
    SubpackageRecord.prototype.enterSequence = function () {
        this.state = LoadState.waiting;
    };
    SubpackageRecord.prototype.loadStart = function () {
        this.state = LoadState.loading;
    };
    SubpackageRecord.prototype.loadFinish = function () {
        while (this.cbs.length > 0) {
            var cb = this.cbs.shift();
            if (!!cb)
                cb();
        }
        this.state = LoadState.finished;
        this.maskCount = 0;
    };
    SubpackageRecord.prototype.turnToLoad = function () {
        this.state = LoadState.turnTo;
    };
    return SubpackageRecord;
}());
/**资源加载状态 */
var LoadState;
(function (LoadState) {
    /**已准备好加载 */
    LoadState[LoadState["inited"] = 1] = "inited";
    /**在队列中等待加载 */
    LoadState[LoadState["waiting"] = 2] = "waiting";
    /**正在加载中 */
    LoadState[LoadState["loading"] = 3] = "loading";
    /**已加载完成 */
    LoadState[LoadState["finished"] = 4] = "finished";
    /**在队列中，轮到加载它了 */
    LoadState[LoadState["turnTo"] = 5] = "turnTo";
})(LoadState || (LoadState = {}));

cc._RF.pop();