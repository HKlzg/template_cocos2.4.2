"use strict";
cc._RF.push(module, '5b708/73FlAXbGUAoQ4RyT8', 'UIManager');
// Script/Common/UIManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameEventType_1 = require("../GameSpecial/GameEventType");
var Loader_1 = require("./Loader");
var EventManager_1 = require("./EventManager");
/**UI管理器 */
var UIManager = /** @class */ (function () {
    function UIManager() {
    }
    UIManager.init = function (node) {
        this.node = node;
        this.UIs = {};
        this.onEvents();
    };
    UIManager.onEvents = function () {
        EventManager_1.default.on(GameEventType_1.EventType.UIEvent.enter, this.enterUI, this);
        EventManager_1.default.on(GameEventType_1.EventType.UIEvent.exit, this.exitUI, this);
    };
    /**获取指定UI脚本 */
    UIManager.getUI = function (type) {
        if (!this.UIs[type]) {
            console.warn("UI尚未加载，无法获取：", type);
            return null;
        }
        return this.UIs[type];
    };
    UIManager.enterUI = function (ui, data) {
        var iui = this.UIs[ui];
        if (null === iui)
            return;
        if (!!iui) {
            this.showUI(ui, data);
        }
        else {
            this.loadUI(ui, data);
        }
    };
    UIManager.showUI = function (ui, data) {
        var js = this.UIs[ui];
        if (!!js) {
            js.show(data);
            EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.entered, ui);
        }
    };
    UIManager.loadUI = function (ui, data) {
        var _this = this;
        var js = cc.find("Canvas").getComponentInChildren(ui);
        if (!!js) {
            this.UIs[ui] = js;
            this.showUI(ui, data);
        }
        else {
            Loader_1.default.loadBundle("LobbyUI", function () {
                Loader_1.default.loadBundleRes("LobbyUI", ui + "/" + ui, function (res) {
                    if (!res) {
                        // this.UIs[ui] = null;
                        // console.error("要显示的界面预制不存在：", ui);
                        _this.loadLevelUI(ui, data);
                        return;
                    }
                    var node = cc.instantiate(res);
                    _this.node.getChildByName(ui).addChild(node);
                    var wg = node.getComponent(cc.Widget);
                    if (!!wg) {
                        wg.updateAlignment();
                    }
                    var ly = node.getComponent(cc.Layout);
                    if (!!ly) {
                        ly.updateLayout();
                    }
                    var js = node.getComponent(ui);
                    js.init();
                    _this.UIs[ui] = js;
                    _this.showUI(ui, data);
                }, cc.Prefab, true);
            }, true);
        }
    };
    UIManager.loadLevelUI = function (ui, data) {
        var _this = this;
        Loader_1.default.loadBundle("LevelUI", function () {
            Loader_1.default.loadBundleRes("LevelUI", ui + "/" + ui, function (res) {
                if (!res) {
                    _this.UIs[ui] = null;
                    console.error("要显示的界面预制不存在：", ui);
                    return;
                }
                var node = cc.instantiate(res);
                _this.node.getChildByName(ui).addChild(node);
                var wg = node.getComponent(cc.Widget);
                if (!!wg) {
                    wg.updateAlignment();
                }
                var ly = node.getComponent(cc.Layout);
                if (!!ly) {
                    ly.updateLayout();
                }
                var js = node.getComponent(ui);
                js.init();
                _this.UIs[ui] = js;
                _this.showUI(ui, data);
            }, cc.Prefab, true);
        }, true);
    };
    UIManager.exitUI = function (ui) {
        var js = this.UIs[ui];
        if (!!js) {
            js.hide();
            EventManager_1.default.emit(GameEventType_1.EventType.UIEvent.exited, ui);
        }
    };
    return UIManager;
}());
exports.default = UIManager;

cc._RF.pop();