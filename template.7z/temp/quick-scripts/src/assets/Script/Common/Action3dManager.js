"use strict";
cc._RF.push(module, 'b26d3htEkFMfJARkhObfcES', 'Action3dManager');
// Script/Common/Action3dManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.RepeatForever = exports.Spawn3d = exports.Sequence3d = exports.CallFun3d = exports.FadeBy = exports.FadeTo = exports.RotateBy2d = exports.RotateTo2d = exports.RotateBy3d = exports.RotateTo3d = exports.ScaleTo3d = exports.MoveBy3d = exports.MoveTo3d = exports.DelayTime = exports.FiniteTimeAction3d = exports.Action3d = exports.ActionMngType = void 0;
/**动作管理器类型 */
var ActionMngType;
(function (ActionMngType) {
    /**UI动作管理器 */
    ActionMngType["UI"] = "UI";
    /**关卡动作管理器 */
    ActionMngType["Level"] = "Level";
})(ActionMngType = exports.ActionMngType || (exports.ActionMngType = {}));
/**3D动画管理器 */
var Action3dManager = /** @class */ (function () {
    function Action3dManager() {
        this.allActions = [];
        this.allActions = [];
    }
    /**
     * 获取指定类型的动作管理器，用于专门管理某一类对象的动作
     * @param type 管理器的类型，可以是枚举值，也可以自定义一个新的名称，获取新的管理器
     */
    Action3dManager.getMng = function (type) {
        if (!this.allMngs[type]) {
            this.allMngs[type] = new Action3dManager();
        }
        return this.allMngs[type];
    };
    Action3dManager.prototype.update = function (dt) {
        for (var i = this.allActions.length - 1; i >= 0; --i) {
            var act = this.allActions[i];
            if (!act) {
                continue;
            }
            act.update(dt);
            if (act.finished) {
                var index = i;
                if (index >= this.allActions.length) {
                    index = this.allActions.length - 1;
                }
                for (; index >= 0; --index) {
                    if (this.allActions[index].Id == act.Id) {
                        this.allActions.splice(index, 1);
                        break;
                    }
                }
            }
        }
    };
    Action3dManager.prototype.runAction = function (node, action) {
        this.stopAllActions(node);
        action.resetFinishState();
        action.setTarget(node);
        this.allActions.push(action);
    };
    Action3dManager.prototype.stopAllActions = function (node) {
        for (var i = this.allActions.length - 1; i >= 0; --i) {
            if (this.allActions[i].node == node) {
                this.allActions.splice(i, 1);
            }
        }
    };
    Action3dManager.delay = function (duration) {
        return new DelayTime(duration);
    };
    Action3dManager.moveTo = function (duration, x, y, z) {
        return new MoveTo3d(duration, x, y, z);
    };
    Action3dManager.moveBy = function (duration, x, y, z) {
        return new MoveBy3d(duration, x, y, z);
    };
    Action3dManager.scaleTo = function (duration, x, y, z) {
        return new ScaleTo3d(duration, x, y, z);
    };
    Action3dManager.rotateTo = function (duration, x, y, z) {
        return new RotateTo3d(duration, x, y, z);
    };
    Action3dManager.rotateBy = function (duration, x, y, z) {
        return new RotateBy3d(duration, x, y, z);
    };
    Action3dManager.rotateTo2d = function (duration, angle) {
        return new RotateTo2d(duration, angle);
    };
    Action3dManager.rotateBy2d = function (duration, angle) {
        return new RotateBy2d(duration, angle);
    };
    Action3dManager.fadeTo = function (duration, opacity) {
        return new FadeTo(duration, opacity);
    };
    Action3dManager.fadeBy = function (duration, opacity) {
        return new FadeBy(duration, opacity);
    };
    /**
     * 按目标值的方式修改对象的任意属性值
     * @param duration 动作持续的时间
     * @param attribute 变量名称
     * @param value 变化的相对值
     * @param newAttribute 值变化时是否需要新建属性再给目标对象赋值，例如要修改节点的position属性时应该为true
     */
    Action3dManager.tweenTo = function (duration, attribute, value, newAttribute) {
        if (newAttribute === void 0) { newAttribute = false; }
        return new TweenTo(duration, attribute, value, newAttribute);
    };
    /**
     * 按相对值的方式修改对象的任意属性值
     * @param duration 动作持续的时间
     * @param attribute 变量名称
     * @param value 变化的相对值
     * @param newAttribute 值变化时是否需要新建属性再给目标对象赋值，例如要修改节点的position属性时应该为true
     */
    Action3dManager.tweenBy = function (duration, attribute, value, newAttribute) {
        if (newAttribute === void 0) { newAttribute = false; }
        return new TweenBy(duration, attribute, value, newAttribute);
    };
    Action3dManager.callFun = function (cb, target, data) {
        return new CallFun3d(cb, target, data);
    };
    Action3dManager.sequence = function () {
        var actions = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            actions[_i] = arguments[_i];
        }
        return new Sequence3d(actions);
    };
    Action3dManager.spawn = function () {
        var actions = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            actions[_i] = arguments[_i];
        }
        return new Spawn3d(actions);
    };
    Action3dManager.repeatForever = function (action) {
        return new RepeatForever(action);
    };
    //缓动动作
    Action3dManager.easeIn = function (rate) {
        return new EaseIn(rate);
    };
    Action3dManager.easeOut = function (rate) {
        return new EaseOut(rate);
    };
    Action3dManager.easeInOut = function (rate) {
        return new EaseInOut(rate);
    };
    Action3dManager.easeOutIn = function (rate) {
        return new EaseOutIn(rate);
    };
    Action3dManager.easeExponentialIn = function () {
        return new EaseExponentialIn();
    };
    Action3dManager.easeExponentialOut = function () {
        return new EaseExponentialOut();
    };
    Action3dManager.easeExponentialInOut = function () {
        return new EaseExponentialInOut();
    };
    Action3dManager.easeSinIn = function () {
        return new EaseSinIn();
    };
    Action3dManager.easeSinOut = function () {
        return new EaseSinOut();
    };
    Action3dManager.easeSinInOut = function () {
        return new EaseSinInOut();
    };
    Action3dManager.easeSinOutIn = function () {
        return new EaseSinOutIn();
    };
    /**弹性变化进入，先回弹再变快 */
    Action3dManager.easeElasticIn = function (rate) {
        return new EaseElasticIn(rate);
    };
    /**弹性变化退出，先快速到达目标值再回弹 */
    Action3dManager.easeElasticOut = function (rate) {
        return new EaseElasticOut(rate);
    };
    /**弹性变化进入再退出，在时间轴的中间部分进行回弹 */
    Action3dManager.easeElasticInOut = function (rate) {
        return new EaseElasticInOut(rate);
    };
    /**按弹跳动作进入 */
    Action3dManager.easeBounceIn = function () {
        return new EaseBounceIn();
    };
    /**按弹跳动作退出 */
    Action3dManager.easeBounceOut = function () {
        return new EaseBounceOut();
    };
    Action3dManager.allMngs = {};
    return Action3dManager;
}());
exports.default = Action3dManager;
//动作基类
var Action3d = /** @class */ (function () {
    function Action3d() {
        this.myId = null;
    }
    Object.defineProperty(Action3d.prototype, "Id", {
        get: function () {
            if (null === this.myId) {
                this.myId = Action3d._id++;
            }
            return this.myId;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Action3d.prototype, "binded", {
        get: function () { return !!this.node; },
        enumerable: false,
        configurable: true
    });
    Action3d.prototype.setTarget = function (node) {
        this.node = node;
    };
    Action3d.prototype.easing = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        this._easeList = [];
        for (var i = 0, c = args.length; i < c; ++i) {
            this._easeList.push(args[i]);
        }
        return this;
    };
    /**缓动动作时间缩放 */
    Action3d.prototype.computeEaseTime = function (rate) {
        var locList = this._easeList;
        if ((!locList) || (locList.length === 0)) {
            return rate;
        }
        for (var i = 0, n = locList.length; i < n; i++) {
            rate = locList[i].easing(rate);
        }
        return rate;
    };
    Object.defineProperty(Action3d.prototype, "finished", {
        get: function () { return false; },
        enumerable: false,
        configurable: true
    });
    Action3d.prototype.resetFinishState = function () {
    };
    Action3d.prototype.update = function (dt) { };
    Action3d._id = 0;
    return Action3d;
}());
exports.Action3d = Action3d;
//有限时长的动作
var FiniteTimeAction3d = /** @class */ (function (_super) {
    __extends(FiniteTimeAction3d, _super);
    function FiniteTimeAction3d(duration) {
        var _this = _super.call(this) || this;
        _this._paused = false;
        _this.duration = duration;
        _this.elapse = 0;
        return _this;
    }
    Object.defineProperty(FiniteTimeAction3d.prototype, "finished", {
        get: function () { return this.elapse >= this.duration; },
        enumerable: false,
        configurable: true
    });
    FiniteTimeAction3d.prototype.resetFinishState = function () {
        this.elapse = 0;
    };
    Object.defineProperty(FiniteTimeAction3d.prototype, "paused", {
        get: function () { return this._paused; },
        enumerable: false,
        configurable: true
    });
    FiniteTimeAction3d.prototype.update = function (dt) {
        var rate = this.addElapseTime(dt);
        this.step(rate);
    };
    FiniteTimeAction3d.prototype.addElapseTime = function (dt) {
        this.elapse += dt;
        var rate = 1;
        if (this.duration > 0) {
            rate = this.elapse / this.duration;
            if (rate > 1)
                rate = 1;
        }
        rate = this.computeEaseTime(rate);
        return rate;
    };
    FiniteTimeAction3d.prototype.step = function (rate) {
    };
    FiniteTimeAction3d.prototype.interpolation = function (min, max, rate) {
        return min + (max - min) * rate;
    };
    return FiniteTimeAction3d;
}(Action3d));
exports.FiniteTimeAction3d = FiniteTimeAction3d;
//延迟
var DelayTime = /** @class */ (function (_super) {
    __extends(DelayTime, _super);
    function DelayTime() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return DelayTime;
}(FiniteTimeAction3d));
exports.DelayTime = DelayTime;
//移动
var MoveTo3d = /** @class */ (function (_super) {
    __extends(MoveTo3d, _super);
    function MoveTo3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        _this.curValue = {
            x: 0,
            y: 0,
            z: 0
        };
        return _this;
    }
    MoveTo3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.x,
            y: node.y,
            z: node.z
        };
    };
    MoveTo3d.prototype.step = function (rate) {
        this.curValue.x = this.interpolation(this.original.x, this.target.x, rate);
        this.curValue.y = this.interpolation(this.original.y, this.target.y, rate);
        this.curValue.z = this.interpolation(this.original.z, this.target.z, rate);
        this.node.setPosition(this.curValue.x, this.curValue.y, this.curValue.z);
    };
    return MoveTo3d;
}(FiniteTimeAction3d));
exports.MoveTo3d = MoveTo3d;
var MoveBy3d = /** @class */ (function (_super) {
    __extends(MoveBy3d, _super);
    function MoveBy3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        _this.curValue = {
            x: 0,
            y: 0,
            z: 0
        };
        return _this;
    }
    MoveBy3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.x,
            y: node.y,
            z: node.z
        };
    };
    MoveBy3d.prototype.step = function (rate) {
        this.curValue.x = this.original.x + this.target.x * rate;
        this.curValue.y = this.original.y + this.target.y * rate;
        this.curValue.z = this.original.z + this.target.z * rate;
        this.node.setPosition(this.curValue.x, this.curValue.y, this.curValue.z);
    };
    return MoveBy3d;
}(FiniteTimeAction3d));
exports.MoveBy3d = MoveBy3d;
//缩放
var ScaleTo3d = /** @class */ (function (_super) {
    __extends(ScaleTo3d, _super);
    function ScaleTo3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        return _this;
    }
    ScaleTo3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.scaleX,
            y: node.scaleY,
            z: node.scaleZ
        };
    };
    ScaleTo3d.prototype.step = function (rate) {
        var x = this.interpolation(this.original.x, this.target.x, rate);
        var y = this.interpolation(this.original.y, this.target.y, rate);
        var z = this.interpolation(this.original.z, this.target.z, rate);
        this.node.setScale(x, y, z);
    };
    return ScaleTo3d;
}(FiniteTimeAction3d));
exports.ScaleTo3d = ScaleTo3d;
//旋转
var RotateTo3d = /** @class */ (function (_super) {
    __extends(RotateTo3d, _super);
    function RotateTo3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        return _this;
    }
    RotateTo3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.eulerAngles.x,
            y: node.eulerAngles.y,
            z: node.eulerAngles.z
        };
    };
    RotateTo3d.prototype.step = function (rate) {
        var x = this.interpolation(this.original.x, this.target.x, rate);
        var y = this.interpolation(this.original.y, this.target.y, rate);
        var z = this.interpolation(this.original.z, this.target.z, rate);
        this.node.eulerAngles = cc.v3(x, y, z);
    };
    return RotateTo3d;
}(FiniteTimeAction3d));
exports.RotateTo3d = RotateTo3d;
var RotateBy3d = /** @class */ (function (_super) {
    __extends(RotateBy3d, _super);
    function RotateBy3d(duration, x, y, z) {
        var _this = _super.call(this, duration) || this;
        if (typeof x === "number") {
            _this.target = {
                x: x,
                y: y,
                z: z
            };
        }
        else {
            _this.target = x;
        }
        return _this;
    }
    RotateBy3d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = {
            x: node.eulerAngles.x,
            y: node.eulerAngles.y,
            z: node.eulerAngles.z
        };
    };
    RotateBy3d.prototype.step = function (rate) {
        var x = this.original.x + this.target.x * rate;
        var y = this.original.y + this.target.y * rate;
        var z = this.original.z + this.target.z * rate;
        this.node.eulerAngles = cc.v3(x, y, z);
    };
    return RotateBy3d;
}(FiniteTimeAction3d));
exports.RotateBy3d = RotateBy3d;
//2D旋转
var RotateTo2d = /** @class */ (function (_super) {
    __extends(RotateTo2d, _super);
    function RotateTo2d(duration, angle) {
        var _this = _super.call(this, duration) || this;
        _this.target = angle;
        return _this;
    }
    RotateTo2d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = node.angle;
    };
    RotateTo2d.prototype.step = function (rate) {
        var angle = this.interpolation(this.original, this.target, rate);
        this.node.angle = angle;
    };
    return RotateTo2d;
}(FiniteTimeAction3d));
exports.RotateTo2d = RotateTo2d;
//2D旋转
var RotateBy2d = /** @class */ (function (_super) {
    __extends(RotateBy2d, _super);
    function RotateBy2d(duration, angle) {
        var _this = _super.call(this, duration) || this;
        _this.target = angle;
        return _this;
    }
    RotateBy2d.prototype.setTarget = function (node) {
        this.node = node;
        this.original = node.angle;
    };
    RotateBy2d.prototype.step = function (rate) {
        var angle = this.original + this.target * rate;
        this.node.angle = angle;
    };
    return RotateBy2d;
}(FiniteTimeAction3d));
exports.RotateBy2d = RotateBy2d;
//2D节点：透明度变化
var FadeTo = /** @class */ (function (_super) {
    __extends(FadeTo, _super);
    function FadeTo(duration, x) {
        var _this = _super.call(this, duration) || this;
        _this.target = x;
        return _this;
    }
    FadeTo.prototype.setTarget = function (node) {
        this.node = node;
        this.original = node.opacity;
    };
    FadeTo.prototype.step = function (rate) {
        var o = this.interpolation(this.original, this.target, rate);
        this.node.opacity = o;
    };
    return FadeTo;
}(FiniteTimeAction3d));
exports.FadeTo = FadeTo;
var FadeBy = /** @class */ (function (_super) {
    __extends(FadeBy, _super);
    function FadeBy(duration, x) {
        var _this = _super.call(this, duration) || this;
        _this.target = x;
        return _this;
    }
    FadeBy.prototype.setTarget = function (node) {
        this.node = node;
        this.original = node.opacity;
    };
    FadeBy.prototype.step = function (rate) {
        this.node.opacity = this.original + this.target * rate;
    };
    return FadeBy;
}(FiniteTimeAction3d));
exports.FadeBy = FadeBy;
//任意属性变化
var TweenTo = /** @class */ (function (_super) {
    __extends(TweenTo, _super);
    /**
     *
     * @param duration 动作持续的时间
     * @param attribute 变量名称
     * @param value 变化的相对值
     * @param newAttribute 值变化时是否需要新建属性再给目标对象赋值，例如要修改节点的position属性时应该为true
     */
    function TweenTo(duration, attribute, value, newAttribute) {
        var _this = _super.call(this, duration) || this;
        _this.attribute = attribute;
        _this.targetValue = value;
        _this.isNumber = (typeof value === "number");
        _this.newAttribute = newAttribute;
        return _this;
    }
    TweenTo.prototype.setTarget = function (obj) {
        this.obj = obj;
        if (undefined === obj[this.attribute]) {
            console.error("对象不存在属性" + this.attribute + "，动作TweenTo将无法生效");
            return;
        }
        this.original = JSON.parse(JSON.stringify(obj[this.attribute]));
    };
    TweenTo.prototype.step = function (rate) {
        if (this.isNumber) {
            this.obj[this.attribute] = this.interpolation(this.original, this.targetValue, rate);
        }
        else if (this.newAttribute) {
            var data = {};
            for (var key in this.original) {
                data[key] = this.interpolation(this.original[key], this.targetValue[key], rate);
            }
            this.obj[this.attribute] = data;
        }
        else {
            for (var key in this.original) {
                this.obj[this.attribute][key] = this.interpolation(this.original[key], this.targetValue[key], rate);
            }
        }
    };
    return TweenTo;
}(FiniteTimeAction3d));
var TweenBy = /** @class */ (function (_super) {
    __extends(TweenBy, _super);
    /**
     *
     * @param duration 动作持续的时间
     * @param attribute 变量名称
     * @param value 变化的相对值
     * @param newAttribute 值变化时是否需要新建属性再给目标对象赋值，例如要修改节点的position属性时应该为true
     */
    function TweenBy(duration, attribute, value, newAttribute) {
        var _this = _super.call(this, duration) || this;
        _this.attribute = attribute;
        _this.targetValue = value;
        _this.isNumber = (typeof value === "number");
        _this.newAttribute = newAttribute;
        return _this;
    }
    TweenBy.prototype.setTarget = function (obj) {
        this.obj = obj;
        if (undefined === obj[this.attribute]) {
            console.error("对象不存在属性" + this.attribute + "，动作TweenTo将无法生效");
            return;
        }
        this.original = JSON.parse(JSON.stringify(obj[this.attribute]));
    };
    TweenBy.prototype.step = function (rate) {
        if (this.isNumber) {
            this.obj[this.attribute] = this.original + this.targetValue * rate;
        }
        else if (this.newAttribute) {
            var data = {};
            for (var key in this.original) {
                data[key] = this.original[key] + this.targetValue[key] * rate;
            }
            this.obj[this.attribute] = data;
        }
        else {
            for (var key in this.original) {
                this.obj[this.attribute][key] = this.original[key] + this.targetValue[key] * rate;
            }
        }
    };
    return TweenBy;
}(FiniteTimeAction3d));
//回调函数
var CallFun3d = /** @class */ (function (_super) {
    __extends(CallFun3d, _super);
    function CallFun3d(cb, target, data) {
        var _this = _super.call(this) || this;
        _this._finished = false;
        _this.cb = cb;
        _this.target = target;
        _this.data = data;
        return _this;
    }
    Object.defineProperty(CallFun3d.prototype, "finished", {
        get: function () { return this._finished; },
        enumerable: false,
        configurable: true
    });
    CallFun3d.prototype.resetFinishState = function () {
        this._finished = false;
    };
    CallFun3d.prototype.update = function (dt) {
        if (this.finished)
            return;
        if (!!this.target) {
            this.cb.call(this.target, this.data || null);
        }
        else {
            this.cb(this.data || null);
        }
        this._finished = true;
    };
    return CallFun3d;
}(Action3d));
exports.CallFun3d = CallFun3d;
//队列动作
var Sequence3d = /** @class */ (function (_super) {
    __extends(Sequence3d, _super);
    function Sequence3d(actions) {
        var _this = _super.call(this) || this;
        _this.curActionPtr = 0;
        _this.actions = [].concat(actions);
        return _this;
    }
    Object.defineProperty(Sequence3d.prototype, "finished", {
        get: function () { return this.curActionPtr >= this.actions.length; },
        enumerable: false,
        configurable: true
    });
    Sequence3d.prototype.resetFinishState = function () {
        for (var i = this.actions.length - 1; i >= 0; --i) {
            this.actions[i].resetFinishState();
        }
        this.curActionPtr = 0;
        this.setCurActionTarget();
    };
    Sequence3d.prototype.setTarget = function (node) {
        this.node = node;
        // for (let i = this.actions.length - 1; i >= 0; --i) {
        //     this.actions[i].setTarget(node);
        // }
        this.setCurActionTarget();
    };
    Sequence3d.prototype.update = function (dt) {
        if (this.finished)
            return;
        var action = this.actions[this.curActionPtr];
        action.update(dt);
        if (action.finished) {
            this.curActionPtr++;
            this.setCurActionTarget();
        }
    };
    /**设置当前正在执行的动作的目标节点 */
    Sequence3d.prototype.setCurActionTarget = function () {
        if (!this.finished)
            this.actions[this.curActionPtr].setTarget(this.node);
    };
    Sequence3d.prototype.pushAction = function (action) {
        this.actions.push(action);
    };
    return Sequence3d;
}(Action3d));
exports.Sequence3d = Sequence3d;
//同步动作
var Spawn3d = /** @class */ (function (_super) {
    __extends(Spawn3d, _super);
    function Spawn3d(actions) {
        var _this = _super.call(this) || this;
        _this.actions = [].concat(actions);
        _this.remainCount = _this.actions.length;
        return _this;
    }
    Object.defineProperty(Spawn3d.prototype, "finished", {
        get: function () {
            return this.remainCount <= 0;
        },
        enumerable: false,
        configurable: true
    });
    Spawn3d.prototype.resetFinishState = function () {
        for (var i = this.actions.length - 1; i >= 0; --i) {
            this.actions[i].resetFinishState();
        }
        this.remainCount = this.actions.length;
    };
    Spawn3d.prototype.setTarget = function (node) {
        this.node = node;
        for (var i = this.actions.length - 1; i >= 0; --i) {
            this.actions[i].setTarget(node);
        }
    };
    Spawn3d.prototype.update = function (dt) {
        if (this.finished)
            return;
        for (var i = this.actions.length - 1; i >= 0; --i) {
            if (!this.actions[i].finished) {
                this.actions[i].update(dt);
                if (this.actions[i].finished) {
                    this.remainCount--;
                }
            }
        }
    };
    //追加一个动作
    Spawn3d.prototype.pushAction = function (action) {
        this.actions.push(action);
        if (!!this.node)
            action.setTarget(this.node);
    };
    return Spawn3d;
}(Action3d));
exports.Spawn3d = Spawn3d;
//重复动作
var RepeatForever = /** @class */ (function (_super) {
    __extends(RepeatForever, _super);
    function RepeatForever(action) {
        var _this = _super.call(this) || this;
        _this.action = action;
        return _this;
    }
    RepeatForever.prototype.setTarget = function (node) {
        this.node = node;
        this.action.setTarget(node);
    };
    RepeatForever.prototype.update = function (dt) {
        this.action.update(dt);
        if (this.action.finished) {
            this.action.resetFinishState();
        }
    };
    return RepeatForever;
}(Action3d));
exports.RepeatForever = RepeatForever;
//缓动曲线
var Ease = /** @class */ (function () {
    function Ease() {
    }
    Ease.prototype.easing = function (rate) {
        return rate;
    };
    return Ease;
}());
var EaseIn = /** @class */ (function (_super) {
    __extends(EaseIn, _super);
    function EaseIn(rate) {
        var _this = _super.call(this) || this;
        _this._rate = rate;
        return _this;
    }
    EaseIn.prototype.easing = function (rate) {
        return Math.pow(rate, this._rate);
    };
    return EaseIn;
}(Ease));
var EaseOut = /** @class */ (function (_super) {
    __extends(EaseOut, _super);
    function EaseOut(rate) {
        var _this = _super.call(this) || this;
        _this._rate = rate;
        return _this;
    }
    EaseOut.prototype.easing = function (rate) {
        return Math.pow(rate, 1 / this._rate);
    };
    return EaseOut;
}(Ease));
var EaseInOut = /** @class */ (function (_super) {
    __extends(EaseInOut, _super);
    function EaseInOut(rate) {
        var _this = _super.call(this) || this;
        _this._rate = rate;
        return _this;
    }
    EaseInOut.prototype.easing = function (rate) {
        rate *= 2;
        if (rate < 1)
            return 0.5 * Math.pow(rate, this._rate);
        else
            return 1.0 - 0.5 * Math.pow(2 - rate, this._rate);
    };
    return EaseInOut;
}(Ease));
var EaseOutIn = /** @class */ (function (_super) {
    __extends(EaseOutIn, _super);
    function EaseOutIn(rate) {
        var _this = _super.call(this) || this;
        _this._rate = rate;
        return _this;
    }
    EaseOutIn.prototype.easing = function (rate) {
        rate *= 2;
        if (rate < 1)
            return 1.0 - 0.5 * Math.pow(2 - rate, this._rate);
        else
            return 0.5 * Math.pow(rate, this._rate);
    };
    return EaseOutIn;
}(Ease));
/**指数函数缓动进入 */
var EaseExponentialIn = /** @class */ (function (_super) {
    __extends(EaseExponentialIn, _super);
    function EaseExponentialIn() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseExponentialIn.prototype.easing = function (rate) {
        return rate === 0 ? 0 : Math.pow(2, 10 * (rate - 1));
    };
    return EaseExponentialIn;
}(Ease));
/**指数函数缓动退出 */
var EaseExponentialOut = /** @class */ (function (_super) {
    __extends(EaseExponentialOut, _super);
    function EaseExponentialOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseExponentialOut.prototype.easing = function (rate) {
        return rate === 1 ? 1 : (-(Math.pow(2, -10 * rate)) + 1);
    };
    return EaseExponentialOut;
}(Ease));
/**指数函数缓动进入——退出 */
var EaseExponentialInOut = /** @class */ (function (_super) {
    __extends(EaseExponentialInOut, _super);
    function EaseExponentialInOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseExponentialInOut.prototype.easing = function (rate) {
        if (rate !== 1 && rate !== 0) {
            rate *= 2;
            if (rate < 1)
                return 0.5 * Math.pow(2, 10 * (rate - 1));
            else
                return 0.5 * (-Math.pow(2, -10 * (rate - 1)) + 2);
        }
        return rate;
    };
    return EaseExponentialInOut;
}(Ease));
var EaseSinIn = /** @class */ (function (_super) {
    __extends(EaseSinIn, _super);
    function EaseSinIn() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseSinIn.prototype.easing = function (rate) {
        return 1 - Math.sin((1 - rate) * 1.57);
    };
    return EaseSinIn;
}(Ease));
var EaseSinOut = /** @class */ (function (_super) {
    __extends(EaseSinOut, _super);
    function EaseSinOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseSinOut.prototype.easing = function (rate) {
        return Math.sin(rate * 1.57);
    };
    return EaseSinOut;
}(Ease));
var EaseSinInOut = /** @class */ (function (_super) {
    __extends(EaseSinInOut, _super);
    function EaseSinInOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseSinInOut.prototype.easing = function (rate) {
        return Math.sin(rate * 3.14 + 4.71) * 0.5 + 0.5;
    };
    return EaseSinInOut;
}(Ease));
var EaseSinOutIn = /** @class */ (function (_super) {
    __extends(EaseSinOutIn, _super);
    function EaseSinOutIn() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseSinOutIn.prototype.easing = function (rate) {
        if (rate < 0.5) {
            return Math.sin(rate * 3.14) * 0.5;
        }
        else {
            return 1 - Math.sin((1 - rate) * 3.14) * 0.5;
        }
    };
    return EaseSinOutIn;
}(Ease));
//弹性变化
var EaseElasticIn = /** @class */ (function (_super) {
    __extends(EaseElasticIn, _super);
    function EaseElasticIn(rate) {
        var _this = _super.call(this) || this;
        _this._period = rate || 0.3;
        return _this;
    }
    EaseElasticIn.prototype.easing = function (rate) {
        if (rate === 0 || rate === 1)
            return rate;
        rate = rate - 1;
        return -Math.pow(2, 10 * rate) * Math.sin((rate - (this._period / 4)) * Math.PI * 2 / this._period);
    };
    return EaseElasticIn;
}(Ease));
var EaseElasticOut = /** @class */ (function (_super) {
    __extends(EaseElasticOut, _super);
    function EaseElasticOut(rate) {
        var _this = _super.call(this) || this;
        _this._period = rate || 0.3;
        return _this;
    }
    EaseElasticOut.prototype.easing = function (dt) {
        return (dt === 0 || dt === 1) ? dt : Math.pow(2, -10 * dt) * Math.sin((dt - (this._period / 4)) * Math.PI * 2 / this._period) + 1;
    };
    return EaseElasticOut;
}(Ease));
var EaseElasticInOut = /** @class */ (function (_super) {
    __extends(EaseElasticInOut, _super);
    function EaseElasticInOut(rate) {
        var _this = _super.call(this) || this;
        _this._period = rate || 0.3;
        return _this;
    }
    EaseElasticInOut.prototype.easing = function (dt) {
        var newT = 0;
        var locPeriod = this._period;
        if (dt === 0 || dt === 1) {
            newT = dt;
        }
        else {
            dt = dt * 2;
            if (!locPeriod)
                locPeriod = this._period = 0.3 * 1.5;
            var s = locPeriod / 4;
            dt = dt - 1;
            if (dt < 0)
                newT = -0.5 * Math.pow(2, 10 * dt) * Math.sin((dt - s) * Math.PI * 2 / locPeriod);
            else
                newT = Math.pow(2, -10 * dt) * Math.sin((dt - s) * Math.PI * 2 / locPeriod) * 0.5 + 1;
        }
        return newT;
    };
    return EaseElasticInOut;
}(Ease));
//按弹跳动作缓动进入的动作
var EaseBounceIn = /** @class */ (function (_super) {
    __extends(EaseBounceIn, _super);
    function EaseBounceIn() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseBounceIn.prototype.easing = function (dt) {
        return 1 - this._bounceTime(1 - dt);
    };
    EaseBounceIn.prototype._bounceTime = function (time1) {
        if (time1 < 1 / 2.75) {
            return 7.5625 * time1 * time1;
        }
        else if (time1 < 2 / 2.75) {
            time1 -= 1.5 / 2.75;
            return 7.5625 * time1 * time1 + 0.75;
        }
        else if (time1 < 2.5 / 2.75) {
            time1 -= 2.25 / 2.75;
            return 7.5625 * time1 * time1 + 0.9375;
        }
        time1 -= 2.625 / 2.75;
        return 7.5625 * time1 * time1 + 0.984375;
    };
    return EaseBounceIn;
}(Ease));
var EaseBounceOut = /** @class */ (function (_super) {
    __extends(EaseBounceOut, _super);
    function EaseBounceOut() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EaseBounceOut.prototype.easing = function (dt) {
        return this._bounceTime(dt);
    };
    EaseBounceOut.prototype._bounceTime = function (time1) {
        if (time1 < 1 / 2.75) {
            return 7.5625 * time1 * time1;
        }
        else if (time1 < 2 / 2.75) {
            time1 -= 1.5 / 2.75;
            return 7.5625 * time1 * time1 + 0.75;
        }
        else if (time1 < 2.5 / 2.75) {
            time1 -= 2.25 / 2.75;
            return 7.5625 * time1 * time1 + 0.9375;
        }
        time1 -= 2.625 / 2.75;
        return 7.5625 * time1 * time1 + 0.984375;
    };
    return EaseBounceOut;
}(Ease));

cc._RF.pop();