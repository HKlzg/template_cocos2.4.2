"use strict";
cc._RF.push(module, '080b4sm8OJF05ZQAgQM+TZ3', 'GameConfig');
// GameSpecial/GameConfig.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var CommonGameConfig_1 = require("../Common/CommonGameConfig");
/**
 * 全局使用的游戏配置，只包含静态数据
 */
var GameConfig = /** @class */ (function (_super) {
    __extends(GameConfig, _super);
    function GameConfig() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * 游戏规则
     */
    GameConfig.GameRule = {
        mapSize: {
            width: 400,
            height: 400,
        }
    };
    return GameConfig;
}(CommonGameConfig_1.default));
exports.default = GameConfig;

cc._RF.pop();