"use strict";
cc._RF.push(module, 'ff8f08lKv1NV45mBkyn71pD', 'LevelDataTemplate');
// GameSpecial/LevelDataTemplate.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//关卡数据示例
var LevelDataTemplate = /** @class */ (function () {
    function LevelDataTemplate() {
    }
    LevelDataTemplate.getData = function () {
        return {
            1: {
                id: 1,
                lv: 1,
                time: 10,
                playerData: {
                    p: cc.v3(),
                    e: cc.v3(0, 180, 0),
                },
                //其他数据
                //场景中的全部碰撞体
                collers: [
                    {
                        n: "WalkRole",
                        p: cc.v3(3, 0, 3),
                        e: cc.v3(),
                    }
                ],
            }
        };
    };
    return LevelDataTemplate;
}());
exports.default = LevelDataTemplate;

cc._RF.pop();