"use strict";
cc._RF.push(module, '5ea36wwlGhLP6nx4W1NN5MX', 'PlayerDataTemplate');
// GameSpecial/PlayerDataTemplate.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//玩家数据示例
var PlayerDataTemplate = /** @class */ (function () {
    function PlayerDataTemplate() {
    }
    PlayerDataTemplate.getData = function () {
        return {
            gameData: {
                curLevel: 1,
                //玩家资源
                asset: {
                    gold: 0,
                    power: 10,
                },
                //主角皮肤
                PlayerSkin: {
                    cur: 0,
                    try: -1,
                    owned: [0],
                },
            },
        };
    };
    return PlayerDataTemplate;
}());
exports.default = PlayerDataTemplate;

cc._RF.pop();