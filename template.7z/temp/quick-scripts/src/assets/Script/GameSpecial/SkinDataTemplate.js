"use strict";
cc._RF.push(module, '41dcfb5SZFDr7K15+0tMdni', 'SkinDataTemplate');
// GameSpecial/SkinDataTemplate.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SkinDataTemplate = /** @class */ (function () {
    function SkinDataTemplate() {
    }
    SkinDataTemplate.getData = function () {
        return {
            //key：对应皮肤id
            1: {
                id: 1,
                model: "Cube",
                skin: "1",
                itemUrl: "1",
                price: 200,
                displayUrl: "",
                name: "" //皮肤名称
            },
        };
    };
    return SkinDataTemplate;
}());
exports.default = SkinDataTemplate;

cc._RF.pop();