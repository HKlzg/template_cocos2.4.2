"use strict";
cc._RF.push(module, '2d652/6KzxHFZz3KIQFL+QK', 'GlobalEnum');
// Script/GameSpecial/GlobalEnum.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalEnum = void 0;
var CommonEnum_1 = require("../Common/CommonEnum");
/**通过全局对象池管理的预制件名称与对应的脚本名称 */
var LevelPrefab;
(function (LevelPrefab) {
    LevelPrefab["goldIcon"] = "GoldIcon";
    LevelPrefab["player"] = "Player";
    LevelPrefab["car1"] = "Car1";
    LevelPrefab["standRole"] = "StandRole";
    LevelPrefab["walkRole"] = "WalkRole";
    LevelPrefab["toiletDoor"] = "ToiletDoor";
    LevelPrefab["shi"] = "Shi";
    LevelPrefab["shiParticle"] = "ShiParticle";
})(LevelPrefab || (LevelPrefab = {}));
/**视频广告位名称 */
var VideoName;
(function (VideoName) {
    /**胜利多倍领取 */
    VideoName[VideoName["getGoldWin"] = 0] = "getGoldWin";
    /**失败多倍领取 */
    VideoName[VideoName["getGoldLose"] = 1] = "getGoldLose";
    /**观看视频获取金币 */
    VideoName[VideoName["getGold"] = 2] = "getGold";
    /**试用皮肤 */
    VideoName[VideoName["trySkin"] = 3] = "trySkin";
    /**复活 */
    VideoName[VideoName["fuHuo"] = 4] = "fuHuo";
    /**试用剑神模式 */
    VideoName[VideoName["tryJianShen"] = 5] = "tryJianShen";
    /**道具-磁铁 */
    VideoName[VideoName["ciTie"] = 6] = "ciTie";
    /**道具-护盾 */
    VideoName[VideoName["huDun"] = 7] = "huDun";
    /**道具-暴走 */
    VideoName[VideoName["baoZou"] = 8] = "baoZou";
})(VideoName || (VideoName = {}));
var GlobalEnum = /** @class */ (function (_super) {
    __extends(GlobalEnum, _super);
    function GlobalEnum() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    GlobalEnum.LevelPrefab = LevelPrefab;
    GlobalEnum.VideoName = VideoName;
    return GlobalEnum;
}(CommonEnum_1.CommonEnum));
exports.GlobalEnum = GlobalEnum;

cc._RF.pop();