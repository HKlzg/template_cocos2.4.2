"use strict";
cc._RF.push(module, 'ba32fZzFh9Kwr/9o3ZFk9hA', 'RecommendContainer');
// Script/Recommend/RecommendContainer.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../Common/yyComponent");
var GlobalPool_1 = require("../Common/GlobalPool");
var GlobalEnum_1 = require("../GameSpecial/GlobalEnum");
var RecommendDataManager_1 = require("./RecommendDataManager");
//互推游戏节点容器
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecommendContainer = /** @class */ (function (_super) {
    __extends(RecommendContainer, _super);
    function RecommendContainer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.content = null; //存放互推节点的父节点
        return _this;
    }
    RecommendContainer.prototype.init = function (data) {
        this.onEvents();
        if (!!data) {
            this.setData(data);
        }
    };
    RecommendContainer.prototype.onEvents = function () {
    };
    RecommendContainer.prototype.reset = function () {
        this.resetItems();
    };
    RecommendContainer.prototype.resetItems = function () {
        GlobalPool_1.default.putAllChildren(this.content);
    };
    RecommendContainer.prototype.reuse = function (data) {
        this.reset();
        this.setData(data);
    };
    RecommendContainer.prototype.unuse = function () {
    };
    RecommendContainer.prototype.setData = function (data) {
        var items = data.items;
        if (!items) {
            items = RecommendDataManager_1.default.getAllRecommendData();
        }
        this.addItems(items);
    };
    //添加互推游戏节点
    RecommendContainer.prototype.addItems = function (data, type) {
        if (type === void 0) { type = GlobalEnum_1.GlobalEnum.RecommendItemType.normal; }
        for (var i = 0, count = data.length; i < count; ++i) {
            var item = this.getItem(type, data[i]);
            this.content.addChild(item);
        }
    };
    /**根据类型获取对应的预制件 */
    RecommendContainer.prototype.getItem = function (prefabName, data) {
        return GlobalPool_1.default.get(prefabName, data);
    };
    //设置布局组件
    RecommendContainer.prototype.setWidget = function (node, widget, targetNode) {
        var wg = node.getComponent(cc.Widget);
        if (!wg) {
            wg = node.addComponent(cc.Widget);
        }
        wg.isAbsoluteBottom = true;
        wg.isAbsoluteLeft = true;
        wg.isAbsoluteRight = true;
        wg.isAbsoluteTop = true;
        wg.isAbsoluteHorizontalCenter = true;
        wg.isAbsoluteVerticalCenter = true;
        if (!widget)
            return;
        if (!!targetNode) {
            wg.target = targetNode;
        }
        else {
            wg.target = node.parent;
        }
        if (undefined != widget.top) {
            wg.isAlignTop = true;
            wg.top = parseFloat(widget.top);
        }
        else {
            wg.isAlignTop = false;
        }
        if (undefined != widget.bottom) {
            wg.isAlignBottom = true;
            wg.bottom = parseFloat(widget.bottom);
        }
        else {
            wg.isAlignBottom = false;
        }
        if (undefined != widget.left) {
            wg.isAlignLeft = true;
            wg.left = parseFloat(widget.left);
        }
        else {
            wg.isAlignLeft = false;
        }
        if (undefined != widget.right) {
            wg.isAlignRight = true;
            wg.right = parseFloat(widget.right);
        }
        else {
            wg.isAlignRight = false;
        }
        wg.isAlignHorizontalCenter = !!widget.horizontalCenter;
        wg.isAlignVerticalCenter = !!widget.verticalCenter;
        wg.updateAlignment();
    };
    __decorate([
        property(cc.Node)
    ], RecommendContainer.prototype, "content", void 0);
    RecommendContainer = __decorate([
        ccclass
    ], RecommendContainer);
    return RecommendContainer;
}(yyComponent_1.default));
exports.default = RecommendContainer;

cc._RF.pop();