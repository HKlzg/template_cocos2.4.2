"use strict";
cc._RF.push(module, '4d9775Zlg1AlYPqAHFIRaiS', 'RecommendManager');
// Script/Recommend/RecommendManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendDataManager_1 = require("./RecommendDataManager");
var Recommend_1 = require("./Recommend");
var RecommendConfig_1 = require("./RecommendConfig");
var GamePlatform_1 = require("../Platform/GamePlatform");
var GamePlatformType_1 = require("../Platform/GamePlatformType");
//互推管理器(仅初始化Recommend与RecommendDataManager，为避免两者相互引用而使用本脚本)
var RecommendManager = /** @class */ (function () {
    function RecommendManager() {
    }
    RecommendManager.init = function (node) {
        var recommend = this.addRecommendComponent(node);
        if (!!recommend) {
            recommend.init();
            RecommendDataManager_1.default.init(node);
        }
    };
    RecommendManager.addRecommendComponent = function (node) {
        var config = node.getComponent(RecommendConfig_1.default);
        if (!config) {
            switch (GamePlatform_1.default.instance.Config.type) {
                case GamePlatformType_1.GamePlatformType.OPPO:
                case GamePlatformType_1.GamePlatformType.PC:
                case GamePlatformType_1.GamePlatformType.WX: {
                    return node.addComponent(Recommend_1.default);
                }
                case GamePlatformType_1.GamePlatformType.TT: {
                    //头条 iOS 不支持互推
                    var systemInfo = window["tt"].getSystemInfoSync();
                    if (systemInfo.platform == "ios" || systemInfo.appName == "XiGua") {
                        return null;
                    }
                    return null;
                }
                default: {
                    return null;
                }
            }
        }
        else {
            switch (config.type) {
                case RecommendConfig_1.default.recommendPlatformType.PC:
                case RecommendConfig_1.default.recommendPlatformType.OPPO:
                case RecommendConfig_1.default.recommendPlatformType.WX: {
                    return node.addComponent(Recommend_1.default);
                }
                case RecommendConfig_1.default.recommendPlatformType.TT: {
                    //头条 iOS 不支持互推
                    var systemInfo = window["tt"].getSystemInfoSync();
                    if (systemInfo.platform == "ios" || systemInfo.appName == "XiGua") {
                        return null;
                    }
                    return null;
                }
                default: {
                    return null;
                }
            }
        }
    };
    return RecommendManager;
}());
exports.default = RecommendManager;

cc._RF.pop();