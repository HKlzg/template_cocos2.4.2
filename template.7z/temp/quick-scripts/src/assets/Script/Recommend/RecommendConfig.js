"use strict";
cc._RF.push(module, '5e757y7KrNODqAfXpNcgrrP', 'RecommendConfig');
// Script/Recommend/RecommendConfig.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**使用Youzi互推时，管理后台提供的平台渠道 默认微信 */
var PLAT_TYPE_CHANNELID = {
    Test: 1001,
    WeChat: 1002,
    Oppo: 8001,
    TouTiao: 11001 //头条小游戏
};
/**互推配置脚本，挂载在互推根节点上 */
var RecommendConfig = /** @class */ (function (_super) {
    __extends(RecommendConfig, _super);
    function RecommendConfig() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = RecommendConfig_1.recommendPlatformType.PC;
        _this.Youzi_Appid = "";
        _this.Youzi_ResVersion = "1.00.00";
        _this._Youzi_ChannelId = RecommendConfig_1.YouziChannelType.WeChat;
        return _this;
    }
    RecommendConfig_1 = RecommendConfig;
    Object.defineProperty(RecommendConfig.prototype, "Youzi_ChannelId", {
        get: function () {
            if (this._Youzi_ChannelId == PLAT_TYPE_CHANNELID.Test) {
                return PLAT_TYPE_CHANNELID.WeChat;
            }
            else {
                return this._Youzi_ChannelId;
            }
        },
        enumerable: false,
        configurable: true
    });
    var RecommendConfig_1;
    RecommendConfig.recommendPlatformType = cc.Enum({
        PC: 0,
        WX: -1,
        TT: -1,
        QQ: -1,
        OPPO: -1,
        VIVO: -1,
        XiaoMi: -1,
        LeYou: -1,
        DYB_QQ: -1,
        Blue_Android: -1,
        Blue_IOS: -1,
        Youzi: -1,
    });
    RecommendConfig.YouziChannelType = cc.Enum(PLAT_TYPE_CHANNELID);
    __decorate([
        property({
            type: RecommendConfig_1.recommendPlatformType,
            tooltip: "互推类型",
        })
    ], RecommendConfig.prototype, "type", void 0);
    __decorate([
        property({
            tooltip: "使用Youzi互推时，渠道提供的appid 如果是微信渠道 填写微信后台提供的appid。"
        })
    ], RecommendConfig.prototype, "Youzi_Appid", void 0);
    __decorate([
        property({
            tooltip: "使用Youzi互推时，中心化资源版本 中心化提供的资源版本号 向中心化对接组咨询 默认'1.00.00'。"
        })
    ], RecommendConfig.prototype, "Youzi_ResVersion", void 0);
    __decorate([
        property({
            type: RecommendConfig_1.YouziChannelType,
            tooltip: "使用Youzi互推时，管理后台提供的平台渠道 默认微信",
            visible: true,
        })
    ], RecommendConfig.prototype, "_Youzi_ChannelId", void 0);
    RecommendConfig = RecommendConfig_1 = __decorate([
        ccclass
    ], RecommendConfig);
    return RecommendConfig;
}(cc.Component));
exports.default = RecommendConfig;

cc._RF.pop();