"use strict";
cc._RF.push(module, '4460azqs/1CM7A+qOUvnNjl', 'Recommend');
// Script/Recommend/Recommend.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var yyComponent_1 = require("../Common/yyComponent");
var GameEventType_1 = require("../GameSpecial/GameEventType");
var GlobalPool_1 = require("../Common/GlobalPool");
var RecommendDataManager_1 = require("./RecommendDataManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Recommend = /** @class */ (function (_super) {
    __extends(Recommend, _super);
    function Recommend() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Recommend.prototype.init = function () {
        this.scheduledRecommend = false;
        this.initSceneStack();
        this.onEvents();
    };
    Recommend.prototype.onEvents = function () {
        this.once(GameEventType_1.EventType.RecommendEvent.assetLoadFinish, this.onConfigLoadFinish, this);
        this.on(GameEventType_1.EventType.RecommendEvent.clickRecommendItem, this.navigateGame, this);
        this.on(GameEventType_1.EventType.RecommendEvent.hideRecommend, this.onHideRecommend, this);
        // this.on(EventType.RecommendEvent.enterRecommendScene, this.onEnterScene, this);
        // this.on(EventType.RecommendEvent.exitRecommendScene, this.onExitScene, this);
        this.on(GameEventType_1.EventType.UIEvent.entered, this.onEnterScene, this);
        this.on(GameEventType_1.EventType.UIEvent.exited, this.onExitScene, this);
    };
    Recommend.prototype.initSceneStack = function () {
        this.sceneStack = [];
    };
    /**回收所有主推游戏节点 */
    Recommend.prototype.reset = function () {
        this.scheduledRecommend = false;
        this.resetSceneStack();
        GlobalPool_1.default.putAllChildren(this.node);
    };
    Recommend.prototype.resetSceneStack = function () {
        this.sceneStack = [];
    };
    /**跳转到其他小游戏 */
    Recommend.prototype.navigateGame = function (recommendId) {
        //发送事件，由各平台SDK执行
        var data = RecommendDataManager_1.default.getRecommendData(recommendId);
        this.emit(GameEventType_1.EventType.SDKEvent.navigateToMiniProgram, data);
    };
    /**进入需要显示互推的场景/UI */
    Recommend.prototype.onEnterScene = function (scene) {
        if (undefined === scene || null === scene)
            return;
        //未对该场景进行互推配置时，不对其进行记录
        var config = RecommendDataManager_1.default.getRecommendConfig(scene);
        if (undefined === config)
            return;
        var curScene = this.getCurScene();
        if (curScene == scene)
            return;
        for (var i = this.sceneStack.length - 1; i >= 0; --i) {
            if (this.sceneStack[i] == scene) {
                this.sceneStack.splice(i, 1);
                break;
            }
        }
        this.sceneStack.push(scene);
        this.updateRecommends();
    };
    /**获取当前显示在最上层的互推场景/UI */
    Recommend.prototype.getCurScene = function () {
        var count = this.sceneStack.length;
        if (count == 0)
            return null;
        return this.sceneStack[count - 1];
    };
    /**退出需要显示互推的场景/UI */
    Recommend.prototype.onExitScene = function (scene) {
        if (undefined === scene || null === scene)
            return;
        //未对该场景进行互推配置时，不需要进行处理
        var config = RecommendDataManager_1.default.getRecommendConfig(scene);
        if (undefined === config)
            return;
        var curScene = this.getCurScene();
        if (curScene == scene) {
            this.sceneStack.pop();
            this.updateRecommends();
        }
        else {
            for (var i = this.sceneStack.length - 1; i >= 0; --i) {
                if (this.sceneStack[i] == scene) {
                    this.sceneStack.splice(i, 1);
                    break;
                }
            }
        }
    };
    /**互推配置表加载完毕，延迟更新互推内容 */
    Recommend.prototype.onConfigLoadFinish = function () {
        console.log("互推资源加载完毕，更新互推内容，scheduledRecommend:", this.scheduledRecommend);
        this.updateRecommends();
    };
    /**切换UI/场景，显示对应的互推内容 */
    Recommend.prototype.updateRecommends = function () {
        //使用计时器，到下一帧才更新互推内容，
        //避免游戏中执行初始化、重置等流程时场景/UI切换过多，
        //需要在一帧中反复显隐互推内容
        if (this.scheduledRecommend)
            return;
        this.scheduleOnce(this.showCurSceneRecommend, 0);
        this.scheduledRecommend = true;
    };
    /**根据显示在最上层的场景/UI，显示相应的互推内容 */
    Recommend.prototype.showCurSceneRecommend = function () {
        this.scheduledRecommend = false;
        GlobalPool_1.default.putAllChildren(this.node);
        var config = null;
        for (var i = this.sceneStack.length - 1; i >= 0; --i) {
            var scene = this.sceneStack[i];
            config = RecommendDataManager_1.default.getRecommendConfig(scene);
            if (!!config) {
                break;
            }
        }
        if (!config)
            return; //可能会出现未配置对应场景的互推内容、互推配置文件尚未加载完成的情况
        for (var key in config) {
            var item = GlobalPool_1.default.get(key, config[key]);
            this.node.addChild(item);
        }
    };
    /**隐藏互推 */
    Recommend.prototype.onHideRecommend = function (recommend) {
    };
    Recommend = __decorate([
        ccclass
    ], Recommend);
    return Recommend;
}(yyComponent_1.default));
exports.default = Recommend;

cc._RF.pop();