"use strict";
cc._RF.push(module, '41aa7Aqw4BHO4CSSBBAQXff', 'RecommendDataManager');
// Script/Recommend/RecommendDataManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RecommendConfig_1 = require("./RecommendConfig");
var EventManager_1 = require("../Common/EventManager");
var GameEventType_1 = require("../GameSpecial/GameEventType");
var GamePlatform_1 = require("../Platform/GamePlatform");
var GamePlatformType_1 = require("../Platform/GamePlatformType");
var GlobalPool_1 = require("../Common/GlobalPool");
var Loader_1 = require("../Common/Loader");
/**互推需要的资源类型 */
var AssetType = {
    config: 1,
    gameIcon: 2,
    prefab: 3,
};
//互推配置数据管理器
var RecommendDataManager = /** @class */ (function () {
    function RecommendDataManager() {
    }
    RecommendDataManager.init = function (node) {
        var _this = this;
        this.allAssetLoad = false;
        this.assetState = {};
        var str = this.getJsonName(node);
        if (!!str) {
            Loader_1.default.loadBundle("Recommend", function () {
                _this.loadConfig(str);
                _this.loadPrefab();
                _this.loadGameIcon();
            }, false);
        }
    };
    /**资源加载完成回调 */
    RecommendDataManager.loadFinish = function (key) {
        this.assetState[key] = true;
        //若全部资源加载完成，则发送事件，通知互推节点更新内容
        var finish = true;
        for (var key_1 in AssetType) {
            if (!this.assetState[AssetType[key_1]]) {
                finish = false;
                break;
            }
        }
        if (finish) {
            this.allAssetLoad = true;
            this.assetState = null;
            EventManager_1.default.emit(GameEventType_1.EventType.RecommendEvent.assetLoadFinish);
        }
    };
    /**加载互推配置表 */
    RecommendDataManager.loadConfig = function (str) {
        var _this = this;
        Loader_1.default.loadBundleRes("Recommend", "Config/" + str, function (res) {
            if (null === res) {
                console.log("互推配置表加载失败：", str);
                return;
            }
            _this.data = res.json;
            _this.loadFinish(AssetType.config);
        }, cc.JsonAsset, false);
    };
    /**根据游戏平台获取互推配置文件名 */
    RecommendDataManager.getJsonName = function (node) {
        var config = null;
        if (!!node) {
            config = node.getComponent(RecommendConfig_1.default);
        }
        if (!config) {
            switch (GamePlatform_1.default.instance.Config.type) {
                case GamePlatformType_1.GamePlatformType.OPPO: return "RecommendConfig_OPPO";
                case GamePlatformType_1.GamePlatformType.QQ: return null;
                case GamePlatformType_1.GamePlatformType.TT: return "RecommendConfig_TT";
                case GamePlatformType_1.GamePlatformType.WX: return "RecommendConfig_WX";
                // case GamePlatformType.PC: return "RecommendConfig_WX";
                case GamePlatformType_1.GamePlatformType.VIVO: return null;
                default: return null;
            }
        }
        else {
            switch (config.type) {
                case RecommendConfig_1.default.recommendPlatformType.OPPO: return "RecommendConfig_OPPO";
                case RecommendConfig_1.default.recommendPlatformType.QQ: return null;
                case RecommendConfig_1.default.recommendPlatformType.TT: return "RecommendConfig_TT";
                case RecommendConfig_1.default.recommendPlatformType.WX: return "RecommendConfig_WX";
                case RecommendConfig_1.default.recommendPlatformType.PC: return "RecommendConfig_WX";
                case RecommendConfig_1.default.recommendPlatformType.VIVO: return null;
                case RecommendConfig_1.default.recommendPlatformType.Youzi: return "RecommendConfig_Youzi";
                default: return null;
            }
        }
    };
    /**加载互推使用的所有预制件 */
    RecommendDataManager.loadPrefab = function () {
        var _this = this;
        var url = "Prefab/";
        switch (GamePlatform_1.default.instance.Config.type) {
            case GamePlatformType_1.GamePlatformType.TT: {
                url += "Recommend_TT";
                break;
            }
            case GamePlatformType_1.GamePlatformType.PC:
            default: {
                url += "Common";
                break;
            }
        }
        Loader_1.default.loadBundleDir("Recommend", url, function (res) {
            if (null === res) {
                console.log("互推预制件加载失败:", url);
                return;
            }
            for (var i = res.length - 1; i >= 0; --i) {
                var prefab = res[i];
                GlobalPool_1.default.createPool(prefab.name, prefab, prefab.name);
            }
            _this.loadFinish(AssetType.prefab);
        }, cc.Prefab, false);
    };
    /**加载所有互推游戏的icon */
    RecommendDataManager.loadGameIcon = function () {
        var _this = this;
        var url = "GameIcon/";
        switch (GamePlatform_1.default.instance.Config.type) {
            case GamePlatformType_1.GamePlatformType.OPPO: {
                url += "Icon_OPPO";
                break;
            }
            case GamePlatformType_1.GamePlatformType.TT: {
                url += "Icon_TT";
                break;
            }
            case GamePlatformType_1.GamePlatformType.PC:
            default: {
                url += "Common";
                break;
            }
        }
        Loader_1.default.loadBundleDir("Recommend", url, function (res) {
            if (null === res) {
                console.log("加载互推图片失败");
                return;
            }
            _this.gameIcons = {};
            for (var i = res.length - 1; i >= 0; --i) {
                _this.gameIcons[res[i].name] = res[i];
            }
            _this.loadFinish(AssetType.gameIcon);
        });
    };
    /**
     * 获取互推数据
     * @param id    互推数据id
     */
    RecommendDataManager.getRecommendData = function (id) {
        if (!this.data)
            return null;
        return this.data.data[id];
    };
    /**
     * 获取全部互推数据
     */
    RecommendDataManager.getAllRecommendData = function () {
        if (!this.data)
            return [];
        return this.data.data;
    };
    /**
     * 获取互推游戏的图标
     * @param icon 游戏图标文件名
     */
    RecommendDataManager.getGameIcon = function (icon) {
        return this.gameIcons[icon];
    };
    /**
     * 获取指定场景的互推配置
     * @param scene     场景/UI类型
     */
    RecommendDataManager.getRecommendConfig = function (scene) {
        if (!this.allAssetLoad || !this.data)
            return null;
        return this.data[scene];
    };
    RecommendDataManager.data = null;
    return RecommendDataManager;
}());
exports.default = RecommendDataManager;

cc._RF.pop();