"use strict";
cc._RF.push(module, 'd48f33Sg+hOu7KjHW8NOSEm', 'MyAtlasSprite');
// Script/Recommend/MyAtlasSprite.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MyAtlasAssembler = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MyAtlasSprite = /** @class */ (function (_super) {
    __extends(MyAtlasSprite, _super);
    function MyAtlasSprite() {
        var _this = _super.call(this) || this;
        _this._assembler = new MyAtlasAssembler();
        _this._assembler.init(_this);
        return _this;
    }
    MyAtlasSprite.prototype.setAtlasData = function (data) {
        this.trim = false;
        this.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.node.width = data.uv.width;
        this.node.height = data.uv.height;
        this.spriteFrame = data.spriteFrame;
        this._assembler.setAtlasUV(data.uv);
    };
    MyAtlasSprite = __decorate([
        ccclass
    ], MyAtlasSprite);
    return MyAtlasSprite;
}(cc.Sprite));
exports.default = MyAtlasSprite;
var MyAtlasAssembler = /** @class */ (function (_super) {
    __extends(MyAtlasAssembler, _super);
    function MyAtlasAssembler() {
        var _this = _super.call(this) || this;
        _this.floatsPerVert = 5;
        _this.verticesCount = 4;
        _this.indicesCount = 6;
        _this.uvOffset = 2;
        _this.colorOffset = 4;
        _this._renderData = new cc.RenderData();
        _this._renderData.init(_this);
        _this.initData();
        _this.initLocal();
        return _this;
    }
    Object.defineProperty(MyAtlasAssembler.prototype, "verticesFloats", {
        get: function () {
            return this.verticesCount * this.floatsPerVert;
        },
        enumerable: false,
        configurable: true
    });
    MyAtlasAssembler.prototype.initData = function () {
        var data = this._renderData;
        data.createQuadData(0, this.verticesFloats, this.indicesCount);
    };
    MyAtlasAssembler.prototype.initLocal = function () {
        this._local = [0, 0, 0, 0];
    };
    MyAtlasAssembler.prototype.updateColor = function (comp, color) {
        var uintVerts = this._renderData.uintVDatas[0];
        if (!uintVerts)
            return;
        color = color != null ? color : comp.node.color._val;
        var floatsPerVert = this.floatsPerVert;
        var colorOffset = this.colorOffset;
        for (var i = colorOffset, l = uintVerts.length; i < l; i += floatsPerVert) {
            uintVerts[i] = color;
        }
    };
    MyAtlasAssembler.prototype.getBuffer = function (renderer) {
        return cc.renderer._handle._meshBuffer;
    };
    MyAtlasAssembler.prototype.updateWorldVerts = function (comp) {
        var local = this._local;
        var verts = this._renderData.vDatas[0];
        var matrix = this._renderComp.node._worldMatrix;
        var matrixm = matrix.m, a = matrixm[0], b = matrixm[1], c = matrixm[4], d = matrixm[5], tx = matrixm[12], ty = matrixm[13];
        var vl = local[0], vr = local[2], vb = local[1], vt = local[3];
        var justTranslate = a === 1 && b === 0 && c === 0 && d === 1;
        if (justTranslate) {
            // left bottom
            verts[0] = vl + tx;
            verts[1] = vb + ty;
            // right bottom
            verts[5] = vr + tx;
            verts[6] = vb + ty;
            // left top
            verts[10] = vl + tx;
            verts[11] = vt + ty;
            // right top
            verts[15] = vr + tx;
            verts[16] = vt + ty;
        }
        else {
            var al = a * vl, ar = a * vr, bl = b * vl, br = b * vr, cb = c * vb, ct = c * vt, db = d * vb, dt = d * vt;
            // left bottom
            verts[0] = al + cb + tx;
            verts[1] = bl + db + ty;
            // right bottom
            verts[5] = ar + cb + tx;
            verts[6] = br + db + ty;
            // left top
            verts[10] = al + ct + tx;
            verts[11] = bl + dt + ty;
            // right top
            verts[15] = ar + ct + tx;
            verts[16] = br + dt + ty;
        }
    };
    MyAtlasAssembler.prototype.fillBuffers = function (comp, renderer) {
        if (renderer.worldMatDirty) {
            this.updateWorldVerts(comp);
        }
        var renderData = this._renderData;
        var vData = renderData.vDatas[0];
        var iData = renderData.iDatas[0];
        var buffer = this.getBuffer(renderer);
        var offsetInfo = buffer.request(this.verticesCount, this.indicesCount);
        // buffer data may be realloc, need get reference after request.
        // fill vertices
        var vertexOffset = offsetInfo.byteOffset >> 2, vbuf = buffer._vData;
        if (vData.length + vertexOffset > vbuf.length) {
            vbuf.set(vData.subarray(0, vbuf.length - vertexOffset), vertexOffset);
        }
        else {
            vbuf.set(vData, vertexOffset);
        }
        // fill indices
        var ibuf = buffer._iData, indiceOffset = offsetInfo.indiceOffset, vertexId = offsetInfo.vertexOffset;
        for (var i = 0, l = iData.length; i < l; i++) {
            ibuf[indiceOffset++] = vertexId + iData[i];
        }
    };
    MyAtlasAssembler.prototype.updateVerts = function () {
        var node = this._renderComp.node, cw = node.width, ch = node.height, appx = node.anchorX * cw, appy = node.anchorY * ch, l, b, r, t;
        l = -appx;
        b = -appy;
        r = cw - appx;
        t = ch - appy;
        var local = this._local;
        local[0] = l;
        local[1] = b;
        local[2] = r;
        local[3] = t;
        this.updateWorldVerts(this._renderComp);
    };
    MyAtlasAssembler.prototype.setAtlasUV = function (uv) {
        this.updateVerts();
        var vData = this._renderData.vDatas[0];
        var floatsPerVert = this.floatsPerVert;
        var offset = this.uvOffset;
        vData[offset] = uv.left;
        vData[offset + 1] = uv.bottom;
        offset += floatsPerVert;
        vData[offset] = uv.right;
        vData[offset + 1] = uv.bottom;
        offset += floatsPerVert;
        vData[offset] = uv.left;
        vData[offset + 1] = uv.top;
        offset += floatsPerVert;
        vData[offset] = uv.right;
        vData[offset + 1] = uv.top;
    };
    return MyAtlasAssembler;
}(cc.Assembler));
exports.MyAtlasAssembler = MyAtlasAssembler;
cc.Assembler.register(MyAtlasSprite, MyAtlasAssembler);

cc._RF.pop();