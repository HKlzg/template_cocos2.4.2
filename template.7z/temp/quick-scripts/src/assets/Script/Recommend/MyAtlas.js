"use strict";
cc._RF.push(module, '69d9bvmEndMR4oOopJj24pV', 'MyAtlas');
// Script/Common/MyAtlas.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var space = 2;
var _textureSize = 2048;
var MyAtlas = /** @class */ (function () {
    function MyAtlas(width, height) {
        if (undefined === height) {
            height = _textureSize;
        }
        if (undefined === width) {
            width = _textureSize;
        }
        var texture = new cc.RenderTexture();
        texture.initWithSize(width, height);
        texture.update();
        this._texture = texture;
        this._spriteFrame = new cc.SpriteFrame(this._texture);
        this._x = space;
        this._y = space;
        this._nexty = space;
        this._width = width;
        this._height = height;
        this.uvMap = {};
    }
    MyAtlas.prototype.insertSpriteFrame = function (spriteFrame, name) {
        if (undefined === name) {
            name = spriteFrame._uuid;
        }
        if (!!this.uvMap[name]) {
            return this.uvMap[name];
        }
        var texture = spriteFrame._texture;
        var width = texture.width, height = texture.height;
        if ((this._x + width + space) > this._width) {
            this._x = space;
            this._y = this._nexty;
        }
        if ((this._y + height + space) > this._nexty) {
            this._nexty = this._y + height + space;
        }
        if (this._nexty > this._height) {
            console.warn("自定义图集已满");
            return null;
        }
        this._texture.drawTextureAt(texture, this._x, this._y);
        this._texture.update();
        this.uvMap[name] = {
            left: (this._x) / this._width,
            right: (this._x + width) / this._width,
            top: this._y / this._height,
            bottom: (this._y + height) / this._height,
            width: width,
            height: height,
        };
        this._x += width + space;
        return this.uvMap[name];
    };
    MyAtlas.prototype.getUV = function (name) {
        if (!!this.uvMap[name]) {
            return this.uvMap[name];
        }
        else {
            console.warn("自定义图集中不存在指定图集：", name);
            return null;
        }
    };
    MyAtlas.prototype.getTexture = function () {
        return this._texture;
    };
    MyAtlas.prototype.getSpriteFrame = function () {
        return this._spriteFrame;
    };
    return MyAtlas;
}());
exports.default = MyAtlas;

cc._RF.pop();