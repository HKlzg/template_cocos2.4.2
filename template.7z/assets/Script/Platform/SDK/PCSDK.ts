import SDK from "./SDK";

export default class PCSDK extends SDK {

}